/**
 * DocuSign eSignature API Integration
 *
 * Sends confidentiality/NDA agreements to new members for electronic signature
 *
 * Required Environment Variables:
 * - DOCUSIGN_INTEGRATION_KEY: DocuSign app integration key
 * - DOCUSIGN_USER_ID: DocuSign user/account ID
 * - DOCUSIGN_ACCOUNT_ID: DocuSign account ID
 * - DOCUSIGN_PRIVATE_KEY: RSA private key for JWT authentication (base64 encoded)
 * - DOCUSIGN_TEMPLATE_ID: Template ID for the confidentiality agreement
 *
 * Optional:
 * - DOCUSIGN_BASE_URL: API base URL (defaults to https://demo.docusign.net for sandbox)
 */

const axios = require('axios');

// Check if DocuSign is configured
function isConfigured() {
  const required = [
    'DOCUSIGN_INTEGRATION_KEY',
    'DOCUSIGN_USER_ID',
    'DOCUSIGN_ACCOUNT_ID',
    'DOCUSIGN_TEMPLATE_ID'
  ];

  const missing = required.filter(key => !process.env[key]);

  if (missing.length > 0) {
    console.log('[DocuSign] Not configured. Missing:', missing.join(', '));
    return false;
  }

  return true;
}

// Get JWT access token for DocuSign API
async function getAccessToken() {
  if (!isConfigured()) {
    throw new Error('DocuSign not configured');
  }

  // TODO: Implement JWT authentication when credentials are provided
  // For now, return mock token to indicate it would work
  console.log('[DocuSign] JWT authentication not yet implemented');
  return null;
}

/**
 * Send confidentiality agreement to member via DocuSign
 *
 * @param {string} memberEmail - Member's email address
 * @param {string} memberName - Member's full name
 * @param {number} memberId - Member ID from database
 * @returns {Promise<{envelopeId: string, status: string}>}
 */
async function sendConfidentialityAgreement(memberEmail, memberName, memberId) {
  if (!isConfigured()) {
    console.log(`[DocuSign] Skipping agreement send for ${memberEmail} - credentials not configured yet`);
    return {
      success: false,
      message: 'DocuSign credentials not configured',
      envelopeId: null,
      status: 'pending_config'
    };
  }

  try {
    const accessToken = await getAccessToken();

    if (!accessToken) {
      console.log('[DocuSign] No access token available');
      return {
        success: false,
        message: 'DocuSign authentication not implemented',
        envelopeId: null,
        status: 'pending_config'
      };
    }

    const baseUrl = process.env.DOCUSIGN_BASE_URL || 'https://demo.docusign.net/restapi';
    const accountId = process.env.DOCUSIGN_ACCOUNT_ID;
    const templateId = process.env.DOCUSIGN_TEMPLATE_ID;

    // Create envelope from template
    const envelopeDefinition = {
      templateId: templateId,
      templateRoles: [
        {
          email: memberEmail,
          name: memberName,
          roleName: 'Member',
          clientUserId: memberId.toString() // For embedded signing (optional)
        }
      ],
      status: 'sent' // Immediately send the envelope
    };

    const response = await axios.post(
      `${baseUrl}/v2.1/accounts/${accountId}/envelopes`,
      envelopeDefinition,
      {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        }
      }
    );

    console.log(`[DocuSign] Agreement sent to ${memberEmail}. Envelope ID: ${response.data.envelopeId}`);

    return {
      success: true,
      envelopeId: response.data.envelopeId,
      status: response.data.status || 'sent'
    };

  } catch (error) {
    console.error('[DocuSign] Error sending agreement:', error.message);
    if (error.response) {
      console.error('[DocuSign] API Error:', error.response.data);
    }

    return {
      success: false,
      message: error.message,
      envelopeId: null,
      status: 'error'
    };
  }
}

/**
 * Check the status of a DocuSign envelope
 *
 * @param {string} envelopeId - DocuSign envelope ID
 * @returns {Promise<{status: string, completedAt?: Date}>}
 */
async function checkEnvelopeStatus(envelopeId) {
  if (!isConfigured()) {
    return { status: 'pending_config' };
  }

  try {
    const accessToken = await getAccessToken();
    if (!accessToken) {
      return { status: 'pending_config' };
    }

    const baseUrl = process.env.DOCUSIGN_BASE_URL || 'https://demo.docusign.net/restapi';
    const accountId = process.env.DOCUSIGN_ACCOUNT_ID;

    const response = await axios.get(
      `${baseUrl}/v2.1/accounts/${accountId}/envelopes/${envelopeId}`,
      {
        headers: {
          'Authorization': `Bearer ${accessToken}`
        }
      }
    );

    const envelope = response.data;

    return {
      status: envelope.status, // 'sent', 'delivered', 'completed', 'declined', etc.
      completedAt: envelope.completedDateTime ? new Date(envelope.completedDateTime) : null
    };

  } catch (error) {
    console.error('[DocuSign] Error checking envelope status:', error.message);
    return { status: 'error' };
  }
}

/**
 * DocuSign webhook handler (for envelope status updates)
 *
 * When an envelope is signed/declined/voided, DocuSign can send a webhook
 * This should be registered in DocuSign Connect settings
 *
 * @param {object} webhookPayload - DocuSign Connect XML/JSON payload
 * @returns {Promise<{envelopeId: string, status: string}>}
 */
async function handleWebhook(webhookPayload) {
  // TODO: Implement webhook parsing when DocuSign is configured
  // Will extract envelope ID and status, then update database

  console.log('[DocuSign] Webhook received but not yet implemented');

  return {
    envelopeId: null,
    status: 'unknown'
  };
}

module.exports = {
  isConfigured,
  sendConfidentialityAgreement,
  checkEnvelopeStatus,
  handleWebhook
};
