/**
 * DocuSeal E-Signature Integration
 *
 * Manages electronic signature of FlipLane's Terms of Service document.
 * Uses DocuSign eSignature API for envelope creation and status tracking.
 *
 * Flow:
 * 1. A new Terms version is created/updated via admin API
 * 2. When a member pays (Co-op Partner) or affiliate is approved, sendTermsForSignature() is called
 * 3. Creates a DocuSign envelope from the Terms template and sends to signee
 * 4. DocuSign webhook updates e_signatures record on completion
 * 5. Admin can view signature status and manage Terms content
 *
 * Required Environment Variables:
 * - DOCUSEAL_API_KEY:     DocuSeal API key (https://docuseal.com/api)
 * - DOCUSEAL_TEMPLATE_ID: DocuSeal template ID for Terms document
 * - DOCUSEAL_WEBHOOK_SECRET: Secret for verifying incoming webhooks
 *
 * Optional:
 * - DOCUSEAL_BASE_URL: API base URL (defaults to https://docuseal.com/api/v1)
 */

const axios = require('axios');

const BASE_URL = process.env.DOCUSEAL_BASE_URL || 'https://docuseal.com/api/v1';

/**
 * Check if DocuSeal is configured with required credentials
 */
function isConfigured() {
  const required = ['DOCUSEAL_API_KEY'];
  const missing = required.filter(key => !process.env[key]);
  if (missing.length > 0) {
    console.log('[DocuSeal] Not configured. Missing:', missing.join(', '));
    return false;
  }
  return true;
}

/**
 * Get the current active Terms version from DB
 * Returns { version, content, created_at }
 *
 * @param {import('pg').Pool} pool
 */
async function getCurrentTermsVersion(pool) {
  const result = await pool.query(
    `SELECT version, content, created_at, created_by
     FROM terms_versions
     WHERE is_active = TRUE
     ORDER BY version DESC
     LIMIT 1`
  );
  return result.rows[0] || null;
}

/**
 * Get a specific Terms version
 * @param {import('pg').Pool} pool
 * @param {number} version
 */
async function getTermsVersion(pool, version) {
  const result = await pool.query(
    `SELECT version, content, created_at, created_by, is_active
     FROM terms_versions WHERE version = $1`,
    [version]
  );
  return result.rows[0] || null;
}

/**
 * Create a new Terms version (used by admin)
 * @param {import('pg').Pool} pool
 * @param {string} content - HTML content of the Terms
 * @param {string} createdBy - admin email or identifier
 * @returns {Promise<{version: number}>}
 */
async function createTermsVersion(pool, content, createdBy) {
  // Deactivate all current active versions
  await pool.query(`UPDATE terms_versions SET is_active = FALSE WHERE is_active = TRUE`);

  // Get next version number
  const lastVersion = await pool.query(
    `SELECT COALESCE(MAX(version), 0) as max_version FROM terms_versions`
  );
  const nextVersion = (parseInt(lastVersion.rows[0].max_version) || 0) + 1;

  // Insert new version
  const result = await pool.query(
    `INSERT INTO terms_versions (version, content, is_active, created_by)
     VALUES ($1, $2, TRUE, $3)
     RETURNING version`,
    [nextVersion, content, createdBy]
  );

  return { version: result.rows[0].version };
}

/**
 * Get Terms version history
 * @param {import('pg').Pool} pool
 */
async function getTermsHistory(pool) {
  const result = await pool.query(
    `SELECT version, created_at, created_by, is_active
     FROM terms_versions
     ORDER BY version DESC
     LIMIT 50`
  );
  return result.rows;
}

/**
 * Record that a document was sent for signature
 * @param {import('pg').Pool} pool
 * @param {object} params
 * @param {string} params.documentType - 'terms' (FlipLane Terms of Service)
 */
async function recordSignatureRequest(pool, { signeeType, signeeId, signeeEmail, signeeName, termsVersion, envelopeId, docusealDocumentId, documentType = 'terms' }) {
  const result = await pool.query(
    `INSERT INTO e_signatures (signee_type, signee_id, signee_email, signee_name, terms_version, docuseal_envelope_id, docuseal_document_id, document_type, status, sent_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'sent', NOW())
     RETURNING id`,
    [signeeType, signeeId, signeeEmail, signeeName, termsVersion, envelopeId, docusealDocumentId, documentType]
  );
  return result.rows[0].id;
}

/**
 * Update e_signature record when DocuSeal confirms delivery
 * @param {import('pg').Pool} pool
 * @param {string} envelopeId
 * @param {string} status - 'sent' | 'viewed' | 'completed' | 'declined'
 * @param {object} metadata
 */
async function updateSignatureStatus(pool, envelopeId, status, metadata = {}) {
  await pool.query(
    `UPDATE e_signatures
     SET status = $2,
         ${status === 'completed' ? 'signed_at = NOW(),' : ''}
         metadata = COALESCE(metadata, '{}'::jsonb) || $3
     WHERE docuseal_envelope_id = $1`,
    [envelopeId, status, JSON.stringify(metadata)]
  );
}

/**
 * Get the latest e_signature record for a signee
 * @param {import('pg').Pool} pool
 * @param {string} signeeType - 'member' | 'affiliate'
 * @param {number} signeeId
 */
async function getSignatureForSignee(pool, signeeType, signeeId) {
  const result = await pool.query(
    `SELECT id, signee_type, signee_id, signee_email, signee_name, terms_version,
            docuseal_envelope_id, docuseal_document_id, document_type, status,
            sent_at, signed_at, metadata
     FROM e_signatures
     WHERE signee_type = $1 AND signee_id = $2
     ORDER BY sent_at DESC
     LIMIT 1`,
    [signeeType, signeeId]
  );
  return result.rows[0] || null;
}

/**
 * Check if a signee has a completed Terms signature
 * @param {import('pg').Pool} pool
 * @param {string} signeeType
 * @param {number} signeeId
 */
async function hasCompletedSignature(pool, signeeType, signeeId) {
  const result = await pool.query(
    `SELECT id FROM e_signatures
     WHERE signee_type = $1 AND signee_id = $2 AND status = 'completed'
     LIMIT 1`,
    [signeeType, signeeId]
  );
  return result.rows.length > 0;
}

/**
 * Create a DocuSeal envelope and send Terms for signature
 *
 * @param {import('pg').Pool} pool
 * @param {string} signeeEmail
 * @param {string} signeeName
 * @param {string} signeeType - 'member' | 'affiliate'
 * @param {number} signeeId
 * @returns {Promise<{success: boolean, envelopeId?: string, documentId?: string, message?: string}>}
 */
async function sendTermsForSignature(pool, signeeEmail, signeeName, signeeType, signeeId) {
  // Check if DocuSeal API key is configured
  const apiKey = process.env.DOCUSEAL_API_KEY;
  if (!apiKey) {
    console.log(`[DocuSeal] Not configured — signing request queued for ${signeeEmail} (no API key)`);
    return {
      success: false,
      message: 'DocuSeal not configured — API key missing',
      status: 'pending_config'
    };
  }

  try {
    // Get current active Terms version
    const terms = await getCurrentTermsVersion(pool);
    if (!terms) {
      // No Terms version exists — use a default placeholder
      console.log(`[DocuSeal] No active Terms version found — using default content`);
    }

    const termsVersion = terms ? terms.version : null;
    const termsContent = terms ? terms.content : getDefaultTermsContent();

    const templateId = process.env.DOCUSEAL_TEMPLATE_ID;
    const docusealBaseUrl = process.env.DOCUSEAL_BASE_URL || BASE_URL;

    let envelopeId;
    let documentId;

    if (templateId) {
      // Option A: Use DocuSeal template (template already created in DocuSeal dashboard)
      // Create document from template
      const docResponse = await axios.post(
        `${docusealBaseUrl}/documents`,
        {
          template_id: templateId,
          signers: [{
            email: signeeEmail,
            name: signeeName,
            redirect_url: `${process.env.APP_URL || 'https://flipl.polsia.app'}/terms-signed`
          }]
        },
        {
          headers: {
            'X-API-Key': apiKey,
            'Content-Type': 'application/json'
          }
        }
      );

      envelopeId = docResponse.data.id || docResponse.data.envelope_id;
      documentId = docResponse.data.document_id;
    } else {
      // Option B: Create document from raw HTML content
      // Send raw HTML as the document — DocuSeal accepts HTML content
      const docResponse = await axios.post(
        `${docusealBaseUrl}/documents`,
        {
          title: `FlipLane Terms of Service — ${signeeName}`,
          content: termsContent,
          signers: [{
            email: signeeEmail,
            name: signeeName,
            redirect_url: `${process.env.APP_URL || 'https://flipl.polsia.app'}/terms-signed`
          }],
          metadata: {
            signee_type: signeeType,
            signee_id: String(signeeId),
            terms_version: String(termsVersion || 'default')
          }
        },
        {
          headers: {
            'X-API-Key': apiKey,
            'Content-Type': 'application/json'
          }
        }
      );

      envelopeId = docResponse.data.id || docResponse.data.envelope_id;
      documentId = docResponse.data.document_id;

      // Send the document to signers
      if (envelopeId) {
        await axios.post(
          `${docusealBaseUrl}/documents/${envelopeId}/send`,
          {},
          {
            headers: {
              'X-API-Key': apiKey,
              'Content-Type': 'application/json'
            }
          }
        );
      }
    }

    // Record in DB — document_type is always 'terms' (FlipLane Terms of Service)
    await recordSignatureRequest(pool, {
      signeeType,
      signeeId,
      signeeEmail,
      signeeName,
      termsVersion: termsVersion || 1,
      envelopeId,
      docusealDocumentId: documentId,
      documentType: 'terms'
    });

    console.log(`[DocuSeal] Terms sent to ${signeeEmail} (envelope: ${envelopeId}, version: ${termsVersion})`);

    return {
      success: true,
      envelopeId,
      documentId,
      status: 'sent'
    };

  } catch (error) {
    console.error('[DocuSeal] Error sending Terms:', error.message);
    if (error.response) {
      console.error('[DocuSeal] API Error:', JSON.stringify(error.response.data));
    }
    return {
      success: false,
      message: error.message,
      status: 'error'
    };
  }
}

/**
 * Check the status of a DocuSeal envelope
 * @param {import('pg').Pool} pool
 * @param {string} envelopeId
 */
async function checkEnvelopeStatus(pool, envelopeId) {
  const apiKey = process.env.DOCUSEAL_API_KEY;
  if (!apiKey) {
    return { status: 'pending_config' };
  }

  try {
    const docusealBaseUrl = process.env.DOCUSEAL_BASE_URL || BASE_URL;
    const response = await axios.get(
      `${docusealBaseUrl}/documents/${envelopeId}`,
      {
        headers: { 'X-API-Key': apiKey }
      }
    );

    const doc = response.data;
    const signerStatus = doc.signers?.[0]?.status || 'unknown';

    // Map DocuSeal status to our status
    const statusMap = {
      'pending': 'sent',
      'sent': 'sent',
      'viewed': 'viewed',
      'completed': 'completed',
      'declined': 'declined',
      'expired': 'expired'
    };

    const mappedStatus = statusMap[signerStatus] || signerStatus;

    // Update DB if status changed
    if (mappedStatus !== 'sent') {
      await updateSignatureStatus(pool, envelopeId, mappedStatus, {
        checked_at: new Date().toISOString()
      });
    }

    return {
      status: mappedStatus,
      completedAt: mappedStatus === 'completed' ? new Date() : null
    };

  } catch (error) {
    console.error('[DocuSeal] Error checking envelope status:', error.message);
    return { status: 'error' };
  }
}

/**
 * Handle DocuSeal webhook callback
 * DocuSeal calls this endpoint when a document is signed or status changes
 *
 * @param {object} payload - DocuSeal webhook payload
 * @param {import('pg').Pool} pool
 * @returns {Promise<{envelopeId: string, status: string}>}
 */
async function handleWebhook(payload, pool) {
  // Verify webhook secret if configured
  if (process.env.DOCUSEAL_WEBHOOK_SECRET) {
    // In real implementation, verify HMAC signature here
  }

  const envelopeId = payload.id || payload.document_id || payload.envelope_id;
  const status = payload.status || payload.event;
  const signerEmail = payload.signer?.email || payload.email;

  if (!envelopeId) {
    console.log('[DocuSeal] Webhook received with no envelope ID');
    return { envelopeId: null, status: 'unknown' };
  }

  // Map DocuSeal event to our status
  const statusMap = {
    'document.completed': 'completed',
    'document.sent': 'sent',
    'document.viewed': 'viewed',
    'document.declined': 'declined',
    'document.expired': 'expired',
    'completed': 'completed',
    'sent': 'sent',
    'viewed': 'viewed',
    'declined': 'declined',
    'expired': 'expired'
  };

  const mappedStatus = statusMap[status] || 'sent';

  // Update the e_signature record
  await updateSignatureStatus(pool, envelopeId, mappedStatus, {
    webhook_received_at: new Date().toISOString(),
    signer_email: signerEmail,
    raw_payload: JSON.stringify(payload)
  });

  // Also update the corresponding member or affiliate record
  // First find which signee this belongs to
  const sigRecord = await pool.query(
    `SELECT signee_type, signee_id FROM e_signatures WHERE docuseal_envelope_id = $1`,
    [envelopeId]
  );

  if (sigRecord.rows.length > 0) {
    const { signee_type, signee_id } = sigRecord.rows[0];
    if (signee_type === 'member') {
      await pool.query(
        `UPDATE members SET terms_signature_status = $1, terms_signed_at = CASE WHEN $1 = 'completed' THEN NOW() ELSE terms_signed_at END WHERE id = $2`,
        [mappedStatus, signee_id]
      );
    } else if (signee_type === 'affiliate') {
      await pool.query(
        `UPDATE affiliate_signups SET terms_signature_status = $1, terms_signed_at = CASE WHEN $1 = 'completed' THEN NOW() ELSE terms_signed_at END WHERE id = $2`,
        [mappedStatus, signee_id]
      );
    }
  }

  console.log(`[DocuSeal Webhook] Envelope ${envelopeId} → ${mappedStatus}`);

  return { envelopeId, status: mappedStatus };
}

/**
 * Get default Terms content for use when no version exists in DB
 * This is the FlipLane Terms of Service document
 */
function getDefaultTermsContent() {
  return `
    <h1>FlipLane Terms of Service &amp; Membership Agreement</h1>
    <p><strong>Last updated: March 1, 2026</strong></p>

    <h2>1. Membership Terms &amp; Conditions</h2>
    <p>By applying for and/or purchasing a FlipLane co-op membership, you ("Member," "you") agree to the following terms and conditions governing your participation in the FlipLane dealer co-op operated by Byrd Dawgs Automotive Group ("FlipLane," "we," "us").</p>

    <h3>1.1 Eligibility</h3>
    <p>Membership is open to individuals who are at least 18 years of age, possess a valid government-issued photo ID, and agree to the terms set forth in this agreement.</p>

    <h3>1.2 Membership Benefits</h3>
    <p>Upon activation, members receive:</p>
    <ul>
      <li>Access to dealer auction platforms (ADESA, OVE, Manheim, and partners) through shared credentials</li>
      <li>Licensed dealer coverage under Byrd Dawgs Automotive Group for vehicle transactions in all 50 states</li>
      <li>Access to ByrddawgsOS, the member back-office dashboard</li>
      <li>Deal processing and compliance support for $250 per transaction</li>
      <li>Customer inquiry management tools</li>
      <li>Member support and community access</li>
    </ul>

    <h3>1.3 Dealer License Coverage</h3>
    <p>Members operate under Byrd Dawgs Automotive Group's active dealer license. This coverage permits members to source, purchase, and sell vehicles in all 50 states without obtaining their own individual dealer license.</p>

    <h3>1.4 Account Security</h3>
    <p>Members are responsible for maintaining the security of their account credentials and shared auction access. Sharing login information with non-members is strictly prohibited.</p>

    <h2>2. Fees &amp; Payment</h2>
    <h3>2.1 Membership Fee</h3>
    <p>The one-time membership fee is <strong>$250 USD</strong>, payable at the time of application. This fee is non-recurring and grants lifetime access to the co-op membership benefits.</p>

    <h3>2.2 Per-Deal Processing Fee</h3>
    <p>A flat processing fee of <strong>$250 USD per transaction</strong> is charged for each vehicle deal processed through FlipLane's infrastructure.</p>

    <h3>2.3 Profit Structure</h3>
    <ul>
      <li><strong>Self-handled deals (100% profit to member):</strong> When the member independently sources the buyer, vehicle, and financing, all profit belongs to the member. Only the $250 processing fee applies.</li>
      <li><strong>FlipLane-financed deals (50/50 split on finance profit):</strong> When FlipLane arranges financing, the finance profit is split 50/50 between FlipLane and the member.</li>
    </ul>

    <h3>2.4 Refund Policy</h3>
    <p>The $250 membership fee is non-refundable once membership has been activated. Processing fees are non-refundable once deal documentation has been initiated.</p>

    <h2>3. Member Conduct &amp; Compliance</h2>
    <h3>3.1 Legal Compliance</h3>
    <p>Members agree to conduct all vehicle transactions in compliance with applicable federal, state, and local laws, including title transfer regulations, consumer protection laws, sales tax obligations, and odometer disclosure requirements.</p>

    <h3>3.2 Prohibited Activities</h3>
    <p>Members shall not:</p>
    <ul>
      <li>Engage in title washing, odometer fraud, or any form of vehicle fraud</li>
      <li>Misrepresent vehicle conditions to buyers</li>
      <li>Use FlipLane's dealer license for illegal activities</li>
      <li>Share auction credentials with non-members</li>
      <li>Represent themselves as independent licensed dealers</li>
      <li>Engage in curbstoning outside the FlipLane platform</li>
      <li>Use the platform for money laundering or other financial crimes</li>
    </ul>

    <h2>4. Confidentiality Agreement</h2>
    <h3>4.1 Confidential Information Defined</h3>
    <p>"Confidential Information" includes dealer auction credentials, internal pricing and margin data, ByrddawgsOS platform features and workflows, lender relationships, customer databases, and business strategies.</p>

    <h3>4.2 Obligations</h3>
    <p>The Member agrees to hold all Confidential Information in strict confidence, use it solely for conducting business within the FlipLane platform, and take reasonable measures to protect it. Confidentiality obligations remain in effect for two (2) years after termination.</p>

    <h3>4.3 Exceptions</h3>
    <p>Confidentiality obligations do not apply to information that was publicly available, becomes public through no fault of the Member, or was independently developed.</p>

    <h3>4.4 Remedies</h3>
    <p>Breach of confidentiality constitutes grounds for immediate membership termination without refund.</p>

    <h2>5. Intellectual Property</h2>
    <p>All intellectual property rights in FlipLane, ByrddawgsOS, and associated tools remain the exclusive property of Byrd Dawgs Automotive Group. Membership grants a limited, non-exclusive license to use the platform solely for conducting business as a co-op partner.</p>

    <h2>6. Termination &amp; Suspension</h2>
    <p>FlipLane reserves the right to suspend or terminate membership immediately, without refund, for breach of this agreement, violation of confidentiality, prohibited activities, fraud, or conduct damaging to the FlipLane brand. Upon termination, access to ByrddawgsOS and all platform tools is immediately revoked.</p>

    <h2>7. Limitation of Liability</h2>
    <p>FlipLane provides the platform on an "as-is" basis. FlipLane is not liable for losses from individual transactions, market fluctuations, or buyer disputes. FlipLane's total liability shall not exceed fees paid in the 12 months preceding the claim.</p>

    <h2>8. Dispute Resolution</h2>
    <p>Disputes shall first be addressed through good-faith negotiation. If unresolved within 30 days, they shall be submitted to binding arbitration in Fulton County, Georgia, under AAA rules. The laws of the State of Georgia govern this agreement.</p>

    <h2>9. Contact</h2>
    <p>FlipLane / Byrd Dawgs Automotive Group — Atlanta, Georgia. Website: flipl.polsia.app</p>
  `;
}

/**
 * Get signing URL for a member/affiliate to sign Terms
 * @param {import('pg').Pool} pool
 * @param {string} signeeType
 * @param {number} signeeId
 */
async function getSigningUrl(pool, signeeType, signeeId) {
  const sig = await getSignatureForSignee(pool, signeeType, signeeId);
  if (!sig || !sig.docuseal_envelope_id) return null;

  const apiKey = process.env.DOCUSEAL_API_KEY;
  if (!apiKey) return null;

  try {
    const docusealBaseUrl = process.env.DOCUSEAL_BASE_URL || BASE_URL;
    const response = await axios.get(
      `${docusealBaseUrl}/documents/${sig.docuseal_envelope_id}/sign`,
      {
        headers: { 'X-API-Key': apiKey },
        params: { email: sig.signee_email }
      }
    );

    return response.data.url || response.data.signing_url || null;
  } catch (error) {
    console.error('[DocuSeal] Error getting signing URL:', error.message);
    return null;
  }
}

module.exports = {
  isConfigured,
  getCurrentTermsVersion,
  getTermsVersion,
  createTermsVersion,
  getTermsHistory,
  recordSignatureRequest,
  updateSignatureStatus,
  getSignatureForSignee,
  hasCompletedSignature,
  sendTermsForSignature,
  checkEnvelopeStatus,
  handleWebhook,
  getDefaultTermsContent,
  getSigningUrl
};