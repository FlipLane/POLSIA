/**
 * FlipLane Terms of Service — Offline E-Signature System
 *
 * Fully self-contained. Zero external API dependencies.
 * Replaces DocuSeal integration entirely.
 *
 * Flow:
 * 1. Admin creates/edits Terms content via admin panel
 * 2. When member pays (Co-op) or affiliate is approved → pending signature record created
 * 3. Member visits /terms?email=... → reads Terms → clicks "I Accept"
 * 4. POST /api/member/sign-terms → records signature with IP + user agent
 * 5. ByrddawgsOS access gate checks terms_signature_status = 'completed'
 * 6. If Terms version updates → existing members flagged for re-sign on next login
 */

// ====================================================================
// TERMS VERSION MANAGEMENT
// ====================================================================

/**
 * Get the current active Terms version from DB
 * @param {import('pg').Pool} pool
 * @returns {Promise<{id, version, title, content, created_at, created_by} | null>}
 */
async function getCurrentTermsVersion(pool) {
  const result = await pool.query(
    `SELECT id, version, title, content, created_at, created_by
     FROM terms_versions
     WHERE is_active = TRUE
     ORDER BY version DESC
     LIMIT 1`
  );
  return result.rows[0] || null;
}

/**
 * Get a specific Terms version by version number
 * @param {import('pg').Pool} pool
 * @param {number} version
 */
async function getTermsVersion(pool, version) {
  const result = await pool.query(
    `SELECT id, version, title, content, created_at, created_by, is_active
     FROM terms_versions WHERE version = $1`,
    [version]
  );
  return result.rows[0] || null;
}

/**
 * Create a new Terms version (admin action)
 * Deactivates all previous versions and activates the new one.
 *
 * @param {import('pg').Pool} pool
 * @param {string} content - HTML/markdown content of the Terms
 * @param {string} createdBy - admin identifier for audit trail
 * @param {string} [title] - optional display title
 * @returns {Promise<{version: number, id: number}>}
 */
async function createTermsVersion(pool, content, createdBy, title) {
  // Deactivate all current active versions
  await pool.query(`UPDATE terms_versions SET is_active = FALSE WHERE is_active = TRUE`);

  // Get next version number
  const lastVersion = await pool.query(
    `SELECT COALESCE(MAX(version), 0) AS max_version FROM terms_versions`
  );
  const nextVersion = (parseInt(lastVersion.rows[0].max_version) || 0) + 1;

  const displayTitle = title || `FlipLane Terms of Service v${nextVersion}`;

  // Insert new version
  const result = await pool.query(
    `INSERT INTO terms_versions (version, title, content, is_active, created_by)
     VALUES ($1, $2, $3, TRUE, $4)
     RETURNING id, version`,
    [nextVersion, displayTitle, content, createdBy]
  );

  return {
    version: result.rows[0].version,
    id: result.rows[0].id
  };
}

/**
 * Get Terms version history (last 50 versions)
 * @param {import('pg').Pool} pool
 */
async function getTermsHistory(pool) {
  const result = await pool.query(
    `SELECT id, version, title, created_at, created_by, is_active
     FROM terms_versions
     ORDER BY version DESC
     LIMIT 50`
  );
  return result.rows;
}

// ====================================================================
// SIGNATURE MANAGEMENT
// ====================================================================

/**
 * Create a pending signature record when a member is expected to sign.
 * Called on: Stripe payment completion (member) and affiliate approval.
 * No email is sent — member signs via /terms page.
 *
 * @param {import('pg').Pool} pool
 * @param {object} params
 * @param {string} params.signeeType - 'member' | 'affiliate'
 * @param {number} params.signeeId
 * @param {string} params.signeeEmail
 * @param {string} params.signeeName
 * @returns {Promise<{success: boolean}>}
 */
async function createPendingSignature(pool, { signeeType, signeeId, signeeEmail, signeeName }) {
  try {
    // Get current active Terms version
    const terms = await getCurrentTermsVersion(pool);
    if (!terms) {
      console.log(`[Terms] No active Terms version found — pending signature skipped for ${signeeEmail}`);
      return { success: false, message: 'No active Terms version' };
    }

    // Check if there's already a pending or completed signature for this version
    const existing = await pool.query(
      `SELECT id, status FROM e_signatures
       WHERE signee_type = $1 AND signee_id = $2 AND terms_version = $3
       LIMIT 1`,
      [signeeType, signeeId, terms.version]
    );

    if (existing.rows.length > 0) {
      console.log(`[Terms] Signature already exists for ${signeeEmail} v${terms.version}: ${existing.rows[0].status}`);
      return { success: true, existing: true };
    }

    // Insert pending signature record
    await pool.query(
      `INSERT INTO e_signatures
         (signee_type, signee_id, signee_email, signee_name, terms_version, document_type, status, sent_at)
       VALUES ($1, $2, $3, $4, $5, 'terms', 'pending', NOW())`,
      [signeeType, signeeId, signeeEmail, signeeName, terms.version]
    );

    console.log(`[Terms] Pending signature created for ${signeeEmail} v${terms.version}`);
    return { success: true };

  } catch (error) {
    console.error('[Terms] Error creating pending signature:', error.message);
    return { success: false, message: error.message };
  }
}

/**
 * Alias kept for backward compatibility with server.js call sites.
 * Replaces docuseal.sendTermsForSignature — no external API calls.
 */
async function sendTermsForSignature(pool, signeeEmail, signeeName, signeeType, signeeId) {
  return createPendingSignature(pool, { signeeType, signeeId, signeeEmail, signeeName });
}

/**
 * Record a member's actual signature when they click "I Accept".
 * Called by POST /api/member/sign-terms
 *
 * @param {import('pg').Pool} pool
 * @param {object} params
 * @param {string} params.signeeType - 'member' | 'affiliate'
 * @param {number} params.signeeId
 * @param {string} params.signeeEmail
 * @param {string} params.signeeName
 * @param {number} params.termsVersion - version they signed
 * @param {string} params.ipAddress
 * @param {string} params.userAgent
 * @returns {Promise<{success: boolean, alreadySigned?: boolean}>}
 */
async function recordMemberSignature(pool, { signeeType, signeeId, signeeEmail, signeeName, termsVersion, ipAddress, userAgent }) {
  try {
    // Verify this version exists and is active
    const terms = await pool.query(
      `SELECT id, version FROM terms_versions WHERE version = $1 AND is_active = TRUE LIMIT 1`,
      [termsVersion]
    );
    if (terms.rows.length === 0) {
      return { success: false, message: 'Terms version not found or not active' };
    }

    // Check for existing completed signature on this version
    const existing = await pool.query(
      `SELECT id, status FROM e_signatures
       WHERE signee_type = $1 AND signee_id = $2 AND terms_version = $3 AND status = 'completed'
       LIMIT 1`,
      [signeeType, signeeId, termsVersion]
    );
    if (existing.rows.length > 0) {
      return { success: true, alreadySigned: true };
    }

    // Upsert: update existing pending record or insert new completed record
    const upsertResult = await pool.query(
      `INSERT INTO e_signatures
         (signee_type, signee_id, signee_email, signee_name, terms_version,
          document_type, status, ip_address, user_agent, signed_at, sent_at)
       VALUES ($1, $2, $3, $4, $5, 'terms', 'completed', $6, $7, NOW(), NOW())
       ON CONFLICT DO NOTHING
       RETURNING id`,
      [signeeType, signeeId, signeeEmail, signeeName, termsVersion, ipAddress, userAgent]
    );

    if (upsertResult.rows.length === 0) {
      // Record already existed (from pending) — update it
      await pool.query(
        `UPDATE e_signatures
         SET status = 'completed', signed_at = NOW(), ip_address = $1, user_agent = $2
         WHERE signee_type = $3 AND signee_id = $4 AND terms_version = $5`,
        [ipAddress, userAgent, signeeType, signeeId, termsVersion]
      );
    }

    // Update the member or affiliate record
    if (signeeType === 'member') {
      await pool.query(
        `UPDATE members
         SET terms_signature_status = 'completed',
             terms_signed_at = NOW(),
             updated_at = NOW()
         WHERE id = $1`,
        [signeeId]
      );
    } else if (signeeType === 'affiliate') {
      await pool.query(
        `UPDATE affiliate_signups
         SET terms_signature_status = 'completed',
             terms_signed_at = NOW()
         WHERE id = $1`,
        [signeeId]
      );
    }

    console.log(`[Terms] ✅ Signature recorded for ${signeeEmail} (${signeeType} #${signeeId}) v${termsVersion} from ${ipAddress}`);
    return { success: true };

  } catch (error) {
    console.error('[Terms] Error recording signature:', error.message);
    return { success: false, message: error.message };
  }
}

/**
 * Get the latest signature record for a signee
 * @param {import('pg').Pool} pool
 * @param {string} signeeType
 * @param {number} signeeId
 */
async function getSignatureForSignee(pool, signeeType, signeeId) {
  const result = await pool.query(
    `SELECT id, signee_type, signee_id, signee_email, signee_name, terms_version,
            document_type, status, signed_at, sent_at, ip_address, user_agent
     FROM e_signatures
     WHERE signee_type = $1 AND signee_id = $2
     ORDER BY signed_at DESC NULLS LAST, sent_at DESC
     LIMIT 1`,
    [signeeType, signeeId]
  );
  return result.rows[0] || null;
}

/**
 * Check if a signee has completed signature on the CURRENT active Terms version.
 * Returns { signed: bool, needsResign: bool, currentVersion, signedVersion }
 *
 * @param {import('pg').Pool} pool
 * @param {string} signeeType
 * @param {number} signeeId
 */
async function checkSignatureStatus(pool, signeeType, signeeId) {
  const current = await getCurrentTermsVersion(pool);
  if (!current) {
    return { signed: false, needsResign: false, currentVersion: null, signedVersion: null };
  }

  // Check for completed signature on current version
  const result = await pool.query(
    `SELECT id, terms_version, signed_at FROM e_signatures
     WHERE signee_type = $1 AND signee_id = $2 AND status = 'completed'
     ORDER BY signed_at DESC NULLS LAST
     LIMIT 1`,
    [signeeType, signeeId]
  );

  if (result.rows.length === 0) {
    return { signed: false, needsResign: false, currentVersion: current.version, signedVersion: null };
  }

  const latestSig = result.rows[0];
  const signedCurrent = latestSig.terms_version === current.version;

  return {
    signed: signedCurrent,
    needsResign: !signedCurrent,
    currentVersion: current.version,
    signedVersion: latestSig.terms_version,
    signedAt: latestSig.signed_at
  };
}

/**
 * Check if a signee has any completed Terms signature (any version)
 */
async function hasCompletedSignature(pool, signeeType, signeeId) {
  const result = await pool.query(
    `SELECT id FROM e_signatures
     WHERE signee_type = $1 AND signee_id = $2 AND status = 'completed'
     LIMIT 1`,
    [signeeType, signeeId]
  );
  return result.rows.length > 0;
}

// ====================================================================
// DEFAULT TERMS CONTENT
// ====================================================================

/**
 * Default FlipLane Terms content for initial seed.
 * Stored as HTML for direct rendering.
 */
function getDefaultTermsContent() {
  return `
    <h1>FlipLane Terms of Service &amp; Membership Agreement</h1>
    <p><strong>Last updated: March 1, 2026</strong></p>

    <h2>1. Membership Terms &amp; Conditions</h2>
    <p>By applying for and/or purchasing a FlipLane co-op membership, you ("Member," "you") agree to the following terms and conditions governing your participation in the FlipLane dealer co-op operated by Byrd Dawgs Automotive Group ("FlipLane," "we," "us").</p>

    <h3>1.1 Eligibility</h3>
    <p>Membership is open to individuals who are at least 18 years of age, possess a valid government-issued photo ID, and agree to the terms set forth in this agreement. FlipLane reserves the right to deny or revoke membership at its sole discretion.</p>

    <h3>1.2 Membership Benefits</h3>
    <p>Upon activation, members receive:</p>
    <ul>
      <li>Access to dealer auction platforms (ADESA, OVE, Manheim, and partners) through shared credentials</li>
      <li>Licensed dealer coverage under Byrd Dawgs Automotive Group for vehicle transactions in all 50 states</li>
      <li>Access to ByrddawgsOS, the member back-office dashboard</li>
      <li>Deal processing and compliance support for $250 per transaction</li>
      <li>Customer inquiry management tools</li>
      <li>Member support and community access</li>
    </ul>

    <h3>1.3 Dealer License Coverage</h3>
    <p>Members operate under Byrd Dawgs Automotive Group's active dealer license. This coverage permits members to source, purchase, and sell vehicles in all 50 states without obtaining their own individual dealer license.</p>

    <h3>1.4 Account Security</h3>
    <p>Members are responsible for maintaining the security of their account credentials and shared auction access. Sharing login information with non-members is strictly prohibited.</p>

    <h2>2. Fees &amp; Payment</h2>
    <h3>2.1 Membership Fee</h3>
    <p>The one-time membership fee is <strong>$250 USD</strong>, payable at the time of application. This fee is non-recurring and grants lifetime access to the co-op membership benefits.</p>

    <h3>2.2 Per-Deal Processing Fee</h3>
    <p>A flat processing fee of <strong>$250 USD per transaction</strong> is charged for each vehicle deal processed through FlipLane's infrastructure.</p>

    <h3>2.3 Profit Structure</h3>
    <ul>
      <li><strong>Self-handled deals (100% profit to member):</strong> When the member independently sources the buyer, vehicle, and financing, all profit belongs to the member. Only the $250 processing fee applies.</li>
      <li><strong>FlipLane-financed deals (50/50 split on finance profit):</strong> When FlipLane arranges financing, the finance profit is split 50/50 between FlipLane and the member.</li>
    </ul>

    <h3>2.4 Refund Policy</h3>
    <p>The $250 membership fee is non-refundable once membership has been activated. Processing fees are non-refundable once deal documentation has been initiated.</p>

    <h3>2.5 Affiliate Commission Structure</h3>
    <p>Approved affiliates earn commissions on referrals they bring to FlipLane:</p>
    <ul>
      <li><strong>Membership referrals:</strong> 50% of the $250 membership fee ($125) for each referred member who pays and activates.</li>
      <li><strong>Deal referrals:</strong> 50% of the $250 per-deal processing fee ($125) for deals sourced by the affiliate.</li>
      <li><strong>Lead referrals:</strong> 50% commission on lead-driven deals as agreed upon in writing with FlipLane.</li>
    </ul>

    <h2>3. Member Conduct &amp; Compliance</h2>
    <h3>3.1 Legal Compliance</h3>
    <p>Members agree to conduct all vehicle transactions in compliance with applicable federal, state, and local laws, including title transfer regulations, consumer protection laws, sales tax obligations, and odometer disclosure requirements.</p>

    <h3>3.2 Prohibited Activities</h3>
    <p>Members shall not:</p>
    <ul>
      <li>Engage in title washing, odometer fraud, or any form of vehicle fraud</li>
      <li>Misrepresent vehicle conditions to buyers</li>
      <li>Use FlipLane's dealer license for illegal activities</li>
      <li>Share auction credentials with non-members</li>
      <li>Represent themselves as independent licensed dealers</li>
      <li>Engage in curbstoning outside the FlipLane platform</li>
      <li>Use the platform for money laundering or other financial crimes</li>
    </ul>

    <h2>4. Confidentiality Agreement</h2>
    <h3>4.1 Confidential Information Defined</h3>
    <p>"Confidential Information" includes dealer auction credentials, internal pricing and margin data, ByrddawgsOS platform features and workflows, lender relationships, customer databases, and business strategies.</p>

    <h3>4.2 Obligations</h3>
    <p>The Member agrees to hold all Confidential Information in strict confidence, use it solely for conducting business within the FlipLane platform, and take reasonable measures to protect it. Confidentiality obligations remain in effect for two (2) years after termination.</p>

    <h3>4.3 Remedies</h3>
    <p>Breach of confidentiality constitutes grounds for immediate membership termination without refund.</p>

    <h2>5. Intellectual Property</h2>
    <p>All intellectual property rights in FlipLane, ByrddawgsOS, and associated tools remain the exclusive property of Byrd Dawgs Automotive Group. Membership grants a limited, non-exclusive license to use the platform solely for conducting business as a co-op partner.</p>

    <h2>6. Termination &amp; Suspension</h2>
    <p>FlipLane reserves the right to suspend or terminate membership immediately, without refund, for breach of this agreement, violation of confidentiality, prohibited activities, fraud, or conduct damaging to the FlipLane brand. Upon termination, access to ByrddawgsOS and all platform tools is immediately revoked.</p>

    <h2>7. Limitation of Liability</h2>
    <p>FlipLane provides the platform on an "as-is" basis. FlipLane is not liable for losses from individual transactions, market fluctuations, or buyer disputes. FlipLane's total liability shall not exceed fees paid in the 12 months preceding the claim.</p>

    <h2>8. Dispute Resolution</h2>
    <p>Disputes shall first be addressed through good-faith negotiation. If unresolved within 30 days, they shall be submitted to binding arbitration in Fulton County, Georgia, under AAA rules. The laws of the State of Georgia govern this agreement.</p>

    <h2 id="earnings-disclaimer">9. Earnings Disclaimer</h2>
    <p>FlipLane provides a co-op platform and infrastructure for vehicle transactions. <strong>Membership in FlipLane does not guarantee any specific level of income or financial success.</strong></p>

    <h3>9.1 No Income Guarantee</h3>
    <p>Any income figures, deal amounts, or financial examples displayed on FlipLane's website, marketing materials, or shared by members represent individual experiences and are not guarantees of income. FlipLane makes no representations, warranties, or promises regarding income, earnings, or financial outcomes of any kind.</p>

    <h3>9.2 Typical Results</h3>
    <p>Individual results vary significantly. Most members earn between <strong>$1,000–$4,000 per completed transaction</strong>, depending on vehicle type, market conditions at the time of sale, vehicle acquisition cost, condition of the vehicle, and individual effort and skill. Some members earn more; some earn less; some members may not complete any transactions or earn any income.</p>

    <h3>9.3 Factors Affecting Earnings</h3>
    <p>Your actual earnings, if any, will depend on many factors, including but not limited to: your prior experience in vehicle sales, your access to capital for vehicle acquisition, local and national market conditions, the time and effort you invest, the vehicles you select, and economic conditions generally. None of these factors are controlled by FlipLane.</p>

    <h3>9.4 Forward-Looking Statements</h3>
    <p>Any statements about potential income, projected earnings, or financial outcomes are forward-looking and subject to uncertainty. Past performance of any member does not guarantee future results. References to members' success stories are exceptional results, not typical outcomes.</p>

    <h3>9.5 FTC Compliance</h3>
    <p>FlipLane's income-related disclosures are made in compliance with the Federal Trade Commission's Endorsement Guides (16 CFR Part 255) and Business Opportunity Rule (16 CFR Part 437). If you have questions about earnings potential, contact us before joining at <a href="mailto:win@fliplane.net">win@fliplane.net</a>.</p>

    <h2>10. Contact</h2>
    <p>FlipLane / Byrd Dawgs Automotive Group — Atlanta, Georgia. Website: <a href="https://fliplane.net">fliplane.net</a></p>
  `;
}

module.exports = {
  // Terms version management
  getCurrentTermsVersion,
  getTermsVersion,
  createTermsVersion,
  getTermsHistory,
  getDefaultTermsContent,

  // Signature management
  createPendingSignature,
  sendTermsForSignature,   // backward-compat alias
  recordMemberSignature,
  getSignatureForSignee,
  checkSignatureStatus,
  hasCompletedSignature,
};
