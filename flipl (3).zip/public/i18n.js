/**
 * ByrddawgsOS — i18n Framework
 * Supports EN (default) and ES (Spanish)
 * Usage: toggleLanguage() or setLanguage('es')
 */

(function() {
  'use strict';

  // ============================
  // Translation Dictionary — ES
  // ============================
  const ES = {

    // --- LOGIN SCREEN ---
    'login_sub': 'Hub de Operaciones de Miembros — Ingresa tu correo para acceder',
    'login_email_ph': 'tu@correo.com',
    'login_btn': 'Acceder al Hub',
    'login_not_member': '¿Aún no eres miembro? ',
    'login_join': 'Únete a FlipLane',
    'login_questions': '¿Preguntas? ',

    // --- TOPBAR ---
    'topbar_logout': 'Cerrar sesión',

    // --- WELCOME BANNER ---
    'welcome_sub': 'Tu hub de miembro. Todo lo que necesitas para comprar, vender y escalar.',

    // --- QUICK STATS ---
    'stat_deals_label': 'Tratos Enviados',
    'stat_deals_sub': 'Todos',
    'stat_cert_label': 'Certificación',
    'stat_cert_sub': 'Estado de entrenamiento',
    'stat_member_label': 'Miembro Desde',
    'stat_member_sub': 'Socio co-op',

    // --- ACTION BUTTONS ---
    'btn_submit_deal': '🚗 Enviar un Trato',
    'btn_find_inventory': '🔍 Buscar Inventario',
    'btn_contact_us': '✉️ Contáctanos',

    // --- SECTION LABEL ---
    'section_ops': 'Tus Operaciones',

    // --- CATEGORY CARDS ---
    'cat_training_title': 'Certificaciones',
    'cat_training_desc': 'Tu estado de certificación, libro de estudio y materiales de entrenamiento. Completa la cert para desbloquear acceso total de dealer.',
    'cat_credentials_title': 'Herramientas y Credenciales',
    'cat_credentials_desc': 'Plataformas de subasta, credenciales de dealer compartidas y enlaces directos a todo lo que necesitas para conseguir inventario.',
    'cat_deals_title': 'Centro de Tratos',
    'cat_deals_desc': 'Analizador ROI, Calculadora ACV, Calculadora de Ganancias, Valor de Mercado, envío de tratos, Fix & Flip, envío y servicios de título.',
    'cat_game_title': 'El Juego',
    'cat_game_desc': 'Guías de plataforma para IAAI, Copart, Edge Pipeline, CarsForSale y OVE. Domina la estrategia de subasta y maximiza tus listados.',
    'cat_support_title': 'Soporte y Conexión',
    'cat_support_desc': 'Obtén ayuda, contacta al equipo de FlipLane y conéctate en redes sociales.',
    'cat_messages_title': 'Mensajes',
    'cat_messages_desc': 'Mensajes directos del equipo de administración de FlipLane. Las respuestas van directo a tu equipo.',
    'cat_vehicle_intel_title': 'Inteligencia de Vehículos',
    'cat_vehicle_intel_desc': 'Retiros NHTSA, calificaciones de seguridad, quejas y economía de combustible EPA — instantáneo, sin clave API.',

    // --- BACK BUTTON ---
    'back_to_hub': '← Volver al Hub',

    // --- TOOLS & CREDENTIALS ---
    'cred_section_title': '🔑 Herramientas y Credenciales',
    'cred_auction_title': '🌐 Plataformas de Subasta y Mayoreo — Acceso Directo',
    'cred_auction_sub': 'Acceso rápido a todas las plataformas principales de subasta y mayoreo de dealers. Las credenciales de cada plataforma están en la bóveda de abajo.',
    'cred_dealer_title': '🚙 Herramientas y Plataformas de Dealer',
    'cred_vault_title': '🔐 Bóveda de Credenciales de Acceso',
    'cred_vault_sub': 'Credenciales de acceso compartidas para plataformas de subasta. Gestionadas por el administrador de Byrd Dawgs.',
    'loading_creds': 'Cargando credenciales...',

    // --- DEAL CENTER ---
    'deals_section_title': '🚗 Centro de Tratos',
    'vi_hub_title': 'Hub de Inteligencia de Vehículos',
    'vi_hub_sub': 'Retiros NHTSA, calificaciones de seguridad, quejas y economía de combustible EPA — instantáneo, sin clave API.',
    'btn_open_hub': 'Abrir Hub →',

    // --- PROFIT CALCULATOR ---
    'calc_title': '🧮 Calculadora de Ganancia en Tratos',
    'calc_sub': 'Desglose completo de costos + análisis ROI. Tarifa FlipLane de $250 siempre incluida.',
    'calc_history_label': 'Cálculos Recientes',
    'label_vehicle_desc': 'Descripción del Vehículo',
    'label_vehicle_desc_opt': '(opcional — ej., 2019 Honda Civic EX)',
    'ph_vehicle_desc': 'ej., 2020 Ford F-150 XLT 4x4',
    'label_buy_price': 'Precio de Compra ($)',
    'ph_buy_price': 'ej., 6500',
    'label_repairs': 'Reparaciones / Costos ($)',
    'ph_repairs': 'ej., 800',
    'label_transport': 'Transporte / Envío ($)',
    'ph_transport': 'ej., 450',
    'label_title_reg': 'Tarifas de Título y Registro ($)',
    'ph_title_reg': 'ej., 150',
    'label_holding': 'Costos de Tenencia ($)',
    'label_holding_sub': 'seguro, almacenamiento',
    'ph_holding': 'ej., 200',
    'label_fliplane_fee': 'Tarifa de Procesamiento FlipLane ($)',
    'label_fee_always': 'siempre incluida',
    'label_target_sell': 'Precio de Venta Meta ($)',
    'ph_target_sell': 'ej., 9500',
    'btn_clear': 'Limpiar',
    'stat_total_cost': 'Costo Total',
    'stat_total_cost_sub': 'Costo todo incluido',
    'stat_net_profit': 'Ganancia Neta',
    'stat_net_profit_sub': 'Después de todos los costos',
    'stat_profit_margin': 'Margen de Ganancia',
    'stat_margin_sub': 'Ganancia ÷ precio de venta',
    'stat_roi': 'ROI',
    'stat_roi_sub': 'Ganancia ÷ costo total',
    'btn_save_calc': '💾 Guardar Cálculo',
    'btn_check_acv': '🏷️ Verificar ACV →',
    'btn_market_value': '📊 Valor de Mercado →',
    'btn_estimate_loan': '💳 Estimar Préstamo →',
    'loading_history': 'Cargando…',

    // --- MARKET VALUE ---
    'mv_title': '📊 Comparador de Valor de Mercado',
    'mv_sub': 'Ingresa un VIN o Año/Marca/Modelo para ver el rango de mercado estimado, listados comparables y cómo se compara tu trato.',
    'label_vin_opt': 'VIN (opcional — autocompleta año/marca/modelo)',
    'ph_vin': 'VIN de 17 caracteres',
    'label_year': 'Año',
    'ph_year': 'ej., 2019',
    'label_make': 'Marca',
    'ph_make': 'ej., Honda',
    'label_model': 'Modelo',
    'ph_model': 'ej., Civic',
    'label_trim_opt': 'Versión (opcional)',
    'ph_trim': 'ej., EX-L',
    'label_mileage': 'Kilometraje',
    'ph_mileage': 'ej., 55000',
    'label_condition': 'Condición',
    'opt_select': '— Selecciona —',
    'opt_excellent': 'Excelente',
    'opt_good': 'Bueno',
    'opt_fair': 'Regular',
    'opt_poor': 'Deficiente',
    'label_target_price': 'Tu Precio Meta ($) (opcional — calcula Puntaje del Trato)',
    'ph_target_price': 'ej., 11500',
    'btn_get_mv': 'Obtener Valor de Mercado',
    'btn_clear_mv': 'Limpiar',
    'mv_market_low': 'Mínimo de Mercado',
    'mv_market_mid': 'Medio de Mercado',
    'mv_market_mid_sub': 'Valor justo estimado',
    'mv_market_high': 'Máximo de Mercado',
    'mv_similar_listings': 'Listados Similares',
    'mv_avg_loan_rate': 'Tasa Promedio de Préstamo Auto',
    'mv_rate_sub': 'Promedio nacional a 60 meses (FRED)',

    // --- DEAL SUBMIT FORM ---
    'deal_form_title': '📋 Enviar un Trato',
    'deal_form_sub': 'Comparte los detalles del vehículo y nosotros te daremos retroalimentación sobre si vale la pena el flip.',
    'label_deal_vin': 'VIN (Opcional)',
    'ph_deal_vin': 'VIN de 17 caracteres',
    'label_deal_year': 'Año del Vehículo *',
    'label_deal_make': 'Marca *',
    'label_deal_model': 'Modelo *',
    'label_deal_buy_price': 'Precio de Compra ($) *',
    'ph_deal_buy_price': 'ej., 5800',
    'label_deal_est_repairs': 'Reparaciones Estimadas ($)',
    'ph_deal_est_repairs': 'ej., 1200',
    'label_deal_est_sell': 'Precio de Venta Estimado ($)',
    'ph_deal_est_sell': 'ej., 9000',
    'label_deal_location': 'Ubicación del Vehículo',
    'ph_deal_location': 'ej., Atlanta, GA',
    'label_deal_notes': 'Notas',
    'ph_deal_notes': 'Condición, ubicación, por qué es un buen trato...',
    'btn_submit_deal_form': 'Enviar Trato',
    'pipe_submitted': 'Enviados',
    'pipe_reviewed': 'Revisados',
    'pipe_closed': 'Cerrados',
    'pipe_paid': 'Pagados',
    'loading_deals': 'Cargando tratos...',

    // --- FIX & FLIP REQUEST ---
    'ff_title': '🔧 Solicitud de Fix & Flip',
    'ff_sub': 'Solicita servicios de reparación y reventa para un vehículo. Revisaremos y responderemos en 24 horas.',
    'label_vehicle_year': 'Año del Vehículo *',
    'ph_vehicle_year': 'ej., 2019',
    'label_make_req': 'Marca *',
    'ph_make_req': 'ej., Honda',
    'label_model_req': 'Modelo *',
    'ph_model_req': 'ej., Civic',
    'label_vin_optional': 'VIN (Opcional)',
    'ph_vin_optional': 'VIN de 17 caracteres',
    'label_current_cond': 'Condición Actual *',
    'opt_select_cond': '— Selecciona condición —',
    'opt_runs_great': 'Funciona perfecto',
    'opt_minor_work': 'Necesita trabajo menor',
    'opt_major_repair': 'Necesita reparación mayor',
    'opt_non_running': 'No arranca',
    'label_repair_scope': 'Descripción del Alcance de Reparación *',
    'ph_repair_scope': 'Describe las reparaciones necesarias o lo que deseas que se haga...',
    'label_est_budget': 'Presupuesto Estimado *',
    'opt_select_range': '— Selecciona rango —',
    'label_timeline': 'Plazo *',
    'opt_select_timeline': '— Selecciona plazo —',
    'opt_asap': 'Lo antes posible',
    'opt_2_weeks': 'En 2 semanas',
    'opt_1_month': 'En 1 mes',
    'opt_flexible': 'Flexible',
    'label_your_name': 'Tu Nombre *',
    'ph_full_name': 'Nombre completo',
    'label_your_email': 'Tu Correo *',
    'ph_email': 'correo@ejemplo.com',
    'btn_submit_request': 'Enviar Solicitud',

    // --- SHIPPING ESTIMATOR ---
    'sc_title': '🗺️ Estimador de Costo de Envío',
    'sc_sub': 'Ingresa las ubicaciones de recogida/entrega y los detalles del vehículo para obtener un estimado instantáneo con mapa de ruta en tiempo real.',
    'label_pickup_loc': 'Ubicación de Recogida *',
    'ph_pickup': 'ej., Atlanta, GA o 30301',
    'label_delivery_loc': 'Ubicación de Entrega *',
    'ph_delivery': 'ej., Miami, FL o 33101',
    'label_vehicle_type': 'Tipo de Vehículo',
    'btn_sedan': '🚗 Sedán',
    'btn_suv': '🚙 SUV / Camioneta',
    'btn_motorcycle': '🏍️ Motocicleta',
    'btn_oversized': '🚛 Sobredimensionado',
    'label_transport_type': 'Tipo de Transporte',
    'btn_open': '🌤 Abierto',
    'btn_enclosed': '📦 Cerrado',
    'label_operable': '¿Operable?',
    'btn_yes_op': '✅ Sí',
    'btn_no_op': '🔧 No (no arranca)',
    'btn_calc_estimate': '📍 Calcular Estimado',
    'sc_est_label': 'Costo de Envío Estimado',
    'sc_est_sub': '+/-15% estimado · La cotización final varía por transportista',
    'btn_request_ship': '🚚 Solicitar Envío',
    'btn_save_estimate': '💾 Guardar Estimado',
    'msg_saved_estimate': 'Estimado guardado en tu historial.',

    // --- SHIPPING REQUEST ---
    'ship_title': '🚚 Solicitud de Envío',
    'ship_sub': '¿Necesitas transportar un vehículo? Te enviaremos opciones en 24–48 horas.',
    'label_pickup_city': 'Ubicación de Recogida (Ciudad, Estado) *',
    'ph_pickup_city': 'ej., Atlanta, GA',
    'label_delivery_city': 'Ubicación de Entrega (Ciudad, Estado) *',
    'ph_delivery_city': 'ej., Miami, FL',
    'label_vehicle_cond': 'Condición del Vehículo *',
    'opt_select_cond_ship': '— Selecciona condición —',
    'opt_running': 'Funciona',
    'label_pickup_date': 'Fecha Preferida de Recogida',
    'label_special_instructions': 'Instrucciones Especiales',
    'ph_special_instructions': 'Cualquier requisito especial o notas sobre este envío...',
    'btn_request_ship_quote': 'Solicitar Cotización de Envío',

    // --- TITLE & REGISTRATION ---
    'title_form_title': '📝 Trámite de Título y Registro',
    'title_form_sub': '¿Necesitas ayuda con transferencia de título, registro u otros servicios del DMV? Envía tu solicitud aquí.',
    'label_title_vin': 'VIN *',
    'label_state_reg': 'Estado de Registro *',
    'ph_state': 'ej., GA',
    'label_services_needed': 'Servicios Necesarios (selecciona todos los que apliquen)',
    'svc_title_transfer': 'Transferencia de Título',
    'svc_registration': 'Registro',
    'svc_temp_tags': 'Placas Temporales',
    'svc_duplicate_title': 'Título Duplicado',
    'svc_lien_release': 'Liberación de Gravamen',
    'svc_out_of_state': 'Transferencia Interestatal',
    'label_docs_have': 'Documentos que Tienes (selecciona todos los que apliquen)',
    'doc_bill_of_sale': 'Factura de Venta',
    'doc_current_title': 'Título Actual',
    'doc_id': 'Identificación',
    'doc_poa': 'Poder Notarial',
    'label_notes': 'Notas',
    'ph_title_notes': 'Cualquier contexto adicional o preguntas...',

    // --- FINANCING REQUEST ---
    'fin_title': '💰 Solicitud de Financiamiento',
    'fin_sub': '¿Buscas financiamiento para tu vehículo? Envía tus datos y te conectaremos con opciones de préstamos.',
    'label_vehicle_interest': 'Vehículo de Interés *',
    'ph_vehicle_interest': 'ej., 2020 Honda Accord EX, 45k millas',
    'label_vehicle_price': 'Precio del Vehículo ($) *',
    'ph_vehicle_price': 'ej., 18000',
    'label_down_payment': 'Enganche ($)',
    'ph_down_payment': 'ej., 3000',
    'label_monthly_payment': 'Pago Mensual Meta ($)',
    'ph_monthly': 'ej., 350',
    'label_credit_score': 'Rango de Puntuación Crediticia *',
    'opt_select_credit': '— Selecciona rango —',
    'opt_excellent_credit': 'Excelente (750+)',
    'opt_good_credit': 'Bueno (700–749)',
    'opt_fair_credit': 'Regular (650–699)',
    'opt_poor_credit': 'Deficiente (menos de 650)',
    'opt_unknown_credit': 'No sé',
    'label_employment': 'Situación Laboral *',
    'opt_select_emp': '— Selecciona —',
    'opt_employed': 'Empleado (W-2)',
    'opt_self_employed': 'Autónomo',
    'opt_unemployed': 'Desempleado',
    'opt_retired': 'Jubilado',
    'label_annual_income': 'Ingresos Anuales ($)',
    'ph_income': 'ej., 55000',
    'label_phone': 'Número de Teléfono',
    'ph_phone': '(555) 123-4567',

    // --- VEHICLE SOURCING ---
    'src_title': '🔍 Solicitud de Búsqueda de Vehículo',
    'src_sub': 'Cuéntanos qué buscas y lo encontraremos en nuestra red de subastas y dealers.',
    'label_year_min': 'Rango de Año (Mín)',
    'ph_year_min': 'ej., 2015',
    'label_year_max': 'Rango de Año (Máx)',
    'ph_year_max': 'ej., 2023',
    'label_body_type': 'Tipo de Carrocería',
    'opt_any': '— Cualquiera —',
    'opt_sedan_body': 'Sedán',
    'opt_suv_body': 'SUV / Crossover',
    'opt_truck': 'Camioneta',
    'opt_coupe': 'Coupé',
    'opt_van': 'Van / Minivan',
    'opt_wagon': 'Familiar',
    'opt_convertible': 'Convertible',
    'label_max_mileage': 'Kilometraje Máximo',
    'ph_max_mileage': 'ej., 80000',
    'label_max_budget': 'Presupuesto Máximo ($) *',
    'ph_max_budget': 'ej., 15000',
    'label_pref_condition': 'Condición Preferida',
    'opt_clean': 'Título Limpio / Funciona',
    'opt_salvage': 'Salvamento OK',
    'opt_minor_damage': 'Daño Menor OK',
    'label_must_have': 'Características Imprescindibles',
    'ph_must_have': 'ej., asientos de cuero, techo solar, cámara trasera, pocos kilómetros...',
    'label_intended_use': 'Uso Previsto',
    'opt_select_use': '— Selecciona —',
    'opt_personal': 'Uso Personal',
    'opt_flip': 'Flip / Reventa',
    'opt_rental': 'Flota de Alquiler',
    'opt_commercial': 'Uso Comercial',
    'label_urgency': 'Urgencia',
    'opt_select_urgency': '— Selecciona —',
    'opt_need_asap': 'Lo antes posible',
    'opt_2_weeks_src': 'En 2 semanas',
    'opt_1_month_src': 'En un mes',
    'opt_no_rush': 'Sin prisa',
    'btn_check_market_first': '📊 Verificar Valor de Mercado Primero',

    // --- CUSTOMER INQUIRY ---
    'inq_title': '🤝 Consulta de Cliente',
    'inq_sub': '¿Tienes un cliente interesado en un vehículo? Envía su información y nosotros hacemos el seguimiento.',
    'label_cust_name': 'Nombre del Cliente *',
    'ph_cust_name': 'Nombre completo del cliente',
    'label_cust_email': 'Correo del Cliente *',
    'ph_cust_email': 'cliente@ejemplo.com',
    'label_cust_phone': 'Teléfono del Cliente',
    'label_vehicle_of_interest': 'Vehículo de Interés *',
    'ph_vehicle_inq': 'ej., 2019 Honda Civic Sport, azul',
    'label_inq_source': 'Fuente de Consulta',
    'opt_select_source': '— Selecciona —',
    'opt_facebook': 'Facebook Marketplace',
    'opt_craigslist': 'Craigslist',
    'opt_offerup': 'OfferUp',
    'opt_referral': 'Referido',
    'opt_website': 'Sitio Web',
    'opt_other': 'Otro',
    'label_partner_name': 'Tu Nombre (Socio)',
    'ph_partner_name': 'Tu nombre',
    'label_message_notes': 'Mensaje / Notas',
    'ph_inq_message': 'Cualquier detalle adicional sobre este cliente o su interés...',
    'btn_submit_inquiry': 'Enviar Consulta',

    // --- MARKETING SUPPORT ---
    'mkt_title': '📢 Solicitud de Apoyo de Marketing',
    'mkt_sub': '¿Necesitas contenido de marketing, gráficos o soporte en redes sociales? Cuéntanos qué necesitas.',
    'label_content_type': 'Tipo de Contenido *',
    'opt_select_type': '— Selecciona tipo —',
    'opt_social_post': 'Publicación en Redes',
    'opt_listing_photos': 'Fotos / Gráficos de Listado',
    'opt_video': 'Video Promocional',
    'opt_flyer': 'Volante / Material Impreso',
    'opt_branding': 'Ayuda con Marca / Logo',
    'label_description': 'Descripción *',
    'ph_mkt_description': 'Describe qué necesitas — incluye detalles específicos, info del vehículo o mensajes que quieras...',
    'label_deadline': 'Fecha Límite',

    // --- THE GAME SECTION ---
    'game_section_title': '🎯 El Juego',
    'game_ai_ph': 'Pregúntale a Byrd Dawg lo que sea...',
    'btn_byrd_dawg': '🦅 Byrd Dawg',

    // --- SUPPORT & CONNECT ---
    'support_section_title': '📞 Soporte y Conexión',
    'faq_title': '❓ Preguntas Frecuentes',

    // --- CERTIFICATIONS ---
    'training_section_title': '🎓 Certificaciones',

    // --- VEHICLE INTELLIGENCE ---
    'vi_section_title': '🔬 Inteligencia de Vehículos',

    // --- ACV CALCULATOR ---
    'acv_title': '🏷️ Calculadora ACV',
    'acv_sub': 'Estima el Valor de Mercado Actual de un vehículo usando datos de NHTSA + ajustes de mercado.',
    'label_acv_vin': 'VIN (Opcional — auto completa año/marca/modelo)',
    'ph_acv_vin': 'VIN de 17 caracteres',
    'label_acv_year': 'Año *',
    'label_acv_make': 'Marca *',
    'label_acv_model': 'Modelo *',
    'label_acv_mileage': 'Kilometraje Actual *',
    'ph_acv_mileage': 'ej., 67000',
    'label_acv_condition': 'Condición del Vehículo *',
    'opt_cond_outstanding': 'Sobresaliente',
    'opt_cond_clean': 'Limpio',
    'opt_cond_average': 'Promedio',
    'opt_cond_rough': 'Deteriorado',
    'opt_cond_damaged': 'Dañado',
    'label_title_type': 'Tipo de Título',
    'opt_title_clean': 'Título Limpio',
    'opt_title_salvage': 'Salvamento',
    'opt_title_rebuilt': 'Reconstruido',
    'opt_title_parts': 'Solo Piezas',
    'label_accident': '¿Historial de Accidente?',
    'opt_no_accident': 'Sin accidentes',
    'opt_minor_accident': 'Accidente menor',
    'opt_major_accident': 'Accidente mayor',
    'btn_calc_acv': 'Calcular ACV',
    'btn_clear_acv': 'Limpiar',
    'acv_est_value': 'Valor ACV Estimado',
    'acv_retail': 'Retail',
    'acv_wholesale': 'Mayoreo',
    'acv_breakdown': 'Desglose',

    // --- LOAN CALCULATOR ---
    'loan_title': '💳 Calculadora de Préstamo',
    'loan_sub': 'Estima pagos mensuales y costo total del préstamo.',
    'label_loan_price': 'Precio del Vehículo ($)',
    'label_loan_down': 'Enganche ($)',
    'label_loan_trade': 'Valor de Trade-In ($)',
    'label_loan_tax': 'Tasa de Impuesto (%)',
    'label_loan_term': 'Plazo del Préstamo (meses)',
    'label_loan_rate': 'Tasa de Interés (% anual)',
    'btn_calc_loan': 'Calcular Préstamo',
    'btn_clear_loan': 'Limpiar',
    'btn_save_scenario': 'Guardar Escenario',
    'loan_monthly_payment': 'Pago Mensual',
    'loan_amount': 'Monto del Préstamo',
    'loan_total_interest': 'Interés Total',
    'loan_total_cost': 'Costo Total',

    // --- DEAL PIPELINE ---
    'pipeline_title': '📊 Línea de Tratos',

    // --- MESSAGES ---
    'messages_section_title': '✉️ Mensajes',

    // --- TOAST/ALERTS ---
    'loading': 'Cargando...',
    'success': '¡Éxito!',
    'error': 'Error',
    'submitting': 'Enviando...',

    // --- CERTIFICATIONS SECTION ---
    'cert_lock_msg': 'Completa tu certificación para desbloquear todas las herramientas de ByrddawgsOS',

    // --- LOCK SCREEN ---
    'lock_complete_cert': 'Completa tu certificación para desbloquear todas las herramientas de ByrddawgsOS',
    'btn_start_cert': 'Comenzar Certificación',

    // --- COMMON LABELS (shared across forms) ---
    'label_common_vin_optional': 'VIN (Opcional)',
    'label_common_make': 'Marca *',
    'label_common_model': 'Modelo *',
    'label_common_year': 'Año del Vehículo *',
    'label_common_name': 'Tu Nombre *',
    'label_common_email': 'Tu Correo *',
    'label_common_notes': 'Notas',
    'ph_common_vin': 'VIN de 17 caracteres',

    // --- GAME PAGE GUIDES ---
    'guide_iaai_title': '🏢 IAAI — Subastas de Autos de Seguros',
    'guide_copart_title': '🔨 Copart — Subastas de Salvamento',
    'guide_edge_title': '📊 Edge Pipeline — Mayoreo de Dealers',
    'guide_cfs_title': '🚙 CarsForSale — Listados de Dealer',
    'guide_ove_title': '🏪 OVE — ADESA Mayoreo',
    'quick_tip': '💡 Consejo Rápido',
    'login_section': '🔐 Acceso',
    'bidding_strategy': '🎯 Estrategia de Oferta',
    'go_to_credentials': '🔑 Ir a Credenciales →',

  };

  // ============================
  // i18n Engine
  // ============================

  function getLang() {
    return localStorage.getItem('fliplane_lang') || 'en';
  }

  function setLang(lang) {
    localStorage.setItem('fliplane_lang', lang);
  }

  function t(key) {
    const lang = getLang();
    if (lang === 'en') return null; // Use HTML default
    return ES[key] || null;
  }

  // Update a single text node (preserves child elements like spans)
  function setTextNode(el, text) {
    if (!el) return;
    // Find first text node and update it
    for (let node of el.childNodes) {
      if (node.nodeType === Node.TEXT_NODE && node.textContent.trim()) {
        node.textContent = text + ' ';
        return;
      }
    }
    // Fallback: prepend text node
    el.insertBefore(document.createTextNode(text + ' '), el.firstChild);
  }

  // Set full text content (no children to preserve)
  function setText(el, text) {
    if (!el) return;
    el.textContent = text;
  }

  // Set placeholder
  function setPlaceholder(el, text) {
    if (!el) return;
    el.placeholder = text;
  }

  // ============================
  // Translation Maps
  // ============================

  function applyDirect(lang) {
    const es = lang === 'es';

    // --- LOGIN SCREEN ---
    const loginSub = document.querySelector('.login-sub');
    if (loginSub) loginSub.textContent = es ? ES.login_sub : 'Member Operations Hub — Enter your email to access';

    const loginEmail = document.getElementById('login-email');
    if (loginEmail) loginEmail.placeholder = es ? ES.login_email_ph : 'your@email.com';

    const loginBtn = document.getElementById('login-btn');
    if (loginBtn) loginBtn.textContent = es ? ES.login_btn : 'Access Hub';

    // Login links — find by text
    const loginLinks = document.querySelectorAll('.login-link');
    loginLinks.forEach(link => {
      if (link.textContent.includes('Not a member')) {
        if (es) {
          link.innerHTML = ES.login_not_member + '<a href="/buy">' + ES.login_join + '</a>';
        } else {
          link.innerHTML = 'Not a member yet? <a href="/buy">Join FlipLane</a>';
        }
      }
      if (link.textContent.includes('Questions?')) {
        if (es) {
          link.innerHTML = ES.login_questions + '<a href="tel:+18555354752">855-5FLIPLANE</a>';
        } else {
          link.innerHTML = 'Questions? <a href="tel:+18555354752">855-5FLIPLANE</a>';
        }
      }
    });

    // --- TOPBAR ---
    const logoutBtn = document.querySelector('button.topbar-logout');
    if (logoutBtn && es) logoutBtn.textContent = ES.topbar_logout;
    else if (logoutBtn && !es) logoutBtn.textContent = 'Logout';

    // --- WELCOME BANNER ---
    const welcomeSub = document.querySelector('.welcome-banner p');
    if (welcomeSub && es) welcomeSub.textContent = ES.welcome_sub;
    else if (welcomeSub && !es) welcomeSub.textContent = 'Your member hub. Everything you need to source, sell, and scale.';

    // --- QUICK STATS ---
    applyStatCards(lang);

    // --- ACTION BUTTONS ---
    applyActionButtons(lang);

    // --- SECTION LABEL ---
    const sectionLabel = document.querySelector('.section-label');
    if (sectionLabel && es) sectionLabel.textContent = ES.section_ops;
    else if (sectionLabel && !es) sectionLabel.textContent = 'Your Operations';

    // --- CATEGORY CARDS ---
    applyCategoryCards(lang);

    // --- BACK BUTTONS ---
    document.querySelectorAll('.back-btn').forEach(btn => {
      if (es) btn.textContent = ES.back_to_hub;
      else btn.textContent = '← Back to Hub';
    });

    // --- CONTENT CARD TITLES + SUBTITLES ---
    applyContentCards(lang);

    // --- FORM LABELS, INPUTS, SELECTS ---
    applyForms(lang);

    // --- GAME SECTION ---
    applyGameSection(lang);

    // --- UPDATE LANG TOGGLE BUTTONS ---
    document.querySelectorAll('.lang-toggle-btn').forEach(btn => {
      btn.textContent = lang === 'es' ? '🌐 EN' : '🌐 ES';
      btn.title = lang === 'es' ? 'Switch to English' : 'Cambiar a Español';
    });

    // --- UPDATE FLOATING LANG BAR ---
    var floatEn = document.getElementById('lang-float-en');
    var floatEs = document.getElementById('lang-float-es');
    if (floatEn && floatEs) {
      if (lang === 'es') {
        floatEs.classList.add('active');
        floatEn.classList.remove('active');
      } else {
        floatEn.classList.add('active');
        floatEs.classList.remove('active');
      }
    }

    // --- UPDATE HTML LANG ATTR ---
    document.documentElement.lang = lang;
  }

  function applyStatCards(lang) {
    const es = lang === 'es';
    const cards = document.querySelectorAll('.stat-card');
    cards.forEach(card => {
      const label = card.querySelector('.stat-label');
      const sub = card.querySelector('.stat-sub');
      if (!label) return;
      const labelText = label.textContent.trim();
      if (labelText === 'Deals Submitted' || labelText === 'Tratos Enviados') {
        label.textContent = es ? ES.stat_deals_label : 'Deals Submitted';
        if (sub) sub.textContent = es ? ES.stat_deals_sub : 'All time';
      } else if (labelText === 'Certification' || labelText === 'Certificación') {
        label.textContent = es ? ES.stat_cert_label : 'Certification';
        if (sub) sub.textContent = es ? ES.stat_cert_sub : 'Training status';
      } else if (labelText === 'Member Since' || labelText === 'Miembro Desde') {
        label.textContent = es ? ES.stat_member_label : 'Member Since';
        if (sub) sub.textContent = es ? ES.stat_member_sub : 'Co-op partner';
      }
    });
  }

  function applyActionButtons(lang) {
    const es = lang === 'es';
    document.querySelectorAll('.action-btn').forEach(btn => {
      const t = btn.textContent.trim();
      if (t.includes('Submit a Deal') || t.includes('Enviar un Trato')) {
        btn.textContent = es ? ES.btn_submit_deal : '🚗 Submit a Deal';
      } else if (t.includes('Find Inventory') || t.includes('Buscar Inventario')) {
        btn.textContent = es ? ES.btn_find_inventory : '🔍 Find Inventory';
      } else if (t.includes('Contact Us') || t.includes('Contáctanos')) {
        btn.textContent = es ? ES.btn_contact_us : '✉️ Contact Us';
      }
    });
  }

  function applyCategoryCards(lang) {
    const es = lang === 'es';
    // EN titles → ES translations
    const enToEs = {
      'Certifications': { title: ES.cat_training_title, desc: ES.cat_training_desc },
      'Tools & Credentials': { title: ES.cat_credentials_title, desc: ES.cat_credentials_desc },
      'Deal Center': { title: ES.cat_deals_title, desc: ES.cat_deals_desc },
      'The Game': { title: ES.cat_game_title, desc: ES.cat_game_desc },
      'Support & Connect': { title: ES.cat_support_title, desc: ES.cat_support_desc },
      'Vehicle Intelligence': { title: ES.cat_vehicle_intel_title, desc: ES.cat_vehicle_intel_desc },
    };
    // ES titles → EN translations
    const esToEn = {
      'Certificaciones': { title: 'Certifications', desc: 'Your certification status, study book, and training materials. Complete cert to unlock full dealer access.' },
      'Herramientas y Credenciales': { title: 'Tools & Credentials', desc: 'Auction platforms, shared dealer credentials, and direct links to everything you need to source inventory.' },
      'Centro de Tratos': { title: 'Deal Center', desc: 'ROI Analyzer, ACV Calculator, Profit Calculator, Market Value, deal submission, Fix & Flip, shipping, and title services.' },
      'El Juego': { title: 'The Game', desc: 'Platform guides for IAAI, Copart, Edge Pipeline, CarsForSale & OVE. Master auction strategy + maximize your listings.' },
      'Soporte y Conexión': { title: 'Support & Connect', desc: 'Get help, contact the FlipLane team, and connect on socials.' },
      'Inteligencia de Vehículos': { title: 'Vehicle Intelligence', desc: 'NHTSA recalls, safety ratings, complaints & EPA fuel economy — instant, no API key.' },
    };

    document.querySelectorAll('.cat-card').forEach(card => {
      const titleEl = card.querySelector('.cat-title');
      const descEl = card.querySelector('.cat-desc');
      if (!titleEl) return;

      // Get base title (strip message badge HTML)
      const rawTitle = titleEl.firstChild && titleEl.firstChild.nodeType === Node.TEXT_NODE
        ? titleEl.firstChild.textContent.trim()
        : titleEl.textContent.trim();

      // For the Messages card, preserve the badge span
      if (rawTitle === 'Messages' || rawTitle === 'Mensajes') {
        const badge = titleEl.querySelector('span[id="hub-msg-badge"]');
        if (titleEl.firstChild && titleEl.firstChild.nodeType === Node.TEXT_NODE) {
          titleEl.firstChild.textContent = es ? ES.cat_messages_title + ' ' : 'Messages ';
        }
        if (descEl) descEl.textContent = es ? ES.cat_messages_desc : 'Direct messages from the FlipLane admin team. Replies go straight to your team.';
        return;
      }

      // Apply the correct translation based on target language
      if (es) {
        // Switching to Spanish: look up the English title → get Spanish
        const entry = enToEs[rawTitle];
        if (entry) {
          if (titleEl) titleEl.textContent = entry.title;
          if (descEl) descEl.textContent = entry.desc;
        }
        // If rawTitle is already Spanish, do nothing (already correct)
      } else {
        // Switching to English: look up the Spanish title → get English
        const entry = esToEn[rawTitle];
        if (entry) {
          if (titleEl) titleEl.textContent = entry.title;
          if (descEl) descEl.textContent = entry.desc;
        }
        // If rawTitle is already English, do nothing (already correct)
      }
    });
  }

  // Map content card titles (section headers) and subtitles
  function applyContentCards(lang) {
    const es = lang === 'es';

    const titleMap = {
      // Tools & Credentials
      '🌐 Auction & Wholesale Platforms — Direct Links': es ? ES.cred_auction_title : '🌐 Auction & Wholesale Platforms — Direct Links',
      '🚙 Dealer Tools & Platforms': es ? ES.cred_dealer_title : '🚙 Dealer Tools & Platforms',
      '🔐 Login Credentials Vault': es ? ES.cred_vault_title : '🔐 Login Credentials Vault',
      // Deal Center
      'Vehicle Intelligence Hub': es ? ES.vi_hub_title : 'Vehicle Intelligence Hub',
      '🧮 Deal Profit Calculator': es ? ES.calc_title : '🧮 Deal Profit Calculator',
      '📊 Market Value Comparator': es ? ES.mv_title : '📊 Market Value Comparator',
      '🔧 Fix & Flip Request': es ? ES.ff_title : '🔧 Fix & Flip Request',
      '🚚 Shipping Request': es ? ES.ship_title : '🚚 Shipping Request',
      '📝 Title & Registration Processing': es ? ES.title_form_title : '📝 Title & Registration Processing',
      '💰 Financing Request': es ? ES.fin_title : '💰 Financing Request',
      '🔍 Vehicle Sourcing Request': es ? ES.src_title : '🔍 Vehicle Sourcing Request',
      '🤝 Customer Inquiry': es ? ES.inq_title : '🤝 Customer Inquiry',
      '📢 Marketing Support Request': es ? ES.mkt_title : '📢 Marketing Support Request',
      '📊 Deal Pipeline': es ? ES.pipeline_title : '📊 Deal Pipeline',
      '🏷️ ACV Calculator': es ? ES.acv_title : '🏷️ ACV Calculator',
      '💳 Loan Calculator': es ? ES.loan_title : '💳 Loan Calculator',
      // Spanish reverse
      'Hub de Inteligencia de Vehículos': 'Vehicle Intelligence Hub',
      '🧮 Calculadora de Ganancia en Tratos': '🧮 Deal Profit Calculator',
      '📊 Comparador de Valor de Mercado': '📊 Market Value Comparator',
      '🔧 Solicitud de Fix & Flip': '🔧 Fix & Flip Request',
      '🚚 Solicitud de Envío': '🚚 Shipping Request',
      '📝 Trámite de Título y Registro': '📝 Title & Registration Processing',
      '💰 Solicitud de Financiamiento': '💰 Financing Request',
      '🔍 Solicitud de Búsqueda de Vehículo': '🔍 Vehicle Sourcing Request',
      '🤝 Consulta de Cliente': '🤝 Customer Inquiry',
      '📢 Solicitud de Apoyo de Marketing': '📢 Marketing Support Request',
    };

    document.querySelectorAll('.content-card-title').forEach(el => {
      const text = el.textContent.trim();
      if (titleMap[text]) el.textContent = titleMap[text];
    });

    // Section titles in section-back
    document.querySelectorAll('.section-title').forEach(el => {
      const text = el.textContent.trim();
      const sectionTitleMap = {
        '🔑 Tools & Credentials': es ? ES.cred_section_title : '🔑 Tools & Credentials',
        '🚗 Deal Center': es ? ES.deals_section_title : '🚗 Deal Center',
        '🎯 The Game': es ? ES.game_section_title : '🎯 The Game',
        '🎓 Certifications': es ? ES.training_section_title : '🎓 Certifications',
        '📞 Support & Connect': es ? ES.support_section_title : '📞 Support & Connect',
        '🔬 Vehicle Intelligence': es ? ES.vi_section_title : '🔬 Vehicle Intelligence',
        '✉️ Messages': es ? ES.messages_section_title : '✉️ Messages',
        // ES reverse
        '🔑 Herramientas y Credenciales': '🔑 Tools & Credentials',
        '🚗 Centro de Tratos': '🚗 Deal Center',
        '🎯 El Juego': '🎯 The Game',
        '🎓 Certificaciones': '🎓 Certifications',
        '📞 Soporte y Conexión': '📞 Support & Connect',
        '🔬 Inteligencia de Vehículos': '🔬 Vehicle Intelligence',
        '✉️ Mensajes': '✉️ Messages',
      };
      if (sectionTitleMap[text]) el.textContent = sectionTitleMap[text];
    });
  }

  // Translate form labels, placeholders, select options, and buttons
  function applyForms(lang) {
    const es = lang === 'es';

    // ---- PROFIT CALCULATOR ----
    translateFormLabels('#profit-calc-card', lang, [
      ['Vehicle Description', es ? 'Descripción del Vehículo' : 'Vehicle Description'],
      ['Buy Price ($)', es ? 'Precio de Compra ($)' : 'Buy Price ($)'],
      ['Repairs / Costs ($)', es ? 'Reparaciones / Costos ($)' : 'Repairs / Costs ($)'],
      ['Transport / Shipping ($)', es ? 'Transporte / Envío ($)' : 'Transport / Shipping ($)'],
      ['Title & Registration Fees ($)', es ? 'Tarifas de Título y Registro ($)' : 'Title & Registration Fees ($)'],
      ['Holding Costs ($)', es ? 'Costos de Tenencia ($)' : 'Holding Costs ($)'],
      ['FlipLane Processing Fee ($)', es ? 'Tarifa FlipLane ($)' : 'FlipLane Processing Fee ($)'],
      ['Target Sell Price ($)', es ? 'Precio de Venta Meta ($)' : 'Target Sell Price ($)'],
    ]);
    translatePlaceholders('#profit-calc-card', lang, [
      ['calc-desc', es ? 'ej., 2020 Ford F-150 XLT 4x4' : 'e.g., 2020 Ford F-150 XLT 4WD'],
      ['calc-buy', es ? 'ej., 6500' : 'e.g., 6500'],
      ['calc-repairs', es ? 'ej., 800' : 'e.g., 800'],
      ['calc-transport', es ? 'ej., 450' : 'e.g., 450'],
      ['calc-title-reg', es ? 'ej., 150' : 'e.g., 150'],
      ['calc-holding', es ? 'ej., 200' : 'e.g., 200'],
      ['calc-sell', es ? 'ej., 9500' : 'e.g., 9500'],
    ]);
    translateButtonsByContainer('#profit-calc-card', lang, [
      ['Clear', es ? 'Limpiar' : 'Clear'],
      ['💾 Save Calculation', es ? '💾 Guardar Cálculo' : '💾 Save Calculation'],
      ['📋 History', es ? '📋 Historial' : '📋 History'],
      ['🏷️ Check ACV →', es ? '🏷️ Verificar ACV →' : '🏷️ Check ACV →'],
      ['📊 Market Value →', es ? '📊 Valor de Mercado →' : '📊 Market Value →'],
      ['💳 Estimate Loan →', es ? '💳 Estimar Préstamo →' : '💳 Estimate Loan →'],
    ]);
    translateStatLabels('#profit-calc-card', lang, [
      ['Total Cost', es ? 'Costo Total' : 'Total Cost', 'All-in cost', es ? 'Costo todo incluido' : 'All-in cost'],
      ['Net Profit', es ? 'Ganancia Neta' : 'Net Profit', 'After all costs', es ? 'Después de todos los costos' : 'After all costs'],
      ['Profit Margin', es ? 'Margen de Ganancia' : 'Profit Margin', 'Profit ÷ sell price', es ? 'Ganancia ÷ precio de venta' : 'Profit ÷ sell price'],
      ['ROI', 'ROI', 'Profit ÷ total cost', es ? 'Ganancia ÷ costo total' : 'Profit ÷ total cost'],
    ]);

    // ---- MARKET VALUE FORM ----
    translateFormLabels('#mv-form', lang, [
      ['VIN', es ? 'VIN (opcional — autocompleta año/marca/modelo)' : 'VIN'],
      ['Year', es ? 'Año' : 'Year'],
      ['Make', es ? 'Marca' : 'Make'],
      ['Model', es ? 'Modelo' : 'Model'],
      ['Trim', es ? 'Versión' : 'Trim'],
      ['Mileage', es ? 'Kilometraje' : 'Mileage'],
      ['Condition', es ? 'Condición' : 'Condition'],
      ['Your Target Price ($)', es ? 'Tu Precio Meta ($) (opcional — calcula Puntaje del Trato)' : 'Your Target Price ($)'],
    ]);
    translatePlaceholders('#mv-form', lang, [
      ['mv-vin', es ? 'VIN de 17 caracteres' : '17-character VIN'],
      ['mv-year', es ? 'ej., 2019' : 'e.g., 2019'],
      ['mv-make', es ? 'ej., Honda' : 'e.g., Honda'],
      ['mv-model', es ? 'ej., Civic' : 'e.g., Civic'],
      ['mv-trim', es ? 'ej., EX-L' : 'e.g., EX-L'],
      ['mv-mileage', es ? 'ej., 55000' : 'e.g., 55000'],
      ['mv-target-price', es ? 'ej., 11500' : 'e.g., 11500'],
    ]);
    translateSelectById('mv-condition', lang, [
      ['', es ? '— Selecciona —' : '— Select —'],
      ['excellent', es ? 'Excelente' : 'Excellent'],
      ['good', es ? 'Bueno' : 'Good'],
      ['fair', es ? 'Regular' : 'Fair'],
      ['poor', es ? 'Deficiente' : 'Poor'],
    ]);
    translateButtonsByContainer('#market-value-card', lang, [
      ['Get Market Value', es ? 'Obtener Valor de Mercado' : 'Get Market Value'],
      ['Clear', es ? 'Limpiar' : 'Clear'],
    ]);

    // ---- FIX & FLIP FORM ----
    translateFormLabels('#fixflip-form', lang, [
      ['Vehicle Year', es ? 'Año del Vehículo' : 'Vehicle Year'],
      ['Make', es ? 'Marca' : 'Make'],
      ['Model', es ? 'Modelo' : 'Model'],
      ['VIN (Optional)', es ? 'VIN (Opcional)' : 'VIN (Optional)'],
      ['Current Condition', es ? 'Condición Actual' : 'Current Condition'],
      ['Repair Scope Description', es ? 'Descripción del Alcance de Reparación' : 'Repair Scope Description'],
      ['Estimated Budget', es ? 'Presupuesto Estimado' : 'Estimated Budget'],
      ['Timeline', es ? 'Plazo' : 'Timeline'],
      ['Your Name', es ? 'Tu Nombre' : 'Your Name'],
      ['Your Email', es ? 'Tu Correo' : 'Your Email'],
    ]);
    translatePlaceholders('#fixflip-form', lang, [
      ['ff-year', es ? 'ej., 2019' : 'e.g., 2019'],
      ['ff-make', es ? 'ej., Honda' : 'e.g., Honda'],
      ['ff-model', es ? 'ej., Civic' : 'e.g., Civic'],
      ['ff-vin', es ? 'VIN de 17 caracteres' : '17-char VIN'],
      ['ff-scope', es ? 'Describe las reparaciones necesarias...' : 'Describe what repairs are needed or what you\'d like done...'],
      ['ff-name', es ? 'Nombre completo' : 'Full name'],
      ['ff-email', es ? 'correo@ejemplo.com' : 'email@example.com'],
    ]);
    translateSelectById('ff-condition', lang, [
      ['', es ? '— Selecciona condición —' : '— Select condition —'],
      ['runs_great', es ? 'Funciona perfecto' : 'Runs great'],
      ['minor_work', es ? 'Necesita trabajo menor' : 'Needs minor work'],
      ['major_repair', es ? 'Necesita reparación mayor' : 'Needs major repair'],
      ['non_running', es ? 'No arranca' : 'Non-running'],
    ]);
    translateSelectById('ff-budget', lang, [
      ['', es ? '— Selecciona rango —' : '— Select range —'],
    ]);
    translateSelectById('ff-timeline', lang, [
      ['', es ? '— Selecciona plazo —' : '— Select timeline —'],
      ['asap', es ? 'Lo antes posible' : 'ASAP'],
      ['2_weeks', es ? 'En 2 semanas' : 'Within 2 weeks'],
      ['1_month', es ? 'En 1 mes' : 'Within 1 month'],
      ['flexible', es ? 'Flexible' : 'Flexible'],
    ]);
    translateButtonsByContainer('#fixflip-form', lang, [
      ['Submit Request', es ? 'Enviar Solicitud' : 'Submit Request'],
    ]);

    // ---- SHIPPING ESTIMATOR ----
    translatePlaceholders('#shipping-calculator-card', lang, [
      ['sc-pickup', es ? 'ej., Atlanta, GA o 30301' : 'e.g., Atlanta, GA or 30301'],
      ['sc-delivery', es ? 'ej., Miami, FL o 33101' : 'e.g., Miami, FL or 33101'],
    ]);
    translateButtonsByContainer('#shipping-calculator-card', lang, [
      ['📍 Calculate Estimate', es ? '📍 Calcular Estimado' : '📍 Calculate Estimate'],
      ['🚚 Request Shipping', es ? '🚚 Solicitar Envío' : '🚚 Request Shipping'],
      ['💾 Save Estimate', es ? '💾 Guardar Estimado' : '💾 Save Estimate'],
    ]);
    const scSaveMsg = document.getElementById('sc-save-msg');
    if (scSaveMsg && es) scSaveMsg.textContent = ES.msg_saved_estimate;
    else if (scSaveMsg && !es) scSaveMsg.textContent = 'Estimate saved to your history.';
    // Ship type buttons
    const shipTypeGrid = document.getElementById('sc-vehicle-type');
    if (shipTypeGrid) {
      const btns = shipTypeGrid.querySelectorAll('button');
      const shipTypeTrans = es
        ? ['🚗 Sedán', '🚙 SUV / Camioneta', '🏍️ Motocicleta', '🚛 Sobredimensionado']
        : ['🚗 Sedan', '🚙 SUV / Truck', '🏍️ Motorcycle', '🚛 Oversized'];
      btns.forEach((btn, i) => { if (shipTypeTrans[i]) btn.textContent = shipTypeTrans[i]; });
    }
    // Transport type toggle
    const transportToggle = document.getElementById('sc-transport-type');
    if (transportToggle) {
      const btns = transportToggle.querySelectorAll('button');
      if (btns[0]) btns[0].textContent = es ? '🌤 Abierto' : '🌤️ Open';
      if (btns[1]) btns[1].textContent = es ? '📦 Cerrado' : '📦 Enclosed';
    }
    // Operable toggle
    const operableToggle = document.getElementById('sc-operable');
    if (operableToggle) {
      const btns = operableToggle.querySelectorAll('button');
      if (btns[0]) btns[0].textContent = es ? '✅ Sí' : '✅ Yes';
      if (btns[1]) btns[1].textContent = es ? '🔧 No (no arranca)' : '🔧 No (inoperable)';
    }
    // Shipping estimator stat label
    const scEstLabel = document.querySelector('.ship-est-label');
    if (scEstLabel && es) scEstLabel.textContent = ES.sc_est_label;
    else if (scEstLabel && !es) scEstLabel.textContent = 'Estimated Shipping Cost';
    const scEstSub = document.querySelector('.ship-est-sub');
    if (scEstSub && es) scEstSub.textContent = ES.sc_est_sub;
    else if (scEstSub && !es) scEstSub.textContent = '+/-15% estimate · Final quote varies by carrier';

    // ---- SHIPPING REQUEST FORM ----
    translateFormLabels('#shipping-form', lang, [
      ['Vehicle Year', es ? 'Año del Vehículo' : 'Vehicle Year'],
      ['Make', es ? 'Marca' : 'Make'],
      ['Model', es ? 'Modelo' : 'Model'],
      ['VIN (Optional)', es ? 'VIN (Opcional)' : 'VIN (Optional)'],
      ['Pickup Location (City, State)', es ? 'Ubicación de Recogida (Ciudad, Estado)' : 'Pickup Location (City, State)'],
      ['Delivery Location (City, State)', es ? 'Ubicación de Entrega (Ciudad, Estado)' : 'Delivery Location (City, State)'],
      ['Vehicle Condition', es ? 'Condición del Vehículo' : 'Vehicle Condition'],
      ['Preferred Pickup Date', es ? 'Fecha Preferida de Recogida' : 'Preferred Pickup Date'],
      ['Special Instructions', es ? 'Instrucciones Especiales' : 'Special Instructions'],
      ['Your Name', es ? 'Tu Nombre' : 'Your Name'],
      ['Your Email', es ? 'Tu Correo' : 'Your Email'],
    ]);
    translatePlaceholders('#shipping-form', lang, [
      ['ship-year', es ? 'ej., 2020' : 'e.g., 2020'],
      ['ship-make', es ? 'ej., Toyota' : 'e.g., Toyota'],
      ['ship-model', es ? 'ej., Camry' : 'e.g., Camry'],
      ['ship-vin', es ? 'VIN de 17 caracteres' : '17-char VIN'],
      ['ship-pickup', es ? 'ej., Atlanta, GA' : 'e.g., Atlanta, GA'],
      ['ship-delivery', es ? 'ej., Miami, FL' : 'e.g., Miami, FL'],
      ['ship-instructions', es ? 'Cualquier requisito especial o notas...' : 'Any special requirements or notes about this shipment...'],
      ['ship-name', es ? 'Nombre completo' : 'Full name'],
      ['ship-email', es ? 'correo@ejemplo.com' : 'email@example.com'],
    ]);
    translateSelectById('ship-condition', lang, [
      ['', es ? '— Selecciona condición —' : '— Select condition —'],
      ['running', es ? 'Funciona' : 'Running'],
      ['non_running', es ? 'No arranca' : 'Non-running'],
    ]);
    translateButtonsByContainer('#shipping-form', lang, [
      ['Request Shipping Quote', es ? 'Solicitar Cotización de Envío' : 'Request Shipping Quote'],
    ]);

    // ---- TITLE & REGISTRATION FORM ----
    translateFormLabels('#title-form', lang, [
      ['Vehicle Year', es ? 'Año del Vehículo' : 'Vehicle Year'],
      ['Make', es ? 'Marca' : 'Make'],
      ['Model', es ? 'Modelo' : 'Model'],
      ['VIN', es ? 'VIN' : 'VIN'],
      ['State of Registration', es ? 'Estado de Registro' : 'State of Registration'],
      ['Services Needed (select all that apply)', es ? 'Servicios Necesarios (selecciona todos los que apliquen)' : 'Services Needed (select all that apply)'],
      ['Documents You Have (select all that apply)', es ? 'Documentos que Tienes (selecciona todos los que apliquen)' : 'Documents You Have (select all that apply)'],
      ['Notes', es ? 'Notas' : 'Notes'],
      ['Your Name', es ? 'Tu Nombre' : 'Your Name'],
      ['Your Email', es ? 'Tu Correo' : 'Your Email'],
    ]);
    translateCheckboxLabels('#title-form', lang, {
      'Title Transfer': es ? 'Transferencia de Título' : 'Title Transfer',
      'Registration': es ? 'Registro' : 'Registration',
      'Temp Tags': es ? 'Placas Temporales' : 'Temp Tags',
      'Duplicate Title': es ? 'Título Duplicado' : 'Duplicate Title',
      'Lien Release': es ? 'Liberación de Gravamen' : 'Lien Release',
      'Out-of-State Transfer': es ? 'Transferencia Interestatal' : 'Out-of-State Transfer',
      'Bill of Sale': es ? 'Factura de Venta' : 'Bill of Sale',
      'Current Title': es ? 'Título Actual' : 'Current Title',
      'ID': es ? 'Identificación' : 'ID',
      'Power of Attorney': es ? 'Poder Notarial' : 'Power of Attorney',
      // Reverse
      'Transferencia de Título': 'Title Transfer',
      'Registro': 'Registration',
      'Placas Temporales': 'Temp Tags',
      'Título Duplicado': 'Duplicate Title',
      'Liberación de Gravamen': 'Lien Release',
      'Transferencia Interestatal': 'Out-of-State Transfer',
      'Factura de Venta': 'Bill of Sale',
      'Título Actual': 'Current Title',
      'Identificación': 'ID',
      'Poder Notarial': 'Power of Attorney',
    });
    translatePlaceholders('#title-form', lang, [
      ['title-year', es ? 'ej., 2017' : 'e.g., 2017'],
      ['title-make', es ? 'ej., Ford' : 'e.g., Ford'],
      ['title-model', es ? 'ej., F-150' : 'e.g., F-150'],
      ['title-vin', es ? 'VIN de 17 caracteres' : '17-char VIN'],
      ['title-state', es ? 'ej., GA' : 'e.g., GA'],
      ['title-notes', es ? 'Cualquier contexto adicional o preguntas...' : 'Any additional context or questions...'],
      ['title-name', es ? 'Nombre completo' : 'Full name'],
      ['title-email', es ? 'correo@ejemplo.com' : 'email@example.com'],
    ]);
    translateButtonsByContainer('#title-form', lang, [
      ['Submit Request', es ? 'Enviar Solicitud' : 'Submit Request'],
    ]);

    // ---- FINANCING REQUEST FORM ----
    translateFormLabels('#financing-form', lang, [
      ['Vehicle of Interest', es ? 'Vehículo de Interés' : 'Vehicle of Interest'],
      ['Vehicle Price ($)', es ? 'Precio del Vehículo ($)' : 'Vehicle Price ($)'],
      ['Down Payment ($)', es ? 'Enganche ($)' : 'Down Payment ($)'],
      ['Target Monthly Payment ($)', es ? 'Pago Mensual Meta ($)' : 'Target Monthly Payment ($)'],
      ['Credit Score Range', es ? 'Rango de Puntuación Crediticia' : 'Credit Score Range'],
      ['Employment Status', es ? 'Situación Laboral' : 'Employment Status'],
      ['Annual Income ($)', es ? 'Ingresos Anuales ($)' : 'Annual Income ($)'],
      ['Your Name', es ? 'Tu Nombre' : 'Your Name'],
      ['Your Email', es ? 'Tu Correo' : 'Your Email'],
      ['Phone Number', es ? 'Número de Teléfono' : 'Phone Number'],
    ]);
    translatePlaceholders('#financing-form', lang, [
      ['fin-vehicle', es ? 'ej., 2020 Honda Accord EX, 45k millas' : 'e.g., 2020 Honda Accord EX, 45k miles'],
      ['fin-price', es ? 'ej., 18000' : 'e.g., 18000'],
      ['fin-down', es ? 'ej., 3000' : 'e.g., 3000'],
      ['fin-monthly', es ? 'ej., 350' : 'e.g., 350'],
      ['fin-income', es ? 'ej., 55000' : 'e.g., 55000'],
      ['fin-name', es ? 'Nombre completo' : 'Full name'],
      ['fin-email', es ? 'correo@ejemplo.com' : 'email@example.com'],
      ['fin-phone', es ? '(555) 123-4567' : '(555) 123-4567'],
    ]);
    translateSelectById('fin-credit', lang, [
      ['', es ? '— Selecciona rango —' : '— Select range —'],
      ['excellent', es ? 'Excelente (750+)' : 'Excellent (750+)'],
      ['good', es ? 'Bueno (700–749)' : 'Good (700–749)'],
      ['fair', es ? 'Regular (650–699)' : 'Fair (650–699)'],
      ['poor', es ? 'Deficiente (menos de 650)' : 'Poor (below 650)'],
      ['unknown', es ? 'No sé' : 'Not sure'],
    ]);
    translateSelectById('fin-employment', lang, [
      ['', es ? '— Selecciona —' : '— Select —'],
      ['employed', es ? 'Empleado (W-2)' : 'Employed (W-2)'],
      ['self_employed', es ? 'Autónomo' : 'Self-Employed'],
      ['unemployed', es ? 'Desempleado' : 'Unemployed'],
      ['retired', es ? 'Jubilado' : 'Retired'],
    ]);
    translateButtonsByContainer('#financing-form', lang, [
      ['Submit Request', es ? 'Enviar Solicitud' : 'Submit Request'],
    ]);

    // ---- VEHICLE SOURCING FORM ----
    translateFormLabels('#sourcing-form', lang, [
      ['Year Range (Min)', es ? 'Rango de Año (Mín)' : 'Year Range (Min)'],
      ['Year Range (Max)', es ? 'Rango de Año (Máx)' : 'Year Range (Max)'],
      ['Make', es ? 'Marca' : 'Make'],
      ['Model', es ? 'Modelo' : 'Model'],
      ['Body Type', es ? 'Tipo de Carrocería' : 'Body Type'],
      ['Max Mileage', es ? 'Kilometraje Máximo' : 'Max Mileage'],
      ['Max Budget ($)', es ? 'Presupuesto Máximo ($)' : 'Max Budget ($)'],
      ['Preferred Condition', es ? 'Condición Preferida' : 'Preferred Condition'],
      ['Must-Have Features', es ? 'Características Imprescindibles' : 'Must-Have Features'],
      ['Intended Use', es ? 'Uso Previsto' : 'Intended Use'],
      ['Urgency', es ? 'Urgencia' : 'Urgency'],
      ['Your Name', es ? 'Tu Nombre' : 'Your Name'],
      ['Your Email', es ? 'Tu Correo' : 'Your Email'],
    ]);
    translatePlaceholders('#sourcing-form', lang, [
      ['src-year-min', es ? 'ej., 2015' : 'e.g., 2015'],
      ['src-year-max', es ? 'ej., 2023' : 'e.g., 2023'],
      ['src-make', es ? 'ej., Toyota' : 'e.g., Toyota'],
      ['src-model', es ? 'ej., Camry' : 'e.g., Camry'],
      ['src-mileage', es ? 'ej., 80000' : 'e.g., 80000'],
      ['src-budget', es ? 'ej., 15000' : 'e.g., 15000'],
      ['src-features', es ? 'ej., asientos de cuero, techo solar, cámara trasera...' : 'e.g., leather seats, sunroof, backup camera, low miles...'],
      ['src-name', es ? 'Nombre completo' : 'Full name'],
      ['src-email', es ? 'correo@ejemplo.com' : 'email@example.com'],
    ]);
    translateSelectById('src-body', lang, [
      ['', es ? '— Cualquiera —' : '— Any —'],
      ['sedan', es ? 'Sedán' : 'Sedan'],
      ['suv', es ? 'SUV / Crossover' : 'SUV / Crossover'],
      ['truck', es ? 'Camioneta' : 'Truck'],
      ['coupe', es ? 'Coupé' : 'Coupe'],
      ['van', es ? 'Van / Minivan' : 'Van / Minivan'],
      ['wagon', es ? 'Familiar' : 'Wagon'],
      ['convertible', es ? 'Convertible' : 'Convertible'],
    ]);
    translateSelectById('src-condition', lang, [
      ['', es ? '— Cualquiera —' : '— Any —'],
      ['clean', es ? 'Título Limpio / Funciona' : 'Clean Title / Run & Drive'],
      ['salvage', es ? 'Salvamento OK' : 'Salvage OK'],
      ['minor_damage', es ? 'Daño Menor OK' : 'Minor Damage OK'],
    ]);
    translateSelectById('src-use', lang, [
      ['', es ? '— Selecciona —' : '— Select —'],
      ['personal', es ? 'Uso Personal' : 'Personal Use'],
      ['flip', es ? 'Flip / Reventa' : 'Flip / Resell'],
      ['rental', es ? 'Flota de Alquiler' : 'Rental Fleet'],
      ['commercial', es ? 'Uso Comercial' : 'Commercial Use'],
    ]);
    translateSelectById('src-urgency', lang, [
      ['', es ? '— Selecciona —' : '— Select —'],
      ['asap', es ? 'Lo antes posible' : 'Need ASAP'],
      ['2_weeks', es ? 'En 2 semanas' : 'Within 2 weeks'],
      ['1_month', es ? 'En un mes' : 'Within a month'],
      ['flexible', es ? 'Sin prisa' : 'No rush'],
    ]);
    translateButtonsByContainer('#sourcing-form', lang, [
      ['Submit Request', es ? 'Enviar Solicitud' : 'Submit Request'],
      ['📊 Check Market Value First', es ? '📊 Verificar Valor de Mercado Primero' : '📊 Check Market Value First'],
    ]);

    // ---- CUSTOMER INQUIRY FORM ----
    translateFormLabels('#inquiry-form', lang, [
      ['Customer Name', es ? 'Nombre del Cliente' : 'Customer Name'],
      ['Customer Email', es ? 'Correo del Cliente' : 'Customer Email'],
      ['Customer Phone', es ? 'Teléfono del Cliente' : 'Customer Phone'],
      ['Vehicle of Interest', es ? 'Vehículo de Interés' : 'Vehicle of Interest'],
      ['Inquiry Source', es ? 'Fuente de Consulta' : 'Inquiry Source'],
      ['Your Name (Partner)', es ? 'Tu Nombre (Socio)' : 'Your Name (Partner)'],
      ['Message / Notes', es ? 'Mensaje / Notas' : 'Message / Notes'],
    ]);
    translatePlaceholders('#inquiry-form', lang, [
      ['inq-cust-name', es ? 'Nombre completo del cliente' : "Customer's full name"],
      ['inq-cust-email', es ? 'cliente@ejemplo.com' : 'customer@example.com'],
      ['inq-cust-phone', es ? '(555) 123-4567' : '(555) 123-4567'],
      ['inq-vehicle', es ? 'ej., 2019 Honda Civic Sport, azul' : 'e.g., 2019 Honda Civic Sport, blue'],
      ['inq-partner', es ? 'Tu nombre' : 'Your name'],
      ['inq-message', es ? 'Cualquier detalle adicional sobre este cliente o su interés...' : 'Any additional details about this customer or their interest...'],
    ]);
    translateSelectById('inq-source', lang, [
      ['', es ? '— Selecciona —' : '— Select —'],
      ['facebook', es ? 'Facebook Marketplace' : 'Facebook Marketplace'],
      ['craigslist', es ? 'Craigslist' : 'Craigslist'],
      ['offerup', es ? 'OfferUp' : 'OfferUp'],
      ['referral', es ? 'Referido' : 'Referral'],
      ['website', es ? 'Sitio Web' : 'Website'],
      ['other', es ? 'Otro' : 'Other'],
    ]);
    translateButtonsByContainer('#inquiry-form', lang, [
      ['Submit Inquiry', es ? 'Enviar Consulta' : 'Submit Inquiry'],
    ]);

    // ---- MARKETING SUPPORT FORM ----
    translateFormLabels('#marketing-form', lang, [
      ['Content Type', es ? 'Tipo de Contenido' : 'Content Type'],
      ['Description', es ? 'Descripción' : 'Description'],
      ['Deadline', es ? 'Fecha Límite' : 'Deadline'],
      ['Your Name', es ? 'Tu Nombre' : 'Your Name'],
      ['Your Email', es ? 'Tu Correo' : 'Your Email'],
    ]);
    translatePlaceholders('#marketing-form', lang, [
      ['mkt-description', es ? 'Describe qué necesitas — incluye detalles específicos, info del vehículo o mensajes...' : 'Describe what you need — include any specific details, vehicle info, or messaging you want...'],
      ['mkt-name', es ? 'Nombre completo' : 'Full name'],
      ['mkt-email', es ? 'correo@ejemplo.com' : 'email@example.com'],
    ]);
    translateSelectById('mkt-type', lang, [
      ['', es ? '— Selecciona tipo —' : '— Select type —'],
      ['social_post', es ? 'Publicación en Redes' : 'Social Media Post'],
      ['listing_photos', es ? 'Fotos / Gráficos de Listado' : 'Listing Photos / Graphics'],
      ['video', es ? 'Video Promocional' : 'Promotional Video'],
      ['flyer', es ? 'Volante / Material Impreso' : 'Flyer / Print Material'],
      ['branding', es ? 'Ayuda con Marca / Logo' : 'Branding / Logo Help'],
      ['other', es ? 'Otro' : 'Other'],
    ]);
    translateButtonsByContainer('#marketing-form', lang, [
      ['Submit Request', es ? 'Enviar Solicitud' : 'Submit Request'],
    ]);

    // ---- DEAL PIPELINE LABELS ----
    const pipeLabels = document.querySelectorAll('.pipe-label');
    const pipeMap = {
      'Submitted': es ? 'Enviados' : 'Submitted',
      'Reviewed': es ? 'Revisados' : 'Reviewed',
      'Closed': es ? 'Cerrados' : 'Closed',
      'Paid': es ? 'Pagados' : 'Paid',
      'Enviados': 'Submitted',
      'Revisados': 'Reviewed',
      'Cerrados': 'Closed',
      'Pagados': 'Paid',
    };
    pipeLabels.forEach(el => {
      const txt = el.textContent.trim();
      if (pipeMap[txt]) el.textContent = pipeMap[txt];
    });
  }

  function applyGameSection(lang) {
    const es = lang === 'es';
    // AI placeholder
    const gameInput = document.getElementById('game-ai-input');
    if (gameInput) gameInput.placeholder = es ? ES.game_ai_ph : 'Ask Byrd Dawg anything...';
    // Byrd Dawg toggle button
    const gameBtn = document.querySelector('button[onclick="toggleGameAiPanel()"]');
    if (gameBtn) gameBtn.textContent = es ? ES.btn_byrd_dawg : '🦅 Byrd Dawg';
  }

  // ============================
  // Helper Functions
  // ============================

  // Translate labels within a container by matching text
  function translateFormLabels(containerSel, lang, pairs) {
    const container = document.querySelector(containerSel);
    if (!container) return;
    const labels = container.querySelectorAll('label');
    labels.forEach(label => {
      // Get first text node content (ignores child spans/inputs)
      let firstText = '';
      for (let node of label.childNodes) {
        if (node.nodeType === Node.TEXT_NODE) {
          firstText = node.textContent.trim();
          if (firstText) break;
        }
      }
      // Remove * suffix for matching
      const cleanText = firstText.replace(/\s*\*\s*$/, '').trim();
      for (const [en, tr] of pairs) {
        const cleanEn = en.replace(/\s*\*\s*$/, '').trim();
        if (cleanText === cleanEn || cleanText === tr.replace(/\s*\*\s*$/, '').trim()) {
          // Update first text node
          for (let node of label.childNodes) {
            if (node.nodeType === Node.TEXT_NODE && node.textContent.trim()) {
              const hasStar = node.textContent.includes('*');
              node.textContent = tr + (hasStar ? ' * ' : ' ');
              break;
            }
          }
          break;
        }
      }
    });
  }

  // Translate placeholders by element IDs
  function translatePlaceholders(containerSel, lang, idPairs) {
    for (const [id, text] of idPairs) {
      const el = document.getElementById(id);
      if (el) el.placeholder = text;
    }
  }

  // Translate select options by element ID using value mapping
  function translateSelectById(id, lang, valuePairs) {
    const sel = document.getElementById(id);
    if (!sel) return;
    for (const [value, text] of valuePairs) {
      const option = sel.querySelector(`option[value="${value}"]`);
      if (option) option.textContent = text;
    }
  }

  // Translate buttons within a container by text matching
  function translateButtonsByContainer(containerSel, lang, pairs) {
    const container = document.querySelector(containerSel);
    if (!container) return;
    container.querySelectorAll('button').forEach(btn => {
      const t = btn.textContent.trim();
      for (const [en, tr] of pairs) {
        if (t === en || t === tr) {
          btn.textContent = tr;
          break;
        }
      }
    });
  }

  // Translate stat labels within a container
  function translateStatLabels(containerSel, lang, tuples) {
    const container = document.querySelector(containerSel);
    if (!container) return;
    container.querySelectorAll('.stat-label').forEach(label => {
      const text = label.textContent.trim();
      for (const [en, enTr, subEn, subTr] of tuples) {
        if (text === en || text === enTr) {
          label.textContent = enTr;
          // Find sibling stat-sub
          const parent = label.parentElement;
          if (parent) {
            const sub = parent.querySelector('.stat-sub');
            if (sub) sub.textContent = subTr;
          }
          break;
        }
      }
    });
  }

  // Translate checkbox labels (labels wrapping checkbox inputs)
  function translateCheckboxLabels(containerSel, lang, textMap) {
    const container = document.querySelector(containerSel);
    if (!container) return;
    container.querySelectorAll('label').forEach(label => {
      const input = label.querySelector('input[type="checkbox"]');
      if (!input) return;
      // Get text node (last text node after checkbox)
      for (let node of label.childNodes) {
        if (node.nodeType === Node.TEXT_NODE) {
          const text = node.textContent.trim();
          if (text && textMap[text]) {
            node.textContent = ' ' + textMap[text];
            break;
          }
        }
      }
    });
  }

  // ============================
  // Public API
  // ============================

  window.i18n = {
    getLang,
    setLang,
    apply: function(lang) {
      if (lang) setLang(lang);
      applyDirect(getLang());
    },
    toggle: function() {
      const next = getLang() === 'en' ? 'es' : 'en';
      setLang(next);
      applyDirect(next);
    }
  };

  // Auto-apply on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
      applyDirect(getLang());
    });
  } else {
    applyDirect(getLang());
  }

})();
