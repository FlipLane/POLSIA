/**
 * FlipLane — Shared Navigation Bar
 * Injects a unified nav across all public pages.
 * Hides old nav elements via JS (no HTML edits needed).
 *
 * Layout:
 *   LEFT:   FLIPLANE logo → /
 *   CENTER: Buyer Lane → /buy | Co-op Partner → /join?lane=coop | Affiliate Lane → /earn
 *   RIGHT:  ByrddawgsOS → /byrddawgsos.html | AffiliateOS → /affiliateos.html | EN|ES toggle
 */

(function () {
  'use strict';

  // ─── Config ───────────────────────────────────────────────────────────────

  var LINKS_CENTER = [
    { label: { en: 'Buyer Lane',      es: 'Carril Comprador' }, href: '/buy' },
    { label: { en: 'Co-op Partner',   es: 'Socio Co-op'     }, href: '/join?lane=coop' },
    { label: { en: 'Affiliate Lane',  es: 'Carril Afiliado'  }, href: '/earn' },
  ];

  var LINKS_RIGHT = [
    { label: { en: 'ByrddawgsOS',  es: 'ByrddawgsOS'  }, href: '/byrddawgsos.html' },
    { label: { en: 'AffiliateOS',  es: 'AffiliateOS'  }, href: '/affiliateos.html' },
  ];

  // ─── Language helpers ─────────────────────────────────────────────────────

  function getLang() {
    try { return localStorage.getItem('fl_lang') || 'en'; } catch (e) { return 'en'; }
  }

  function setLang(l) {
    try { localStorage.setItem('fl_lang', l); } catch (e) {}
  }

  function t(obj) {
    var lang = getLang();
    return obj[lang] || obj['en'];
  }

  // ─── Active-link detection ────────────────────────────────────────────────

  function isActive(href) {
    var path = window.location.pathname;
    if (href === '/buy'  && path === '/buy')  return true;
    if (href === '/earn' && path === '/earn') return true;
    if (href.indexOf('/join') === 0 && path === '/join') return true;
    return false;
  }

  // ─── CSS ─────────────────────────────────────────────────────────────────

  var CSS = [
    '#fl-shared-nav {',
    '  position: fixed;',
    '  top: 0; left: 0; right: 0;',
    '  z-index: 9999;',
    '  display: flex;',
    '  align-items: center;',
    '  justify-content: space-between;',
    '  height: 56px;',
    '  padding: 0 24px;',
    '  background: rgba(5, 5, 5, 0.97);',
    '  border-bottom: 1px solid rgba(0, 255, 65, 0.18);',
    '  backdrop-filter: blur(12px);',
    '  -webkit-backdrop-filter: blur(12px);',
    '  font-family: "Orbitron", "Share Tech Mono", monospace;',
    '}',

    '#fl-shared-nav .fl-nav-logo {',
    '  text-decoration: none;',
    '  font-weight: 800;',
    '  font-size: 1.15rem;',
    '  letter-spacing: 0.08em;',
    '  color: #e8ffe8;',
    '  white-space: nowrap;',
    '  flex-shrink: 0;',
    '}',

    '#fl-shared-nav .fl-nav-logo .flip { color: #e8ffe8; }',
    '#fl-shared-nav .fl-nav-logo .lane { color: #00ff41; text-shadow: 0 0 8px rgba(0,255,65,0.5); }',

    '#fl-shared-nav .fl-nav-center {',
    '  display: flex;',
    '  gap: 6px;',
    '  align-items: center;',
    '  flex: 1;',
    '  justify-content: center;',
    '}',

    '#fl-shared-nav .fl-nav-center a {',
    '  text-decoration: none;',
    '  color: rgba(232,255,232,0.72);',
    '  font-size: 0.68rem;',
    '  letter-spacing: 0.06em;',
    '  text-transform: uppercase;',
    '  padding: 5px 10px;',
    '  border-radius: 3px;',
    '  border: 1px solid transparent;',
    '  transition: color 0.2s, border-color 0.2s;',
    '  white-space: nowrap;',
    '}',

    '#fl-shared-nav .fl-nav-center a:hover {',
    '  color: #00ff41;',
    '  border-color: rgba(0,255,65,0.3);',
    '}',

    '#fl-shared-nav .fl-nav-center a.fl-active {',
    '  color: #00ff41;',
    '  border-color: rgba(0,255,65,0.4);',
    '  background: rgba(0,255,65,0.07);',
    '}',

    '#fl-shared-nav .fl-nav-right {',
    '  display: flex;',
    '  gap: 6px;',
    '  align-items: center;',
    '  flex-shrink: 0;',
    '}',

    '#fl-shared-nav .fl-nav-right a {',
    '  text-decoration: none;',
    '  font-size: 0.63rem;',
    '  letter-spacing: 0.05em;',
    '  text-transform: uppercase;',
    '  color: rgba(232,255,232,0.55);',
    '  padding: 4px 9px;',
    '  border: 1px solid rgba(0,255,65,0.2);',
    '  border-radius: 3px;',
    '  white-space: nowrap;',
    '  transition: color 0.2s, border-color 0.2s, background 0.2s;',
    '}',

    '#fl-shared-nav .fl-nav-right a:hover {',
    '  color: #00ff41;',
    '  border-color: rgba(0,255,65,0.5);',
    '  background: rgba(0,255,65,0.08);',
    '}',

    '#fl-shared-nav .fl-lang-toggle {',
    '  display: flex;',
    '  align-items: center;',
    '  gap: 2px;',
    '  font-size: 0.63rem;',
    '  letter-spacing: 0.08em;',
    '  color: rgba(232,255,232,0.5);',
    '  cursor: pointer;',
    '  user-select: none;',
    '  border: 1px solid rgba(0,255,65,0.15);',
    '  border-radius: 3px;',
    '  padding: 4px 8px;',
    '  transition: color 0.2s, border-color 0.2s;',
    '}',

    '#fl-shared-nav .fl-lang-toggle:hover { color: #00ff41; border-color: rgba(0,255,65,0.4); }',

    '#fl-shared-nav .fl-lang-toggle .fl-lang-en,',
    '#fl-shared-nav .fl-lang-toggle .fl-lang-es {',
    '  transition: color 0.2s;',
    '}',

    '#fl-shared-nav .fl-lang-toggle.fl-lang-is-en .fl-lang-en { color: #00ff41; }',
    '#fl-shared-nav .fl-lang-toggle.fl-lang-is-es .fl-lang-es { color: #00ff41; }',

    '#fl-shared-nav .fl-lang-sep { opacity: 0.35; margin: 0 2px; }',

    /* Hamburger — mobile only */
    '#fl-shared-nav .fl-nav-hamburger {',
    '  display: none;',
    '  flex-direction: column;',
    '  gap: 5px;',
    '  cursor: pointer;',
    '  padding: 6px;',
    '  border: none;',
    '  background: none;',
    '}',

    '#fl-shared-nav .fl-nav-hamburger span {',
    '  display: block;',
    '  width: 22px;',
    '  height: 2px;',
    '  background: rgba(0,255,65,0.7);',
    '  border-radius: 2px;',
    '  transition: all 0.25s;',
    '}',

    /* Mobile drawer */
    '#fl-shared-nav .fl-nav-mobile-menu {',
    '  display: none;',
    '  position: fixed;',
    '  top: 56px;',
    '  left: 0; right: 0;',
    '  background: rgba(5,5,5,0.98);',
    '  border-bottom: 1px solid rgba(0,255,65,0.2);',
    '  padding: 16px 24px 20px;',
    '  flex-direction: column;',
    '  gap: 10px;',
    '  z-index: 9998;',
    '}',

    '#fl-shared-nav .fl-nav-mobile-menu.open { display: flex; }',

    '#fl-shared-nav .fl-nav-mobile-menu a {',
    '  text-decoration: none;',
    '  color: rgba(232,255,232,0.75);',
    '  font-size: 0.82rem;',
    '  letter-spacing: 0.06em;',
    '  text-transform: uppercase;',
    '  padding: 8px 4px;',
    '  border-bottom: 1px solid rgba(0,255,65,0.1);',
    '  transition: color 0.2s;',
    '}',

    '#fl-shared-nav .fl-nav-mobile-menu a:last-child { border-bottom: none; }',
    '#fl-shared-nav .fl-nav-mobile-menu a:hover { color: #00ff41; }',
    '#fl-shared-nav .fl-nav-mobile-menu .fl-mobile-lang {',
    '  margin-top: 4px;',
    '  font-size: 0.75rem;',
    '  color: rgba(0,255,65,0.6);',
    '  cursor: pointer;',
    '  letter-spacing: 0.1em;',
    '}',

    /* Push page content below fixed nav */
    'body.fl-nav-injected { padding-top: 56px !important; }',

    /* Responsive */
    '@media (max-width: 700px) {',
    '  #fl-shared-nav .fl-nav-center { display: none; }',
    '  #fl-shared-nav .fl-nav-right  { display: none; }',
    '  #fl-shared-nav .fl-nav-hamburger { display: flex; }',
    '}',
  ].join('\n');

  // ─── DOM builders ─────────────────────────────────────────────────────────

  function buildLogo() {
    var a = document.createElement('a');
    a.href = '/';
    a.className = 'fl-nav-logo';
    a.innerHTML = '<span class="flip">FLIP</span><span class="lane">LANE</span>';
    return a;
  }

  function buildCenter() {
    var wrap = document.createElement('div');
    wrap.className = 'fl-nav-center';
    LINKS_CENTER.forEach(function (link) {
      var a = document.createElement('a');
      a.href = link.href;
      a.textContent = t(link.label);
      a.setAttribute('data-fl-link', JSON.stringify(link.label));
      if (isActive(link.href)) a.classList.add('fl-active');
      wrap.appendChild(a);
    });
    return wrap;
  }

  function buildRight(mobileMenu) {
    var wrap = document.createElement('div');
    wrap.className = 'fl-nav-right';

    LINKS_RIGHT.forEach(function (link) {
      var a = document.createElement('a');
      a.href = link.href;
      a.textContent = t(link.label);
      a.setAttribute('data-fl-link', JSON.stringify(link.label));
      wrap.appendChild(a);
    });

    // Lang toggle
    var toggle = buildLangToggle(mobileMenu);
    wrap.appendChild(toggle);
    return wrap;
  }

  function buildLangToggle(mobileMenu) {
    var lang = getLang();
    var div = document.createElement('div');
    div.className = 'fl-lang-toggle fl-lang-is-' + lang;
    div.setAttribute('role', 'button');
    div.setAttribute('aria-label', 'Toggle language');
    div.innerHTML =
      '<span class="fl-lang-en">EN</span>' +
      '<span class="fl-lang-sep">|</span>' +
      '<span class="fl-lang-es">ES</span>';
    div.addEventListener('click', function () {
      var current = getLang();
      var next = current === 'en' ? 'es' : 'en';
      setLang(next);
      applyLang(next, mobileMenu);
    });
    return div;
  }

  function buildHamburger() {
    var btn = document.createElement('button');
    btn.className = 'fl-nav-hamburger';
    btn.setAttribute('aria-label', 'Open menu');
    btn.innerHTML = '<span></span><span></span><span></span>';
    return btn;
  }

  function buildMobileMenu() {
    var div = document.createElement('div');
    div.className = 'fl-nav-mobile-menu';

    var allLinks = LINKS_CENTER.concat(LINKS_RIGHT);
    allLinks.forEach(function (link) {
      var a = document.createElement('a');
      a.href = link.href;
      a.textContent = t(link.label);
      a.setAttribute('data-fl-link', JSON.stringify(link.label));
      div.appendChild(a);
    });

    // Mobile lang toggle label
    var langLabel = document.createElement('div');
    langLabel.className = 'fl-mobile-lang';
    langLabel.id = 'fl-mobile-lang-btn';
    langLabel.textContent = getLang() === 'en' ? '[ Español ]' : '[ English ]';
    langLabel.addEventListener('click', function () {
      var current = getLang();
      var next = current === 'en' ? 'es' : 'en';
      setLang(next);
      applyLang(next, div);
    });
    div.appendChild(langLabel);

    return div;
  }

  // ─── Language application ─────────────────────────────────────────────────

  function applyLang(lang, mobileMenu) {
    // Update nav links text
    var nav = document.getElementById('fl-shared-nav');
    if (!nav) return;

    nav.querySelectorAll('[data-fl-link]').forEach(function (el) {
      try {
        var labels = JSON.parse(el.getAttribute('data-fl-link'));
        el.textContent = labels[lang] || labels['en'];
      } catch (e) {}
    });

    // Update lang toggle class
    var toggle = nav.querySelector('.fl-lang-toggle');
    if (toggle) {
      toggle.classList.remove('fl-lang-is-en', 'fl-lang-is-es');
      toggle.classList.add('fl-lang-is-' + lang);
    }

    // Update mobile lang label
    var mLang = document.getElementById('fl-mobile-lang-btn');
    if (mLang) {
      mLang.textContent = lang === 'en' ? '[ Español ]' : '[ English ]';
    }

    // Notify i18n.js if it's loaded (it handles page content)
    if (typeof window.setLanguage === 'function') {
      try { window.setLanguage(lang); } catch (e) {}
    } else if (typeof window.toggleLanguage === 'function') {
      try {
        var current = getLang();
        if (current !== lang) window.toggleLanguage();
      } catch (e) {}
    }
  }

  // ─── Hide old navs ────────────────────────────────────────────────────────

  function hideOldNavs() {
    var selectors = [
      '.nav-wrap',          // buy, earn, apply, about, login pages
      '#main-nav',          // homepage
      '.picker-header',     // join page lane picker header
      '.site-nav',          // potential other variant
    ];

    selectors.forEach(function (sel) {
      try {
        document.querySelectorAll(sel).forEach(function (el) {
          el.style.setProperty('display', 'none', 'important');
        });
      } catch (e) {}
    });

    // Also remove top padding that old navs used to push content down
    // (we set our own via body.fl-nav-injected)
    try {
      var body = document.body;
      var pt = parseInt(window.getComputedStyle(body).paddingTop, 10);
      // Only reset if it was set by old nav (common values: 56px, 64px, 72px, 88px)
      // We handle padding ourselves via .fl-nav-injected
    } catch (e) {}
  }

  // ─── Inject ───────────────────────────────────────────────────────────────

  function inject() {
    // Don't inject on admin pages
    var path = window.location.pathname;
    var skip = ['/admin', '/admin-login', '/admin-blog', '/affiliateos', '/byrddawgsos', '/dashboard', '/login', '/welcome', '/payment-success', '/unsubscribe', '/game'];
    for (var i = 0; i < skip.length; i++) {
      if (path === skip[i] || path.indexOf(skip[i] + '.html') !== -1 || path.indexOf(skip[i] + '/') === 0) {
        return;
      }
    }
    // Also skip if already injected (double-script guard)
    if (document.getElementById('fl-shared-nav')) return;

    // Inject CSS
    var style = document.createElement('style');
    style.id = 'fl-shared-nav-css';
    style.textContent = CSS;
    document.head.appendChild(style);

    // Build mobile menu first (needed as ref in right)
    var mobileMenu = buildMobileMenu();

    // Build nav element
    var nav = document.createElement('nav');
    nav.id = 'fl-shared-nav';
    nav.setAttribute('role', 'navigation');
    nav.setAttribute('aria-label', 'FlipLane main navigation');

    var logo = buildLogo();
    var center = buildCenter();
    var right = buildRight(mobileMenu);
    var hamburger = buildHamburger();

    nav.appendChild(logo);
    nav.appendChild(center);
    nav.appendChild(right);
    nav.appendChild(hamburger);
    nav.appendChild(mobileMenu);

    // Insert as first child of body
    var body = document.body;
    if (body.firstChild) {
      body.insertBefore(nav, body.firstChild);
    } else {
      body.appendChild(nav);
    }

    // Add body class for padding
    body.classList.add('fl-nav-injected');

    // Wire hamburger
    hamburger.addEventListener('click', function () {
      mobileMenu.classList.toggle('open');
    });

    // Hide old navs
    hideOldNavs();

    // Also hide old navs after a short delay (for dynamically rendered pages)
    setTimeout(hideOldNavs, 200);
    setTimeout(hideOldNavs, 600);
  }

  // ─── Boot ─────────────────────────────────────────────────────────────────

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', inject);
  } else {
    inject();
  }

})();
