// ============================================================
// DEAL SUBMISSIONS - Admin Functionality
// ============================================================

let _deals = [];

function loadDeals() {
  if (_loadedTabs.has('deals')) return;
  _loadedTabs.add('deals');

  const statusFilter = document.getElementById('deals-status-filter')?.value || '';
  const search = document.getElementById('deals-search')?.value || '';

  document.getElementById('deals-loading').style.display = 'block';
  document.getElementById('deals-table-wrap').style.display = 'none';

  const queryParams = new URLSearchParams();
  if (statusFilter) queryParams.append('status', statusFilter);
  if (search) queryParams.append('search', search);
  queryParams.append('limit', '100');

  api(`/api/admin/deal-submissions?${queryParams.toString()}`).then(data => {
    document.getElementById('deals-loading').style.display = 'none';
    document.getElementById('deals-table-wrap').style.display = 'block';
    if (!data.success) { showToast('Failed to load deals', 'error'); return; }
    _deals = data.deals;
    document.getElementById('deals-count-label').textContent = `${data.total} deal${data.total !== 1 ? 's' : ''}`;
    renderDealsTable(_deals);
  });
}

function filterDealRows() {
  const search = document.getElementById('deals-search').value.toLowerCase();
  const status = document.getElementById('deals-status-filter').value;
  const filtered = _deals.filter(d => {
    const matchesSearch = !search ||
      (d.vehicle_description||'').toLowerCase().includes(search) ||
      (d.vin||'').toLowerCase().includes(search) ||
      (d.affiliate_name||'').toLowerCase().includes(search) ||
      (d.affiliate_email||'').toLowerCase().includes(search);
    const matchesStatus = !status || d.status === status;
    return matchesSearch && matchesStatus;
  });
  renderDealsTable(filtered);
}

function renderDealsTable(deals) {
  const tbody = document.getElementById('deals-tbody');
  if (!deals.length) {
    tbody.innerHTML = `<tr><td colspan="7" class="table-empty">No deals found</td></tr>`;
    return;
  }
  tbody.innerHTML = deals.map(d => {
    const statusClass = d.status === 'submitted' ? 'pending' : d.status === 'reviewed' ? 'active' : d.status === 'closed' ? 'paid' : 'applied';
    const priceDisplay = d.price ? `$${parseFloat(d.price).toLocaleString()}` : '—';
    return `
      <tr>
        <td>
          <div style="font-weight:600">${esc(d.affiliate_name || '?')}</div>
          <div style="font-size:12px;color:var(--text2)">${esc(d.affiliate_email || '')}</div>
          <div style="font-size:11px;color:var(--text3)">${esc(d.referral_code || '')}</div>
        </td>
        <td style="max-width:200px">
          <div style="font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${esc(d.vehicle_description||'')}">${esc(d.vehicle_description || '?')}</div>
          ${d.vin ? `<div style="font-size:11px;color:var(--text3)">VIN: ${esc(d.vin)}</div>` : ''}
        </td>
        <td style="font-weight:600">${priceDisplay}</td>
        <td>
          ${d.source_name ? `<div>${esc(d.source_name)}</div>` : ''}
          ${d.source_url ? `<a href="${esc(d.source_url)}" target="_blank" style="font-size:11px;color:var(--accent)">Link ↗</a>` : ''}
        </td>
        <td><span class="badge badge-${statusClass}">${d.status || '—'}</span></td>
        <td style="font-size:12px;color:var(--text2)">${fmtDateTime(d.created_at)}</td>
        <td><button class="btn btn-sm btn-ghost" onclick="openDealPanel(${d.id})">View</button></td>
      </tr>
    `;
  }).join('');
}

function openDealPanel(dealId) {
  const deal = _deals.find(d => d.id === dealId);
  if (!deal) return;

  document.getElementById('deal-panel-title').textContent = deal.vehicle_description?.substring(0, 40) || 'Deal Details';
  document.getElementById('deal-panel-sub').textContent = `${deal.affiliate_name || 'Unknown'} · ${fmtDateTime(deal.created_at)}`;

  const priceDisplay = deal.price ? `$${parseFloat(deal.price).toLocaleString()}` : 'Not specified';

  const panelBody = document.getElementById('deal-panel-body');
  panelBody.innerHTML = `
    <div style="display:grid;gap:16px">
      <div class="detail-row">
        <div class="detail-label">Status</div>
        <div class="detail-value">
          <select id="deal-status-select" onchange="updateDealStatus(${deal.id}, this.value)" style="background:var(--surface2);border:1px solid var(--border);color:var(--text);padding:6px 10px;border-radius:6px;font-size:14px">
            <option value="submitted" ${deal.status === 'submitted' ? 'selected' : ''}>Submitted</option>
            <option value="reviewed" ${deal.status === 'reviewed' ? 'selected' : ''}>Reviewed</option>
            <option value="closed" ${deal.status === 'closed' ? 'selected' : ''}>Closed</option>
          </select>
        </div>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
        <div class="detail-row">
          <div class="detail-label">Affiliate</div>
          <div class="detail-value">
            <div style="font-weight:600">${esc(deal.affiliate_name || '?')}</div>
            <div style="font-size:13px;color:var(--text2)">${esc(deal.affiliate_email || '')}</div>
            <div style="font-size:12px;color:var(--text3)">Ref: ${esc(deal.referral_code || '—')}</div>
          </div>
        </div>
        <div class="detail-row">
          <div class="detail-label">Price</div>
          <div class="detail-value" style="font-size:18px;font-weight:700">${priceDisplay}</div>
        </div>
      </div>

      <div class="detail-row">
        <div class="detail-label">Vehicle Description</div>
        <div class="detail-value">${esc(deal.vehicle_description || '—')}</div>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
        <div class="detail-row">
          <div class="detail-label">VIN</div>
          <div class="detail-value" style="font-family:monospace;font-size:14px">${esc(deal.vin || '—')}</div>
        </div>
        <div class="detail-row">
          <div class="detail-label">Source</div>
          <div class="detail-value">
            ${deal.source_name ? `<div>${esc(deal.source_name)}</div>` : '<div style="color:var(--text3)">—</div>'}
            ${deal.source_url ? `<a href="${esc(deal.source_url)}" target="_blank" style="font-size:12px;color:var(--accent)">${esc(deal.source_url).substring(0, 40)}… ↗</a>` : ''}
          </div>
        </div>
      </div>

      <div class="detail-row">
        <div class="detail-label">Notes</div>
        <div class="detail-value" style="white-space:pre-wrap;font-size:13px;color:var(--text2)">${esc(deal.notes || 'No notes')}</div>
      </div>

      <div class="detail-row">
        <div class="detail-label">Admin Notes</div>
        <textarea id="deal-admin-notes" placeholder="Add notes about this deal…" onblur="saveDealAdminNotes(${deal.id}, this.value)" style="width:100%;background:var(--surface2);border:1px solid var(--border);color:var(--text);padding:10px;border-radius:8px;font-size:14px;min-height:80px;resize:vertical">${esc(deal.admin_notes || '')}</textarea>
      </div>

      <div class="detail-row">
        <div class="detail-label">Commission</div>
        <div style="display:flex;gap:8px;align-items:center">
          <span style="font-size:18px;font-weight:700">$</span>
          <input type="number" id="deal-commission-input" value="${deal.commission_amount || ''}" placeholder="0.00" step="0.01" min="0" style="background:var(--surface2);border:1px solid var(--border);color:var(--text);padding:8px 12px;border-radius:6px;font-size:16px;width:120px">
          <button class="btn btn-sm btn-primary" onclick="updateDealCommission(${deal.id})">Set</button>
        </div>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;font-size:12px;color:var(--text2)">
        <div>Submitted<br><strong style="color:var(--text)">${fmtDateTime(deal.created_at)}</strong></div>
        <div>Reviewed<br><strong style="color:var(--text)">${deal.reviewed_at ? fmtDateTime(deal.reviewed_at) : '—'}</strong></div>
        <div>Closed<br><strong style="color:var(--text)">${deal.closed_at ? fmtDateTime(deal.closed_at) : '—'}</strong></div>
      </div>
    </div>
  `;

  document.getElementById('deal-panel-overlay').style.display = 'flex';
}

function closeDealPanel(event) {
  if (event && event.target !== event.currentTarget) return;
  document.getElementById('deal-panel-overlay').style.display = 'none';
}

async function updateDealStatus(dealId, status) {
  try {
    const res = await api(`/api/admin/deal-submissions/${dealId}`, {
      method: 'PATCH',
      body: JSON.stringify({ status })
    });
    if (res.success) {
      showToast('Status updated', 'success');
      const deal = _deals.find(d => d.id === dealId);
      if (deal) {
        deal.status = status;
        deal.updated_at = new Date().toISOString();
        if (status === 'reviewed') deal.reviewed_at = new Date().toISOString();
        if (status === 'closed') deal.closed_at = new Date().toISOString();
      }
      renderDealsTable(_deals);
    } else {
      showToast(res.message || 'Failed to update status', 'error');
    }
  } catch (err) {
    showToast('Error updating status', 'error');
  }
}

async function updateDealCommission(dealId) {
  const input = document.getElementById('deal-commission-input');
  const amount = parseFloat(input.value);

  if (isNaN(amount) || amount < 0) {
    showToast('Please enter a valid amount', 'error');
    return;
  }

  try {
    const res = await api(`/api/admin/deal-submissions/${dealId}`, {
      method: 'PATCH',
      body: JSON.stringify({ commission_amount: amount })
    });
    if (res.success) {
      showToast('Commission updated', 'success');
      const deal = _deals.find(d => d.id === dealId);
      if (deal) deal.commission_amount = amount;
    } else {
      showToast(res.message || 'Failed to update commission', 'error');
    }
  } catch (err) {
    showToast('Error updating commission', 'error');
  }
}

async function saveDealAdminNotes(dealId, notes) {
  try {
    await api(`/api/admin/deal-submissions/${dealId}`, {
      method: 'PATCH',
      body: JSON.stringify({ admin_notes: notes })
    });
    const deal = _deals.find(d => d.id === dealId);
    if (deal) deal.admin_notes = notes;
  } catch (err) {}
}