/**
 * FlipLane i18n Framework
 * EN/ES language switching for the member portal.
 * Usage: add data-i18n="key" to any element; for placeholders data-i18n-placeholder="key"
 * Dynamic strings: window.t('key') returns the translated string
 */

const FLIPLANE_TRANSLATIONS = {
  en: {
    // ── Navigation ───────────────────────────────────────────────
    nav_phone:        '📞 855-5FLIPLANE',
    nav_apply:        'Apply Now',
    nav_login:        'Member Login',
    nav_dashboard:    'Member Dashboard',

    // ── Footer ───────────────────────────────────────────────────
    footer_location:  'Atlanta, GA',
    footer_phone:     '📞 855-5FLIPLANE',
    footer_email:     '✉️ win@fliplane.net',

    // ── Dashboard ────────────────────────────────────────────────
    dash_title:             'Member Dashboard',
    dash_subtitle:          'Enter your email to check your membership status',
    dash_email_placeholder: 'Your email address',
    dash_check_btn:         'Check Status',
    dash_loading:           'Loading your dashboard...',
    dash_redirecting:       'Redirecting to ByrddawgsOS...',
    dash_welcome_back:      'Welcome back',
    dash_label_applied:     'Applied',
    dash_label_status:      'Status',
    dash_error_network:     'Network error. Please try again.',
    dash_error_notfound:    'No application found for this email. Apply now →',

    // Member action cards
    dash_pay_heading:  'Complete your membership',
    dash_pay_desc:     'Pay the $250 membership fee to activate your dealer group access.',
    dash_pay_btn:      'Pay $250 — Activate Now',
    dash_cert_heading: 'One step left — complete certification',
    dash_cert_desc:    'Your payment is confirmed! Complete the quick co-op certification (under 5 minutes) to unlock your full dashboard.',
    dash_cert_btn:     'Start Certification →',

    // Status badges
    status_certified:   'Certified Member',
    status_cert_pend:   'Certification Pending',
    status_pay_pend:    'Payment Pending',
    status_await_pay:   'Awaiting Payment',
    status_applied:     'Applied',

    // ── Join Flow (join.html) ────────────────────────────────────
    join_step_apply:     'Apply',
    join_step_agreement: 'Agreement',
    join_step_payment:   'Payment',
    join_step_verify:    'Verify ID',
    join_step1_badge:    'Step 1 of 4',
    join_step2_badge:    'Step 2 of 4',
    join_step3_badge:    'Step 3 of 4',
    join_final_badge:    'Final Step',

    // Step 1 — Application form
    join_s1_h1:          'Join FlipLane Co-op',
    join_s1_sub:         'Tell us about yourself to get started.',
    join_s1_price_desc:  'One-time membership. Access dealer auctions, AI tools, training, and the full FlipLane system — for life.',
    join_label_name:     'Full Name *',
    join_ph_name:        'Your full legal name',
    join_label_email:    'Email Address *',
    join_ph_email:       'you@example.com',
    join_label_phone:    'Phone Number',
    join_ph_phone:       '+1 (555) 000-0000',
    join_label_exp:      'Car Experience',
    join_exp_default:    'Select your background',
    join_exp_none:       'No prior experience',
    join_exp_few:        'Bought/sold a few personal cars',
    join_exp_some:       'Some dealer or wholesale experience',
    join_exp_pro:        'Experienced dealer / wholesaler',
    join_exp_hint:       'Helps us tailor your onboarding.',
    join_s1_btn:         'Continue to Agreement →',
    join_err_generic:    'Something went wrong. Please try again.',
    join_err_network:    'Network error. Please check your connection and try again.',

    // Step 2 — Agreement
    join_s2_h1:          'Membership Agreement',
    join_s2_sub:         'Read and accept the FlipLane Co-op membership terms before proceeding.',
    join_s2_scroll_hint: '↓ Scroll to the bottom to enable acceptance',
    join_s2_read_done:   '✓ You\'ve read the full agreement',
    join_s2_agree_title: 'FlipLane Co-op Membership Agreement — Version 1.0',
    join_s2_sec1:        '1. Membership & Access',
    join_s2_sec2:        '2. Confidentiality',
    join_s2_sec3:        '3. Representations & Warranties',
    join_s2_sec4:        '4. Limitations of Liability',
    join_s2_sec5:        '5. Dispute Resolution',
    join_s2_sec6:        '6. Termination',
    join_s2_sec7:        '7. Governing Law',
    join_s2_checkbox:    'I have read the FlipLane Co-op Membership Agreement in full and agree to all terms and conditions. I understand this is a binding legal agreement.',
    join_s2_btn:         'Accept Agreement & Continue →',
    join_s2_err:         'Failed to save agreement. Please try again.',

    // Step 3 — Payment
    join_s3_h1:           'Complete Your Payment',
    join_s3_sub:          'You\'re almost a member. One payment away from full access.',
    join_s3_check1:       'Application submitted',
    join_s3_check2:       'Membership agreement signed',
    join_s3_check3:       'Complete payment',
    join_tab_card:        '💳 Pay with Card',
    join_tab_manual:      '📲 Pay Manually',
    join_stripe_label:    'FlipLane Co-op Membership',
    join_stripe_type:     'One-time, no recurring fees',
    join_stripe_type_lbl: 'Type',
    join_stripe_total:    'Total Due Today',
    join_promo_show:      'Have a promo code?',
    join_promo_hide:      'Hide promo code',
    join_promo_ph:        'ENTER CODE',
    join_promo_apply:     'Apply',
    join_promo_empty:     'Please enter a promo code.',
    join_promo_session:   'Session error — please reload and try again.',
    join_promo_success:   '✓ Code applied! Redirecting…',
    join_promo_invalid:   'Invalid promo code.',
    join_err_network2:    'Network error. Please try again.',
    join_stripe_cta:      'Click below to complete your secure $250 payment and activate your membership.',
    join_stripe_btn:      'Pay $250 — Activate Membership →',
    join_stripe_secure:   '🔒 Powered by Stripe · Secure 256-bit SSL encryption',
    join_manual_ref_lbl:  'Your Order / Reference Number',
    join_manual_loading:  'Loading…',
    join_manual_err:      'Error — reload',
    join_copy_btn:        'Copy',
    join_manual_note:     '📝 Include this Order Number in the Memo / Note field of your payment so we can verify your transaction instantly.',
    join_cashapp_pay:     'Pay $250 →',
    join_cashapp_copy:    'Copy $tag',
    join_venmo_pay:       'Pay $250 →',
    join_venmo_copy:      'Copy handle',
    join_zelle_call:      'Call / Open →',
    join_zelle_copy:      'Copy number',
    join_confirm_btn:     '✓ I\'ve Sent My Payment →',
    join_copied:          '✓ Copied!',
    join_recording:       'Recording…',
    join_pay_pending:     '⏳ Payment pending verification. Your membership activates once we confirm your $250 payment — typically within a few hours. You\'ll receive an email when it\'s approved.',

    // Step 4 — ID Upload
    join_s4_badge:        'Final Step',
    join_s4_h1:           'Verify Your Identity',
    join_s4_sub:          'Upload a government-issued ID to complete your membership activation.',
    join_id_h2:           'Upload Government-Issued ID',
    join_id_drag:         'Drag & drop or click to upload',
    join_id_types:        'JPG · PNG · WebP · PDF · Max 10MB',
    join_id_privacy:      '🔒 Secure & Private. Your ID is encrypted and used solely to verify your identity as required by our membership policy. It is never shared with third parties.',
    join_id_accepted:     'Accepted: Driver\'s License, State ID, Passport, or equivalent government-issued photo ID.',
    join_id_btn:          'Upload ID & Continue →',
    join_id_uploading:    'Uploading…',
    join_id_remove:       'Remove',
    join_id_pay_note:     '⏳ Payment pending verification. Your membership will activate once we confirm your payment. Upload your ID now — we\'ll email you when everything is approved.',
    join_id_err1:         'Upload failed. Please try again.',
    join_id_err2:         'Network error. Please check your connection.',

    // ── Apply Flow (apply.html) ──────────────────────────────────
    apply_step_apply:   'Apply',
    apply_step_verify:  'Verify ID',
    apply_step_payment: 'Payment',

    // Step 1 — Application
    apply_s1_badge:     'Co-op Partner Application',
    apply_s1_h1:        'Join the dealer group',
    apply_s1_sub:       'Fill out your info below. After submitting, you\'ll verify your identity and complete payment.',
    apply_label_name:   'Full Name *',
    apply_ph_name:      'John Smith',
    apply_label_email:  'Email *',
    apply_ph_email:     'john@example.com',
    apply_label_phone:  'Phone',
    apply_ph_phone:     '(555) 123-4567',
    apply_label_exp:    'Car Flipping Experience',
    apply_exp_default:  'Select your experience level',
    apply_exp_0:        'Brand new — never flipped',
    apply_exp_1:        'Beginner — 1-5 flips',
    apply_exp_2:        'Intermediate — 6-20 flips',
    apply_exp_3:        'Experienced — 20+ flips',
    apply_exp_4:        'Already a licensed dealer',
    apply_exp_hint:     'All experience levels welcome',
    apply_price_desc:   'One-time membership fee — due after identity verification. Stripe-secured checkout.',
    apply_s1_btn:       'Continue to ID Verification →',
    apply_submitting:   'Submitting...',
    apply_questions:    'Questions? Call us at 855-5FLIPLANE',
    apply_err1:         'Something went wrong.',
    apply_err2:         'Network error. Please try again.',

    // Step 2 — ID Upload
    apply_s2_badge:     'Identity Verification',
    apply_s2_h1:        'Verify Your Identity',
    apply_s2_sub:       'We verify every member. This protects you and the network — only real operators get access to dealer credentials.',
    apply_id_h2:        'Upload Government-Issued ID',
    apply_id_sub:       'Driver\'s license, state ID, or passport',
    apply_id_types:     'JPG · PNG · PDF · Max 10MB',
    apply_id_privacy:   '🔒 Stored securely. Reviewed by our team only. Your ID is encrypted and used solely to verify membership eligibility. It\'s never shared with third parties and deleted within 90 days of review.',
    apply_id_btn:       'Upload & Continue to Payment →',
    apply_id_uploading: 'Uploading...',
    apply_id_remove:    'Remove',
    apply_id_required:  'You must upload an ID to proceed to payment.',
    apply_id_err1:      'Please upload a JPG, PNG, WebP, or PDF file.',
    apply_id_err2:      'File is too large. Maximum size is 10MB.',
    apply_id_err3:      'Upload failed. Please try again.',
    apply_id_err4:      'Upload failed. Please check your connection and try again.',

    // Step 3 — Payment
    apply_s3_badge:     'Final Step',
    apply_s3_h1:        'Complete your membership',
    apply_s3_sub:       'Application and verification done. One payment to activate your account.',
    apply_almost:       'Almost there.',
    apply_check1:       'Application submitted',
    apply_check2:       'Government ID uploaded',
    apply_check3:       'Complete $250 payment',
    apply_s3_cta:       'Complete your $250 membership payment to activate your account and gain access to ByrddawgsOS.',
    apply_s3_btn:       'Pay $250 — Activate Membership',
    apply_s3_skip:      'Already paid? Check my status →',

    // ── Welcome Page ─────────────────────────────────────────────
    welcome_badge:        '● Membership Active',
    welcome_h1:           'Welcome to FlipLane!',
    welcome_h1_named:     'Welcome, {name}!',
    welcome_active:       'Your membership is active.',
    welcome_sub1:         'Payment confirmed. You\'re officially a co-op partner.',
    welcome_sub2:         'One step stands between you and full access.',
    welcome_next_label:   '⚡ Your next step',
    welcome_cert_title:   'Complete your certification to unlock ByrddawgsOS',
    welcome_cert_desc:    'Read 4 short modules and pass a 5-question quiz — takes about 5 minutes. Instant dashboard access on pass.',
    welcome_cert_btn:     'Start Certification Now →',
    welcome_cert_hint:    'Takes ~5 minutes · Instant access on pass · Unlimited retakes',
    welcome_email_note:   'Check your inbox. We sent a welcome email with your member ID, certification link, and quick-start guide. Also watch for a DocuSign agreement — sign it to complete onboarding.',
    welcome_email_spam:   'Don\'t see it? Check your Spam, Junk, or Promotions folder — it sometimes lands there.',
    welcome_unlock_title: 'What you unlock after certification',
    welcome_feat1_title:  'Dealer Auction Access',
    welcome_feat1_desc:   'Bid on wholesale inventory using our shared dealer credentials.',
    welcome_feat2_title:  'Deal Center',
    welcome_feat2_desc:   'Fix & flip requests, shipping, title & registration — one dashboard.',
    welcome_feat3_title:  'Affiliate Hub',
    welcome_feat3_desc:   'Customer inquiry tools, marketing support, co-op referrals.',
    welcome_feat4_title:  'ByrddawgsOS Dashboard',
    welcome_feat4_desc:   'Full back-office toolkit to run every deal end-to-end.',
    welcome_progress_title: 'Your onboarding progress',
    welcome_prog1_title:  'Applied & paid',
    welcome_prog1_desc:   '$250 membership payment confirmed.',
    welcome_prog2_title:  'Complete certification',
    welcome_prog2_desc:   'Read 4 modules, pass the quiz. Unlocks your dashboard instantly.',
    welcome_prog3_title:  'Sign DocuSign agreement',
    welcome_prog3_desc:   'Protects shared dealer credentials. Check your email.',
    welcome_prog4_title:  'Run your first deal',
    welcome_prog4_desc:   'Submit through ByrddawgsOS. Flat $250 fee per deal. FlipLane handles paperwork.',
    welcome_questions:    'Questions?',
    welcome_phone:        '📞 855-5FLIPLANE',
    welcome_email:        'win@fliplane.net',

    // ── Certification Page ───────────────────────────────────────
    cert_title:           'Co-op Certification',
    cert_badge:           'Co-op Certification',
    cert_progress_label:  'Module {current} of {total}',
    cert_quiz_badge:      'Final Quiz',
    cert_next_btn:        'Next Module →',
    cert_start_quiz:      'Start Quiz →',
    cert_submit_quiz:     'Submit Answers →',
    cert_submitting:      'Submitting…',
    cert_question_label:  'Question {n} of {total}',
    cert_pass_h1:         'Certification Complete! 🎉',
    cert_pass_sub:        'You\'re now a certified FlipLane co-op partner.',
    cert_pass_btn:        'Go to My Dashboard →',
    cert_fail_h1:         'Not quite — try again',
    cert_fail_sub:        'Review the modules and retake the quiz. Unlimited retakes.',
    cert_fail_btn:        'Retake Quiz →',
    cert_err_submit:      'Submission error — please try again.',
    cert_err_network:     'Network error. Please try again.',
    cert_progress_bar:    'Module Progress',
    cert_score_label:     'You scored {score}/{total}',

    // ── Payment Success Page ─────────────────────────────────────
    pay_success_h1:    'Payment Confirmed!',
    pay_success_sub:   'Your FlipLane membership is now active.',
    pay_success_cta:   'Go to My Dashboard →',
    pay_success_note:  'A confirmation email is on its way.',

    // ── Shared Navigation (Landing Pages) ───────────────────────
    nav_home:           'Home',
    nav_buyer:          'Buyer Lane',
    nav_affiliate:      'Affiliate Lane',
    nav_coop:           'Co-op Partner',
    nav_pricing:        'Pricing',
    nav_tools:          'Tools',
    nav_blog:           'Blog',
    nav_playbook:       'Free Playbook',
    nav_terms:          'Terms',
    nav_member_login:   'Member Login',

    // ── Shared Footer ──────────────────────────────────────────
    footer_brand_desc:  'The most transparent, technology-backed automotive co-op in the country.',
    footer_lanes:       'Lanes',
    footer_company:     'Company',
    footer_members:     'Members',
    footer_dashboard:   'Dashboard',
    footer_apply:       'Apply',
    footer_copyright:   '\u00A9 2025 FlipLane \u2014 Powered by Byrd Dawgs Automotive Group',
    footer_tagline:     'Built for hustle, honesty, and $250.',

    // ── Homepage ────────────────────────────────────────────────
    home_badge:             'Co-op Dealership Network \u00B7 Now Accepting Partners',
    home_hero_h1:           'The <span class="green-glow">$250</span> Dealership.',
    home_hero_sub:          'One payment. Full auction access. We handle title, shipping, and backend \u2014 you keep 100% of every deal.',
    home_cta_primary:       'Join the Co-op \u2192',
    home_cta_secondary:     'See Pricing \u2192',
    home_cta_questions:     'Questions?',
    home_cta_call:          'Call us at 855-5FLIPLANE',
    home_lanes_label:       'Choose Your Lane',
    home_lanes_h2:          'Three Lanes. One Platform.',
    home_lanes_sub:         'Choose how you want to win.',
    home_lane1_h3:          'Buyer Lane',
    home_lane1_subtitle:    'Best-Price Vehicle Access',
    home_lane1_p:           'Don\'t waste time dealership hopping. We source, negotiate, and deliver your next vehicle at the best available price.',
    home_lane1_link:        'Find Your Car \u2192',
    home_lane2_h3:          'Affiliate Lane',
    home_lane2_subtitle:    'Free Entry. 50% Commission.',
    home_lane2_p:           'Refer buyers, find deals, create content. Earn 50% commission on every closed opportunity you influence.',
    home_lane2_link:        'Start Earning \u2192',
    home_lane3_h3:          'Co-op Partner Lane',
    home_lane3_subtitle:    '$250 Membership. 100% Profit.',
    home_lane3_p:           'Join our dealer group. Full auction access, title &amp; shipping handled, nationwide transactions. Keep every dollar you make.',
    home_lane3_link:        'Join the Co-op \u2192',
    home_stat1_label:       'Vehicles Moved',
    home_stat2_label:       'Avg Savings',
    home_stat3_label:       'States Covered',
    home_stat4_label:       '$250/Deal Fee',
    home_money_label:       'Crystal Clear Fees',
    home_money_h2:          'How The Money Works',
    home_money_sub:         'No hidden fees. No monthly subscriptions. No surprises. Here\'s every dollar explained.',
    home_fee1_label:        'To Join',
    home_fee1_p:            'One-time membership fee. You\'re in the co-op. Unlock auctions, tools, and nationwide reach. No recurring charges.',
    home_fee2_label:        'Per Deal',
    home_fee2_p:            'Flat processing fee per transaction. Title, compliance, and paperwork \u2014 handled. You keep 100% of the profit on every deal.',
    home_fee3_label:        'Only on Financed Deals',
    home_fee3_p:            'We bring the lender? We split the finance upside. You handle financing yourself? It\'s all yours. Fair and simple.',
    home_comp_old_label:    'Traditional Dealer License',
    home_comp_old_price:    '$15K \u2013 $50K+',
    home_comp_new_label:    'FlipLane Co-op',
    home_unlock_label:      'Your Toolkit',
    home_unlock_h2:         'What You Unlock',
    home_unlock_sub:        'Everything you need to run a real car business. All included with your $250 membership.',
    home_unlock1_h4:        'Dealer Auction Access',
    home_unlock1_p:         'ADESA, OVE, and wholesale channels \u2014 buy below market value',
    home_unlock2_h4:        'Inventory Management',
    home_unlock2_p:         'Track your vehicles, costs, and margins in one place',
    home_unlock3_h4:        'Nationwide Deal Processing',
    home_unlock3_p:         'Title, compliance, and paperwork across all 50 states',
    home_unlock4_h4:        'Shipping Partner Network',
    home_unlock4_p:         'Competitive transport rates to move inventory anywhere',
    home_unlock5_h4:        'CarsForSale Dealer Listing',
    home_unlock5_p:         'List your vehicles on CarsForSale.com as a verified dealer',
    home_unlock6_h4:        'Financing Connections',
    home_unlock6_p:         'Connect buyers with competitive financing through our trusted lender network',
    home_unlock7_h4:        'ByrddawgsOS Back-Office',
    home_unlock7_p:         'Your command center \u2014 auctions, inquiries, credentials, and support in one dashboard',
    home_trust_label:       'Backed by Real Infrastructure',
    home_trust_h2:          'Powered by Byrd Dawgs Automotive Group',
    home_trust_sub:         'Licensed. Nationwide. Transparent. We\'re the real deal \u2014 a licensed dealer group building the co-op model that makes the car business accessible to everyone.',
    home_trust_badge:       '<strong>Licensed Dealer Group</strong> \u2014 Operating in compliance nationwide',
    home_final_h2:          'Ready to enter the lane?',
    home_final_sub:         '$250 stands between you and a real car business. No gatekeeping. No nonsense. Just opportunity.',
    home_final_cta:         'Apply Now \u2192',
    home_lead_badge:        '\uD83C\uDFAF Free Insider Playbook',
    home_lead_h2:           'Flip Cars Without a License.<br><span class="green">100% Profit. $0 Risk.</span>',
    home_lead_p:            'Download the playbook 300+ members used to start flipping. Real margins, proven auction tactics, and the exact co-op model that bypasses the $15K dealer license entirely.',
    home_lead_placeholder:  'Your email',
    home_lead_btn:          'Get Free Access',
    home_testi_label:       'Member Results',
    home_testi_h2:          'Real People. Real Results.',
    home_testi_sub:         'From first flip to residual income \u2014 here\'s what co-op members are building.',
    home_news_label:        'FlipLane Newsletter',
    home_news_h2:           'Join the FlipLane Newsletter',
    home_news_sub:          'Deals, market updates, flip strategies, and insider tips \u2014 straight to your inbox. No spam. Unsubscribe anytime.',
    home_news_btn:          'Subscribe Free',

    // ── Ticker Bar ─────────────────────────────────────────────
    ticker_1:   'Marcus just flipped a 2019 Camry \u2014 <strong>$3,200 profit</strong>',
    ticker_2:   'New co-op partner joined from <strong>Texas</strong>',
    ticker_3:   'Vehicle sourced: 2021 Honda Accord \u2014 <strong>$4,800 below retail</strong>',
    ticker_4:   'Shipped: 2020 Ford F-150 \u2014 Memphis \u2192 Miami in <strong>4 days</strong>',
    ticker_5:   'Deal closed: 2022 Tesla Model 3 \u2014 <strong>$6,100 saved</strong>',
    ticker_6:   'New affiliate joined from <strong>Atlanta, GA</strong>',
    ticker_7:   'Jordan flipped a 2018 BMW 5-Series \u2014 <strong>$2,900 profit</strong>',
    ticker_8:   'Co-op expanding into <strong>Pacific Northwest</strong>',
    ticker_9:   'Keisha sourced a 2023 Kia Telluride \u2014 <strong>$5,500 below MSRP</strong>',
    ticker_10:  '300+ vehicles sourced this year \u2014 <strong>and counting</strong>',

    // ── Hero Extras ────────────────────────────────────────────
    home_hero_proof:    'One-time \u00B7 No subscriptions \u00B7 No revenue splits',
    home_chip_1:        'ADESA Access',
    home_chip_2:        '50k+ Vehicles/Week',
    home_chip_3:        'No Revenue Split',
    home_chip_4:        'Nationwide Shipping',
    home_chip_5:        'Direct Lender Access',
    home_scroll:        'Scroll',
    home_earnings_disclaimer: '<strong style="color:var(--text-secondary);">Earnings Disclaimer:</strong> Results vary. The figures shown represent exceptional outcomes. Most members earn between $1,000\u2013$4,000 per completed transaction depending on vehicle type, market conditions, and individual effort. Past performance does not guarantee future results. <a href="/terms#earnings-disclaimer" style="color:var(--text-dim);text-decoration:underline;">Learn more</a>.',
    home_news_success:  '\u2713 You\'re subscribed! Watch your inbox.',
    footer_income_disc: 'Income Disclaimer',

    // ── Buy Page ────────────────────────────────────────────────
    buy_badge:              'Buyer Lane',
    buy_hero_h1:            'Skip the Dealership.<br>Find Your Car at <span class="green">Auction Prices.</span>',
    buy_hero_sub:           'FlipLane sources vehicles at dealer auction prices. You negotiate and close at wholesale \u2014 no dealer markup, no hidden dealer lot fees, no dealership BS.',
    buy_hero_cta:           'Request a Quote \u2192',
    buy_how_label:          'How It Works',
    buy_how_h2:             'Four steps. One flat fee.',

    // ── Earn Page ───────────────────────────────────────────────
    earn_badge:             'Application-Based Program',
    earn_hero_h1:           '50% Commissions. $0 Entry. Not Everyone Gets In.',
    earn_hero_sub:          'This isn\'t open enrollment. We vet our affiliates, protect our network, and pay the ones who make it through. If you have real reach, real hustle, or real deals \u2014 apply.',
    earn_stat1_label:       'Commission rate',
    earn_stat2_label:       'Cost to join',
    earn_stat3_label:       'Ways to earn',
    earn_stat4_label:       'Entry process',
    earn_hero_cta:          'Apply to Be an Affiliate \u2192',
    earn_opp_label:         'The Opportunity',
    earn_opp_h2:            'A $1.2 trillion market with a gaping hole in the middle.',
    earn_opp_sub:           'Independent car flippers and small dealers get squeezed out by the costs of licensing, auctions, and overhead. FlipLane closes that gap \u2014 and affiliates are how we grow the network.',
    earn_comm_label:        'Commission Structure',
    earn_comm_h2:           'Crystal clear. No fine print.',
    earn_comm_sub:          'Fifty percent across the board. Every category, every deal type. Here\'s exactly how it breaks down.',
    earn_form_badge:        'Application Under Review',
    earn_form_h2:           'Apply to Be an Affiliate',
    earn_form_sub:          'Complete all fields. Applications are reviewed by the FlipLane team \u2014 not auto-approved. You\'ll hear back within 48\u201372 hours if approved.',
    earn_form_btn:          'Submit Application \u2192',

    // ── Partner Page ────────────────────────────────────────────
    partner_badge:          'Co-op Partner',
    partner_hero_h1:        'Plug Into the System. Keep Your Profits. Scale with AI.',
    partner_hero_sub:       'Pay $250 once to access the FlipLane co-op system \u2014 AI tools, branding, marketing infrastructure, lead flow systems, training, and back-end support. Keep 100% of profits on every deal you close.',
    partner_hero_cta:       'Become a Co-op Partner \u2014 $250',
    partner_hero_cta2:      'Read the FAQ \u2193',
    partner_fees_label:     'Full fee transparency',
    partner_fees_h2:        'Know exactly what you\'re paying. No surprises.',
    partner_fees_sub:       'Two fees. That\'s it. The system, the tools, the support \u2014 all included.',
    partner_profit_label:   'How profit works',
    partner_profit_h2:      'Your deal, your money. Fair and simple.',
    partner_profit_sub:     'We only share in the profit when we bring the financing. If you source the buyer and the deal \u2014 you keep everything.',
    partner_bo_label:       'Your back office \u2014 exclusive to partners',
    partner_bo_h2:          'ByrddawgsOS unlocks when you join.',
    partner_bo_sub:         'The full FlipLane operating system. AI tools, marketing infrastructure, deal processing, and support \u2014 all in one place. You get access the day you pay.',
    partner_start_label:    'Getting started',
    partner_start_h2:       'From application to operating in days.',
    partner_start_sub:      'Six steps. No lengthy review. No months of waiting. You\'re inside the system and moving within a week.',
    partner_faq_label:      'Questions answered',
    partner_faq_h2:         'Frequently Asked Questions',
    partner_close_h2:       'Plug into the <span class="green">system.</span>',
    partner_close_sub:      '$250 gets you in. AI tools, branding, marketing systems, lead flow, training, and back-end support \u2014 the full FlipLane operating structure. Keep 100% of what you earn.',
    partner_close_cta:      'Become a Co-op Partner \u2014 $250 One-Time \u2192',

    // ── Language Toggle ──────────────────────────────────────────
    lang_toggle_label:  'EN / ES',
  },

  es: {
    // ── Navigation ───────────────────────────────────────────────
    nav_phone:        '📞 855-5FLIPLANE',
    nav_apply:        'Aplica Ahora',
    nav_login:        'Acceso de Miembro',
    nav_dashboard:    'Panel de Miembro',

    // ── Footer ───────────────────────────────────────────────────
    footer_location:  'Atlanta, GA',
    footer_phone:     '📞 855-5FLIPLANE',
    footer_email:     '✉️ win@fliplane.net',

    // ── Dashboard ────────────────────────────────────────────────
    dash_title:             'Panel de Miembro',
    dash_subtitle:          'Ingresa tu correo electrónico para consultar el estado de tu membresía',
    dash_email_placeholder: 'Tu correo electrónico',
    dash_check_btn:         'Consultar Estado',
    dash_loading:           'Cargando tu panel...',
    dash_redirecting:       'Redirigiendo a ByrddawgsOS...',
    dash_welcome_back:      'Bienvenido de regreso',
    dash_label_applied:     'Solicitado',
    dash_label_status:      'Estado',
    dash_error_network:     'Error de red. Por favor inténtalo de nuevo.',
    dash_error_notfound:    'No se encontró ninguna solicitud para este correo. Aplica ahora →',

    dash_pay_heading:  'Completa tu membresía',
    dash_pay_desc:     'Paga la cuota de membresía de $250 para activar tu acceso al grupo de distribuidores.',
    dash_pay_btn:      'Pagar $250 — Activar Ahora',
    dash_cert_heading: 'Un paso más — completa la certificación',
    dash_cert_desc:    '¡Tu pago está confirmado! Completa la certificación rápida de la cooperativa (menos de 5 minutos) para desbloquear tu panel completo.',
    dash_cert_btn:     'Iniciar Certificación →',

    status_certified:   'Miembro Certificado',
    status_cert_pend:   'Certificación Pendiente',
    status_pay_pend:    'Pago Pendiente',
    status_await_pay:   'En Espera de Pago',
    status_applied:     'Solicitado',

    // ── Join Flow ────────────────────────────────────────────────
    join_step_apply:     'Aplicar',
    join_step_agreement: 'Acuerdo',
    join_step_payment:   'Pago',
    join_step_verify:    'Verificar ID',
    join_step1_badge:    'Paso 1 de 4',
    join_step2_badge:    'Paso 2 de 4',
    join_step3_badge:    'Paso 3 de 4',
    join_final_badge:    'Último Paso',

    join_s1_h1:          'Únete a FlipLane Co-op',
    join_s1_sub:         'Cuéntanos sobre ti para comenzar.',
    join_s1_price_desc:  'Membresía única. Accede a subastas de distribuidores, herramientas de IA, capacitación y el sistema completo FlipLane — de por vida.',
    join_label_name:     'Nombre Completo *',
    join_ph_name:        'Tu nombre legal completo',
    join_label_email:    'Correo Electrónico *',
    join_ph_email:       'tu@ejemplo.com',
    join_label_phone:    'Número de Teléfono',
    join_ph_phone:       '+1 (555) 000-0000',
    join_label_exp:      'Experiencia con Autos',
    join_exp_default:    'Selecciona tu nivel',
    join_exp_none:       'Sin experiencia previa',
    join_exp_few:        'He comprado/vendido algunos autos personales',
    join_exp_some:       'Algo de experiencia como distribuidor o mayorista',
    join_exp_pro:        'Distribuidor / mayorista experimentado',
    join_exp_hint:       'Nos ayuda a personalizar tu incorporación.',
    join_s1_btn:         'Continuar al Acuerdo →',
    join_err_generic:    'Algo salió mal. Por favor inténtalo de nuevo.',
    join_err_network:    'Error de red. Verifica tu conexión e inténtalo de nuevo.',

    join_s2_h1:          'Acuerdo de Membresía',
    join_s2_sub:         'Lee y acepta los términos de membresía de FlipLane Co-op antes de continuar.',
    join_s2_scroll_hint: '↓ Desplázate al final para habilitar la aceptación',
    join_s2_read_done:   '✓ Has leído el acuerdo completo',
    join_s2_agree_title: 'Acuerdo de Membresía FlipLane Co-op — Versión 1.0',
    join_s2_sec1:        '1. Membresía y Acceso',
    join_s2_sec2:        '2. Confidencialidad',
    join_s2_sec3:        '3. Declaraciones y Garantías',
    join_s2_sec4:        '4. Limitaciones de Responsabilidad',
    join_s2_sec5:        '5. Resolución de Disputas',
    join_s2_sec6:        '6. Terminación',
    join_s2_sec7:        '7. Ley Aplicable',
    join_s2_checkbox:    'He leído el Acuerdo de Membresía FlipLane Co-op en su totalidad y acepto todos los términos y condiciones. Entiendo que es un contrato legalmente vinculante.',
    join_s2_btn:         'Aceptar Acuerdo y Continuar →',
    join_s2_err:         'Error al guardar el acuerdo. Por favor inténtalo de nuevo.',

    join_s3_h1:           'Completa tu Pago',
    join_s3_sub:          'Ya casi eres miembro. Un pago más para acceso completo.',
    join_s3_check1:       'Solicitud enviada',
    join_s3_check2:       'Acuerdo de membresía firmado',
    join_s3_check3:       'Completar pago',
    join_tab_card:        '💳 Pagar con Tarjeta',
    join_tab_manual:      '📲 Pagar Manualmente',
    join_stripe_label:    'Membresía FlipLane Co-op',
    join_stripe_type:     'Pago único, sin cargos recurrentes',
    join_stripe_type_lbl: 'Tipo',
    join_stripe_total:    'Total a Pagar Hoy',
    join_promo_show:      '¿Tienes un código promocional?',
    join_promo_hide:      'Ocultar código promocional',
    join_promo_ph:        'INGRESA EL CÓDIGO',
    join_promo_apply:     'Aplicar',
    join_promo_empty:     'Por favor ingresa un código promocional.',
    join_promo_session:   'Error de sesión — recarga la página e inténtalo de nuevo.',
    join_promo_success:   '✓ ¡Código aplicado! Redirigiendo…',
    join_promo_invalid:   'Código promocional inválido.',
    join_err_network2:    'Error de red. Por favor inténtalo de nuevo.',
    join_stripe_cta:      'Haz clic a continuación para completar tu pago seguro de $250 y activar tu membresía.',
    join_stripe_btn:      'Pagar $250 — Activar Membresía →',
    join_stripe_secure:   '🔒 Procesado por Stripe · Cifrado SSL seguro de 256 bits',
    join_manual_ref_lbl:  'Tu Número de Orden / Referencia',
    join_manual_loading:  'Cargando…',
    join_manual_err:      'Error — recarga',
    join_copy_btn:        'Copiar',
    join_manual_note:     '📝 Incluye este Número de Orden en el campo Memo / Nota de tu pago para que podamos verificar tu transacción al instante.',
    join_cashapp_pay:     'Pagar $250 →',
    join_cashapp_copy:    'Copiar $tag',
    join_venmo_pay:       'Pagar $250 →',
    join_venmo_copy:      'Copiar usuario',
    join_zelle_call:      'Llamar / Abrir →',
    join_zelle_copy:      'Copiar número',
    join_confirm_btn:     '✓ Ya Envié Mi Pago →',
    join_copied:          '✓ ¡Copiado!',
    join_recording:       'Registrando…',
    join_pay_pending:     '⏳ Pago pendiente de verificación. Tu membresía se activa una vez que confirmemos tu pago de $250 — generalmente en pocas horas. Recibirás un correo cuando sea aprobado.',

    join_s4_badge:        'Último Paso',
    join_s4_h1:           'Verifica Tu Identidad',
    join_s4_sub:          'Sube una identificación oficial para completar la activación de tu membresía.',
    join_id_h2:           'Subir Identificación Oficial',
    join_id_drag:         'Arrastra y suelta o haz clic para subir',
    join_id_types:        'JPG · PNG · WebP · PDF · Máx 10MB',
    join_id_privacy:      '🔒 Seguro y Privado. Tu identificación está cifrada y se usa únicamente para verificar tu identidad según nuestra política de membresía. Nunca se comparte con terceros.',
    join_id_accepted:     'Aceptado: Licencia de conducir, ID estatal, Pasaporte o identificación oficial equivalente con fotografía.',
    join_id_btn:          'Subir ID y Continuar →',
    join_id_uploading:    'Subiendo…',
    join_id_remove:       'Eliminar',
    join_id_pay_note:     '⏳ Pago pendiente de verificación. Tu membresía se activará una vez que confirmemos tu pago. Sube tu ID ahora — te enviaremos un correo cuando todo esté aprobado.',
    join_id_err1:         'Error al subir. Por favor inténtalo de nuevo.',
    join_id_err2:         'Error de red. Verifica tu conexión.',

    // ── Apply Flow ───────────────────────────────────────────────
    apply_step_apply:   'Aplicar',
    apply_step_verify:  'Verificar ID',
    apply_step_payment: 'Pago',

    apply_s1_badge:     'Solicitud de Socio Co-op',
    apply_s1_h1:        'Únete al grupo de distribuidores',
    apply_s1_sub:       'Completa tu información a continuación. Luego verificarás tu identidad y realizarás el pago.',
    apply_label_name:   'Nombre Completo *',
    apply_ph_name:      'Juan García',
    apply_label_email:  'Correo Electrónico *',
    apply_ph_email:     'juan@ejemplo.com',
    apply_label_phone:  'Teléfono',
    apply_ph_phone:     '(555) 123-4567',
    apply_label_exp:    'Experiencia en Compra/Venta de Autos',
    apply_exp_default:  'Selecciona tu nivel de experiencia',
    apply_exp_0:        'Nuevo — nunca he vendido',
    apply_exp_1:        'Principiante — 1-5 ventas',
    apply_exp_2:        'Intermedio — 6-20 ventas',
    apply_exp_3:        'Experimentado — más de 20 ventas',
    apply_exp_4:        'Ya soy distribuidor con licencia',
    apply_exp_hint:     'Todos los niveles de experiencia son bienvenidos',
    apply_price_desc:   'Cuota de membresía única — se paga después de la verificación de identidad. Pago seguro con Stripe.',
    apply_s1_btn:       'Continuar a Verificación de ID →',
    apply_submitting:   'Enviando...',
    apply_questions:    '¿Preguntas? Llámanos al 855-5FLIPLANE',
    apply_err1:         'Algo salió mal.',
    apply_err2:         'Error de red. Por favor inténtalo de nuevo.',

    apply_s2_badge:     'Verificación de Identidad',
    apply_s2_h1:        'Verifica Tu Identidad',
    apply_s2_sub:       'Verificamos a cada miembro. Esto te protege a ti y a la red — solo los operadores reales acceden a las credenciales del distribuidor.',
    apply_id_h2:        'Subir Identificación Oficial',
    apply_id_sub:       'Licencia de conducir, ID estatal o pasaporte',
    apply_id_types:     'JPG · PNG · PDF · Máx 10MB',
    apply_id_privacy:   '🔒 Almacenado de forma segura. Revisado solo por nuestro equipo. Tu ID está cifrado y se usa únicamente para verificar la elegibilidad de membresía. Nunca se comparte con terceros y se elimina dentro de los 90 días posteriores a la revisión.',
    apply_id_btn:       'Subir y Continuar al Pago →',
    apply_id_uploading: 'Subiendo...',
    apply_id_remove:    'Eliminar',
    apply_id_required:  'Debes subir una identificación para continuar al pago.',
    apply_id_err1:      'Por favor sube un archivo JPG, PNG, WebP o PDF.',
    apply_id_err2:      'El archivo es demasiado grande. El tamaño máximo es 10MB.',
    apply_id_err3:      'Error al subir. Por favor inténtalo de nuevo.',
    apply_id_err4:      'Error al subir. Verifica tu conexión e inténtalo de nuevo.',

    apply_s3_badge:     'Último Paso',
    apply_s3_h1:        'Completa tu membresía',
    apply_s3_sub:       'Solicitud y verificación completadas. Un pago para activar tu cuenta.',
    apply_almost:       'Ya casi.',
    apply_check1:       'Solicitud enviada',
    apply_check2:       'Identificación oficial subida',
    apply_check3:       'Completar pago de $250',
    apply_s3_cta:       'Completa tu pago de membresía de $250 para activar tu cuenta y acceder a ByrddawgsOS.',
    apply_s3_btn:       'Pagar $250 — Activar Membresía',
    apply_s3_skip:      '¿Ya pagaste? Ver mi estado →',

    // ── Welcome Page ─────────────────────────────────────────────
    welcome_badge:        '● Membresía Activa',
    welcome_h1:           '¡Bienvenido a FlipLane!',
    welcome_h1_named:     '¡Bienvenido, {name}!',
    welcome_active:       'Tu membresía está activa.',
    welcome_sub1:         'Pago confirmado. Ya eres oficialmente un socio de la cooperativa.',
    welcome_sub2:         'Solo un paso entre tú y el acceso completo.',
    welcome_next_label:   '⚡ Tu próximo paso',
    welcome_cert_title:   'Completa tu certificación para desbloquear ByrddawgsOS',
    welcome_cert_desc:    'Lee 4 módulos cortos y pasa un cuestionario de 5 preguntas — toma aproximadamente 5 minutos. Acceso instantáneo al panel al aprobar.',
    welcome_cert_btn:     'Iniciar Certificación Ahora →',
    welcome_cert_hint:    'Toma ~5 minutos · Acceso instantáneo al aprobar · Reintentos ilimitados',
    welcome_email_note:   'Revisa tu bandeja de entrada. Te enviamos un correo de bienvenida con tu ID de miembro, enlace de certificación y guía de inicio rápido. También espera un acuerdo DocuSign — fírmalo para completar el proceso.',
    welcome_email_spam:   '¿No lo ves? Revisa tu carpeta de Spam, No deseado o Promociones — a veces llega ahí.',
    welcome_unlock_title: 'Lo que desbloqueas después de la certificación',
    welcome_feat1_title:  'Acceso a Subastas de Distribuidores',
    welcome_feat1_desc:   'Oferta en inventario mayorista usando nuestras credenciales compartidas de distribuidor.',
    welcome_feat2_title:  'Centro de Negocios',
    welcome_feat2_desc:   'Solicitudes de reparación y venta, envíos, título y registro — un solo panel.',
    welcome_feat3_title:  'Hub de Afiliados',
    welcome_feat3_desc:   'Herramientas de consulta de clientes, apoyo de marketing, referencias de la cooperativa.',
    welcome_feat4_title:  'Panel ByrddawgsOS',
    welcome_feat4_desc:   'Kit completo de oficina trasera para gestionar cada negocio de extremo a extremo.',
    welcome_progress_title: 'Tu progreso de incorporación',
    welcome_prog1_title:  'Solicitado y pagado',
    welcome_prog1_desc:   'Pago de membresía de $250 confirmado.',
    welcome_prog2_title:  'Completar certificación',
    welcome_prog2_desc:   'Lee 4 módulos, pasa el cuestionario. Desbloquea tu panel al instante.',
    welcome_prog3_title:  'Firmar acuerdo DocuSign',
    welcome_prog3_desc:   'Protege las credenciales compartidas del distribuidor. Revisa tu correo.',
    welcome_prog4_title:  'Realizar tu primer negocio',
    welcome_prog4_desc:   'Envía a través de ByrddawgsOS. Tarifa plana de $250 por negocio. FlipLane maneja el papeleo.',
    welcome_questions:    '¿Preguntas?',
    welcome_phone:        '📞 855-5FLIPLANE',
    welcome_email:        'win@fliplane.net',

    // ── Certification Page ───────────────────────────────────────
    cert_title:           'Certificación Co-op',
    cert_badge:           'Certificación Co-op',
    cert_progress_label:  'Módulo {current} de {total}',
    cert_quiz_badge:      'Cuestionario Final',
    cert_next_btn:        'Siguiente Módulo →',
    cert_start_quiz:      'Iniciar Cuestionario →',
    cert_submit_quiz:     'Enviar Respuestas →',
    cert_submitting:      'Enviando…',
    cert_question_label:  'Pregunta {n} de {total}',
    cert_pass_h1:         '¡Certificación Completa! 🎉',
    cert_pass_sub:        'Ya eres un socio certificado de FlipLane Co-op.',
    cert_pass_btn:        'Ir a Mi Panel →',
    cert_fail_h1:         'Casi — inténtalo de nuevo',
    cert_fail_sub:        'Revisa los módulos y vuelve a tomar el cuestionario. Reintentos ilimitados.',
    cert_fail_btn:        'Reintentar Cuestionario →',
    cert_err_submit:      'Error al enviar — por favor inténtalo de nuevo.',
    cert_err_network:     'Error de red. Por favor inténtalo de nuevo.',
    cert_progress_bar:    'Progreso del Módulo',
    cert_score_label:     'Tu puntuación: {score}/{total}',

    // ── Payment Success Page ─────────────────────────────────────
    pay_success_h1:    '¡Pago Confirmado!',
    pay_success_sub:   'Tu membresía FlipLane ya está activa.',
    pay_success_cta:   'Ir a Mi Panel →',
    pay_success_note:  'Un correo de confirmación está en camino.',

    // ── Shared Navigation (Landing Pages) ───────────────────────
    nav_home:           'Inicio',
    nav_buyer:          'Comprar Auto',
    nav_affiliate:      'Afiliados',
    nav_coop:           'Socio Co-op',
    nav_pricing:        'Precios',
    nav_tools:          'Herramientas',
    nav_blog:           'Blog',
    nav_playbook:       'Guía Gratis',
    nav_terms:          'Términos',
    nav_member_login:   'Acceso Miembros',

    // ── Shared Footer ──────────────────────────────────────────
    footer_brand_desc:  'La cooperativa automotriz más transparente y respaldada por tecnología del país.',
    footer_lanes:       'Opciones',
    footer_company:     'Compañía',
    footer_members:     'Miembros',
    footer_dashboard:   'Panel',
    footer_apply:       'Aplicar',
    footer_copyright:   '\u00A9 2025 FlipLane \u2014 Respaldado por Byrd Dawgs Automotive Group',
    footer_tagline:     'Hecho para el esfuerzo, la honestidad y $250.',

    // ── Homepage ────────────────────────────────────────────────
    home_badge:             'Red de Concesionaria Co-op \u00B7 Aceptando Socios',
    home_hero_h1:           'La Concesionaria de <span class="green-glow">$250</span>.',
    home_hero_sub:          'Un pago. Acceso total a subastas. Nos encargamos del título, envío y gestión \u2014 tú te quedas con el 100% de cada negocio.',
    home_cta_primary:       'Únete a la Co-op \u2192',
    home_cta_secondary:     'Ver Precios \u2192',
    home_cta_questions:     '¿Preguntas?',
    home_cta_call:          'Llámanos al 855-5FLIPLANE',
    home_lanes_label:       'Elige Tu Lane',
    home_lanes_h2:          'Tres Lanes. Una Plataforma.',
    home_lanes_sub:         'Elige cómo quieres ganar.',
    home_lane1_h3:          'Buyer Lane',
    home_lane1_subtitle:    'Acceso al Mejor Precio',
    home_lane1_p:           'No pierdas tiempo en concesionarias. Buscamos, negociamos y entregamos tu vehículo al mejor precio disponible.',
    home_lane1_link:        'Encontrar Tu Auto \u2192',
    home_lane2_h3:          'Affiliate Lane',
    home_lane2_subtitle:    'Entrada Gratis. 50% de Comisión.',
    home_lane2_p:           'Refiere compradores, encuentra negocios, crea contenido. Gana 50% de comisión en cada oportunidad que cierres.',
    home_lane2_link:        'Empezar a Ganar \u2192',
    home_lane3_h3:          'Co-op Partner Lane',
    home_lane3_subtitle:    'Membresía $250. 100% Ganancia.',
    home_lane3_p:           'Únete a nuestro grupo de distribuidores. Acceso total a subastas, título y envío incluidos, transacciones a nivel nacional. Quédate con cada dólar que ganes.',
    home_lane3_link:        'Únete a la Co-op \u2192',
    home_stat1_label:       'Vehículos Movidos',
    home_stat2_label:       'Ahorro Promedio',
    home_stat3_label:       'Estados Cubiertos',
    home_stat4_label:       'Tarifa por Operación',
    home_money_label:       'Tarifas Transparentes',
    home_money_h2:          'Cómo Funciona el Dinero',
    home_money_sub:         'Sin tarifas ocultas. Sin suscripciones mensuales. Sin sorpresas. Cada dólar explicado.',
    home_fee1_label:        'Para Unirte',
    home_fee1_p:            'Cuota de membresía única. Estás en la cooperativa. Desbloquea subastas, herramientas y alcance nacional. Sin cargos recurrentes.',
    home_fee2_label:        'Por Negocio',
    home_fee2_p:            'Tarifa plana de procesamiento por transacción. Título, cumplimiento y papeleo \u2014 resuelto. Te quedas con el 100% de la ganancia en cada negocio.',
    home_fee3_label:        'Solo en Negocios Financiados',
    home_fee3_p:            '¿Nosotros traemos el prestamista? Dividimos la ganancia del financiamiento. ¿Tú manejas el financiamiento? Todo es tuyo. Justo y simple.',
    home_comp_old_label:    'Licencia de Distribuidor Tradicional',
    home_comp_old_price:    '$15K \u2013 $50K+',
    home_comp_new_label:    'FlipLane Co-op',
    home_unlock_label:      'Tu Kit de Herramientas',
    home_unlock_h2:         'Lo Que Desbloqueas',
    home_unlock_sub:        'Todo lo que necesitas para un negocio real de autos. Incluido con tu membresía de $250.',
    home_unlock1_h4:        'Acceso a Subastas de Distribuidores',
    home_unlock1_p:         'ADESA, OVE y canales mayoristas \u2014 compra por debajo del valor de mercado',
    home_unlock2_h4:        'Gestión de Inventario',
    home_unlock2_p:         'Rastrea tus vehículos, costos y márgenes en un solo lugar',
    home_unlock3_h4:        'Procesamiento Nacional de Negocios',
    home_unlock3_p:         'Título, cumplimiento y papeleo en los 50 estados',
    home_unlock4_h4:        'Red de Socios de Envío',
    home_unlock4_p:         'Tarifas competitivas de transporte para mover inventario a cualquier lugar',
    home_unlock5_h4:        'Listado en CarsForSale',
    home_unlock5_p:         'Lista tus vehículos en CarsForSale.com como distribuidor verificado',
    home_unlock6_h4:        'Conexiones de Financiamiento',
    home_unlock6_p:         'Conecta compradores con financiamiento competitivo a través de nuestra red de prestamistas',
    home_unlock7_h4:        'ByrddawgsOS Back-Office',
    home_unlock7_p:         'Tu centro de comando \u2014 subastas, consultas, credenciales y soporte en un solo panel',
    home_trust_label:       'Respaldado por Infraestructura Real',
    home_trust_h2:          'Impulsado por Byrd Dawgs Automotive Group',
    home_trust_sub:         'Con licencia. A nivel nacional. Transparente. Somos reales \u2014 un grupo de distribuidores con licencia construyendo el modelo cooperativo que hace el negocio de autos accesible para todos.',
    home_trust_badge:       '<strong>Grupo de Distribuidores con Licencia</strong> \u2014 Operando en cumplimiento a nivel nacional',
    home_final_h2:          '¿Listo para entrar al lane?',
    home_final_sub:         '$250 te separan de un negocio real de autos. Sin barreras. Sin tonterías. Solo oportunidad.',
    home_final_cta:         'Aplica Ahora \u2192',
    home_lead_badge:        '\uD83C\uDFAF Guía Gratis para Insiders',
    home_lead_h2:           'Vende Autos Sin Licencia.<br><span class="green">100% Ganancia. $0 Riesgo.</span>',
    home_lead_p:            'Descarga la guía que más de 300 miembros usaron para empezar a vender. Márgenes reales, tácticas probadas de subasta y el modelo exacto de cooperativa que evita la licencia de distribuidor de $15K.',
    home_lead_placeholder:  'Tu correo electrónico',
    home_lead_btn:          'Obtener Acceso Gratis',
    home_testi_label:       'Resultados de Miembros',
    home_testi_h2:          'Personas Reales. Resultados Reales.',
    home_testi_sub:         'Desde la primera venta hasta ingresos recurrentes \u2014 esto es lo que los miembros de la cooperativa están construyendo.',
    home_news_label:        'Newsletter de FlipLane',
    home_news_h2:           'Únete al Newsletter de FlipLane',
    home_news_sub:          'Ofertas, actualizaciones de mercado, estrategias de venta y tips de expertos \u2014 directo a tu bandeja. Sin spam. Cancela cuando quieras.',
    home_news_btn:          'Suscríbete Gratis',

    // ── Ticker Bar ─────────────────────────────────────────────
    ticker_1:   'Marcus vendi\u00F3 un Camry 2019 \u2014 <strong>$3,200 de ganancia</strong>',
    ticker_2:   'Nuevo socio co-op se uni\u00F3 desde <strong>Texas</strong>',
    ticker_3:   'Veh\u00EDculo conseguido: Honda Accord 2021 \u2014 <strong>$4,800 bajo retail</strong>',
    ticker_4:   'Enviado: Ford F-150 2020 \u2014 Memphis \u2192 Miami en <strong>4 d\u00EDas</strong>',
    ticker_5:   'Negocio cerrado: Tesla Model 3 2022 \u2014 <strong>$6,100 ahorrados</strong>',
    ticker_6:   'Nuevo afiliado se uni\u00F3 desde <strong>Atlanta, GA</strong>',
    ticker_7:   'Jordan vendi\u00F3 un BMW Serie 5 2018 \u2014 <strong>$2,900 de ganancia</strong>',
    ticker_8:   'La co-op se expande al <strong>Noroeste del Pac\u00EDfico</strong>',
    ticker_9:   'Keisha consigui\u00F3 un Kia Telluride 2023 \u2014 <strong>$5,500 bajo MSRP</strong>',
    ticker_10:  '300+ veh\u00EDculos conseguidos este a\u00F1o \u2014 <strong>y contando</strong>',

    // ── Hero Extras ────────────────────────────────────────────
    home_hero_proof:    '\u00DAnico pago \u00B7 Sin suscripciones \u00B7 Sin divisi\u00F3n de ingresos',
    home_chip_1:        'Acceso ADESA',
    home_chip_2:        '50k+ Veh\u00EDculos/Semana',
    home_chip_3:        'Sin Divisi\u00F3n de Ingresos',
    home_chip_4:        'Env\u00EDo Nacional',
    home_chip_5:        'Acceso Directo a Prestamistas',
    home_scroll:        'Desplazar',
    home_earnings_disclaimer: '<strong style="color:var(--text-secondary);">Aviso de Ganancias:</strong> Los resultados var\u00EDan. Las cifras mostradas representan resultados excepcionales. La mayor\u00EDa de los miembros ganan entre $1,000\u2013$4,000 por transacci\u00F3n completada dependiendo del tipo de veh\u00EDculo, condiciones del mercado y esfuerzo individual. El rendimiento pasado no garantiza resultados futuros. <a href="/terms#earnings-disclaimer" style="color:var(--text-dim);text-decoration:underline;">M\u00E1s informaci\u00F3n</a>.',
    home_news_success:  '\u2713 \u00A1Est\u00E1s suscrito! Revisa tu bandeja de entrada.',
    footer_income_disc: 'Aviso de Ingresos',

    // ── Buy Page ────────────────────────────────────────────────
    buy_badge:              'Comprar Auto',
    buy_hero_h1:            'Evita la Concesionaria.<br>Encuentra Tu Auto a <span class="green">Precios de Subasta.</span>',
    buy_hero_sub:           'FlipLane consigue vehículos a precios de subasta de distribuidores. Tú negocias y cierras al mayoreo \u2014 sin sobreprecio de concesionaria, sin tarifas ocultas, sin trucos.',
    buy_hero_cta:           'Solicitar Cotización \u2192',
    buy_how_label:          'Cómo Funciona',
    buy_how_h2:             'Cuatro pasos. Una tarifa plana.',

    // ── Earn Page ───────────────────────────────────────────────
    earn_badge:             'Programa por Solicitud',
    earn_hero_h1:           '50% de Comisiones. $0 de Entrada. No Todos Entran.',
    earn_hero_sub:          'Esto no es inscripción abierta. Evaluamos a nuestros afiliados, protegemos nuestra red y pagamos a los que pasan. Si tienes alcance real, esfuerzo real o negocios reales \u2014 aplica.',
    earn_stat1_label:       'Tasa de comisión',
    earn_stat2_label:       'Costo de entrada',
    earn_stat3_label:       'Formas de ganar',
    earn_stat4_label:       'Proceso de entrada',
    earn_hero_cta:          'Aplica para ser Afiliado \u2192',
    earn_opp_label:         'La Oportunidad',
    earn_opp_h2:            'Un mercado de $1.2 billones con un hueco enorme en el medio.',
    earn_opp_sub:           'Los revendedores independientes y pequeños distribuidores son exprimidos por los costos de licencias, subastas y gastos generales. FlipLane cierra esa brecha \u2014 y los afiliados son cómo hacemos crecer la red.',
    earn_comm_label:        'Estructura de Comisiones',
    earn_comm_h2:           'Transparente. Sin letra pequeña.',
    earn_comm_sub:          'Cincuenta por ciento en todas las categorías. Cada tipo de negocio. Así es exactamente cómo funciona.',
    earn_form_badge:        'Solicitud en Revisión',
    earn_form_h2:           'Aplica para ser Afiliado',
    earn_form_sub:          'Completa todos los campos. Las solicitudes son revisadas por el equipo de FlipLane \u2014 no se aprueban automáticamente. Recibirás respuesta en 48\u201372 horas si eres aprobado.',
    earn_form_btn:          'Enviar Solicitud \u2192',

    // ── Partner Page ────────────────────────────────────────────
    partner_badge:          'Socio Co-op',
    partner_hero_h1:        'Conéctate al Sistema. Quédate con tus Ganancias. Escala con IA.',
    partner_hero_sub:       'Paga $250 una vez para acceder al sistema cooperativo de FlipLane \u2014 herramientas de IA, marca, infraestructura de marketing, sistemas de generación de leads, capacitación y soporte operativo. Quédate con el 100% de las ganancias en cada negocio que cierres.',
    partner_hero_cta:       'Conviértete en Socio Co-op \u2014 $250',
    partner_hero_cta2:      'Lee las Preguntas Frecuentes \u2193',
    partner_fees_label:     'Transparencia total de tarifas',
    partner_fees_h2:        'Sabes exactamente lo que pagas. Sin sorpresas.',
    partner_fees_sub:       'Dos tarifas. Eso es todo. El sistema, las herramientas, el soporte \u2014 todo incluido.',
    partner_profit_label:   'Cómo funcionan las ganancias',
    partner_profit_h2:      'Tu negocio, tu dinero. Justo y simple.',
    partner_profit_sub:     'Solo compartimos la ganancia cuando traemos el financiamiento. Si tú encuentras al comprador y el negocio \u2014 te quedas con todo.',
    partner_bo_label:       'Tu oficina trasera \u2014 exclusiva para socios',
    partner_bo_h2:          'ByrddawgsOS se desbloquea cuando te unes.',
    partner_bo_sub:         'El sistema operativo completo de FlipLane. Herramientas de IA, infraestructura de marketing, procesamiento de negocios y soporte \u2014 todo en un solo lugar. Obtienes acceso el día que pagas.',
    partner_start_label:    'Para empezar',
    partner_start_h2:       'De la solicitud a operar en días.',
    partner_start_sub:      'Seis pasos. Sin revisiones largas. Sin meses de espera. Estás dentro del sistema y operando en una semana.',
    partner_faq_label:      'Preguntas respondidas',
    partner_faq_h2:         'Preguntas Frecuentes',
    partner_close_h2:       'Conéctate al <span class="green">sistema.</span>',
    partner_close_sub:      '$250 te da acceso. Herramientas de IA, marca, sistemas de marketing, generación de leads, capacitación y soporte operativo \u2014 la estructura operativa completa de FlipLane. Quédate con el 100% de lo que ganes.',
    partner_close_cta:      'Conviértete en Socio Co-op \u2014 $250 Único \u2192',

    // ── Language Toggle ──────────────────────────────────────────
    lang_toggle_label:  'EN / ES',
  }
};

// ─────────────────────────────────────────────────────────────
// Core i18n engine
// ─────────────────────────────────────────────────────────────

(function () {
  'use strict';

  const STORAGE_KEY = 'fliplane_lang';
  let currentLang = localStorage.getItem(STORAGE_KEY) || 'en';

  /** Return translated string for key; falls back to EN then to key itself */
  function t(key, vars) {
    const dict = FLIPLANE_TRANSLATIONS[currentLang] || FLIPLANE_TRANSLATIONS.en;
    let str = dict[key] || FLIPLANE_TRANSLATIONS.en[key] || key;
    if (vars) {
      Object.keys(vars).forEach(function (k) {
        str = str.replace('{' + k + '}', vars[k]);
      });
    }
    return str;
  }

  /** Walk DOM and apply translations */
  function applyTranslations() {
    // Text content (use innerHTML if translation contains HTML tags)
    document.querySelectorAll('[data-i18n]').forEach(function (el) {
      const key = el.getAttribute('data-i18n');
      const val = t(key);
      if (val.indexOf('<') !== -1 && val.indexOf('>') !== -1) {
        el.innerHTML = val;
      } else {
        el.textContent = val;
      }
    });
    // Placeholders
    document.querySelectorAll('[data-i18n-placeholder]').forEach(function (el) {
      el.setAttribute('placeholder', t(el.getAttribute('data-i18n-placeholder')));
    });
    // aria-label
    document.querySelectorAll('[data-i18n-aria]').forEach(function (el) {
      el.setAttribute('aria-label', t(el.getAttribute('data-i18n-aria')));
    });
    // Update html lang attribute
    document.documentElement.lang = currentLang;

    // Fire event so page scripts can re-render dynamic strings
    document.dispatchEvent(new CustomEvent('fliplane:langchange', { detail: { lang: currentLang } }));
  }

  /** Switch to given lang, persist, re-render */
  function setLanguage(lang) {
    if (!FLIPLANE_TRANSLATIONS[lang]) return;
    currentLang = lang;
    localStorage.setItem(STORAGE_KEY, lang);
    updateToggleBtn();
    applyTranslations();
  }

  function updateToggleBtn() {
    var btn = document.getElementById('fl-lang-toggle');
    if (btn) {
      if (currentLang === 'es') {
        btn.textContent = '🇺🇸 English';
        btn.title = 'Switch to English';
      } else {
        btn.textContent = '🇲🇽 Español';
        btn.title = 'Cambiar a Español';
      }
    }
    // Also update mobile toggle
    var mobileBtn = document.getElementById('fl-lang-toggle-mobile');
    if (mobileBtn) {
      if (currentLang === 'es') {
        mobileBtn.textContent = '🇺🇸 EN';
        mobileBtn.title = 'Switch to English';
      } else {
        mobileBtn.textContent = '🇲🇽 ES';
        mobileBtn.title = 'Cambiar a Español';
      }
    }
  }

  /** Inject floating language toggle button (or wire existing one in markup) */
  function injectToggleBtn() {
    var existing = document.getElementById('fl-lang-toggle');
    if (existing) {
      // Button already exists in the page markup — just wire click and update label
      existing.addEventListener('click', function () {
        setLanguage(currentLang === 'en' ? 'es' : 'en');
      });
    }
    // Wire mobile toggle too
    var mobileBtn = document.getElementById('fl-lang-toggle-mobile');
    if (mobileBtn) {
      mobileBtn.addEventListener('click', function () {
        setLanguage(currentLang === 'en' ? 'es' : 'en');
      });
    }
    if (existing || mobileBtn) {
      updateToggleBtn();
      return;
    }
    // Only auto-inject the floating toggle on pages with comprehensive translations
    // (pages with 10+ data-i18n elements have full translations; others just have nav items)
    var i18nCount = document.querySelectorAll('[data-i18n]').length;
    if (i18nCount < 10) return;
    const btn = document.createElement('button');
    btn.id = 'fl-lang-toggle';
    btn.type = 'button';
    btn.style.cssText = [
      'position:fixed',
      'bottom:24px',
      'right:24px',
      'z-index:9999',
      'background:linear-gradient(135deg,#1a1a1a 0%,#2a2a2a 100%)',
      'color:#fff',
      'border:2px solid #00e676',
      'border-radius:30px',
      'padding:10px 20px',
      'font-family:DM Sans,-apple-system,sans-serif',
      'font-size:0.95rem',
      'font-weight:700',
      'letter-spacing:0.3px',
      'cursor:pointer',
      'transition:all 0.25s ease',
      'box-shadow:0 4px 20px rgba(0,230,118,0.25),0 2px 8px rgba(0,0,0,0.4)',
      'user-select:none'
    ].join(';');
    btn.addEventListener('mouseover', function () {
      btn.style.background = '#00e676';
      btn.style.color = '#000';
      btn.style.borderColor = '#00e676';
      btn.style.boxShadow = '0 4px 24px rgba(0,230,118,0.4)';
      btn.style.transform = 'scale(1.05)';
    });
    btn.addEventListener('mouseout', function () {
      btn.style.background = 'linear-gradient(135deg,#1a1a1a 0%,#2a2a2a 100%)';
      btn.style.color = '#fff';
      btn.style.borderColor = '#00e676';
      btn.style.boxShadow = '0 4px 20px rgba(0,230,118,0.25),0 2px 8px rgba(0,0,0,0.4)';
      btn.style.transform = 'scale(1)';
    });
    btn.addEventListener('click', function () {
      setLanguage(currentLang === 'en' ? 'es' : 'en');
    });
    document.body.appendChild(btn);
    updateToggleBtn();
  }

  // ── Public API ────────────────────────────────────────────────
  window.t = t;
  window.setLanguage = setLanguage;
  window.getCurrentLang = function () { return currentLang; };

  // ── Init ──────────────────────────────────────────────────────
  function init() {
    injectToggleBtn();
    applyTranslations();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
