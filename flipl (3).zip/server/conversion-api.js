'use strict';

/**
 * Meta Conversions API Gateway (CAPIG) — Stape Proxy
 *
 * Sends server-side conversion events to Meta via the Stape CAPIG proxy.
 * Pixel ID: 1297854672218437
 *
 * Required env vars:
 *   CAPIG_URL         — Stape gateway base URL (e.g. https://capig.stape.st)
 *   CAPIG_IDENTIFIER  — Stape identifier (e.g. hdxuiaas)
 *   CAPIG_API_KEY     — Bearer token for Authorization header
 *
 * Usage:
 *   const { sendCapigEvent } = require('./server/conversion-api');
 *   await sendCapigEvent({ eventName: 'Purchase', email, ip, userAgent, customData: { value: 250, currency: 'USD' } });
 */

const crypto = require('crypto');
const https = require('https');

const CAPIG_PIXEL_ID = '1297854672218437';

/**
 * Hash a string with SHA-256, lowercase + trimmed (Meta's normalization requirement).
 */
function sha256(value) {
  if (!value) return undefined;
  return crypto.createHash('sha256').update(value.toString().trim().toLowerCase()).digest('hex');
}

/**
 * Send a single event to Meta CAPIG via Stape proxy.
 *
 * @param {object} opts
 * @param {string} opts.eventName       - Meta standard event name: 'PageView', 'Lead', 'Purchase', etc.
 * @param {string} [opts.eventId]       - Deduplication ID (match client-side fbq event_id if present)
 * @param {string} [opts.email]         - User email (will be SHA-256 hashed)
 * @param {string} [opts.phone]         - User phone (digits only, will be SHA-256 hashed)
 * @param {string} [opts.ip]            - Client IP address
 * @param {string} [opts.userAgent]     - Client User-Agent
 * @param {string} [opts.fbc]           - _fbc cookie value
 * @param {string} [opts.fbp]           - _fbp cookie value
 * @param {string} [opts.sourceUrl]     - Page URL where conversion happened
 * @param {object} [opts.customData]    - Event-specific data (value, currency, content_ids, etc.)
 * @returns {Promise<object|null>}      - CAPIG response or null on error/misconfiguration
 */
async function sendCapigEvent({
  eventName,
  eventId,
  email,
  phone,
  ip,
  userAgent,
  fbc,
  fbp,
  sourceUrl,
  customData = {}
}) {
  const capigUrl = process.env.CAPIG_URL;
  const identifier = process.env.CAPIG_IDENTIFIER;
  const apiKey = process.env.CAPIG_API_KEY;

  if (!capigUrl || !identifier || !apiKey) {
    console.log(`[CAPIG] Skipped — env vars not configured. Event: ${eventName}`);
    return null;
  }

  // Build user_data with hashed PII
  const userData = {};
  if (email) userData.em = [sha256(email)];
  if (phone) userData.ph = [sha256(phone.replace(/\D/g, ''))];
  if (ip) userData.client_ip_address = ip;
  if (userAgent) userData.client_user_agent = userAgent;
  if (fbc) userData.fbc = fbc;
  if (fbp) userData.fbp = fbp;

  const eventIdResolved = eventId || crypto.randomBytes(16).toString('hex');

  const payload = {
    data: [{
      event_name: eventName,
      event_time: Math.floor(Date.now() / 1000),
      event_id: eventIdResolved,
      event_source_url: sourceUrl || process.env.APP_URL || 'https://flipl.polsia.app',
      action_source: 'website',
      user_data: userData,
      custom_data: customData
    }]
  };

  // CAPIG endpoint: POST /api/gateway/v1/{identifier}/events/{pixel_id}
  const endpoint = `${capigUrl.replace(/\/$/, '')}/api/gateway/v1/${identifier}/events/${CAPIG_PIXEL_ID}`;

  try {
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify(payload)
    });

    const responseText = await response.text();
    let responseData;
    try {
      responseData = JSON.parse(responseText);
    } catch (_) {
      responseData = { raw: responseText };
    }

    if (response.ok) {
      console.log(`[CAPIG] ✅ ${eventName} sent. EventId: ${eventIdResolved}`, responseData);
    } else {
      console.error(`[CAPIG] ❌ ${eventName} failed (${response.status}):`, responseData);
    }

    return responseData;
  } catch (err) {
    console.error(`[CAPIG] ❌ ${eventName} network error:`, err.message);
    return null;
  }
}

/**
 * Fire-and-forget wrapper — logs errors but never throws.
 * Use this for non-blocking integration in request handlers.
 */
function fireCapigEvent(opts) {
  sendCapigEvent(opts).catch(err => {
    console.error(`[CAPIG] Unhandled error for ${opts.eventName}:`, err.message);
  });
}

module.exports = { sendCapigEvent, fireCapigEvent, sha256 };
