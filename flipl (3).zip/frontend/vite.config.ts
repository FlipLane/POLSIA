import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [
    react(),
    tailwindcss(),
  ],
  // Serve from /app/ path — Express static maps /app/* → public/app/*
  base: '/app/',
  build: {
    // Output to parent public/app so Express serves the built files
    outDir: '../public/app',
    emptyOutDir: true,
  },
})
