/**
 * FlipLane Visitor Analytics
 *
 * Lightweight, zero-dependency tracking module.
 * Sends events to POST /api/track → stored in `events` table.
 *
 * Events:
 *  - funnel_stage   { funnel_stage }                  — discrete funnel checkpoints
 *  - section_view   { section }                        — IntersectionObserver triggers
 *  - cta_click      { label, section, href? }          — every CTA / button click
 *  - scroll_depth   { pct }                            — 25/50/75/90/100% milestones
 *  - time_on_section{ section, duration_ms }           — time before leaving section
 *  - exit           { last_section, scroll_pct, duration_ms } — page unload beacon
 */

// ── Session ID ────────────────────────────────────────────────────────────────

function getSessionId(): string {
  const KEY = 'fl_sid';
  let sid = sessionStorage.getItem(KEY);
  if (!sid) {
    sid = crypto.randomUUID();
    sessionStorage.setItem(KEY, sid);
  }
  return sid;
}

// ── Core send ─────────────────────────────────────────────────────────────────

function send(event_type: string, metadata?: Record<string, unknown>): void {
  const payload = JSON.stringify({
    event_type,
    session_id: getSessionId(),
    page: window.location.pathname,
    metadata: metadata ?? {},
  });

  // Prefer sendBeacon (fire-and-forget, survives page unload)
  if (navigator.sendBeacon) {
    navigator.sendBeacon('/api/track', new Blob([payload], { type: 'application/json' }));
  } else {
    fetch('/api/track', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: payload,
      keepalive: true,
    }).catch(() => {/* silent — analytics never crashes the app */});
  }
}

// ── Deduplication cache ───────────────────────────────────────────────────────

const _sent = new Set<string>();

function once(key: string, fn: () => void): void {
  if (_sent.has(key)) return;
  _sent.add(key);
  fn();
}

// ── Public API ────────────────────────────────────────────────────────────────

/** Log a funnel stage checkpoint */
export function trackFunnelStage(stage: 'hero_view' | 'lane_interaction' | 'pricing_view' | 'apply_click' | 'form_submit'): void {
  once(`funnel:${stage}`, () => send('funnel_stage', { funnel_stage: stage }));
}

/** Log a section coming into view (each section fires once per session) */
export function trackSectionView(section: string): void {
  once(`section:${section}`, () => send('section_view', { section }));
}

/** Log a CTA click */
export function trackCtaClick(label: string, section: string, href?: string): void {
  send('cta_click', { label, section, ...(href ? { href } : {}) });
}

/** Internal — called by scroll tracker */
function trackScrollDepth(pct: number): void {
  once(`scroll:${pct}`, () => send('scroll_depth', { pct }));
}

// ── Page-level tracking (call once on mount) ──────────────────────────────────

let _pageStartMs = Date.now();
let _lastSection = 'hero';
let _scrollPct = 0;

export function setLastSection(section: string): void {
  _lastSection = section;
}

export function initPageTracking(): () => void {
  _pageStartMs = Date.now();

  // ── Scroll depth milestones ────────────────────────────────────────────────
  const milestones = [25, 50, 75, 90, 100];
  let nextMilestone = 0;

  function onScroll(): void {
    const scrolled = window.scrollY + window.innerHeight;
    const total = document.documentElement.scrollHeight;
    const pct = Math.round((scrolled / total) * 100);
    _scrollPct = pct;

    while (nextMilestone < milestones.length && pct >= milestones[nextMilestone]) {
      trackScrollDepth(milestones[nextMilestone]);
      nextMilestone++;
    }
  }

  window.addEventListener('scroll', onScroll, { passive: true });

  // ── Exit / unload beacon ───────────────────────────────────────────────────
  function onUnload(): void {
    const duration_ms = Date.now() - _pageStartMs;
    send('exit', {
      last_section: _lastSection,
      scroll_pct: _scrollPct,
      duration_ms,
    });
  }

  window.addEventListener('pagehide', onUnload);
  // visibilitychange fires on mobile Safari before pagehide
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') onUnload();
  });

  // Return cleanup (call on React unmount)
  return () => {
    window.removeEventListener('scroll', onScroll);
    window.removeEventListener('pagehide', onUnload);
  };
}

// ── IntersectionObserver helper ───────────────────────────────────────────────

/**
 * Observe a ref and fire callbacks when it enters/exits the viewport.
 * @param el        - DOM element to observe
 * @param section   - Section name (used for trackSectionView + setLastSection)
 * @param threshold - 0–1, fraction visible before triggering (default 0.2)
 * @returns cleanup function
 */
export function observeSection(
  el: Element | null,
  section: string,
  threshold = 0.2,
): () => void {
  if (!el || typeof IntersectionObserver === 'undefined') return () => {};

  const observer = new IntersectionObserver(
    (entries) => {
      for (const entry of entries) {
        if (entry.isIntersecting) {
          trackSectionView(section);
          setLastSection(section);
        }
      }
    },
    { threshold },
  );

  observer.observe(el);
  return () => observer.disconnect();
}
