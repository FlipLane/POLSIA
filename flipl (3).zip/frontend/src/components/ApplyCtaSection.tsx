// ApplyCtaSection — "Ready to Join the Lane?"
// Full-width dramatic CTA with 3 mini-cards + pulsing button
import { useEffect, useRef } from 'react'
import { motion } from 'framer-motion'
import { useTranslation } from 'react-i18next'
import { Phone } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { observeSection, trackCtaClick, trackFunnelStage } from '../analytics'

const LANE_KEYS = ['buyer', 'affiliate', 'coop'] as const
const LANE_COLORS = ['#00e5ff', '#a855f7', '#00ff7f'] as const

export default function ApplyCtaSection() {
  const { t } = useTranslation()
  const navigate = useNavigate()
  const sectionRef = useRef<HTMLElement>(null)
  useEffect(() => observeSection(sectionRef.current, 'apply_cta'), [])

  return (
    <section
      ref={sectionRef}
      className="relative py-28 sm:py-40 overflow-hidden"
      aria-label="Apply CTA"
      style={{
        background: 'linear-gradient(180deg, #0a0a0a 0%, #080f08 50%, #0a0a0a 100%)',
      }}
    >
      {/* Top section divider */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-fl-green/20 to-transparent" />
      {/* Green radial glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse 70% 60% at 50% 60%, rgba(0,255,127,0.07) 0%, transparent 70%)',
        }}
      />
      {/* Subtle grid */}
      <div
        className="absolute inset-0 opacity-[0.015] pointer-events-none"
        style={{
          backgroundImage:
            'linear-gradient(rgba(0,255,127,1) 1px, transparent 1px), linear-gradient(90deg, rgba(0,255,127,1) 1px, transparent 1px)',
          backgroundSize: '44px 44px',
        }}
      />

      <div className="relative z-10 max-w-6xl mx-auto px-6 sm:px-10">
        {/* ── Header ── */}
        <div className="text-center mb-16">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.6 }}
            className="font-mono text-fl-green uppercase tracking-[0.2em] text-[0.7rem] mb-4"
          >
            {t('apply.eyebrow')}
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 36 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="font-display font-bold text-fl-white leading-tight"
            style={{ fontSize: 'clamp(2.2rem, 6vw, 4rem)' }}
          >
            {t('apply.heading')}
          </motion.h2>
        </div>

        {/* ── Three mini-cards ── */}
        <motion.div
          className="grid grid-cols-1 sm:grid-cols-3 gap-5 mb-16"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-80px' }}
          variants={{ hidden: {}, visible: { transition: { staggerChildren: 0.12 } } }}
        >
          {LANE_KEYS.map((key, i) => (
            <motion.div
              key={key}
              className="flex flex-col gap-3 p-6 rounded-2xl border border-fl-border bg-fl-card/60"
              variants={{
                hidden: { opacity: 0, y: 30, scale: 0.95 },
                visible: {
                  opacity: 1, y: 0, scale: 1,
                  transition: { duration: 0.55, ease: [0.22, 1, 0.36, 1], delay: i * 0.12 },
                },
              }}
            >
              <div
                className="w-2 h-2 rounded-full"
                style={{ background: LANE_COLORS[i], boxShadow: `0 0 8px ${LANE_COLORS[i]}` }}
              />
              <h3
                className="font-display font-bold text-sm"
                style={{ color: LANE_COLORS[i] }}
              >
                {t(`apply.lanes.${key}.title`)}
              </h3>
              <p className="font-body text-fl-muted text-sm leading-relaxed">
                {t(`apply.lanes.${key}.pitch`)}
              </p>
            </motion.div>
          ))}
        </motion.div>

        {/* ── CTA Buttons ── */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.6, delay: 0.45 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-5"
        >
          <motion.button
            type="button"
            onClick={() => { trackCtaClick('Join the Co-op', 'apply_cta', '/join'); trackFunnelStage('apply_click'); navigate('/join') }}
            className="inline-flex items-center gap-3 px-10 py-5 rounded-xl font-mono text-fl-black font-bold uppercase tracking-widest bg-fl-green text-base cursor-pointer"
            style={{ animation: 'pulse-green 2.5s ease-in-out infinite' }}
            whileHover={{ scale: 1.05, boxShadow: '0 0 60px rgba(0,255,127,0.5)' }}
            whileTap={{ scale: 0.97 }}
          >
            {t('apply.cta_primary')}
            <span className="text-xl">→</span>
          </motion.button>

          <a
            href="tel:+18005551234"
            onClick={() => trackCtaClick('Call Us', 'apply_cta', 'tel:+18005551234')}
            className="inline-flex items-center gap-2 px-6 py-5 rounded-xl border border-fl-border bg-fl-card/50 font-mono text-fl-muted text-sm uppercase tracking-widest hover:border-fl-green/50 hover:text-fl-white transition-all duration-200"
          >
            <Phone className="w-4 h-4" />
            {t('apply.cta_secondary')}
          </a>
        </motion.div>

        {/* ── Trust note ── */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="text-center font-mono text-fl-muted/50 text-[0.65rem] uppercase tracking-widest mt-8"
        >
          {t('apply.trust_note')}
        </motion.p>
      </div>
    </section>
  )
}
