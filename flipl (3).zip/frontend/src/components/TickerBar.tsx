// TickerBar — Scrolling live activity feed
// Dual-track seamless loop, pauses on hover, uses i18n ticker messages

import { useTranslation } from 'react-i18next'

export default function TickerBar() {
  const { t } = useTranslation()
  const items = t('ticker.items', { returnObjects: true }) as string[]

  // Double for seamless loop
  const doubled = [...items, ...items]

  return (
    <div
      className="relative overflow-hidden border-y border-fl-border bg-fl-dark"
      style={{ height: '44px' }}
      aria-hidden="true"
    >
      {/* Left fade */}
      <div
        className="absolute left-0 top-0 bottom-0 z-10 w-16 pointer-events-none"
        style={{
          background: 'linear-gradient(90deg, var(--color-fl-dark), transparent)',
        }}
      />
      {/* Right fade */}
      <div
        className="absolute right-0 top-0 bottom-0 z-10 w-16 pointer-events-none"
        style={{
          background: 'linear-gradient(270deg, var(--color-fl-dark), transparent)',
        }}
      />

      {/* Track */}
      <div
        className="flex items-center h-full whitespace-nowrap"
        style={{
          animation: 'ticker 38s linear infinite',
          width: 'max-content',
        }}
        onMouseEnter={(e) => {
          ;(e.currentTarget as HTMLDivElement).style.animationPlayState = 'paused'
        }}
        onMouseLeave={(e) => {
          ;(e.currentTarget as HTMLDivElement).style.animationPlayState = 'running'
        }}
      >
        {doubled.map((item, i) => (
          <span key={i} className="inline-flex items-center gap-2 px-6">
            <span
              className="w-1.5 h-1.5 rounded-full bg-fl-green flex-shrink-0"
              style={{ boxShadow: '0 0 6px rgba(0,255,127,0.8)' }}
            />
            <span className="font-mono text-xs text-fl-muted tracking-wide">
              {item}
            </span>
          </span>
        ))}
      </div>
    </div>
  )
}
