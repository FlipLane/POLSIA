// ToolkitSection — "Your Automotive Arsenal"
// 3-col grid of tool cards with hover glow
import { motion } from 'framer-motion'
import { useTranslation } from 'react-i18next'

/* ── Tool Icons (custom SVGs, no brand logos) ── */
const TOOL_ICONS: Record<string, React.ReactNode> = {
  jd_power: (
    <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
      <rect x="2" y="6" width="28" height="20" rx="3" stroke="#00ff7f" strokeWidth="1.5"/>
      <path d="M8 16l4 4 8-8" stroke="#00ff7f" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <circle cx="24" cy="10" r="2" fill="#00ff7f" opacity="0.6"/>
    </svg>
  ),
  kbb: (
    <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
      <rect x="4" y="8" width="24" height="16" rx="2" stroke="#00ff7f" strokeWidth="1.5"/>
      <path d="M10 16h12M10 12h6M10 20h8" stroke="#00ff7f" strokeWidth="1.5" strokeLinecap="round" opacity="0.7"/>
      <circle cx="22" cy="10" r="1.5" fill="#00ff7f"/>
    </svg>
  ),
  nada: (
    <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
      <path d="M6 24L12 8l6 12 4-6 4 10" stroke="#00ff7f" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
      <circle cx="6" cy="24" r="2" fill="#00ff7f" opacity="0.5"/>
      <circle cx="12" cy="8" r="2" fill="#00ff7f" opacity="0.5"/>
      <circle cx="26" cy="24" r="2" fill="#00ff7f" opacity="0.5"/>
    </svg>
  ),
  vin_check: (
    <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
      <path d="M16 4L26 9v7c0 5.5-4 10-10 13C10 26 6 21.5 6 16V9z" stroke="#00ff7f" strokeWidth="1.5" strokeLinejoin="round"/>
      <path d="M11 16l3 3 6-6" stroke="#00ff7f" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  copart: (
    <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
      <rect x="4" y="16" width="6" height="10" rx="1" stroke="#00ff7f" strokeWidth="1.5"/>
      <rect x="13" y="10" width="6" height="16" rx="1" stroke="#00ff7f" strokeWidth="1.5"/>
      <rect x="22" y="6" width="6" height="20" rx="1" stroke="#00ff7f" strokeWidth="1.5"/>
      <path d="M4 26h24" stroke="#00ff7f" strokeWidth="1" opacity="0.4"/>
    </svg>
  ),
  iaai: (
    <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
      <path d="M6 26V18l10-14 10 14v8" stroke="#00ff7f" strokeWidth="1.5" strokeLinejoin="round"/>
      <rect x="11" y="18" width="10" height="8" rx="1" stroke="#00ff7f" strokeWidth="1.5"/>
      <circle cx="16" cy="10" r="3" stroke="#00ff7f" strokeWidth="1.5"/>
    </svg>
  ),
  edge_pipeline: (
    <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
      <circle cx="8" cy="16" r="4" stroke="#00ff7f" strokeWidth="1.5"/>
      <circle cx="24" cy="16" r="4" stroke="#00ff7f" strokeWidth="1.5"/>
      <path d="M12 16h8" stroke="#00ff7f" strokeWidth="1.5" strokeDasharray="2 2"/>
      <path d="M16 8v4M16 20v4" stroke="#00ff7f" strokeWidth="1.5" strokeLinecap="round" opacity="0.5"/>
    </svg>
  ),
  titlemax: (
    <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
      <rect x="6" y="8" width="20" height="16" rx="2" stroke="#00ff7f" strokeWidth="1.5"/>
      <path d="M11 14h10M11 18h6" stroke="#00ff7f" strokeWidth="1.5" strokeLinecap="round"/>
      <circle cx="23" cy="18" r="2.5" fill="#00ff7f" opacity="0.25" stroke="#00ff7f" strokeWidth="1.5"/>
      <path d="M22 18l.8.8 1.4-1.4" stroke="#00ff7f" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
}

const TOOL_KEYS = ['jd_power', 'kbb', 'nada', 'vin_check', 'copart', 'iaai', 'edge_pipeline', 'titlemax'] as const

export default function ToolkitSection() {
  const { t } = useTranslation()
  return (
    <section
      className="relative py-28 sm:py-36 overflow-hidden"
      aria-label="Free Toolkit"
      style={{
        background: 'linear-gradient(180deg, #0a0a0a 0%, #0d100d 50%, #0a0a0a 100%)',
      }}
    >
      {/* Top section divider */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-fl-green/15 to-transparent" />
      <div className="relative z-10 max-w-6xl mx-auto px-6 sm:px-10">
        {/* ── Header ── */}
        <div className="text-center mb-16">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.6 }}
            className="font-mono text-fl-green uppercase tracking-[0.2em] text-[0.7rem] mb-4"
          >
            {t('toolkit.eyebrow')}
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 36 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="font-display font-bold text-fl-white leading-tight"
            style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)' }}
          >
            {t('toolkit.heading')}
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="font-body text-fl-muted text-lg mt-4 max-w-xl mx-auto"
          >
            {t('toolkit.subheading')}
          </motion.p>
        </div>

        {/* ── Tool Cards ── */}
        <motion.div
          className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-80px' }}
          variants={{ hidden: {}, visible: { transition: { staggerChildren: 0.08 } } }}
        >
          {TOOL_KEYS.map((key, i) => (
            <motion.div
              key={key}
              className="group flex flex-col gap-4 p-6 rounded-2xl border border-fl-border bg-fl-card"
              variants={{
                hidden: { opacity: 0, y: 30, scale: 0.94 },
                visible: {
                  opacity: 1, y: 0, scale: 1,
                  transition: { duration: 0.55, ease: [0.22, 1, 0.36, 1], delay: i * 0.07 },
                },
              }}
              whileHover={{
                y: -5,
                borderColor: 'rgba(0, 255, 127, 0.3)',
                boxShadow: '0 16px 48px rgba(0,0,0,0.4), 0 0 30px rgba(0,255,127,0.1)',
                transition: { duration: 0.25 },
              }}
            >
              {/* Icon */}
              <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-fl-green/5 border border-fl-green/15 transition-all duration-300 group-hover:bg-fl-green/10 group-hover:border-fl-green/30">
                {TOOL_ICONS[key]}
              </div>

              {/* Name */}
              <h3 className="font-display font-bold text-fl-white text-base">
                {t(`toolkit.tools.${key}.name`)}
              </h3>

              {/* Description */}
              <p className="font-body text-fl-muted text-xs leading-relaxed">
                {t(`toolkit.tools.${key}.description`)}
              </p>

              {/* Free badge */}
              <span className="mt-auto inline-flex items-center gap-1 font-mono text-fl-green text-[0.6rem] uppercase tracking-widest">
                <span className="w-1.5 h-1.5 rounded-full bg-fl-green inline-block" />
                {t('toolkit.free_badge')}
              </span>
            </motion.div>
          ))}
        </motion.div>

        {/* ── Bottom note ── */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.6, delay: 0.7 }}
          className="text-center font-mono text-fl-muted text-xs uppercase tracking-[0.15em] mt-12"
        >
          {t('toolkit.footer_note')}
        </motion.p>
      </div>
    </section>
  )
}
