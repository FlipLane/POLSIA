import { useEffect, useRef } from 'react'
import { motion } from 'framer-motion'
import { ArrowRight, ChevronDown, Shield } from 'lucide-react'
import { Link } from 'react-router-dom'
import ParticleCanvas from './ParticleCanvas'
import { observeSection, trackFunnelStage, trackCtaClick } from '../analytics'

type FadeInUpProps = {
  children: React.ReactNode
  delay?: number
  className?: string
}

function FadeInUp({ children, delay = 0, className }: FadeInUpProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 32 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, ease: 'easeOut', delay }}
      className={className}
    >
      {children}
    </motion.div>
  )
}

export default function HeroSection() {
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    return observeSection(sectionRef.current, 'hero', 0.3)
  }, [])

  useEffect(() => {
    trackFunnelStage('hero_view')
  }, [])

  return (
    <section
      ref={sectionRef}
      className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden pt-20"
      aria-label="Hero"
    >
      {/* ── Particle network background ── */}
      <div className="absolute inset-0 z-0">
        <ParticleCanvas />
      </div>

      {/* ── Animated grid overlay ── */}
      <div
        className="absolute inset-0 z-[1] pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(rgba(0,255,127,0.04) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0,255,127,0.04) 1px, transparent 1px)
          `,
          backgroundSize: '40px 40px',
          animation: 'gridMove 8s linear infinite',
        }}
      />

      {/* ── Scanline sweep ── */}
      <div
        className="absolute inset-x-0 top-0 z-[2] pointer-events-none h-[2px]"
        style={{
          background: 'linear-gradient(90deg, transparent, rgba(0,255,127,0.3), transparent)',
          animation: 'scanline 6s linear infinite',
        }}
      />

      {/* ── Radial vignette at edges ── */}
      <div
        className="absolute inset-0 z-[2] pointer-events-none"
        style={{
          background:
            'radial-gradient(ellipse 80% 60% at 50% 50%, transparent 30%, rgba(10,10,10,0.85) 100%)',
        }}
      />

      {/* ── Main content ── */}
      <div className="relative z-10 w-full max-w-5xl mx-auto px-6 sm:px-10 text-center flex flex-col items-center gap-8">

        {/* Badge */}
        <FadeInUp delay={0}>
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-fl-green/30 bg-fl-green/5 backdrop-blur-sm">
            <span
              className="w-2 h-2 rounded-full bg-fl-green"
              style={{ animation: 'pulse-green 2s ease-in-out infinite' }}
            />
            <span className="font-mono text-fl-green text-xs uppercase tracking-[0.2em]">
              Backed by Byrd Dawgs Automotive Group · Licensed Dealer Network
            </span>
          </div>
        </FadeInUp>

        {/* Headline */}
        <FadeInUp delay={0.15}>
          <h1
            className="font-display font-extrabold leading-[1.05] tracking-tight text-fl-white"
            style={{ fontSize: 'clamp(2.6rem, 7vw, 5.5rem)' }}
          >
            Buy Smarter.{' '}
            <span
              className="relative inline-block text-fl-green"
              style={{
                textShadow:
                  '0 0 40px rgba(0,255,127,0.4), 0 0 80px rgba(0,255,127,0.15)',
              }}
            >
              Sell Bigger.
              {/* Green underline glow */}
              <span
                className="absolute bottom-0 left-0 right-0 h-[3px] rounded-full bg-fl-green"
                style={{ boxShadow: '0 0 12px rgba(0,255,127,0.8)' }}
              />
            </span>{' '}
            FlipLane.
          </h1>
        </FadeInUp>

        {/* Subheadline */}
        <FadeInUp delay={0.28}>
          <p
            className="font-body text-fl-muted max-w-2xl mx-auto leading-relaxed"
            style={{ fontSize: 'clamp(1rem, 2.2vw, 1.2rem)', fontWeight: 300 }}
          >
            Whether you need a car at the best price — or want to build a car business — we're your lane.
          </p>
        </FadeInUp>

        {/* Two-path CTA section */}
        <FadeInUp delay={0.42}>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full max-w-xl mx-auto mt-2">

            {/* Primary — Car Concierge (Buyer Lane) */}
            <Link
              to="/join?lane=buyer"
              onClick={() => {
                trackCtaClick('Find My Car', 'hero', '/join?lane=buyer')
                trackFunnelStage('lane_interaction')
              }}
              className="group relative flex-1 inline-flex items-center justify-center gap-2 px-7 py-4 rounded-xl bg-fl-green text-fl-black font-body font-bold text-base overflow-hidden transition-all duration-200 hover:brightness-110 active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-fl-green focus-visible:ring-offset-2 focus-visible:ring-offset-fl-black"
              style={{ boxShadow: '0 0 28px rgba(0,255,127,0.4), 0 4px 16px rgba(0,0,0,0.4)' }}
            >
              <span className="absolute inset-0 translate-x-[-100%] bg-white/10 transition-transform duration-300 group-hover:translate-x-0" />
              <span className="relative z-10 leading-tight text-left">
                <span className="block text-sm font-semibold opacity-70 uppercase tracking-widest mb-0.5">Car Concierge</span>
                Find My Car
              </span>
              <ArrowRight className="relative z-10 w-4 h-4 transition-transform duration-200 group-hover:translate-x-1 shrink-0" />
            </Link>

            {/* Divider text */}
            <span className="font-mono text-fl-muted/50 text-xs uppercase tracking-widest self-center hidden sm:block">or</span>
            <span className="font-mono text-fl-muted/50 text-xs uppercase tracking-widest self-center sm:hidden">— or —</span>

            {/* Secondary — Co-op Membership */}
            <Link
              to="/join?lane=coop"
              onClick={() => {
                trackCtaClick('Join the Co-op', 'hero', '/join?lane=coop')
                trackFunnelStage('lane_interaction')
              }}
              className="group flex-1 inline-flex items-center justify-center gap-2 px-7 py-4 rounded-xl border-2 border-fl-green/50 text-fl-white font-body font-bold text-base transition-all duration-200 hover:border-fl-green hover:bg-fl-green/10 hover:text-fl-green active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-fl-green focus-visible:ring-offset-2 focus-visible:ring-offset-fl-black backdrop-blur-sm"
            >
              <span className="leading-tight text-left">
                <span className="block text-sm font-semibold opacity-60 uppercase tracking-widest mb-0.5">Co-op Membership</span>
                Join — <span className="text-fl-green">$250</span>
              </span>
              <ArrowRight className="w-4 h-4 opacity-60 transition-all duration-200 group-hover:opacity-100 group-hover:translate-x-0.5 group-hover:text-fl-green shrink-0" />
            </Link>
          </div>
        </FadeInUp>

        {/* Trust signal row */}
        <FadeInUp delay={0.55}>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-8 mt-1">
            {/* Dealer backing */}
            <div className="flex items-center gap-2.5 px-4 py-2.5 rounded-lg border border-fl-border bg-fl-card/50 backdrop-blur-sm">
              <Shield className="w-4 h-4 text-fl-green shrink-0" />
              <span className="font-mono text-fl-muted text-xs uppercase tracking-wide">
                Licensed Dealer Network
              </span>
            </div>

            {/* Price comparison */}
            <div className="flex items-center gap-2 font-mono text-fl-muted text-xs uppercase tracking-wide">
              <span className="text-fl-green font-bold text-sm">$250</span>
              <span className="opacity-50">vs</span>
              <span className="line-through opacity-40">$15,000+</span>
              <span className="opacity-60">dealer license</span>
            </div>
          </div>
        </FadeInUp>

        {/* Path descriptions — desktop only */}
        <FadeInUp delay={0.65}>
          <div className="hidden md:grid grid-cols-2 gap-4 w-full max-w-xl mx-auto mt-1">
            <div className="text-left px-4 py-3 rounded-lg border border-fl-border/50 bg-fl-card/30">
              <p className="font-mono text-fl-green text-[10px] uppercase tracking-widest mb-1">Car Concierge</p>
              <p className="font-body text-fl-muted text-xs leading-relaxed">
                We find and negotiate your next vehicle at the best price. Flat rate, no dealer markup.
              </p>
            </div>
            <div className="text-left px-4 py-3 rounded-lg border border-fl-border/50 bg-fl-card/30">
              <p className="font-mono text-fl-green text-[10px] uppercase tracking-widest mb-1">Co-op Membership</p>
              <p className="font-body text-fl-muted text-xs leading-relaxed">
                Start your car business. Keep 100% of every deal. Backed by a licensed dealer network.
              </p>
            </div>
          </div>
        </FadeInUp>
      </div>

      {/* ── Scroll indicator ── */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2, duration: 0.8 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-1 text-fl-muted/50"
      >
        <span className="font-mono text-[10px] uppercase tracking-[0.2em]">Scroll</span>
        <ChevronDown
          className="w-4 h-4"
          style={{ animation: 'bounceDown 1.5s ease-in-out infinite' }}
        />
      </motion.div>
    </section>
  )
}
