// StatsSection — Animated count-up stats bar
// Uses IntersectionObserver to trigger count animation on scroll-into-view

import { useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { trackSectionView } from '../analytics'

type Stat = {
  target: number
  prefix: string
  suffix: string
  labelKey: string
}

const STATS: Stat[] = [
  { target: 300, prefix: '', suffix: '+', labelKey: 'stats.vehicles_sourced' },
  { target: 7, prefix: '$', suffix: 'K', labelKey: 'stats.avg_savings' },
  { target: 50, prefix: '', suffix: '', labelKey: 'stats.states_covered' },
  { target: 250, prefix: '$', suffix: '', labelKey: 'stats.membership_fee' },
]

function useCountUp(target: number, duration = 1800, active: boolean) {
  const [value, setValue] = useState(0)
  const frameRef = useRef<number | null>(null)

  useEffect(() => {
    if (!active) return
    const start = performance.now()
    const tick = (now: number) => {
      const elapsed = now - start
      const progress = Math.min(elapsed / duration, 1)
      // Ease-out cubic
      const ease = 1 - Math.pow(1 - progress, 3)
      setValue(Math.round(ease * target))
      if (progress < 1) {
        frameRef.current = requestAnimationFrame(tick)
      }
    }
    frameRef.current = requestAnimationFrame(tick)
    return () => {
      if (frameRef.current !== null) cancelAnimationFrame(frameRef.current)
    }
  }, [active, target, duration])

  return value
}

function StatItem({ stat, active }: { stat: Stat; active: boolean }) {
  const { t } = useTranslation()
  const value = useCountUp(stat.target, 1800, active)

  return (
    <div className="flex flex-col items-center gap-1 px-8 py-6 relative group">
      {/* Number */}
      <span
        className={`font-display font-extrabold tabular-nums leading-none ${active ? 'text-fl-green' : 'text-fl-white'}`}
        style={{
          fontSize: 'clamp(2rem, 5vw, 3rem)',
          fontFeatureSettings: '"tnum"',
          textShadow: active
            ? '0 0 20px rgba(0,255,127,0.25)'
            : undefined,
          transition: 'text-shadow 0.4s ease',
        }}
      >
        {stat.prefix}
        {value}
        {stat.suffix}
      </span>
      {/* Label */}
      <span className="font-mono text-fl-muted text-xs uppercase tracking-[0.15em]">
        {t(stat.labelKey)}
      </span>
      {/* Vertical divider (not last) */}
    </div>
  )
}

export default function StatsSection() {
  const ref = useRef<HTMLDivElement>(null)
  const [active, setActive] = useState(false)

  useEffect(() => {
    const el = ref.current
    if (!el) return
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !active) {
          setActive(true)
          trackSectionView('stats')
        }
      },
      { threshold: 0.3 }
    )
    observer.observe(el)
    return () => observer.disconnect()
  }, [active])

  return (
    <section
      ref={ref}
      className="relative bg-fl-card border-y border-fl-border/60 py-4 sm:py-6"
      aria-label="Key stats"
    >
      {/* Top accent line */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-fl-green/30 to-transparent" />
      <div
        className="max-w-6xl mx-auto px-6 sm:px-10 grid grid-cols-2 sm:grid-cols-4 divide-x divide-fl-border/50"
      >
        {STATS.map((stat, i) => (
          <StatItem key={i} stat={stat} active={active} />
        ))}
      </div>
    </section>
  )
}
