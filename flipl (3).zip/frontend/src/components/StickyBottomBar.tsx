// StickyBottomBar — Appears after scrolling past hero, dismissible
// Glassmorphism + backdrop-blur, stores dismissal in localStorage
import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useTranslation } from 'react-i18next'
import { X } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { trackCtaClick, trackFunnelStage } from '../analytics'

const STORAGE_KEY = 'fl_sticky_dismissed'

export default function StickyBottomBar() {
  const { t } = useTranslation()
  const navigate = useNavigate()
  const [visible, setVisible] = useState(false)
  const [dismissed, setDismissed] = useState(false)

  useEffect(() => {
    // Check persisted dismissal
    try {
      if (localStorage.getItem(STORAGE_KEY) === '1') {
        setDismissed(true)
        return
      }
    } catch {}

    let ticking = false
    const onScroll = () => {
      if (ticking) return
      ticking = true
      requestAnimationFrame(() => {
        const scrollY = window.scrollY
        const threshold = window.innerHeight * 0.85
        // Hide when near the very bottom (within 300px of page end) to avoid footer overlap
        const nearBottom =
          document.documentElement.scrollHeight - scrollY - window.innerHeight < 300
        setVisible(scrollY > threshold && !nearBottom)
        ticking = false
      })
    }

    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const dismiss = () => {
    setDismissed(true)
    try { localStorage.setItem(STORAGE_KEY, '1') } catch {}
  }

  if (dismissed) return null

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ y: '100%', opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: '100%', opacity: 0 }}
          transition={{ type: 'spring', stiffness: 320, damping: 32 }}
          className="fixed bottom-0 left-0 right-0 z-50"
          style={{
            // Don't overlap footer — add bottom padding equal to footer height; we rely on the bar being short
            marginBottom: 0,
          }}
          aria-label="Join FlipLane sticky bar"
        >
          <div
            className="relative border-t border-fl-border/60"
            style={{
              background: 'rgba(10, 10, 10, 0.88)',
              backdropFilter: 'blur(20px)',
              WebkitBackdropFilter: 'blur(20px)',
              boxShadow: '0 -4px 40px rgba(0,0,0,0.5), 0 -1px 0 rgba(0,255,127,0.12)',
            }}
          >
            {/* Green top accent line */}
            <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-fl-green/50 to-transparent" />

            <div className="max-w-6xl mx-auto px-6 sm:px-10 py-4 flex items-center justify-between gap-4">
              {/* Left copy */}
              <div className="flex items-center gap-3 min-w-0">
                <div
                  className="hidden sm:block w-2 h-2 rounded-full bg-fl-green flex-shrink-0"
                  style={{ animation: 'pulse-green 2s ease-in-out infinite' }}
                />
                <p className="font-body text-fl-white text-sm truncate">
                  <span className="font-bold">{t('sticky.headline')}</span>
                  <span className="text-fl-muted hidden sm:inline"> · {t('sticky.subline')}</span>
                </p>
              </div>

              {/* Right: CTA + dismiss */}
              <div className="flex items-center gap-3 flex-shrink-0">
                <motion.button
                  type="button"
                  onClick={() => { trackCtaClick('Join Now (sticky)', 'sticky_bar', '/join'); trackFunnelStage('apply_click'); navigate('/join') }}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg font-mono text-fl-black font-bold text-xs uppercase tracking-widest bg-fl-green cursor-pointer"
                  whileHover={{ scale: 1.04, boxShadow: '0 0 24px rgba(0,255,127,0.5)' }}
                  whileTap={{ scale: 0.97 }}
                >
                  {t('sticky.cta')}
                </motion.button>
                <button
                  onClick={dismiss}
                  className="flex items-center justify-center w-7 h-7 rounded-full border border-fl-border/60 text-fl-muted hover:text-fl-white hover:border-fl-green/40 transition-colors duration-200"
                  aria-label="Dismiss"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
