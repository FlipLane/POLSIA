// TestimonialsSection — "Real People. Real Results."
// 7 testimonial cards with colored badges, star ratings, member photos or initials
import { useEffect, useRef, useState } from 'react'
import { motion } from 'framer-motion'
import { useTranslation } from 'react-i18next'
import { Star } from 'lucide-react'
import { observeSection } from '../analytics'

interface Testimonial {
  key: string
  color: string          // badge + avatar accent
  avatarBg: string       // avatar background
  initials: string       // fallback initials
  image: string          // profile photo URL (empty = initials only)
  badgeKey: string       // i18n key for result badge
}

// Real member photos hosted on R2 (restored from original legacy site)
const R2_BASE = 'https://pub-629428d185ca4960a0a73c850d32294b.r2.dev/company_20624/images'

const TESTIMONIALS: Testimonial[] = [
  { key: 'mario',    color: '#00e5ff', avatarBg: 'rgba(0,229,255,0.15)',   initials: 'M',  image: '',                                                          badgeKey: 'badge_profit' },
  { key: 'raymond',  color: '#00e5ff', avatarBg: 'rgba(0,229,255,0.15)',   initials: 'RL', image: `${R2_BASE}/018a4799-3f46-463e-aa61-05152b6ee5e9.png`,        badgeKey: 'badge_access' },
  { key: 'tony',     color: '#a855f7', avatarBg: 'rgba(168,85,247,0.15)',  initials: 'TT', image: `${R2_BASE}/c375f00d-0546-4984-970a-470bd6ff800b.png`,        badgeKey: 'badge_profit' },
  { key: 'gloria',   color: '#f59e0b', avatarBg: 'rgba(245,158,11,0.15)',  initials: 'G',  image: `${R2_BASE}/de2f32dd-4b4b-4ee1-bf83-21769a704425.png`,        badgeKey: 'badge_savings' },
  { key: 'ronald',   color: '#ec4899', avatarBg: 'rgba(236,72,153,0.15)',  initials: 'RP', image: `${R2_BASE}/8a4d6602-352c-45d9-abc6-542dc8e52d3d.png`,        badgeKey: 'badge_profit' },
  { key: 'laila',    color: '#10b981', avatarBg: 'rgba(16,185,129,0.15)',  initials: 'LM', image: `${R2_BASE}/5c5657e0-b028-4938-87f1-8b192d2b9c9c.png`,        badgeKey: 'badge_access' },
  { key: 'mohammed', color: '#f97316', avatarBg: 'rgba(249,115,22,0.15)', initials: 'MS', image: '',                                                           badgeKey: 'badge_savings' },
]

function StarRow() {
  return (
    <div className="flex items-center gap-1">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
      ))}
    </div>
  )
}

function AvatarImg({ tm }: { tm: Testimonial }) {
  const [failed, setFailed] = useState(false)
  const showImage = tm.image && !failed
  return (
    <div
      className="relative flex-shrink-0 w-11 h-11 rounded-full flex items-center justify-center overflow-hidden"
      style={{
        background: tm.avatarBg,
        border: `2px solid ${tm.color}60`,
        boxShadow: `0 0 12px ${tm.color}25`,
      }}
    >
      {showImage ? (
        <img
          src={tm.image}
          alt=""
          width={44}
          height={44}
          loading="lazy"
          className="w-full h-full object-cover"
          onError={() => setFailed(true)}
        />
      ) : (
        <span
          className="font-display font-bold text-sm select-none"
          style={{ color: tm.color }}
        >
          {tm.initials}
        </span>
      )}
    </div>
  )
}

export default function TestimonialsSection() {
  const { t } = useTranslation()
  const sectionRef = useRef<HTMLElement>(null)
  useEffect(() => observeSection(sectionRef.current, 'testimonials'), [])

  return (
    <section
      ref={sectionRef}
      className="relative py-28 sm:py-36"
      aria-label="Testimonials"
      style={{
        background: 'linear-gradient(180deg, #0a0a0a 0%, #0c0c14 50%, #0a0a0a 100%)',
      }}
    >
      {/* Top section divider */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-fl-green/20 to-transparent" />
      {/* Subtle radial glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse 60% 40% at 50% 30%, rgba(0,255,127,0.03) 0%, transparent 70%)',
        }}
      />
      <div className="relative z-10 max-w-6xl mx-auto px-6 sm:px-10">
        {/* ── Header ── */}
        <div className="text-center mb-16">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.6 }}
            className="font-mono text-fl-green uppercase tracking-[0.2em] text-[0.7rem] mb-4"
          >
            {t('testimonials.eyebrow')}
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 36 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="font-display font-bold text-fl-white leading-tight"
            style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)' }}
          >
            {t('testimonials.heading')}
          </motion.h2>
        </div>

        {/* ── Cards Grid ── */}
        <motion.div
          className="flex flex-wrap justify-center gap-6"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-80px' }}
          variants={{ hidden: {}, visible: { transition: { staggerChildren: 0.1 } } }}
        >
          {TESTIMONIALS.map((tm, i) => (
            <motion.div
              key={tm.key}
              className="group flex flex-col gap-5 p-7 rounded-2xl border border-fl-border bg-fl-card w-full sm:w-[calc(50%-12px)] lg:w-[calc(33.333%-16px)]"
              variants={{
                hidden: { opacity: 0, y: 40, scale: 0.95 },
                visible: {
                  opacity: 1, y: 0, scale: 1,
                  transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1], delay: i * 0.1 },
                },
              }}
              whileHover={{
                y: -4,
                borderColor: 'rgba(0, 255, 127, 0.35)',
                boxShadow: '0 20px 60px rgba(0,0,0,0.4), 0 0 40px rgba(0,255,127,0.1)',
                transition: { duration: 0.3 },
              }}
            >
              {/* Stars */}
              <StarRow />

              {/* Badge */}
              <span
                className="inline-flex items-center px-3 py-1 rounded-full font-mono text-[0.65rem] uppercase tracking-widest self-start"
                style={{
                  color: tm.color,
                  background: `${tm.avatarBg}`,
                  border: `1px solid ${tm.color}40`,
                }}
              >
                {t(`testimonials.${tm.key}.${tm.badgeKey}`)}
              </span>

              {/* Quote */}
              <blockquote className="font-body text-fl-muted text-sm leading-relaxed italic flex-1">
                "{t(`testimonials.${tm.key}.quote`)}"
              </blockquote>

              {/* Avatar + Name */}
              <div className="flex items-center gap-3 mt-auto">
                <AvatarImg tm={tm} />
                <div>
                  <p className="font-display font-bold text-fl-white text-sm">
                    {t(`testimonials.${tm.key}.name`)}
                  </p>
                  <p className="font-body text-fl-muted text-xs">
                    {t(`testimonials.${tm.key}.role`)}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
