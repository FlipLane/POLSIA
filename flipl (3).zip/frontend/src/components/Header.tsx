// FlipLane — Site-wide navigation header
// Sticky dark nav · active page indicator · mobile hamburger drawer

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Link, useLocation } from 'react-router-dom'
import NeonLogo from './NeonLogo'

// ── Nav link definitions ──────────────────────────────────────────────────────
// internal: true → use React Router <Link> (no full page reload)
// internal: false → regular <a> (navigates to static Express page)

interface NavItem {
  label: string
  href: string
  internal?: boolean
}

const NAV_LINKS: NavItem[] = [
  { label: 'Home', href: '/', internal: true },
  { label: 'Three Lanes', href: '/join', internal: true },
  { label: 'Pricing', href: '/pricing', internal: false },
  { label: 'Tools', href: '/tools', internal: false },
  { label: 'Blog', href: '/blog', internal: false },
]

export default function Header() {
  const [mobileOpen, setMobileOpen] = useState(false)
  const location = useLocation()

  const isActive = (href: string) => {
    if (href === '/') return location.pathname === '/'
    return location.pathname.startsWith(href)
  }

  return (
    <motion.header
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: 'easeOut' }}
      className="fixed top-0 left-0 right-0 z-50 backdrop-blur-md bg-fl-black/80 border-b border-fl-border/50"
    >
      <div className="max-w-6xl mx-auto px-6 sm:px-10 py-3 flex items-center justify-between">
        {/* Logo */}
        <Link to="/">
          <NeonLogo size="md" as="span" />
        </Link>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-6">
          {NAV_LINKS.map((link) => {
            const active = isActive(link.href)
            return link.internal ? (
              <Link
                key={link.href}
                to={link.href}
                className={`relative font-body text-sm transition-colors duration-200 group ${
                  active ? 'text-fl-white' : 'text-fl-muted hover:text-fl-white'
                }`}
              >
                {link.label}
                <span className={`absolute left-0 -bottom-1 h-[2px] rounded-full transition-all duration-300 ${
                  active ? 'w-full bg-fl-green' : 'w-0 bg-fl-green group-hover:w-full'
                }`} />
              </Link>
            ) : (
              <a
                key={link.href}
                href={link.href}
                className={`relative font-body text-sm transition-colors duration-200 group ${
                  active ? 'text-fl-white' : 'text-fl-muted hover:text-fl-white'
                }`}
              >
                {link.label}
                <span className={`absolute left-0 -bottom-1 h-[2px] rounded-full transition-all duration-300 ${
                  active ? 'w-full bg-fl-green' : 'w-0 bg-fl-green group-hover:w-full'
                }`} />
              </a>
            )
          })}

          {/* Apply CTA */}
          <Link
            to="/apply"
            className="ml-4 px-5 py-2 rounded-lg bg-fl-green text-fl-black font-body font-bold text-sm transition-all duration-200 hover:brightness-110"
            style={{ boxShadow: '0 0 16px rgba(0,255,127,0.3)' }}
          >
            Apply Now
          </Link>
        </nav>

        {/* Mobile toggle */}
        <button
          className="md:hidden flex flex-col gap-1.5 p-2"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label="Toggle menu"
        >
          <motion.span
            animate={mobileOpen ? { rotate: 45, y: 6 } : { rotate: 0, y: 0 }}
            className="block w-6 h-0.5 bg-fl-white rounded-full"
          />
          <motion.span
            animate={mobileOpen ? { opacity: 0 } : { opacity: 1 }}
            className="block w-6 h-0.5 bg-fl-white rounded-full"
          />
          <motion.span
            animate={mobileOpen ? { rotate: -45, y: -6 } : { rotate: 0, y: 0 }}
            className="block w-6 h-0.5 bg-fl-white rounded-full"
          />
        </button>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="md:hidden overflow-hidden border-t border-fl-border/30 bg-fl-black/95 backdrop-blur-lg"
          >
            <nav className="flex flex-col items-center gap-4 py-6">
              {NAV_LINKS.map((link) => {
                const active = isActive(link.href)
                return link.internal ? (
                  <Link
                    key={link.href}
                    to={link.href}
                    className={`font-body text-base transition-colors ${active ? 'text-fl-green' : 'text-fl-muted hover:text-fl-white'}`}
                    onClick={() => setMobileOpen(false)}
                  >
                    {link.label}
                  </Link>
                ) : (
                  <a
                    key={link.href}
                    href={link.href}
                    className={`font-body text-base transition-colors ${active ? 'text-fl-green' : 'text-fl-muted hover:text-fl-white'}`}
                    onClick={() => setMobileOpen(false)}
                  >
                    {link.label}
                  </a>
                )
              })}
              <Link
                to="/apply"
                className="mt-2 px-6 py-3 rounded-lg bg-fl-green text-fl-black font-body font-bold text-sm"
                style={{ boxShadow: '0 0 16px rgba(0,255,127,0.3)' }}
                onClick={() => setMobileOpen(false)}
              >
                Apply Now
              </Link>
              <Link
                to="/login"
                className="font-body text-sm text-fl-muted hover:text-fl-white transition-colors"
                onClick={() => setMobileOpen(false)}
              >
                Member Login
              </Link>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  )
}
