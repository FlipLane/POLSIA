import { motion } from 'framer-motion'

interface NeonLogoProps {
  size?: 'sm' | 'md' | 'lg'
  className?: string
  as?: 'a' | 'span' | 'div'
  href?: string
}

const sizeClasses = {
  sm: 'text-xl',
  md: 'text-2xl',
  lg: 'text-4xl',
}

/**
 * FlipLane neon logo — "Flip" in white neon, "Lane" in green neon.
 * Global brand treatment used everywhere the logo appears.
 */
export default function NeonLogo({ size = 'md', className = '', as = 'a', href = '/' }: NeonLogoProps) {
  const Wrapper = as === 'a' ? motion.a : as === 'div' ? motion.div : motion.span

  return (
    <Wrapper
      {...(as === 'a' ? { href } : {})}
      className={`inline-flex items-baseline font-display font-extrabold tracking-tight select-none ${sizeClasses[size]} ${className}`}
      whileHover={{ scale: 1.03 }}
      transition={{ type: 'spring', stiffness: 400, damping: 20 }}
    >
      {/* FLIP — white neon glow */}
      <span
        className="neon-flip"
        style={{
          color: '#ffffff',
          textShadow: `
            0 0 7px rgba(255, 255, 255, 0.6),
            0 0 20px rgba(255, 255, 255, 0.3),
            0 0 40px rgba(255, 255, 255, 0.15)
          `,
          animation: 'neonFlipPulse 3s ease-in-out infinite',
        }}
      >
        Flip
      </span>
      {/* LANE — green neon glow */}
      <span
        className="neon-lane"
        style={{
          color: '#00ff7f',
          textShadow: `
            0 0 7px rgba(0, 255, 127, 0.6),
            0 0 20px rgba(0, 255, 127, 0.3),
            0 0 40px rgba(0, 255, 127, 0.15)
          `,
          animation: 'neonLanePulse 3s ease-in-out infinite 0.5s',
        }}
      >
        Lane
      </span>
    </Wrapper>
  )
}
