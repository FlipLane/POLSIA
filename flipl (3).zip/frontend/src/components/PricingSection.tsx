// PricingSection — "How The Money Works"
// Fee cards + comparison table + bottom CTA
import { useEffect, useRef } from 'react'
import { motion } from 'framer-motion'
import { useTranslation } from 'react-i18next'
import { Check, X } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { observeSection, trackFunnelStage, trackCtaClick } from '../analytics'

const FEE_CARD_KEYS = ['join', 'deal', 'financed'] as const

const TABLE_ROW_KEYS = [
  'upfront',
  'revenue_split',
  'dealer_license',
  'title_shipping',
  'support',
  'profit',
] as const

export default function PricingSection() {
  const { t } = useTranslation()
  const navigate = useNavigate()
  const sectionRef = useRef<HTMLElement>(null)
  useEffect(() => observeSection(sectionRef.current, 'pricing', 0.15), [])
  // Fire pricing_view funnel stage when section enters view
  useEffect(() => {
    if (!sectionRef.current) return
    const obs = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) { trackFunnelStage('pricing_view'); obs.disconnect() }
    }, { threshold: 0.15 })
    obs.observe(sectionRef.current)
    return () => obs.disconnect()
  }, [])

  return (
    <section
      ref={sectionRef}
      className="relative py-28 sm:py-36 overflow-hidden"
      aria-label="Pricing"
      style={{
        background: 'linear-gradient(180deg, #0a0a0a 0%, #0c0c14 50%, #0a0a0a 100%)',
      }}
    >
      {/* Top section divider */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-fl-green/20 to-transparent" />
      {/* Subtle background grid */}
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage:
            'linear-gradient(var(--color-fl-green) 1px, transparent 1px), linear-gradient(90deg, var(--color-fl-green) 1px, transparent 1px)',
          backgroundSize: '60px 60px',
        }}
      />

      <div className="relative z-10 max-w-6xl mx-auto px-6 sm:px-10">
        {/* ── Header ── */}
        <div className="text-center mb-16">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.6 }}
            className="font-mono text-fl-green uppercase tracking-[0.2em] text-[0.7rem] mb-4"
          >
            {t('pricing.eyebrow')}
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 36 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="font-display font-bold text-fl-white leading-tight"
            style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)' }}
          >
            {t('pricing.heading')}
          </motion.h2>
        </div>

        {/* ── Fee Cards ── */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-80px' }}
          variants={{ hidden: {}, visible: { transition: { staggerChildren: 0.15 } } }}
        >
          {FEE_CARD_KEYS.map((key, i) => (
            <motion.div
              key={key}
              className="group relative flex flex-col gap-4 p-8 rounded-2xl border border-fl-border bg-fl-card"
              variants={{
                hidden: { opacity: 0, y: 40, scale: 0.95 },
                visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1], delay: i * 0.15 } },
              }}
              whileHover={{
                y: -6,
                borderColor: 'rgba(0, 255, 127, 0.35)',
                boxShadow: '0 20px 60px rgba(0,0,0,0.4), 0 0 40px rgba(0,255,127,0.08)',
                transition: { duration: 0.3 },
              }}
            >
              <p className="font-mono text-fl-green text-[0.65rem] uppercase tracking-[0.2em]">
                {t(`pricing.cards.${key}.label`)}
              </p>
              <p
                className="font-display font-bold text-fl-white"
                style={{ fontSize: 'clamp(1.8rem, 4vw, 2.6rem)' }}
              >
                {t(`pricing.cards.${key}.amount`)}
              </p>
              <p className="font-body text-fl-muted text-sm leading-relaxed">
                {t(`pricing.cards.${key}.description`)}
              </p>
            </motion.div>
          ))}
        </motion.div>

        {/* ── Comparison Table ── */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.7, delay: 0.4 }}
          className="rounded-2xl border border-fl-border overflow-hidden mb-16"
        >
          {/* Table header */}
          <div className="grid grid-cols-3 bg-fl-card/80 border-b border-fl-border px-6 py-4">
            <span className="font-mono text-fl-muted text-xs uppercase tracking-widest">
              {t('pricing.table.feature')}
            </span>
            <span className="font-mono text-fl-muted text-xs uppercase tracking-widest text-center">
              {t('pricing.table.traditional')}
            </span>
            <span className="font-mono text-fl-green text-xs uppercase tracking-widest text-center">
              {t('pricing.table.fliplane')}
            </span>
          </div>

          {TABLE_ROW_KEYS.map((key, i) => (
            <div
              key={key}
              className={`grid grid-cols-3 items-center px-6 py-4 border-b border-fl-border/50 ${
                i % 2 === 0 ? 'bg-fl-black/40' : 'bg-fl-card/30'
              }`}
            >
              <span className="font-body text-fl-white text-sm">
                {t(`pricing.table.rows.${key}.feature`)}
              </span>
              <div className="flex items-center justify-center gap-2">
                <X className="w-4 h-4 text-red-500 flex-shrink-0" />
                <span className="font-body text-fl-muted text-xs hidden sm:block">
                  {t(`pricing.table.rows.${key}.traditional`)}
                </span>
              </div>
              <div className="flex items-center justify-center gap-2">
                <Check className="w-4 h-4 text-fl-green flex-shrink-0" />
                <span className="font-body text-fl-green text-xs hidden sm:block">
                  {t(`pricing.table.rows.${key}.fliplane`)}
                </span>
              </div>
            </div>
          ))}
        </motion.div>

        {/* ── Bottom CTA ── */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.6, delay: 0.55 }}
          className="flex flex-col items-center gap-6 text-center"
        >
          <p className="font-body text-fl-muted text-lg">
            {t('pricing.cta.comparison')}{' '}
            <span className="line-through text-fl-muted/60">$15K–$50K+</span>{' '}
            <span className="font-bold text-fl-white">vs.</span>{' '}
            <span
              className="font-display font-bold text-fl-green"
              style={{ textShadow: '0 0 20px rgba(0,255,127,0.4)' }}
            >
              $250
            </span>
          </p>
          <motion.button
            type="button"
            onClick={() => { trackCtaClick('Join Now', 'pricing', '/join'); trackFunnelStage('apply_click'); navigate('/join') }}
            className="inline-flex items-center gap-3 px-8 py-4 rounded-xl font-mono text-fl-black font-bold text-sm uppercase tracking-widest bg-fl-green cursor-pointer"
            style={{ animation: 'pulse-green 2.5s ease-in-out infinite' }}
            whileHover={{ scale: 1.04, boxShadow: '0 0 40px rgba(0,255,127,0.5)' }}
            whileTap={{ scale: 0.98 }}
          >
            {t('pricing.cta.button')}
            <span className="text-base">→</span>
          </motion.button>
        </motion.div>
      </div>
    </section>
  )
}
