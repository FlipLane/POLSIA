// LeadMagnetSection — "Get the Dealer Playbook. Free."
// Email capture form + CSS-only book cover
import { motion } from 'framer-motion'
import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Send, BookOpen } from 'lucide-react'

export default function LeadMagnetSection() {
  const { t } = useTranslation()
  const [email, setEmail] = useState('')
  const [submitted, setSubmitted] = useState(false)
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email.trim()) return
    setLoading(true)
    try {
      await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim() }),
      })
    } catch {
      // Proceed regardless — lead captured client-side
    }
    setLoading(false)
    setSubmitted(true)
  }

  return (
    <section
      className="relative py-28 sm:py-36 overflow-hidden"
      aria-label="Lead Magnet"
      style={{
        background:
          'linear-gradient(160deg, #0a0a0a 0%, #0d160d 40%, #0a0a0a 100%)',
      }}
    >
      {/* Top section divider */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-fl-green/15 to-transparent" />
      {/* Radial green glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse 60% 50% at 70% 50%, rgba(0,255,127,0.06) 0%, transparent 70%)',
        }}
      />

      <div className="relative z-10 max-w-6xl mx-auto px-6 sm:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* ── Left: Form ── */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
            className="flex flex-col gap-7"
          >
            <p className="font-mono text-fl-green uppercase tracking-[0.2em] text-[0.7rem]">
              {t('leadmagnet.eyebrow')}
            </p>
            <h2
              className="font-display font-bold text-fl-white leading-tight"
              style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)' }}
            >
              {t('leadmagnet.heading')}
            </h2>
            <p className="font-body text-fl-muted text-lg leading-relaxed max-w-md">
              {t('leadmagnet.subheading')}
            </p>

            {submitted ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex items-center gap-3 p-5 rounded-xl border border-fl-green/40 bg-fl-green/5"
              >
                <span className="text-fl-green text-2xl">✓</span>
                <p className="font-body text-fl-white text-sm">
                  {t('leadmagnet.success')}
                </p>
              </motion.div>
            ) : (
              <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder={t('leadmagnet.placeholder')}
                  required
                  className="flex-1 px-5 py-4 rounded-xl border border-fl-border bg-fl-card text-fl-white font-body text-sm placeholder:text-fl-muted/50 focus:outline-none focus:border-fl-green/50 transition-colors"
                />
                <motion.button
                  type="submit"
                  disabled={loading}
                  className="inline-flex items-center justify-center gap-2 px-6 py-4 rounded-xl font-mono text-fl-black font-bold text-sm uppercase tracking-widest bg-fl-green disabled:opacity-60 whitespace-nowrap"
                  whileHover={{ scale: 1.03, boxShadow: '0 0 30px rgba(0,255,127,0.4)' }}
                  whileTap={{ scale: 0.97 }}
                >
                  {loading ? (
                    <span className="inline-block w-4 h-4 border-2 border-fl-black/40 border-t-fl-black rounded-full animate-spin" />
                  ) : (
                    <Send className="w-4 h-4" />
                  )}
                  {t('leadmagnet.cta')}
                </motion.button>
              </form>
            )}

            <p className="font-mono text-fl-muted/50 text-[0.65rem] uppercase tracking-widest">
              {t('leadmagnet.privacy')}
            </p>
          </motion.div>

          {/* ── Right: CSS Book Cover ── */}
          <motion.div
            initial={{ opacity: 0, x: 40, rotateY: 20 }}
            whileInView={{ opacity: 1, x: 0, rotateY: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1], delay: 0.2 }}
            className="flex items-center justify-center"
          >
            {/* Book wrapper */}
            <div
              className="relative"
              style={{
                width: 220,
                height: 290,
                perspective: '800px',
              }}
            >
              {/* Book spine (side) */}
              <div
                className="absolute left-0 top-2 bottom-2 w-5 rounded-l-sm"
                style={{
                  background: 'linear-gradient(180deg, #006640 0%, #003d26 100%)',
                  transform: 'rotateY(-60deg) translateX(-8px)',
                  transformOrigin: 'right center',
                }}
              />

              {/* Book cover */}
              <div
                className="relative w-full h-full rounded-r-lg overflow-hidden"
                style={{
                  background: 'linear-gradient(135deg, #0d1a10 0%, #0a1a0f 40%, #0d2010 100%)',
                  border: '1px solid rgba(0,255,127,0.2)',
                  boxShadow: '8px 12px 40px rgba(0,0,0,0.7), 0 0 60px rgba(0,255,127,0.08)',
                }}
              >
                {/* Top accent line */}
                <div className="absolute top-0 left-0 right-0 h-1 bg-fl-green opacity-80" />

                {/* Icon */}
                <div className="absolute top-8 left-0 right-0 flex justify-center">
                  <div className="flex items-center justify-center w-14 h-14 rounded-xl bg-fl-green/10 border border-fl-green/30">
                    <BookOpen className="w-7 h-7 text-fl-green" />
                  </div>
                </div>

                {/* Title */}
                <div className="absolute top-28 left-0 right-0 px-6 text-center">
                  <p className="font-mono text-fl-green text-[0.55rem] uppercase tracking-[0.25em] mb-2 opacity-80">
                    FlipLane
                  </p>
                  <p className="font-display font-bold text-fl-white text-lg leading-tight">
                    The Dealer<br />Playbook
                  </p>
                  <div className="w-10 h-px bg-fl-green/50 mx-auto my-3" />
                  <p className="font-body text-fl-muted text-[0.65rem] leading-snug">
                    Insider tactics for buying,<br />flipping & profiting
                  </p>
                </div>

                {/* Grid lines decoration */}
                <div
                  className="absolute bottom-0 left-0 right-0 h-28 opacity-10"
                  style={{
                    backgroundImage:
                      'linear-gradient(rgba(0,255,127,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(0,255,127,0.5) 1px, transparent 1px)',
                    backgroundSize: '20px 20px',
                  }}
                />

                {/* Edition tag */}
                <div className="absolute bottom-5 left-0 right-0 flex justify-center">
                  <span className="font-mono text-fl-green/60 text-[0.55rem] uppercase tracking-widest">
                    Free · 2026 Edition
                  </span>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
