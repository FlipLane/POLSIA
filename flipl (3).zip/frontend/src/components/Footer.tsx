// Footer — FTC disclaimer, links, EN/ES toggle
import { useTranslation } from 'react-i18next'
import NeonLogo from './NeonLogo'

export default function Footer() {
  const { t, i18n } = useTranslation()
  const currentLang = i18n.language === 'es' ? 'es' : 'en'

  const toggleLang = () => {
    const next = currentLang === 'en' ? 'es' : 'en'
    i18n.changeLanguage(next)
    try {
      localStorage.setItem('fl_lang', next)
    } catch {}
  }

  return (
    <footer className="relative bg-fl-dark border-t border-fl-border">
      {/* Green accent line */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-fl-green/20 to-transparent" />
      {/* Top section */}
      <div className="max-w-6xl mx-auto px-6 sm:px-10 py-12">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-8">
          {/* Logo + tagline */}
          <div className="flex flex-col gap-2">
            <NeonLogo />
            <p className="font-mono text-fl-muted text-xs mt-1">
              {t('footer.tagline')}
            </p>
          </div>

          {/* Links */}
          <nav className="flex flex-wrap gap-x-6 gap-y-2">
            {(
              [
                ['buy', '/join?lane=buyer'],
                ['earn', '/join?lane=affiliate'],
                ['pricing', '/pricing'],
                ['blog', '/blog'],
                ['terms', '/terms'],
                ['contact', 'mailto:Win@fliplane.net'],
              ] as const
            ).map(([key, href]) => (
              <a
                key={key}
                href={href}
                className="font-body text-fl-muted text-sm hover:text-fl-green transition-colors duration-150"
              >
                {t(`footer.links.${key}`)}
              </a>
            ))}
          </nav>

          {/* Language toggle */}
          <button
            onClick={toggleLang}
            className="flex items-center gap-2 px-4 py-2 rounded-lg border border-fl-border hover:border-fl-green/60 bg-fl-card/50 hover:bg-fl-green/5 transition-all duration-200"
            aria-label="Toggle language"
          >
            <span className="font-mono text-xs text-fl-muted uppercase tracking-wider">
              {currentLang === 'en' ? '🇺🇸 EN' : '🇲🇽 ES'}
            </span>
            <span className="font-mono text-xs text-fl-muted opacity-40">|</span>
            <span className="font-mono text-xs text-fl-green uppercase tracking-wider">
              {currentLang === 'en' ? 'ES' : 'EN'}
            </span>
          </button>
        </div>
      </div>

      {/* Divider */}
      <div className="border-t border-fl-border/50" />

      {/* FTC disclaimer */}
      <div className="max-w-6xl mx-auto px-6 sm:px-10 py-6">
        <p className="font-mono text-[10px] text-fl-muted/50 leading-relaxed">
          {t('footer.ftc')}
        </p>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-fl-border/30">
        <div className="max-w-6xl mx-auto px-6 sm:px-10 py-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="font-mono text-[10px] text-fl-muted/40">
            © {new Date().getFullYear()} FlipLane · Byrd Dawgs Automotive Group LLC.{' '}
            {t('footer.rights')}
          </p>
          <div className="flex items-center gap-4">
            <a
              href="https://x.com/fliplanes"
              target="_blank"
              rel="noopener noreferrer"
              className="font-mono text-[10px] text-fl-muted/40 hover:text-fl-green transition-colors"
              aria-label="X / Twitter"
            >
              𝕏
            </a>
            <a
              href="https://www.instagram.com/flippinglane"
              target="_blank"
              rel="noopener noreferrer"
              className="font-mono text-[10px] text-fl-muted/40 hover:text-fl-green transition-colors"
              aria-label="Instagram"
            >
              IG
            </a>
            <a
              href="https://www.tiktok.com/@fliplane66"
              target="_blank"
              rel="noopener noreferrer"
              className="font-mono text-[10px] text-fl-muted/40 hover:text-fl-green transition-colors"
              aria-label="TikTok"
            >
              TK
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}
