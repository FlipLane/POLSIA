import { useEffect, useRef } from 'react'
import { motion } from 'framer-motion'
import { ArrowRight } from 'lucide-react'
import { useTranslation } from 'react-i18next'
import { useNavigate } from 'react-router-dom'
import { observeSection, trackCtaClick, trackFunnelStage } from '../analytics'

/* ── Lane icons (static SVGs) ── */
const ICONS = [
  // Buyer — code brackets
  <svg width="48" height="48" viewBox="0 0 48 48" fill="none" key="buyer">
    <path d="M14 8L6 24L14 40" stroke="#00ff7f" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M34 8L42 24L34 40" stroke="#00ff7f" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M20 16H28M20 24H32M20 32H26" stroke="#00ff7f" strokeWidth="2" strokeLinecap="round" opacity="0.7" />
  </svg>,
  // Affiliate — network nodes
  <svg width="48" height="48" viewBox="0 0 48 48" fill="none" key="affiliate">
    <circle cx="12" cy="24" r="4" stroke="#00ff7f" strokeWidth="2"/>
    <circle cx="36" cy="12" r="4" stroke="#00ff7f" strokeWidth="2"/>
    <circle cx="36" cy="36" r="4" stroke="#00ff7f" strokeWidth="2"/>
    <line x1="16" y1="22" x2="32" y2="14" stroke="#00ff7f" strokeWidth="1.5" opacity="0.6"/>
    <line x1="16" y1="26" x2="32" y2="34" stroke="#00ff7f" strokeWidth="1.5" opacity="0.6"/>
    <circle cx="12" cy="24" r="2" fill="#00ff7f" opacity="0.8"/>
    <circle cx="36" cy="12" r="2" fill="#00ff7f" opacity="0.8"/>
    <circle cx="36" cy="36" r="2" fill="#00ff7f" opacity="0.8"/>
  </svg>,
  // Co-op — circuit grid
  <svg width="48" height="48" viewBox="0 0 48 48" fill="none" key="coop">
    <rect x="8" y="8" width="14" height="14" rx="2" stroke="#00ff7f" strokeWidth="2"/>
    <rect x="26" y="8" width="14" height="14" rx="2" stroke="#00ff7f" strokeWidth="2"/>
    <rect x="8" y="26" width="14" height="14" rx="2" stroke="#00ff7f" strokeWidth="2"/>
    <rect x="26" y="26" width="14" height="14" rx="2" stroke="#00ff7f" strokeWidth="2"/>
    <line x1="22" y1="15" x2="26" y2="15" stroke="#00ff7f" strokeWidth="1.5" opacity="0.5"/>
    <line x1="22" y1="33" x2="26" y2="33" stroke="#00ff7f" strokeWidth="1.5" opacity="0.5"/>
    <line x1="15" y1="22" x2="15" y2="26" stroke="#00ff7f" strokeWidth="1.5" opacity="0.5"/>
    <line x1="33" y1="22" x2="33" y2="26" stroke="#00ff7f" strokeWidth="1.5" opacity="0.5"/>
    <circle cx="24" cy="24" r="3" fill="#00ff7f" opacity="0.3"/>
  </svg>,
]

const LANE_KEYS = ['buyer', 'affiliate', 'coop'] as const
const LANE_HREFS = ['/join?lane=buyer', '/join?lane=affiliate', '/join?lane=coop']

/* ── Animated Lane Card ── */
function LaneCard({ laneKey, index, icon }: {
  laneKey: typeof LANE_KEYS[number]
  index: number
  icon: React.ReactNode
}) {
  const { t } = useTranslation()
  const navigate = useNavigate()

  return (
    <motion.div
      role="link"
      tabIndex={0}
      onClick={() => {
        trackCtaClick(`${laneKey} Lane`, 'three_lanes', LANE_HREFS[index])
        trackFunnelStage('lane_interaction')
        navigate(LANE_HREFS[index])
      }}
      onKeyDown={(e) => { if (e.key === 'Enter') navigate(LANE_HREFS[index]) }}
      className="group relative flex flex-col gap-5 p-8 rounded-2xl border border-fl-border bg-fl-card/80 backdrop-blur-sm overflow-hidden transition-colors cursor-pointer"
      variants={{
        hidden: { opacity: 0, y: 50, scale: 0.95 },
        visible: {
          opacity: 1,
          y: 0,
          scale: 1,
          transition: {
            duration: 0.7,
            ease: [0.22, 1, 0.36, 1],
            delay: index * 0.18,
          },
        },
      }}
      whileHover={{
        y: -12,
        scale: 1.015,
        borderColor: 'rgba(0, 255, 127, 0.45)',
        boxShadow:
          '0 24px 64px rgba(0, 0, 0, 0.5), 0 0 60px rgba(0, 255, 127, 0.12), inset 0 0 24px rgba(0, 255, 127, 0.04)',
        transition: { duration: 0.35, ease: 'easeOut' },
      }}
      style={{ boxShadow: '0 4px 24px rgba(0, 0, 0, 0.3)' }}
    >
      {/* Bottom green bar on hover */}
      <span className="absolute bottom-0 left-0 right-0 h-[3px] bg-gradient-to-r from-fl-green to-fl-green-dim transform scale-x-0 origin-left transition-transform duration-400 group-hover:scale-x-100" />

      {/* Icon */}
      <span className="flex items-center justify-center w-16 h-16 rounded-xl bg-fl-green/5 border border-fl-green/15 transition-all duration-400 group-hover:bg-fl-green/10 group-hover:border-fl-green/35 group-hover:shadow-[0_0_24px_rgba(0,255,127,0.15)]">
        {icon}
      </span>

      {/* Title */}
      <h3 className="font-display font-bold text-fl-white text-xl leading-snug">
        {t(`lanes.${laneKey}.title`)}
      </h3>

      {/* Subtitle */}
      <span className="font-mono text-fl-green text-xs uppercase tracking-widest -mt-3">
        {t(`lanes.${laneKey}.subtitle`)}
      </span>

      {/* Description */}
      <p className="font-body text-fl-muted text-sm leading-relaxed">
        {t(`lanes.${laneKey}.description`)}
      </p>

      {/* CTA link */}
      <span className="mt-auto inline-flex items-center gap-2 font-mono text-fl-green text-xs uppercase tracking-widest transition-all duration-300 group-hover:gap-3">
        {t(`lanes.${laneKey}.cta`)}
        <ArrowRight className="w-4 h-4" />
      </span>
    </motion.div>
  )
}

/* ── Section ── */
export default function ThreeLanesSection() {
  const { t } = useTranslation()
  const sectionRef = useRef<HTMLElement>(null)
  useEffect(() => observeSection(sectionRef.current, 'three_lanes'), [])

  return (
    <section
      ref={sectionRef}
      className="relative py-28 sm:py-36"
      aria-label="Three Lanes"
      style={{
        background: 'linear-gradient(180deg, #0a0a0a 0%, #0d120d 50%, #0a0a0a 100%)',
      }}
    >
      {/* Subtle grid texture */}
      <div
        className="absolute inset-0 opacity-[0.02] pointer-events-none"
        style={{
          backgroundImage:
            'linear-gradient(rgba(0,255,127,1) 1px, transparent 1px), linear-gradient(90deg, rgba(0,255,127,1) 1px, transparent 1px)',
          backgroundSize: '60px 60px',
        }}
      />
      {/* Top section divider */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-fl-green/15 to-transparent" />
      <div className="relative z-10 max-w-6xl mx-auto px-6 sm:px-10">
        {/* ── Section header ── */}
        <div className="text-center mb-16">
          {/* Eyebrow */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.6, ease: 'easeOut' }}
            className="font-mono text-fl-green text-sm uppercase tracking-[0.15em] font-semibold mb-4"
          >
            {t('lanes.eyebrow')}
          </motion.p>

          {/* Heading */}
          <motion.h2
            initial={{ opacity: 0, y: 36 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.7, ease: 'easeOut', delay: 0.12 }}
            className="font-display font-extrabold text-fl-white leading-[1.1] tracking-tight"
            style={{ fontSize: 'clamp(2.4rem, 6vw, 3.8rem)' }}
          >
            {/* First sentence plain, second sentence in green */}
            {t('lanes.heading').split('. ')[0]}.{' '}
            <span
              className="text-fl-green"
              style={{
                textShadow: '0 0 30px rgba(0,255,127,0.35), 0 0 60px rgba(0,255,127,0.12)',
              }}
            >
              {t('lanes.heading').split('. ').slice(1).join('. ')}
            </span>
          </motion.h2>

          {/* Sub */}
          <motion.p
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.6, ease: 'easeOut', delay: 0.24 }}
            className="font-body text-fl-muted text-lg mt-5 max-w-lg mx-auto"
          >
            {t('lanes.subheading')}
          </motion.p>
        </div>

        {/* ── Cards grid ── */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-80px' }}
          variants={{
            hidden: {},
            visible: { transition: { staggerChildren: 0.18 } },
          }}
        >
          {LANE_KEYS.map((key, i) => (
            <LaneCard key={key} laneKey={key} index={i} icon={ICONS[i]} />
          ))}
        </motion.div>
      </div>
    </section>
  )
}
