// FlipLane — /login page
// Member login: email lookup → redirect to ByrddawgsOS

import { useState } from 'react'
import { motion } from 'framer-motion'
import { ArrowRight, Loader2, AlertCircle } from 'lucide-react'
import { Link } from 'react-router-dom'
import Header from '../components/Header'
import Footer from '../components/Footer'

function ErrorBanner({ message }: { message: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -8 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex items-start gap-3 p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 font-body text-sm"
    >
      <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
      {message}
    </motion.div>
  )
}

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email.trim()) return
    setError('')
    setLoading(true)

    try {
      const res = await fetch(`/api/member-status?email=${encodeURIComponent(email.trim())}`)
      const data = await res.json()

      if (!data.success || !data.found) {
        setError("No account found with that email. Check your spelling or apply for membership.")
        return
      }

      const member = data.member
      // Redirect based on status
      if (member.is_paid || member.status === 'active') {
        window.location.href = '/byrddawgsos'
      } else if (member.status === 'applied') {
        // Needs to complete payment
        window.location.href = data.payment_link || '/apply'
      } else {
        window.location.href = '/byrddawgsos'
      }
    } catch {
      setError('Network error. Please check your connection and try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-fl-black text-fl-white font-body flex flex-col">
      <Header />

      <main className="flex-1 flex items-center justify-center px-6 pt-24 pb-16">
        <div className="w-full max-w-md">
          {/* Background glow */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div
              className="w-[600px] h-[400px] rounded-full blur-[120px] opacity-[0.06]"
              style={{ background: 'radial-gradient(ellipse, #00ff7f 0%, transparent 70%)' }}
            />
          </div>

          <motion.div
            initial={{ opacity: 0, y: 32, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            className="relative rounded-2xl border border-fl-border bg-fl-card p-8 sm:p-10"
            style={{ boxShadow: '0 0 48px rgba(0,0,0,0.5), 0 0 80px rgba(0,255,127,0.04)' }}
          >
            {/* Logo area */}
            <div className="text-center mb-8">
              <p className="font-mono text-fl-green text-xs uppercase tracking-[0.2em] mb-3">Member Portal</p>
              <h1 className="font-display font-extrabold text-fl-white text-3xl tracking-tight mb-2">
                Welcome Back
              </h1>
              <p className="font-body text-fl-muted text-sm">
                Enter your email to access ByrddawgsOS
              </p>
            </div>

            <form onSubmit={handleSubmit} className="flex flex-col gap-5">
              <div className="flex flex-col gap-1.5">
                <label className="font-mono text-xs uppercase tracking-widest text-fl-muted">
                  Email Address <span className="text-fl-green">*</span>
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  required
                  autoComplete="email"
                  autoFocus
                  className="w-full px-4 py-3 rounded-xl bg-fl-black border border-fl-border text-fl-white font-body text-sm placeholder:text-fl-muted/50 focus:outline-none focus:border-fl-green focus:shadow-[0_0_0_2px_rgba(0,255,127,0.12)] transition-all duration-200"
                />
              </div>

              {error && <ErrorBanner message={error} />}

              <button
                type="submit"
                disabled={loading || !email.trim()}
                className="w-full flex items-center justify-center gap-2 py-4 px-8 rounded-xl bg-fl-green text-fl-black font-body font-bold text-base transition-all duration-200 hover:brightness-110 disabled:opacity-50 disabled:cursor-not-allowed"
                style={email.trim() ? { boxShadow: '0 0 24px rgba(0,255,127,0.25)' } : {}}
              >
                {loading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <>Access Portal <ArrowRight className="w-5 h-5" /></>
                )}
              </button>
            </form>

            {/* Divider */}
            <div className="flex items-center gap-4 my-6">
              <div className="flex-1 h-px bg-fl-border" />
              <span className="font-mono text-xs text-fl-muted uppercase tracking-widest">or</span>
              <div className="flex-1 h-px bg-fl-border" />
            </div>

            {/* Not a member */}
            <div className="text-center">
              <p className="font-body text-fl-muted text-sm mb-3">Not a member yet?</p>
              <Link
                to="/apply"
                className="inline-flex items-center gap-2 py-2.5 px-6 rounded-xl border border-fl-green text-fl-green font-body font-bold text-sm transition-all duration-200 hover:bg-fl-green/10"
              >
                Apply Now <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

            {/* Support */}
            <p className="text-center mt-6 font-body text-xs text-fl-muted/60">
              Need help?{' '}
              <a href="mailto:win@fliplane.net" className="text-fl-green/70 hover:text-fl-green underline-offset-2 hover:underline">
                Contact support
              </a>
            </p>
          </motion.div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
