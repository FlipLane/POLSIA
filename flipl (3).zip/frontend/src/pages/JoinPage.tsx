// FlipLane — /join page
// Premium entry point: three lane cards (Buyer / Affiliate / Co-op)
// Matches homepage dark/green/neon design system

import { motion } from 'framer-motion'
import { ArrowRight, Check } from 'lucide-react'
import { useTranslation } from 'react-i18next'
import { Link } from 'react-router-dom'
import Header from '../components/Header'
import Footer from '../components/Footer'

/* ── Lane icons ── */
const ICONS = [
  // Buyer — car/keys icon
  <svg width="48" height="48" viewBox="0 0 48 48" fill="none" key="buyer">
    <path d="M8 28h32M10 28l4-10h20l4 10" stroke="#00ff7f" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
    <circle cx="14" cy="34" r="3" stroke="#00ff7f" strokeWidth="2"/>
    <circle cx="34" cy="34" r="3" stroke="#00ff7f" strokeWidth="2"/>
    <path d="M22 18h4" stroke="#00ff7f" strokeWidth="2" strokeLinecap="round" opacity="0.6"/>
  </svg>,
  // Affiliate — network
  <svg width="48" height="48" viewBox="0 0 48 48" fill="none" key="affiliate">
    <circle cx="12" cy="24" r="4" stroke="#00ff7f" strokeWidth="2"/>
    <circle cx="36" cy="12" r="4" stroke="#00ff7f" strokeWidth="2"/>
    <circle cx="36" cy="36" r="4" stroke="#00ff7f" strokeWidth="2"/>
    <line x1="16" y1="22" x2="32" y2="14" stroke="#00ff7f" strokeWidth="1.5" opacity="0.6"/>
    <line x1="16" y1="26" x2="32" y2="34" stroke="#00ff7f" strokeWidth="1.5" opacity="0.6"/>
    <circle cx="12" cy="24" r="2" fill="#00ff7f" opacity="0.8"/>
    <circle cx="36" cy="12" r="2" fill="#00ff7f" opacity="0.8"/>
    <circle cx="36" cy="36" r="2" fill="#00ff7f" opacity="0.8"/>
  </svg>,
  // Co-op — grid
  <svg width="48" height="48" viewBox="0 0 48 48" fill="none" key="coop">
    <rect x="8" y="8" width="14" height="14" rx="2" stroke="#00ff7f" strokeWidth="2"/>
    <rect x="26" y="8" width="14" height="14" rx="2" stroke="#00ff7f" strokeWidth="2"/>
    <rect x="8" y="26" width="14" height="14" rx="2" stroke="#00ff7f" strokeWidth="2"/>
    <rect x="26" y="26" width="14" height="14" rx="2" stroke="#00ff7f" strokeWidth="2"/>
    <line x1="22" y1="15" x2="26" y2="15" stroke="#00ff7f" strokeWidth="1.5" opacity="0.5"/>
    <line x1="22" y1="33" x2="26" y2="33" stroke="#00ff7f" strokeWidth="1.5" opacity="0.5"/>
    <line x1="15" y1="22" x2="15" y2="26" stroke="#00ff7f" strokeWidth="1.5" opacity="0.5"/>
    <line x1="33" y1="22" x2="33" y2="26" stroke="#00ff7f" strokeWidth="1.5" opacity="0.5"/>
    <circle cx="24" cy="24" r="3" fill="#00ff7f" opacity="0.3"/>
  </svg>,
]

interface Lane {
  key: 'buyer' | 'affiliate' | 'coop'
  href: string
  badge?: string
  perks: string[]
  featured?: boolean
}

const LANES: Lane[] = [
  {
    key: 'buyer',
    href: '/join?lane=buyer',
    perks: ['Best-price vehicle sourcing', 'ADESA auction access', 'Title & registration handled', 'Nationwide shipping'],
  },
  {
    key: 'affiliate',
    href: '/join?lane=affiliate',
    perks: ['Free to join', '50% commission on referrals', 'Marketing support', 'Dedicated affiliate portal'],
  },
  {
    key: 'coop',
    href: '/apply',
    badge: 'Most Popular',
    featured: true,
    perks: ['$250 one-time membership', 'Full dealer infrastructure', 'AI tools & ByrddawgsOS', 'Keep 100% of profits'],
  },
]

function LaneCard({ lane, index, icon }: { lane: Lane; index: number; icon: React.ReactNode }) {
  const { t } = useTranslation()
  const laneKey = lane.key

  return (
    <motion.div
      initial={{ opacity: 0, y: 48, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.65, ease: [0.22, 1, 0.36, 1], delay: 0.1 + index * 0.14 }}
      className={`relative flex flex-col gap-5 p-8 rounded-2xl border overflow-hidden transition-all duration-300 ${
        lane.featured
          ? 'border-fl-green/60 bg-fl-card'
          : 'border-fl-border bg-fl-card/80'
      }`}
      style={
        lane.featured
          ? { boxShadow: '0 0 48px rgba(0,255,127,0.08), 0 8px 32px rgba(0,0,0,0.4)' }
          : { boxShadow: '0 4px 24px rgba(0,0,0,0.3)' }
      }
      whileHover={{
        y: -8,
        scale: 1.01,
        borderColor: 'rgba(0, 255, 127, 0.5)',
        boxShadow: '0 24px 64px rgba(0,0,0,0.5), 0 0 60px rgba(0,255,127,0.12)',
        transition: { duration: 0.3, ease: 'easeOut' },
      }}
    >
      {/* Featured badge */}
      {lane.badge && (
        <span className="absolute top-5 right-5 px-3 py-1 rounded-full bg-fl-green text-fl-black font-mono text-xs font-bold uppercase tracking-widest">
          {lane.badge}
        </span>
      )}

      {/* Green bottom bar on hover */}
      <span className="absolute bottom-0 left-0 right-0 h-[3px] bg-gradient-to-r from-fl-green to-fl-green-dim transform scale-x-0 origin-left transition-transform duration-300 group-hover:scale-x-100" />

      {/* Icon */}
      <span className="flex items-center justify-center w-16 h-16 rounded-xl bg-fl-green/5 border border-fl-green/15">
        {icon}
      </span>

      {/* Title */}
      <h3 className="font-display font-bold text-fl-white text-2xl leading-snug">
        {t(`lanes.${laneKey}.title`)}
      </h3>

      {/* Subtitle */}
      <span className="font-mono text-fl-green text-xs uppercase tracking-widest -mt-3">
        {t(`lanes.${laneKey}.subtitle`)}
      </span>

      {/* Description */}
      <p className="font-body text-fl-muted text-sm leading-relaxed">
        {t(`lanes.${laneKey}.description`)}
      </p>

      {/* Perks */}
      <ul className="flex flex-col gap-2 mt-1">
        {lane.perks.map((perk) => (
          <li key={perk} className="flex items-center gap-2 font-body text-sm text-fl-muted">
            <Check className="w-4 h-4 text-fl-green shrink-0" />
            {perk}
          </li>
        ))}
      </ul>

      {/* CTA */}
      <Link
        to="/apply"
        className={`mt-auto inline-flex items-center justify-center gap-2 w-full py-3 px-6 rounded-xl font-body font-bold text-sm transition-all duration-200 ${
          lane.featured
            ? 'bg-fl-green text-fl-black hover:brightness-110'
            : 'border border-fl-green text-fl-green hover:bg-fl-green/10'
        }`}
        style={lane.featured ? { boxShadow: '0 0 20px rgba(0,255,127,0.25)' } : {}}
      >
        {t(`lanes.${laneKey}.cta`)}
        <ArrowRight className="w-4 h-4" />
      </Link>
    </motion.div>
  )
}

export default function JoinPage() {
  const { t } = useTranslation()

  return (
    <div className="min-h-screen bg-fl-black text-fl-white font-body overflow-x-hidden">
      <Header />

      {/* Hero */}
      <section className="relative pt-36 pb-20 overflow-hidden">
        {/* Background grid */}
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: 'linear-gradient(rgba(0,255,127,0.8) 1px, transparent 1px), linear-gradient(90deg, rgba(0,255,127,0.8) 1px, transparent 1px)',
            backgroundSize: '40px 40px',
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-fl-black/0 via-fl-black/80 to-fl-black" />

        <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="font-mono text-fl-green text-sm uppercase tracking-[0.15em] mb-4"
          >
            {t('join.eyebrow')}
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, y: 32 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: [0.22, 1, 0.36, 1], delay: 0.1 }}
            className="font-display font-extrabold text-fl-white leading-[1.08] tracking-tight mb-6"
            style={{ fontSize: 'clamp(2.4rem, 6vw, 4rem)' }}
          >
            {t('join.heading')}{' '}
            <span
              className="text-fl-green"
              style={{ textShadow: '0 0 30px rgba(0,255,127,0.4), 0 0 60px rgba(0,255,127,0.15)' }}
            >
              {t('join.headingAccent')}
            </span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="font-body text-fl-muted text-lg max-w-2xl mx-auto"
          >
            {t('join.subheading')}
          </motion.p>
        </div>
      </section>

      {/* Lane cards */}
      <section className="relative pb-28">
        <div className="max-w-6xl mx-auto px-6 sm:px-10">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
            {LANES.map((lane, i) => (
              <LaneCard key={lane.key} lane={lane} index={i} icon={ICONS[i]} />
            ))}
          </div>

          {/* Already a member */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6, duration: 0.5 }}
            className="text-center mt-12 font-body text-fl-muted text-sm"
          >
            {t('join.alreadyMember')}{' '}
            <Link to="/login" className="text-fl-green hover:underline underline-offset-2">
              {t('join.loginLink')}
            </Link>
          </motion.p>
        </div>
      </section>

      <Footer />
    </div>
  )
}
