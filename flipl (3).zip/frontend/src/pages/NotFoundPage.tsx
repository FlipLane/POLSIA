// FlipLane — 404 Not Found page
// "Lost in the Lane?" — on-brand error page with link back home

import { motion } from 'framer-motion'
import { ArrowRight } from 'lucide-react'
import { Link } from 'react-router-dom'
import Header from '../components/Header'
import Footer from '../components/Footer'

export default function NotFoundPage() {
  return (
    <div className="min-h-screen bg-fl-black text-fl-white font-body flex flex-col">
      <Header />

      <main className="flex-1 flex items-center justify-center px-6 pt-24 pb-16">
        {/* Background grid */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none overflow-hidden">
          <div
            className="absolute inset-0 opacity-[0.03]"
            style={{
              backgroundImage: 'linear-gradient(rgba(0,255,127,0.8) 1px, transparent 1px), linear-gradient(90deg, rgba(0,255,127,0.8) 1px, transparent 1px)',
              backgroundSize: '40px 40px',
            }}
          />
          <div
            className="w-[700px] h-[500px] rounded-full blur-[140px] opacity-[0.05]"
            style={{ background: 'radial-gradient(ellipse, #00ff7f 0%, transparent 70%)' }}
          />
        </div>

        <div className="relative z-10 text-center max-w-xl">
          {/* 404 number */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          >
            <p
              className="font-display font-extrabold leading-none tracking-tight text-fl-green select-none"
              style={{
                fontSize: 'clamp(6rem, 22vw, 14rem)',
                textShadow: '0 0 40px rgba(0,255,127,0.3), 0 0 80px rgba(0,255,127,0.1)',
                opacity: 0.15,
              }}
            >
              404
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.15, ease: 'easeOut' }}
            className="-mt-8 sm:-mt-12 lg:-mt-16"
          >
            <p className="font-mono text-fl-green text-xs uppercase tracking-[0.2em] mb-4">Wrong Turn</p>
            <h1 className="font-display font-extrabold text-fl-white leading-tight tracking-tight mb-4"
              style={{ fontSize: 'clamp(2rem, 5vw, 3.2rem)' }}>
              Lost in the Lane?
            </h1>
            <p className="font-body text-fl-muted text-base sm:text-lg max-w-md mx-auto mb-8 leading-relaxed">
              This page doesn't exist — or it took a wrong turn at the auction block.
              Let's get you back on track.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link
                to="/"
                className="inline-flex items-center gap-2 py-3.5 px-7 rounded-xl bg-fl-green text-fl-black font-body font-bold text-sm transition-all duration-200 hover:brightness-110"
                style={{ boxShadow: '0 0 24px rgba(0,255,127,0.25)' }}
              >
                Back to Home <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                to="/apply"
                className="inline-flex items-center gap-2 py-3.5 px-7 rounded-xl border border-fl-border text-fl-muted font-body font-bold text-sm transition-all duration-200 hover:border-fl-green/40 hover:text-fl-white"
              >
                Apply Now
              </Link>
            </div>
          </motion.div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
