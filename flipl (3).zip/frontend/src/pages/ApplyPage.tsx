// FlipLane — /apply page
// 4-step application wizard: Form → Agreement → Payment → Verify ID
// All steps match the dark/green/neon design system

import { useState, useRef } from 'react'
import { trackFunnelStage } from '../analytics'
import { motion, AnimatePresence } from 'framer-motion'
import { Check, ChevronRight, Upload, ExternalLink, AlertCircle, Loader2 } from 'lucide-react'
import Header from '../components/Header'
import Footer from '../components/Footer'

// ── Types ─────────────────────────────────────────────────────────────────────

interface FormData {
  name: string
  email: string
  phone: string
  experience: string
  ref_code: string
}

// ── Progress bar ──────────────────────────────────────────────────────────────

const STEPS = ['Apply', 'Agreement', 'Payment', 'Verify ID']

function ProgressBar({ current }: { current: number }) {
  return (
    <div className="w-full mb-10">
      <div className="flex items-center justify-between mb-3">
        {STEPS.map((label, i) => (
          <div key={label} className="flex flex-col items-center gap-1" style={{ width: `${100 / STEPS.length}%` }}>
            <motion.div
              className={`flex items-center justify-center w-8 h-8 rounded-full border-2 font-mono text-xs font-bold transition-colors duration-300 ${
                i < current
                  ? 'bg-fl-green border-fl-green text-fl-black'
                  : i === current
                  ? 'border-fl-green text-fl-green bg-fl-black'
                  : 'border-fl-border text-fl-muted bg-fl-card'
              }`}
              animate={i === current ? { boxShadow: '0 0 16px rgba(0,255,127,0.4)' } : { boxShadow: 'none' }}
            >
              {i < current ? <Check className="w-4 h-4" /> : i + 1}
            </motion.div>
            <span className={`font-mono text-[10px] uppercase tracking-widest transition-colors duration-300 ${
              i <= current ? 'text-fl-green' : 'text-fl-muted'
            }`}>
              {label}
            </span>
          </div>
        ))}
      </div>
      {/* Track */}
      <div className="relative h-[2px] bg-fl-border rounded-full overflow-hidden">
        <motion.div
          className="absolute left-0 top-0 h-full bg-fl-green rounded-full"
          initial={{ width: '0%' }}
          animate={{ width: `${(current / (STEPS.length - 1)) * 100}%` }}
          transition={{ duration: 0.5, ease: 'easeOut' }}
        />
      </div>
    </div>
  )
}

// ── Input component ───────────────────────────────────────────────────────────

function Field({
  label, type = 'text', name, value, onChange, required, placeholder, hint,
}: {
  label: string; type?: string; name: string; value: string; onChange: (v: string) => void
  required?: boolean; placeholder?: string; hint?: string
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="font-mono text-xs uppercase tracking-widest text-fl-muted">
        {label}{required && <span className="text-fl-green ml-1">*</span>}
      </label>
      <input
        type={type}
        name={name}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        required={required}
        autoComplete={type === 'email' ? 'email' : type === 'tel' ? 'tel' : 'off'}
        className="w-full px-4 py-3 rounded-xl bg-fl-black border border-fl-border text-fl-white font-body text-sm placeholder:text-fl-muted/50 focus:outline-none focus:border-fl-green focus:shadow-[0_0_0_2px_rgba(0,255,127,0.12)] transition-all duration-200"
      />
      {hint && <p className="font-body text-xs text-fl-muted/60">{hint}</p>}
    </div>
  )
}

function Select({
  label, name, value, onChange, options, required,
}: {
  label: string; name: string; value: string; onChange: (v: string) => void
  options: { value: string; label: string }[]; required?: boolean
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="font-mono text-xs uppercase tracking-widest text-fl-muted">
        {label}{required && <span className="text-fl-green ml-1">*</span>}
      </label>
      <select
        name={name}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        required={required}
        className="w-full px-4 py-3 rounded-xl bg-fl-black border border-fl-border text-fl-white font-body text-sm focus:outline-none focus:border-fl-green focus:shadow-[0_0_0_2px_rgba(0,255,127,0.12)] transition-all duration-200 appearance-none cursor-pointer"
      >
        {options.map((opt) => (
          <option key={opt.value} value={opt.value}>{opt.label}</option>
        ))}
      </select>
    </div>
  )
}

function ErrorBanner({ message }: { message: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -8 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex items-start gap-3 p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 font-body text-sm"
    >
      <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
      {message}
    </motion.div>
  )
}


// ── Step 1: Application Form ──────────────────────────────────────────────────

function Step1Form({ onNext }: { onNext: (email: string, memberId: number, paymentLink: string | null) => void }) {
  const [form, setForm] = useState<FormData>({
    name: '', email: '', phone: '', experience: '', ref_code: ''
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const set = (key: keyof FormData) => (val: string) => setForm(prev => ({ ...prev, [key]: val }))

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      const res = await fetch('/api/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      const data = await res.json()
      if (!data.success && !data.already_applied) {
        setError(data.message || 'Something went wrong. Please try again.')
        return
      }
      trackFunnelStage('form_submit')
      onNext(form.email, data.member_id, data.payment_link || null)
    } catch {
      setError('Network error. Please check your connection and try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-5">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
        <Field label="Full Name" name="name" value={form.name} onChange={set('name')} required placeholder="Your full name" />
        <Field label="Email Address" type="email" name="email" value={form.email} onChange={set('email')} required placeholder="you@example.com" />
        <Field label="Phone Number" type="tel" name="phone" value={form.phone} onChange={set('phone')} placeholder="(555) 555-5555" />
        <Select
          label="Car Experience"
          name="experience"
          value={form.experience}
          onChange={set('experience')}
          options={[
            { value: '', label: 'Select your experience level' },
            { value: 'none', label: 'No experience — just getting started' },
            { value: 'some', label: 'Bought/sold 1–5 cars privately' },
            { value: 'dealer', label: 'Worked at a dealership' },
            { value: 'flipper', label: 'Been flipping cars independently' },
          ]}
        />
      </div>
      <Field label="Referral Code" name="ref_code" value={form.ref_code} onChange={set('ref_code')} placeholder="Optional — enter if you have one" hint="Enter a referral code to credit your sponsor." />

      {error && <ErrorBanner message={error} />}

      <button
        type="submit"
        disabled={loading}
        className="mt-2 w-full flex items-center justify-center gap-2 py-4 px-8 rounded-xl bg-fl-green text-fl-black font-body font-bold text-base transition-all duration-200 hover:brightness-110 disabled:opacity-60 disabled:cursor-not-allowed"
        style={{ boxShadow: '0 0 24px rgba(0,255,127,0.25)' }}
      >
        {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <>Continue <ChevronRight className="w-5 h-5" /></>}
      </button>
    </form>
  )
}

// ── Step 2: Member Agreement ──────────────────────────────────────────────────

function Step2Agreement({ email, onNext }: { email: string; onNext: () => void }) {
  const [agreed, setAgreed] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleAccept = async () => {
    setError('')
    setLoading(true)
    try {
      // Get current terms version
      const statusRes = await fetch(`/api/member/agreement-status?email=${encodeURIComponent(email)}`)
      const statusData = await statusRes.json()
      const termsVersion = statusData.termsVersion || statusData.current_version || 1

      const res = await fetch('/api/member/sign-terms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, termsVersion, type: 'member' }),
      })
      const data = await res.json()
      if (!data.success && !data.alreadySigned) {
        setError(data.message || 'Could not record your agreement. Please try again.')
        return
      }
      onNext()
    } catch {
      // Non-blocking — proceed anyway if API fails
      onNext()
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex flex-col gap-6">
      {/* Agreement content */}
      <div className="rounded-xl border border-fl-border bg-fl-black p-6 h-72 overflow-y-auto scrollbar-thin font-body text-sm text-fl-muted leading-relaxed space-y-4">
        <h3 className="font-display font-bold text-fl-white text-lg">FlipLane Co-op Member Agreement</h3>
        <p>By accepting this agreement, you acknowledge that FlipLane is a car dealer co-op operated by Byrd Dawgs Automotive Group LLC. Your $250 one-time membership fee grants you access to our dealer network, auction access tools, and co-op infrastructure.</p>
        <p><strong className="text-fl-white">Membership Terms:</strong> Your membership is non-refundable once activated. Access to ByrddawgsOS, auction tools, and dealer resources begins after ID verification is approved by our team.</p>
        <p><strong className="text-fl-white">No Revenue Split:</strong> FlipLane does not take a percentage of your deals. You keep 100% of all profits from vehicles you source and sell through our platform.</p>
        <p><strong className="text-fl-white">Platform Use:</strong> You agree to use FlipLane's infrastructure for lawful vehicle transactions only. Any misuse, fraudulent activity, or violation of our terms will result in immediate membership termination without refund.</p>
        <p><strong className="text-fl-white">Earnings Disclaimer:</strong> Results vary. The figures shown on our website represent exceptional outcomes. Your actual earnings depend on vehicle selection, market conditions, and execution. This is not a guaranteed income program.</p>
        <p><strong className="text-fl-white">FTC Compliance:</strong> FlipLane is a business opportunity. Full disclosure documents are available upon request. You have the right to review them before payment.</p>
        <p>For the complete Terms of Service, visit <a href="/terms" target="_blank" rel="noopener noreferrer" className="text-fl-green hover:underline">fliplane.net/terms</a>.</p>
      </div>

      {/* Checkbox */}
      <label className="flex items-start gap-3 cursor-pointer group">
        <button
          type="button"
          onClick={() => setAgreed(!agreed)}
          className={`flex-shrink-0 w-5 h-5 mt-0.5 rounded border-2 flex items-center justify-center transition-all duration-200 ${
            agreed ? 'bg-fl-green border-fl-green' : 'border-fl-border bg-fl-black group-hover:border-fl-green/50'
          }`}
        >
          {agreed && <Check className="w-3 h-3 text-fl-black" />}
        </button>
        <span className="font-body text-sm text-fl-muted leading-relaxed">
          I have read and agree to the FlipLane Member Agreement and{' '}
          <a href="/terms" target="_blank" rel="noopener noreferrer" className="text-fl-green hover:underline">
            Terms of Service
          </a>.
        </span>
      </label>

      {error && <ErrorBanner message={error} />}

      <button
        onClick={handleAccept}
        disabled={!agreed || loading}
        className="w-full flex items-center justify-center gap-2 py-4 px-8 rounded-xl bg-fl-green text-fl-black font-body font-bold text-base transition-all duration-200 hover:brightness-110 disabled:opacity-40 disabled:cursor-not-allowed"
        style={agreed ? { boxShadow: '0 0 24px rgba(0,255,127,0.25)' } : {}}
      >
        {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <>Accept &amp; Continue <ChevronRight className="w-5 h-5" /></>}
      </button>
    </div>
  )
}

// ── Step 3: Payment ───────────────────────────────────────────────────────────

function Step3Payment({ email, paymentLink, onNext }: { email: string; paymentLink: string | null; onNext: () => void }) {
  const baseLink = 'https://buy.stripe.com/4gM8wRaoH15s978fAMcAo04'
  const stripeUrl = paymentLink || `${baseLink}?prefilled_email=${encodeURIComponent(email)}&client_reference_id=${encodeURIComponent(email)}`

  return (
    <div className="flex flex-col gap-6">
      {/* Pricing card */}
      <div className="rounded-2xl border border-fl-green/30 bg-fl-card p-8 text-center"
        style={{ boxShadow: '0 0 40px rgba(0,255,127,0.06)' }}>
        <p className="font-mono text-fl-green text-xs uppercase tracking-[0.2em] mb-3">One-Time Fee</p>
        <p className="font-display font-extrabold text-fl-white leading-none mb-2"
          style={{ fontSize: 'clamp(3rem, 8vw, 5rem)' }}>
          $250
        </p>
        <p className="font-body text-fl-muted text-sm mb-8">No subscriptions. No revenue splits. Ever.</p>

        {/* What you get */}
        <ul className="flex flex-col gap-3 text-left mb-8">
          {[
            'ADESA & Manheim auction access',
            'ByrddawgsOS dealer dashboard',
            'AI vehicle intelligence tools',
            'Title, shipping & registration support',
            'Nationwide dealer network',
            'Keep 100% of every deal',
          ].map((item) => (
            <li key={item} className="flex items-center gap-3 font-body text-sm text-fl-muted">
              <Check className="w-4 h-4 text-fl-green shrink-0" />
              {item}
            </li>
          ))}
        </ul>

        {/* Stripe button */}
        <a
          href={stripeUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="w-full inline-flex items-center justify-center gap-2 py-4 px-8 rounded-xl bg-fl-green text-fl-black font-body font-bold text-base transition-all duration-200 hover:brightness-110"
          style={{ boxShadow: '0 0 28px rgba(0,255,127,0.3)' }}
        >
          Pay $250 Securely with Stripe
          <ExternalLink className="w-4 h-4" />
        </a>

        <p className="mt-4 font-body text-xs text-fl-muted/60">
          Secured by Stripe · 256-bit SSL encryption · No card data stored on our servers
        </p>
      </div>

      {/* Already paid? */}
      <div className="rounded-xl border border-fl-border bg-fl-card/60 p-5 text-center">
        <p className="font-body text-sm text-fl-muted mb-3">
          Already completed payment? Click below to continue to ID verification.
        </p>
        <button
          onClick={onNext}
          className="inline-flex items-center gap-2 py-2.5 px-6 rounded-xl border border-fl-green text-fl-green font-body font-bold text-sm transition-all duration-200 hover:bg-fl-green/10"
        >
          I Already Paid → Verify ID <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  )
}

// ── Step 4: Verify ID ─────────────────────────────────────────────────────────

function Step4VerifyId({ email }: { email: string }) {
  const [file, setFile] = useState<File | null>(null)
  const [uploading, setUploading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState('')
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0]
    if (f) setFile(f)
  }

  const handleUpload = async () => {
    if (!file) return
    setUploading(true)
    setError('')
    try {
      const fd = new FormData()
      fd.append('id_document', file)
      fd.append('email', email)

      const res = await fetch('/api/upload-id', {
        method: 'POST',
        body: fd,
      })
      const data = await res.json()
      if (!data.success) {
        setError(data.message || 'Upload failed. Please try again.')
        return
      }
      setSuccess(true)
    } catch {
      setError('Network error during upload. Please try again.')
    } finally {
      setUploading(false)
    }
  }

  if (success) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        className="flex flex-col items-center gap-6 py-8 text-center"
      >
        <div className="w-20 h-20 rounded-full bg-fl-green/15 border border-fl-green/40 flex items-center justify-center"
          style={{ boxShadow: '0 0 40px rgba(0,255,127,0.2)' }}>
          <Check className="w-10 h-10 text-fl-green" />
        </div>
        <h3 className="font-display font-bold text-fl-white text-2xl">Application Complete!</h3>
        <p className="font-body text-fl-muted text-base max-w-sm">
          Your ID has been submitted. Our team will verify it within 1–2 business days.
          You'll receive an email when your membership is activated.
        </p>
        <a
          href="/"
          className="mt-2 inline-flex items-center gap-2 py-3 px-6 rounded-xl bg-fl-green text-fl-black font-body font-bold text-sm hover:brightness-110 transition-all duration-200"
          style={{ boxShadow: '0 0 20px rgba(0,255,127,0.25)' }}
        >
          Back to Home
        </a>
      </motion.div>
    )
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="rounded-xl border border-fl-border bg-fl-card/60 p-4">
        <p className="font-body text-sm text-fl-muted leading-relaxed">
          <strong className="text-fl-white">Why we verify ID:</strong> FlipLane operates under a licensed dealer entity.
          Federal and state regulations require identity verification for all co-op members. Your document is encrypted
          and stored securely — never shared with third parties.
        </p>
      </div>

      {/* Upload area */}
      <div
        onClick={() => fileInputRef.current?.click()}
        className={`relative flex flex-col items-center justify-center gap-4 p-10 rounded-2xl border-2 border-dashed cursor-pointer transition-all duration-200 ${
          file
            ? 'border-fl-green/60 bg-fl-green/5'
            : 'border-fl-border hover:border-fl-green/40 hover:bg-fl-green/3 bg-fl-card/40'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp,application/pdf"
          onChange={handleFileChange}
          className="hidden"
        />
        <Upload className={`w-10 h-10 ${file ? 'text-fl-green' : 'text-fl-muted'}`} />
        {file ? (
          <>
            <p className="font-body font-semibold text-fl-white text-sm">{file.name}</p>
            <p className="font-mono text-xs text-fl-green uppercase tracking-widest">File ready to upload</p>
          </>
        ) : (
          <>
            <p className="font-body font-semibold text-fl-white text-sm text-center">
              Click to upload your government-issued ID
            </p>
            <p className="font-mono text-xs text-fl-muted uppercase tracking-widest">
              JPG · PNG · WebP · PDF · Max 10MB
            </p>
          </>
        )}
      </div>

      {error && <ErrorBanner message={error} />}

      <button
        onClick={handleUpload}
        disabled={!file || uploading}
        className="w-full flex items-center justify-center gap-2 py-4 px-8 rounded-xl bg-fl-green text-fl-black font-body font-bold text-base transition-all duration-200 hover:brightness-110 disabled:opacity-40 disabled:cursor-not-allowed"
        style={file ? { boxShadow: '0 0 24px rgba(0,255,127,0.25)' } : {}}
      >
        {uploading ? <Loader2 className="w-5 h-5 animate-spin" /> : <>Submit ID <ChevronRight className="w-5 h-5" /></>}
      </button>
    </div>
  )
}

// ── Main wizard ───────────────────────────────────────────────────────────────

const STEP_TITLES = [
  { title: 'Start Your Application', subtitle: 'Tell us a bit about yourself to begin.' },
  { title: 'Member Agreement', subtitle: 'Review and accept the co-op terms.' },
  { title: 'Activate Membership', subtitle: 'Secure your $250 one-time membership.' },
  { title: 'Verify Your Identity', subtitle: 'Upload a government-issued ID to complete onboarding.' },
]

export default function ApplyPage() {
  const [step, setStep] = useState(0)
  const [email, setEmail] = useState('')
  const [paymentLink, setPaymentLink] = useState<string | null>(null)

  const handleStep1Complete = (e: string, _id: number, pl: string | null) => {
    setEmail(e)
    setPaymentLink(pl)
    setStep(1)
  }

  return (
    <div className="min-h-screen bg-fl-black text-fl-white font-body">
      <Header />

      {/* Page header */}
      <section className="relative pt-36 pb-12 overflow-hidden">
        <div
          className="absolute inset-0 opacity-[0.025]"
          style={{
            backgroundImage: 'linear-gradient(rgba(0,255,127,0.8) 1px, transparent 1px), linear-gradient(90deg, rgba(0,255,127,0.8) 1px, transparent 1px)',
            backgroundSize: '40px 40px',
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-fl-black/0 to-fl-black pointer-events-none" />

        <div className="relative z-10 max-w-xl mx-auto px-6 text-center">
          <motion.p
            key={`eyebrow-${step}`}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="font-mono text-fl-green text-xs uppercase tracking-[0.2em] mb-3"
          >
            Step {step + 1} of {STEPS.length}
          </motion.p>
          <motion.h1
            key={`title-${step}`}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: 'easeOut' }}
            className="font-display font-extrabold text-fl-white text-3xl sm:text-4xl tracking-tight mb-3"
          >
            {STEP_TITLES[step].title}
          </motion.h1>
          <motion.p
            key={`sub-${step}`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.1 }}
            className="font-body text-fl-muted text-base"
          >
            {STEP_TITLES[step].subtitle}
          </motion.p>
        </div>
      </section>

      {/* Wizard card */}
      <section className="pb-28">
        <div className="max-w-xl mx-auto px-6">
          <div className="rounded-2xl border border-fl-border bg-fl-card p-8"
            style={{ boxShadow: '0 8px 48px rgba(0,0,0,0.4)' }}>

            <ProgressBar current={step} />

            <AnimatePresence mode="wait">
              <motion.div
                key={step}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3, ease: 'easeOut' }}
              >
                {step === 0 && <Step1Form onNext={handleStep1Complete} />}
                {step === 1 && <Step2Agreement email={email} onNext={() => setStep(2)} />}
                {step === 2 && <Step3Payment email={email} paymentLink={paymentLink} onNext={() => setStep(3)} />}
                {step === 3 && <Step4VerifyId email={email} />}
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
