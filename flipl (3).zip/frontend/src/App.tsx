// FlipLane — Root app with React Router
// Routes: / (homepage) · /join · /apply · /login · * (404)
// i18n: EN/ES via react-i18next (toggle in Footer)

import { Suspense, lazy, useEffect } from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { initPageTracking } from './analytics'

// Homepage sections (eager-load — above-fold critical path)
import Header from './components/Header'
import HeroSection from './components/HeroSection'
import TickerBar from './components/TickerBar'
import StatsSection from './components/StatsSection'
import ThreeLanesSection from './components/ThreeLanesSection'
import PricingSection from './components/PricingSection'
import ToolkitSection from './components/ToolkitSection'
import TestimonialsSection from './components/TestimonialsSection'
import LeadMagnetSection from './components/LeadMagnetSection'
import ApplyCtaSection from './components/ApplyCtaSection'
import Footer from './components/Footer'
import StickyBottomBar from './components/StickyBottomBar'

// Lazy-load public pages (code-split — only loaded when navigated to)
const JoinPage = lazy(() => import('./pages/JoinPage'))
const ApplyPage = lazy(() => import('./pages/ApplyPage'))
const LoginPage = lazy(() => import('./pages/LoginPage'))
const NotFoundPage = lazy(() => import('./pages/NotFoundPage'))

function PageLoader() {
  return (
    <div className="min-h-screen bg-fl-black flex items-center justify-center">
      <div className="w-6 h-6 rounded-full border-2 border-fl-green border-t-transparent animate-spin" />
    </div>
  )
}

function Homepage() {
  // Start page-level analytics: scroll depth milestones + exit beacon
  useEffect(() => {
    const cleanup = initPageTracking()
    return cleanup
  }, [])

  return (
    <div className="min-h-screen bg-fl-black text-fl-white font-body overflow-x-hidden">
      <Header />
      <HeroSection />
      <TickerBar />
      <StatsSection />
      <ThreeLanesSection />
      <PricingSection />
      <ToolkitSection />
      <TestimonialsSection />
      <LeadMagnetSection />
      <ApplyCtaSection />
      <Footer />
      <StickyBottomBar />
    </div>
  )
}

export default function App() {
  return (
    <Suspense fallback={null}>
      {/* No basename — React Router matches actual URL paths served by Express */}
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Homepage />} />
          <Route path="/join" element={
            <Suspense fallback={<PageLoader />}><JoinPage /></Suspense>
          } />
          <Route path="/apply" element={
            <Suspense fallback={<PageLoader />}><ApplyPage /></Suspense>
          } />
          <Route path="/login" element={
            <Suspense fallback={<PageLoader />}><LoginPage /></Suspense>
          } />
          <Route path="*" element={
            <Suspense fallback={<PageLoader />}><NotFoundPage /></Suspense>
          } />
        </Routes>
      </BrowserRouter>
    </Suspense>
  )
}
