const fs = require('fs');
const files = [
  'public/index.html', 'public/buy.html', 'public/earn.html', 'public/join.html',
  'public/partner.html', 'public/pricing.html', 'public/tools.html', 'public/vehicle-intelligence.html',
  'public/welcome.html', 'public/dashboard.html', 'public/flip-to-fortune.html',
  'public/payment-success.html', 'public/admin.html', 'public/affiliateos.html',
  'public/apply.html', 'public/blog-post.html', 'public/blog.html',
  'public/byrddawgsos.html', 'public/certification.html', 'public/admin-blog.html',
  'public/admin-login.html', 'public/terms.html', 'public/unsubscribe.html'
];
let updated = 0;
files.forEach(f => {
  if (fs.existsSync(f) === false) { console.log('MISSING: ' + f); return; }
  let content = fs.readFileSync(f, 'utf8');
  // Remove any existing duplicate wrappers first (safety)
  content = content.replace(/<span class="logo-img-container"><img/g, '<img');
  // Wrap logo img in logo-img-container span
  content = content.replace(/(<img src="\/images\/flip-lane-logo\.svg"[^>]*>)/g, '<span class="logo-img-container">$1</span>');
  fs.writeFileSync(f, content);
  console.log('Updated: ' + f);
  updated++;
});
console.log('Done: ' + updated + ' files');