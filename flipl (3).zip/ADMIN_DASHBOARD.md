# Admin Analytics Dashboard

## Access

**Dashboard URL:**
```
https://flipl.polsia.app/admin?key=<ADMIN_SECRET>
```

Default admin secret: `fliplaneadmin2024` (change via `ADMIN_SECRET` env var)

## Features

### Real-Time Metrics

The dashboard displays:

1. **Member Metrics**
   - Total signups
   - Active members
   - Pending applications
   - Inactive/churned members

2. **Payment Metrics**
   - Total revenue ($250 per member)
   - Number of paid members
   - Average revenue per member

3. **DocuSign Agreement Status**
   - Agreements sent
   - Signed agreements
   - Pending signatures
   - Completion rate percentage

4. **Conversion Funnel**
   - Landing page visits (estimated: applications × 10)
   - Applications submitted
   - Payments completed
   - Active members
   - Conversion rates at each stage

### Auto-Refresh

The dashboard automatically refreshes every 30 seconds to show the latest data.

## API Endpoints

### Get Metrics (JSON)

```bash
GET https://flipl.polsia.app/api/admin/metrics?key=<ADMIN_SECRET>
```

Returns all metrics in JSON format for programmatic access.

### Save Daily Snapshot

```bash
POST https://flipl.polsia.app/api/admin/snapshot?key=<ADMIN_SECRET>
```

Saves the current metrics to the `reports` table with:
- `report_type`: `daily_metrics`
- `report_date`: Current date (YYYY-MM-DD)
- `metrics`: Full metrics object (JSONB)

## Setting Up Daily Snapshots

To track metrics over time, set up a daily cron job:

### Option 1: GitHub Actions (Recommended)

Create `.github/workflows/daily-snapshot.yml`:

```yaml
name: Daily Metrics Snapshot

on:
  schedule:
    - cron: '0 0 * * *'  # Run at midnight UTC daily
  workflow_dispatch:  # Allow manual trigger

jobs:
  snapshot:
    runs-on: ubuntu-latest
    steps:
      - name: Save metrics snapshot
        run: |
          curl -X POST "https://flipl.polsia.app/api/admin/snapshot?key=${{ secrets.ADMIN_SECRET }}"
```

Add `ADMIN_SECRET` to your GitHub repository secrets.

### Option 2: External Cron Service

Use services like:
- **cron-job.org** (free, no signup)
- **EasyCron** (free tier available)
- **Zapier** (scheduled webhooks)

Configure to POST to:
```
https://flipl.polsia.app/api/admin/snapshot?key=<ADMIN_SECRET>
```

### Option 3: Server-Side Cron

If you have a server with cron access:

```bash
# Add to crontab (crontab -e)
0 0 * * * curl -X POST "https://flipl.polsia.app/api/admin/snapshot?key=<ADMIN_SECRET>"
```

## Querying Historical Data

Snapshots are stored in the `reports` table:

```sql
-- Get all daily snapshots
SELECT report_date, metrics
FROM reports
WHERE report_type = 'daily_metrics'
ORDER BY report_date DESC;

-- Get metrics for a specific date
SELECT metrics
FROM reports
WHERE report_type = 'daily_metrics'
  AND report_date = '2026-03-09';

-- Get metrics for the last 7 days
SELECT report_date,
       metrics->'members'->'total' as total_members,
       metrics->'payments'->'total_revenue' as revenue
FROM reports
WHERE report_type = 'daily_metrics'
  AND report_date >= CURRENT_DATE - INTERVAL '7 days'
ORDER BY report_date DESC;
```

## Security

- The admin dashboard is protected by a secret key
- Change the default `ADMIN_SECRET` in production
- The key can be passed via query param (`?key=`) or `X-Admin-Key` header
- Keep the admin secret private and rotate it periodically

## Notes

- **Visit tracking**: Currently estimated as `applications × 10` (update when real analytics are added)
- **Payment amount**: Hardcoded as $250 per member (adjust if pricing changes)
- **Funnel estimates**: Improve accuracy by adding real page view tracking (e.g., Google Analytics, Plausible)
