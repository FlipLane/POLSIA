const https = require('https');

const BASE = 'https://flipl.polsia.app';
const EMAIL = 'win@fliplane.net';

function get(path) {
  return new Promise((resolve, reject) => {
    https.get(`${BASE}${path}`, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        console.log(`GET ${path} → ${res.statusCode}`);
        try { resolve({ status: res.statusCode, body: JSON.parse(data) }); }
        catch { resolve({ status: res.statusCode, body: data.substring(0, 500) }); }
      });
    }).on('error', reject);
  });
}

function post(path, payload) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify(payload);
    const url = new URL(`${BASE}${path}`);
    const opts = {
      hostname: url.hostname,
      path: url.pathname,
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) }
    };
    const req = https.request(opts, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        console.log(`POST ${path} → ${res.statusCode}`);
        try { resolve({ status: res.statusCode, body: JSON.parse(data) }); }
        catch { resolve({ status: res.statusCode, body: data.substring(0, 500) }); }
      });
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

async function main() {
  console.log('=== TOS Flow Verification ===\n');

  // Step 1: Load terms
  console.log('1. Loading terms...');
  const terms = await get('/api/terms');
  console.log('   Version:', terms.body?.terms?.version);
  console.log('   Has content:', !!terms.body?.terms?.content);
  console.log('   Success:', terms.body?.success);

  // Step 2: Check member status
  console.log('\n2. Checking member terms status...');
  const check = await get(`/api/member/terms-check?email=${encodeURIComponent(EMAIL)}&type=member`);
  console.log('   Response:', JSON.stringify(check.body));

  // Step 3: Test sign-terms endpoint
  console.log('\n3. Testing sign-terms endpoint...');
  const sign = await post('/api/member/sign-terms', {
    email: EMAIL,
    type: 'member',
    termsVersion: terms.body?.terms?.version || 1
  });
  console.log('   Response:', JSON.stringify(sign.body));

  // Step 4: Verify status changed
  console.log('\n4. Re-checking status after signing...');
  const recheck = await get(`/api/member/terms-check?email=${encodeURIComponent(EMAIL)}&type=member`);
  console.log('   Response:', JSON.stringify(recheck.body));

  // Step 5: Check agreement-status endpoint too
  console.log('\n5. Checking agreement-status endpoint...');
  const agreement = await get(`/api/member/agreement-status?email=${encodeURIComponent(EMAIL)}`);
  console.log('   Response:', JSON.stringify(agreement.body));

  // Step 6: Check that /terms page HTML loads
  console.log('\n6. Loading /terms HTML page...');
  const page = await get(`/terms?email=${encodeURIComponent(EMAIL)}&type=member`);
  console.log('   Status:', page.status);
  const html = typeof page.body === 'string' ? page.body : '';
  console.log('   Has acceptance-section div:', html.includes('acceptance-section'));
  console.log('   Has submitAcceptance function:', html.includes('submitAcceptance'));
  console.log('   Has updateAcceptBtn function:', html.includes('updateAcceptBtn'));
  console.log('   Has accept-checkbox:', html.includes('accept-checkbox'));
  console.log('   HTML length:', html.length);

  console.log('\n=== Done ===');
}

main().catch(e => console.error('FATAL:', e.message));
