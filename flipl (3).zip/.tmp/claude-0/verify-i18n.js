var src = require("fs").readFileSync("public/js/i18n.js", "utf8");
var objSrc = src.split('(function')[0].replace('const ', 'var ');
eval(objSrc);
var en = Object.keys(FLIPLANE_TRANSLATIONS.en);
var es = Object.keys(FLIPLANE_TRANSLATIONS.es);
console.log("EN keys:", en.length, "| ES keys:", es.length);
var missingInEs = en.filter(function(k) { return es.indexOf(k) === -1; });
var missingInEn = es.filter(function(k) { return en.indexOf(k) === -1; });
if (missingInEs.length) console.log("Missing in ES:", missingInEs);
if (missingInEn.length) console.log("Missing in EN:", missingInEn);
if (missingInEs.length === 0 && missingInEn.length === 0) console.log("All keys match!");
var checks = ['ticker_1','ticker_10','home_stat1_label','home_chip_1','home_hero_proof','home_scroll','home_earnings_disclaimer','home_news_success','footer_income_disc'];
checks.forEach(function(k) {
  var enOk = FLIPLANE_TRANSLATIONS.en[k] ? 'OK' : 'MISSING';
  var esOk = FLIPLANE_TRANSLATIONS.es[k] ? 'OK' : 'MISSING';
  console.log(k, '- EN:', enOk, '| ES:', esOk);
});
