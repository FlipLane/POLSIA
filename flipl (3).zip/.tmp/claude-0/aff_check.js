

    // ====== State ======
    let affiliateEmail = sessionStorage.getItem('affiliate_email') || '';
    let affiliateProfile = null;
    let dashboardData = null;

    // ====== Init ======
    if (affiliateEmail) {
      silentLogin(affiliateEmail);
    }

    // ====== Auth ======
    async function handleLogin() {
      const email = document.getElementById('login-email').value.trim();
      if (!email) return;

      const btn = document.getElementById('login-btn');
      const errorEl = document.getElementById('login-error');
      const pendingEl = document.getElementById('login-pending');

      btn.disabled = true;
      btn.innerHTML = '<div class="spinner"></div> Checking...';
      errorEl.style.display = 'none';
      pendingEl.style.display = 'none';

      try {
        const res = await fetch('/api/affiliateos/auth', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email })
        });

        const data = await res.json();

        if (data.success) {
          affiliateEmail = email;
          affiliateProfile = data.affiliate;
          sessionStorage.setItem('affiliate_email', email);
          showDashboard();
        } else if (data.status === 'new') {
          pendingEl.textContent = data.message;
          pendingEl.style.display = 'block';
        } else {
          errorEl.textContent = data.message;
          errorEl.style.display = 'block';
        }
      } catch (err) {
        errorEl.textContent = 'Connection error. Please try again.';
        errorEl.style.display = 'block';
      }

      btn.disabled = false;
      btn.textContent = 'Access Dashboard';
    }

    async function silentLogin(email) {
      try {
        const res = await fetch('/api/affiliateos/auth', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email })
        });
        const data = await res.json();
        if (data.success) {
          affiliateProfile = data.affiliate;
          showDashboard();
        } else {
          sessionStorage.removeItem('affiliate_email');
        }
      } catch (err) {
        sessionStorage.removeItem('affiliate_email');
      }
    }

    function handleLogout() {
      sessionStorage.removeItem('affiliate_email');
      affiliateEmail = '';
      affiliateProfile = null;
      document.getElementById('login-screen').style.display = 'flex';
      document.getElementById('dashboard-screen').style.display = 'none';
    }

    // ====== Dashboard ======
    function showDashboard() {
      document.getElementById('login-screen').style.display = 'none';
      document.getElementById('dashboard-screen').style.display = 'block';
      document.getElementById('user-name').textContent = affiliateProfile.name;
      document.getElementById('welcome-name').textContent = affiliateProfile.name.split(' ')[0];

      loadDashboardData();
      loadReferralLinks();
      loadShareCopy();
      loadDeals();
      loadCommissions();

      // Show notification bell + tab
      const bellBtn = document.getElementById('notif-bell-btn');
      const notifTabBtn = document.getElementById('notif-tab-btn');
      if (bellBtn) bellBtn.style.display = 'flex';
      if (notifTabBtn) notifTabBtn.style.display = 'inline-block';
      loadAffiliateAnnouncements();
    }

    async function loadDashboardData() {
      try {
        const res = await fetch(`/api/affiliateos/dashboard?email=${encodeURIComponent(affiliateEmail)}`);
        const data = await res.json();
        if (!data.success) return;

        dashboardData = data;

        // Update stats
        document.getElementById('stat-earned').textContent = formatMoney(data.earnings.total_earned);
        document.getElementById('stat-pending').textContent = formatMoney(data.earnings.total_pending);
        document.getElementById('stat-paid').textContent = formatMoney(data.earnings.total_paid);
        document.getElementById('stat-clicks').textContent = data.referrals.total_clicks.toLocaleString();
        document.getElementById('stat-signups').textContent = data.referrals.total_signups.toLocaleString();
        document.getElementById('stat-deals-closed').textContent = data.referrals.deals_closed.toLocaleString();

        // Update pipeline
        document.getElementById('pipe-submitted').textContent = data.deals.submitted;
        document.getElementById('pipe-reviewed').textContent = data.deals.reviewed;
        document.getElementById('pipe-closed').textContent = data.deals.closed;
        document.getElementById('pipe-paid').textContent = data.deals.commission_paid;

        // Quick steps
        if (data.referrals.total_clicks > 0) document.getElementById('step-1').classList.add('done');
        if (data.deals.total > 0) document.getElementById('step-2').classList.add('done');
        if (data.earnings.total_earned > 0) document.getElementById('step-3').classList.add('done');

        // Activity feed
        renderActivityFeed(data.activity);

      } catch (err) {
        console.error('Dashboard load error:', err);
      }
    }

    function renderActivityFeed(activities) {
      const feed = document.getElementById('activity-feed');
      if (!activities || activities.length === 0) {
        feed.innerHTML = `<div class="empty-state"><div class="empty-icon">📋</div>No activity yet. Start by sharing your referral link!</div>`;
        return;
      }

      feed.innerHTML = activities.map(a => {
        const iconClass = getActivityIcon(a.type);
        return `
          <div class="activity-item">
            <div class="activity-icon ${iconClass.color}">${iconClass.emoji}</div>
            <div class="activity-text">
              <div class="activity-title">${escapeHtml(a.title)}</div>
              <div class="activity-desc">${escapeHtml(a.description || '')}</div>
            </div>
            <div class="activity-time">${timeAgo(a.created_at)}</div>
          </div>
        `;
      }).join('');
    }

    // ====== Referral Links ======
    async function loadReferralLinks() {
      try {
        const res = await fetch(`/api/affiliateos/links?email=${encodeURIComponent(affiliateEmail)}`);
        const data = await res.json();
        if (!data.success) return;

        // Set main referral link
        const mainLink = data.links.length > 0 ? data.links[0].full_url : `${data.base_url}/ref/${data.referral_code.toLowerCase()}`;
        document.getElementById('main-ref-link').textContent = mainLink;

        // Generate QR code
        generateQR(mainLink);

        // Render links table
        renderLinksTable(data.links);

      } catch (err) {
        console.error('Links load error:', err);
      }
    }

    function renderLinksTable(links) {
      const container = document.getElementById('links-table');
      if (!links || links.length === 0) {
        container.innerHTML = `<div class="empty-state">No links yet. Create your first one!</div>`;
        return;
      }

      container.innerHTML = `
        <table>
          <thead>
            <tr>
              <th>Label</th>
              <th>Channel</th>
              <th>URL</th>
              <th>Clicks</th>
              <th>Signups</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            ${links.map(l => `
              <tr>
                <td style="font-weight: 500; color: var(--text-primary);">${escapeHtml(l.label)}</td>
                <td>${escapeHtml(l.channel)}</td>
                <td class="link-url-cell">${escapeHtml(l.full_url)}</td>
                <td style="font-family: 'Space Grotesk'; font-weight: 600;">${l.clicks}</td>
                <td style="font-family: 'Space Grotesk'; font-weight: 600;">${l.signups}</td>
                <td><button class="btn-icon" onclick="copyText('${escapeHtml(l.full_url)}', this)" title="Copy link">📋</button></td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      `;
    }

    async function createNewLink() {
      const label = document.getElementById('new-link-label').value.trim();
      const channel = document.getElementById('new-link-channel').value;

      try {
        const res = await fetch('/api/affiliateos/links', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: affiliateEmail, label, channel })
        });
        const data = await res.json();
        if (data.success) {
          showToast('Link created!');
          document.getElementById('new-link-label').value = '';
          document.getElementById('new-link-form').classList.remove('visible');
          loadReferralLinks();
        } else {
          showToast(data.message, true);
        }
      } catch (err) {
        showToast('Failed to create link', true);
      }
    }

    function toggleNewLinkForm() {
      document.getElementById('new-link-form').classList.toggle('visible');
    }

    // ====== Share Copy ======
    async function loadShareCopy() {
      try {
        const res = await fetch(`/api/affiliateos/share-copy?email=${encodeURIComponent(affiliateEmail)}`);
        const data = await res.json();
        if (!data.success) return;

        const sc = data.share_copy;
        const grid = document.getElementById('share-grid');

        grid.innerHTML = `
          <div class="share-card">
            <div class="share-card-header">
              <div class="share-platform"><div class="share-platform-icon fb">f</div> Facebook</div>
              <button class="btn-icon" onclick="copyShareText('fb')" title="Copy text">📋</button>
            </div>
            <div class="share-text" id="share-fb">${escapeHtml(sc.facebook.text)}</div>
            <div class="share-actions">
              <button class="btn btn-secondary btn-sm" onclick="shareToFacebook()">Share to Facebook</button>
            </div>
          </div>

          <div class="share-card">
            <div class="share-card-header">
              <div class="share-platform"><div class="share-platform-icon ig">&#9829;</div> Instagram</div>
              <button class="btn-icon" onclick="copyShareText('ig')" title="Copy text">📋</button>
            </div>
            <div class="share-text" id="share-ig">${escapeHtml(sc.instagram.caption)}</div>
            <div class="share-actions">
              <button class="btn btn-secondary btn-sm" onclick="copyShareText('ig')">Copy Caption</button>
            </div>
          </div>

          <div class="share-card">
            <div class="share-card-header">
              <div class="share-platform"><div class="share-platform-icon tw">𝕏</div> Twitter / X</div>
              <button class="btn-icon" onclick="copyShareText('tw')" title="Copy text">📋</button>
            </div>
            <div class="share-text" id="share-tw">${escapeHtml(sc.twitter.text)}</div>
            <div class="share-actions">
              <button class="btn btn-secondary btn-sm" onclick="shareToTwitter()">Post to X</button>
            </div>
          </div>

          <div class="share-card">
            <div class="share-card-header">
              <div class="share-platform"><div class="share-platform-icon tt">♪</div> TikTok</div>
              <button class="btn-icon" onclick="copyShareText('tt')" title="Copy text">📋</button>
            </div>
            <div class="share-text" id="share-tt">${escapeHtml(sc.tiktok.caption)}</div>
            <div class="share-actions">
              <button class="btn btn-secondary btn-sm" onclick="copyShareText('tt')">Copy Caption</button>
            </div>
          </div>
        `;
      } catch (err) {
        console.error('Share copy load error:', err);
      }
    }

    function shareToFacebook() {
      const url = document.getElementById('main-ref-link').textContent;
      window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`, '_blank');
    }

    function shareToTwitter() {
      const text = document.getElementById('share-tw').textContent;
      window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}`, '_blank');
    }

    function copyShareText(platform) {
      const el = document.getElementById(`share-${platform}`);
      if (el) {
        navigator.clipboard.writeText(el.textContent);
        showToast('Copied to clipboard!');
      }
    }

    // ====== Deals ======
    async function loadDeals() {
      const container = document.getElementById('deal-list');
      if (!container) return;
      // Show loading state immediately — don't rely on static HTML
      container.innerHTML = '<div class="loading-overlay"><div class="spinner"></div> Loading deals...</div>';

      // Guard: require affiliate email
      if (!affiliateEmail) {
        container.innerHTML = '<div class="empty-state"><div class="empty-icon">⚠️</div>Please log in to view your deals.</div>';
        return;
      }

      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 10000); // 10s timeout

        const res = await fetch(`/api/affiliateos/deals?email=${encodeURIComponent(affiliateEmail)}`, {
          signal: controller.signal
        });
        clearTimeout(timeout);

        const data = await res.json();
        if (!res.ok || !data.success) {
          const msg = data.message || `Server error (${res.status}). Please try again.`;
          container.innerHTML = `<div class="empty-state"><div class="empty-icon">⚠️</div>${msg}</div>`;
          return;
        }

        renderDealList(data.deals);
      } catch (err) {
        console.error('Deals load error:', err);
        const isAbort = err.name === 'AbortError' || err.message && err.message.includes('abort');
        container.innerHTML = `<div class="empty-state"><div class="empty-icon">⚠️</div>${isAbort ? 'Request timed out. Please refresh.' : 'Failed to load deals. Please check your connection and try again.'}</div>`;
      }
    }

    function renderDealList(deals) {
      const container = document.getElementById('deal-list');
      if (!deals || deals.length === 0) {
        // Zero-out pipeline counts on empty
        ['pipe-submitted','pipe-reviewed','pipe-closed','pipe-paid'].forEach(id => {
          const el = document.getElementById(id);
          if (el) el.textContent = '0';
        });
        container.innerHTML = `<div class="empty-state"><div class="empty-icon">🚗</div>No deals submitted yet. Find a vehicle and submit it above!</div>`;
        return;
      }

      // Update pipeline header counts
      const counts = { submitted: 0, reviewed: 0, closed: 0, commission_paid: 0 };
      for (const d of deals) {
        if (d.status in counts) counts[d.status]++;
      }
      const pipeMap = { submitted: 'pipe-submitted', reviewed: 'pipe-reviewed', closed: 'pipe-closed', commission_paid: 'pipe-paid' };
      for (const [status, elId] of Object.entries(pipeMap)) {
        const el = document.getElementById(elId);
        if (el) el.textContent = counts[status];
      }

      container.innerHTML = deals.map(d => `
        <div class="deal-item">
          <div class="deal-status-dot ${d.status}"></div>
          <div class="deal-info">
            <div class="deal-title">${escapeHtml(d.vehicle_description)}</div>
            <div class="deal-meta">
              ${d.vin ? `<span>VIN: ${escapeHtml(d.vin)}</span>` : ''}
              ${d.source_name ? `<span>Source: ${escapeHtml(d.source_name)}</span>` : ''}
              <span>${timeAgo(d.created_at)}</span>
            </div>
          </div>
          ${d.price ? `<div class="deal-price">$${parseFloat(d.price).toLocaleString()}</div>` : ''}
          <div class="deal-status-badge ${d.status}">${d.status.replace('_', ' ')}</div>
        </div>
      `).join('');
    }

    async function submitDeal(e) {
      e.preventDefault();
      const btn = document.getElementById('deal-submit-btn');
      btn.disabled = true;
      btn.innerHTML = '<div class="spinner"></div> Submitting...';

      try {
        const res = await fetch('/api/affiliateos/deals', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            email: affiliateEmail,
            vin: document.getElementById('deal-vin').value.trim(),
            vehicle_description: document.getElementById('deal-description').value.trim(),
            price: document.getElementById('deal-price').value || null,
            source_url: document.getElementById('deal-source-url').value.trim(),
            source_name: document.getElementById('deal-source-name').value.trim(),
            notes: document.getElementById('deal-notes').value.trim()
          })
        });

        const data = await res.json();
        if (data.success) {
          showToast('Deal submitted!');
          document.getElementById('deal-form').reset();
          loadDeals();
          loadDashboardData();
        } else {
          showToast(data.message, true);
        }
      } catch (err) {
        showToast('Failed to submit deal', true);
      }

      btn.disabled = false;
      btn.textContent = 'Submit Deal';
    }

    // ====== Commissions ======
    async function loadCommissions() {
      try {
        const res = await fetch(`/api/affiliateos/commissions?email=${encodeURIComponent(affiliateEmail)}`);
        const data = await res.json();
        if (!data.success) return;

        // Update commission stats
        if (dashboardData) {
          document.getElementById('comm-total').textContent = formatMoney(dashboardData.earnings.total_earned);
          document.getElementById('comm-pending').textContent = formatMoney(dashboardData.earnings.total_pending);
          document.getElementById('comm-paid').textContent = formatMoney(dashboardData.earnings.total_paid);
        }

        renderCommissionsList(data.commissions);
      } catch (err) {
        console.error('Commissions load error:', err);
      }
    }

    function renderCommissionsList(commissions) {
      const container = document.getElementById('commissions-list');
      if (!commissions || commissions.length === 0) {
        container.innerHTML = `<div class="empty-state"><div class="empty-icon">💰</div>No commissions yet. Start sharing your referral link and submitting deals!</div>`;
        return;
      }

      container.innerHTML = commissions.map(c => {
        const statusColor = c.status === 'paid' ? 'blue' : c.status === 'pending' ? 'yellow' : 'green';
        const statusEmoji = c.status === 'paid' ? '✅' : c.status === 'pending' ? '⏳' : '💰';
        return `
          <div class="activity-item">
            <div class="activity-icon ${statusColor}">${statusEmoji}</div>
            <div class="activity-text">
              <div class="activity-title">${escapeHtml(c.type)} — ${formatMoney(c.amount)}</div>
              <div class="activity-desc">${escapeHtml(c.description || '')}</div>
            </div>
            <div style="text-align: right;">
              <div class="deal-status-badge ${c.status === 'paid' ? 'closed' : c.status === 'pending' ? 'reviewed' : 'submitted'}">${c.status}</div>
              <div class="activity-time">${timeAgo(c.created_at)}</div>
            </div>
          </div>
        `;
      }).join('');
    }

    // ====== Tab Navigation ======
    function switchTab(tabId) {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
      document.querySelector(`.tab[data-tab="${tabId}"]`).classList.add('active');
      document.getElementById(`tab-${tabId}`).classList.add('active');
      if (tabId === 'deals') loadDeals();
    }

    // ====== QR Code ======
    function generateQR(url) {
      const container = document.getElementById('qr-code');
      container.innerHTML = '';
      if (typeof QRCode !== 'undefined') {
        const canvas = document.createElement('canvas');
        container.appendChild(canvas);
        QRCode.toCanvas(canvas, url, {
          width: 124,
          margin: 1,
          color: { dark: '#000000', light: '#ffffff' }
        });
      }
    }

    // ====== Utilities ======
    function copyRefLink(btn) {
      const url = document.getElementById('main-ref-link').textContent;
      navigator.clipboard.writeText(url).then(() => {
        btn.textContent = 'Copied!';
        btn.classList.add('copied');
        setTimeout(() => {
          btn.textContent = 'Copy';
          btn.classList.remove('copied');
        }, 2000);
      });
    }

    function copyText(text, btn) {
      navigator.clipboard.writeText(text).then(() => {
        showToast('Link copied!');
      });
    }

    function showToast(msg, isError = false) {
      const toast = document.getElementById('toast');
      toast.textContent = msg;
      toast.className = 'toast show' + (isError ? ' error' : '');
      setTimeout(() => { toast.className = 'toast'; }, 3000);
    }

    function formatMoney(amount) {
      return '$' + parseFloat(amount || 0).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
    }

    function escapeHtml(str) {
      if (!str) return '';
      return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function timeAgo(dateStr) {
      const now = new Date();
      const date = new Date(dateStr);
      const seconds = Math.floor((now - date) / 1000);
      if (seconds < 60) return 'just now';
      if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
      if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
      if (seconds < 604800) return `${Math.floor(seconds / 86400)}d ago`;
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    }

    function getActivityIcon(type) {
      const icons = {
        'profile_created': { emoji: '🎉', color: 'green' },
        'link_created': { emoji: '🔗', color: 'blue' },
        'deal_submitted': { emoji: '🚗', color: 'yellow' },
        'milestone': { emoji: '🏆', color: 'purple' },
        'commission_earned': { emoji: '💰', color: 'green' },
        'referral_signup': { emoji: '👤', color: 'blue' },
        'deal_closed': { emoji: '✅', color: 'green' },
        'payout': { emoji: '💸', color: 'purple' }
      };
      return icons[type] || { emoji: '📌', color: 'blue' };
    }

    // Enter key on login
    document.getElementById('login-email').addEventListener('keydown', (e) => {
      if (e.key === 'Enter') handleLogin();
    });

    // ====== Marketing Hub ======
    function copyTemplateText(elementId) {
      const el = document.getElementById(elementId);
      if (el) {
        navigator.clipboard.writeText(el.textContent);
        showToast('Copied to clipboard!');
      }
    }

    // ====== Training Section ======
    function toggleFaq(id) {
      const el = document.getElementById('faq-' + id);
      if (el) {
        el.style.display = el.style.display === 'none' ? 'block' : 'none';
      }
    }

    function toggleInlineFaq(btn) {
      const answer = btn.nextElementSibling;
      if (!answer) return;
      const isOpen = answer.classList.contains('open');
      // Close all
      document.querySelectorAll('.faq-answer.open').forEach(a => {
        a.classList.remove('open');
        a.previousElementSibling.classList.remove('open');
      });
      if (!isOpen) {
        answer.classList.add('open');
        btn.classList.add('open');
      }
    }

    function calcEarnings() {
      const referrals = parseInt(document.getElementById('calc-referrals').value) || 0;
      const conv = parseInt(document.getElementById('calc-conv').value) || 0;
      const signups = Math.round(referrals * conv / 100);
      const commission = 125; // $250 × 50%
      const monthly = signups * commission;
      document.getElementById('calc-monthly').textContent = '$' + monthly.toLocaleString();
      document.getElementById('calc-breakdown').textContent = `${referrals} referrals × ${conv}% conversion = ${signups} signups × $${commission} = $${monthly.toLocaleString()}/mo`;
    }
    // Initialize calc
    calcEarnings();

    // ====== Affiliate Hub Forms ======
    async function submitAffiliateRequest(e, requestType, prefix) {
      e.preventDefault();
      const alertEl = document.getElementById(prefix + '-alert');
      const submitBtn = document.getElementById(prefix + '-submit-btn');

      submitBtn.disabled = true;
      submitBtn.textContent = 'Submitting...';
      alertEl.style.display = 'none';

      let formData = {};
      if (requestType === 'customer_inquiry') {
        formData = {
          customer_name: document.getElementById('inq-name').value.trim(),
          customer_email: document.getElementById('inq-email').value.trim(),
          customer_phone: document.getElementById('inq-phone').value.trim(),
          vehicle_interest: document.getElementById('inq-vehicle').value.trim(),
          source: document.getElementById('inq-source').value,
          message: document.getElementById('inq-message').value.trim()
        };
      } else if (requestType === 'marketing_support') {
        formData = {
          name: document.getElementById('mkt-name').value.trim(),
          content_type: document.getElementById('mkt-type').value,
          description: document.getElementById('mkt-description').value.trim(),
          deadline: document.getElementById('mkt-deadline').value
        };
      }

      try {
        const res = await fetch('/api/affiliateos/service-request', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            email: affiliateEmail,
            request_type: requestType,
            form_data: formData
          })
        });
        const data = await res.json();
        alertEl.style.display = 'block';
        if (data.success) {
          alertEl.className = 'form-alert success';
          alertEl.textContent = '✅ ' + data.message;
          e.target.reset();
        } else {
          alertEl.className = 'form-alert error';
          alertEl.textContent = '❌ ' + (data.message || 'Submission failed. Try again.');
        }
      } catch (err) {
        alertEl.style.display = 'block';
        alertEl.className = 'form-alert error';
        alertEl.textContent = '❌ Connection error. Please try again.';
      }

      submitBtn.disabled = false;
      submitBtn.textContent = requestType === 'customer_inquiry' ? 'Submit Inquiry' : 'Submit Request';
    }

    // ====== AI Chat ======
    let aiMessages = [];
    let aiInitialized = false;

    // Detect if message likely needs live web search
    const AFFILIATE_SEARCH_PATTERNS = [
      /\b(price|prices|pricing|market|worth|value|how much)\b/i,
      /\b(recall|recalls|nhtsa|safety)\b/i,
      /\b(news|trend|trends|trending|what.?s happening)\b/i,
      /\b(current|today|now|latest|recent|2026|2025)\b/i,
      /what.?s? (the |a )?(market|going rate|average price)\b/i,
      /\b(best cars? to flip|hot cars?|what.?s selling)\b/i,
      /\bused car market\b/i
    ];
    function affiliateNeedsSearch(text) {
      return AFFILIATE_SEARCH_PATTERNS.some(p => p.test(text));
    }

    function initAiChat() {
      if (aiInitialized) return;
      aiInitialized = true;
    }

    function sendAiStarter(text) {
      document.getElementById('ai-starters').style.display = 'none';
      document.getElementById('ai-input').value = text;
      sendAiMessage();
    }

    function handleAiKeydown(e) {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendAiMessage();
      }
    }

    function autoResizeInput(el) {
      el.style.height = 'auto';
      el.style.height = Math.min(el.scrollHeight, 120) + 'px';
    }

    async function sendAiMessage() {
      const input = document.getElementById('ai-input');
      const text = input.value.trim();
      if (!text) return;

      const sendBtn = document.getElementById('ai-send-btn');
      sendBtn.disabled = true;
      input.value = '';
      input.style.height = 'auto';

      // Hide starter prompts
      document.getElementById('ai-starters').style.display = 'none';

      // Add user message to UI
      appendAiMessage('user', text);
      aiMessages.push({ role: 'user', content: text });

      // Show typing indicator (with search hint if applicable)
      const typingId = showAiTyping(affiliateNeedsSearch(text));

      // Build context from dashboard data
      const context = {};
      if (affiliateProfile?.name) context.name = affiliateProfile.name;
      if (dashboardData?.commissions?.total_earned !== undefined) context.total_earned = dashboardData.commissions.total_earned;
      if (dashboardData?.referrals?.total_signups !== undefined) context.referral_signups = dashboardData.referrals.total_signups;

      try {
        const res = await fetch('/api/ai/affiliate-chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ messages: aiMessages, context })
        });
        const data = await res.json();
        removeAiTyping(typingId);

        const reply = data.success ? data.message : "Sorry, something went wrong. Try again.";
        appendAiMessage('bot', reply, data.sources);
        aiMessages.push({ role: 'assistant', content: reply });
      } catch (err) {
        removeAiTyping(typingId);
        appendAiMessage('bot', 'Connection error. Please check your internet and try again.');
      }

      sendBtn.disabled = false;
    }

    function appendAiMessage(role, text, sources) {
      const container = document.getElementById('ai-messages');
      const icon = role === 'bot' ? '🤖' : '👤';
      const div = document.createElement('div');
      div.className = 'ai-message ' + role;
      let sourceHtml = '';
      if (role === 'bot' && sources && sources.length > 0) {
        const links = sources.filter(s => s.url).map(s => {
          const display = s.url.replace(/^https?:\/\//, '').replace(/\/$/, '').split('/')[0];
          return `<a href="https://${s.url.replace(/^https?:\/\//, '')}" target="_blank" rel="noopener" style="color:#FF6B35;text-decoration:none;">${display}</a>`;
        }).join(' &middot; ');
        if (links) sourceHtml = `<div style="margin-top:8px;padding-top:7px;border-top:1px solid rgba(255,255,255,0.1);font-size:11px;color:#888;">🔍 Web sources: ${links}</div>`;
      }
      div.innerHTML = `
        <div class="ai-message-icon">${icon}</div>
        <div class="ai-message-bubble">${escapeHtml(text)}${sourceHtml}</div>
      `;
      container.appendChild(div);
      container.scrollTop = container.scrollHeight;
    }

    function showAiTyping(isSearching) {
      const container = document.getElementById('ai-messages');
      const id = 'typing-' + Date.now();
      const div = document.createElement('div');
      div.id = id;
      div.className = 'ai-message bot';
      const bubbleContent = isSearching
        ? '<span style="font-size:11px;color:#aaa;">🔍 Searching the web&hellip;</span>'
        : '<div class="ai-typing"><span></span><span></span><span></span></div>';
      div.innerHTML = `<div class="ai-message-icon">🤖</div><div class="ai-message-bubble">${bubbleContent}</div>`;
      container.appendChild(div);
      container.scrollTop = container.scrollHeight;
      return id;
    }

    function removeAiTyping(id) {
      const el = document.getElementById(id);
      if (el) el.remove();
    }

    // ====== Notifications / Announcements ======
    async function loadAffiliateAnnouncements() {
      const loadingEl = document.getElementById('affiliate-announcements-loading');
      const listEl = document.getElementById('affiliate-announcements-list');
      if (!loadingEl || !listEl) return;
      loadingEl.style.display = 'block';
      listEl.innerHTML = '';
      try {
        const res = await fetch('/api/announcements');
        const data = await res.json();
        loadingEl.style.display = 'none';
        if (!data.success || !data.announcements || !data.announcements.length) {
          listEl.innerHTML = '<div style="text-align:center;padding:40px 0;color:var(--text-dim)">No announcements yet.</div>';
          // Hide bell badge if no announcements
          const badge = document.getElementById('notif-bell-badge');
          if (badge) badge.style.display = 'none';
          return;
        }
        // Show bell badge
        const badge = document.getElementById('notif-bell-badge');
        if (badge) badge.style.display = 'flex';
        listEl.innerHTML = data.announcements.map(a => `
          <div style="background:var(--card-bg,#1f2937);border:1px solid var(--border,#374151);border-radius:12px;padding:20px;margin-bottom:16px">
            <div style="font-weight:600;font-size:16px;margin-bottom:8px">${escapeHtml(a.title)}</div>
            <div style="color:var(--text-secondary,#9ca3af);font-size:14px;line-height:1.6;white-space:pre-wrap">${escapeHtml(a.body)}</div>
            <div style="color:var(--text-dim,#6b7280);font-size:12px;margin-top:12px">${new Date(a.created_at).toLocaleDateString('en-US',{year:'numeric',month:'long',day:'numeric'})}</div>
          </div>
        `).join('');
      } catch (err) {
        if (loadingEl) loadingEl.style.display = 'none';
        if (listEl) listEl.innerHTML = '<div style="text-align:center;padding:40px 0;color:var(--text-dim)">Failed to load announcements.</div>';
      }
    }

    function escapeHtml(text) {
      const div = document.createElement('div');
      div.appendChild(document.createTextNode(text || ''));
      return div.innerHTML;
    }
  
