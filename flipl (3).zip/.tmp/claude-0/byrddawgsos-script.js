

    // ====== SHIPPING CALCULATOR ======
    var _scMap = null, _scPickupM = null, _scDeliveryM = null, _scRouteL = null;
    var _scVehicle = 'sedan', _scTransport = 'open', _scOperable = 'yes';
    var _scResult = null;

    function scSetType(btn, groupId) {
      document.querySelectorAll('#' + groupId + ' .ship-type-btn').forEach(function(b){ b.classList.remove('sc-active'); });
      btn.classList.add('sc-active');
      _scVehicle = btn.dataset.val;
    }
    function scSetToggle(btn, groupId) {
      document.querySelectorAll('#' + groupId + ' .ship-toggle-btn').forEach(function(b){ b.classList.remove('sc-active'); });
      btn.classList.add('sc-active');
      if (groupId === 'sc-transport-type') _scTransport = btn.dataset.val;
      else _scOperable = btn.dataset.val;
    }
    function scShowAlert(msg, type) {
      var el = document.getElementById('sc-alert');
      el.style.display = 'block';
      el.style.background = type === 'error' ? 'rgba(255,82,82,0.08)' : 'rgba(255,152,0,0.08)';
      el.style.border = '1px solid ' + (type === 'error' ? 'rgba(255,82,82,0.3)' : 'rgba(255,152,0,0.3)');
      el.style.color = type === 'error' ? 'var(--red)' : 'var(--orange)';
      el.textContent = msg;
    }
    function scClearAlert() { var el = document.getElementById('sc-alert'); if (el) el.style.display = 'none'; }

    async function scGeocode(query) {
      var url = 'https://nominatim.openstreetmap.org/search?q=' + encodeURIComponent(query) + '&format=json&limit=1';
      var resp = await fetch(url, { headers: { 'Accept-Language': 'en' } });
      var data = await resp.json();
      if (!data || data.length === 0) return null;
      return { lat: parseFloat(data[0].lat), lon: parseFloat(data[0].lon) };
    }

    function scTieredCost(miles) {
      if (miles <= 500) return miles * 1.00;
      if (miles <= 1000) return 500 + (miles - 500) * 0.75;
      return 500 + 375 + (miles - 1000) * 0.50;
    }

    async function runShippingCalc() {
      scClearAlert();
      var pickup = (document.getElementById('sc-pickup') || {}).value || '';
      var delivery = (document.getElementById('sc-delivery') || {}).value || '';
      pickup = pickup.trim(); delivery = delivery.trim();
      if (!pickup || !delivery) { scShowAlert('Enter both pickup and delivery locations.', 'error'); return; }

      var btn = document.getElementById('sc-calc-btn');
      btn.disabled = true; btn.textContent = 'Calculating...';

      try {
        var geos = await Promise.all([scGeocode(pickup), scGeocode(delivery)]);
        var pg = geos[0], dg = geos[1];
        if (!pg) { scShowAlert('Could not find "' + pickup + '". Try city, state or zip.', 'error'); return; }
        if (!dg) { scShowAlert('Could not find "' + delivery + '". Try city, state or zip.', 'error'); return; }

        var osrmUrl = 'https://router.project-osrm.org/route/v1/driving/' + pg.lon + ',' + pg.lat + ';' + dg.lon + ',' + dg.lat + '?overview=full&geometries=geojson';
        var oResp = await fetch(osrmUrl);
        var oData = await oResp.json();
        if (!oData || oData.code !== 'Ok' || !oData.routes || !oData.routes.length) {
          scShowAlert('Could not calculate driving route. Check locations.', 'error'); return;
        }
        var route = oData.routes[0];
        var distMi = Math.round(route.distance / 1609.34);

        var base = scTieredCost(distMi);
        var vAdj = { sedan: 0, suv: 150, motorcycle: -75, oversized: 200 }[_scVehicle] || 0;
        var eAdj = _scTransport === 'enclosed' ? Math.round(base * 0.40) : 0;
        var iAdj = _scOperable === 'no' ? 150 : 0;
        var total = base + vAdj + eAdj + iAdj;
        var low = Math.round(total * 0.85), high = Math.round(total * 1.15);

        _scResult = { pickup: pickup, delivery: delivery, distMi: distMi, low: low, high: high };

        // Map
        var mapEl = document.getElementById('shipping-map');
        mapEl.style.display = 'block';
        if (!_scMap) {
          _scMap = L.map('shipping-map');
          L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OpenStreetMap', maxZoom: 18 }).addTo(_scMap);
        }
        if (_scPickupM) _scMap.removeLayer(_scPickupM);
        if (_scDeliveryM) _scMap.removeLayer(_scDeliveryM);
        if (_scRouteL) _scMap.removeLayer(_scRouteL);

        var mkGreen = L.divIcon({ html: '<div style="background:#00e676;width:12px;height:12px;border-radius:50%;border:2px solid #fff;box-shadow:0 0 5px rgba(0,230,118,0.7)"></div>', iconSize:[12,12], iconAnchor:[6,6] });
        var mkOrange = L.divIcon({ html: '<div style="background:#ff9800;width:12px;height:12px;border-radius:50%;border:2px solid #fff;box-shadow:0 0 5px rgba(255,152,0,0.7)"></div>', iconSize:[12,12], iconAnchor:[6,6] });
        _scPickupM = L.marker([pg.lat, pg.lon], { icon: mkGreen }).addTo(_scMap).bindPopup('<strong>Pickup:</strong> ' + pickup);
        _scDeliveryM = L.marker([dg.lat, dg.lon], { icon: mkOrange }).addTo(_scMap).bindPopup('<strong>Delivery:</strong> ' + delivery);
        var coords = route.geometry.coordinates.map(function(c){ return [c[1], c[0]]; });
        _scRouteL = L.polyline(coords, { color: '#448aff', weight: 3, opacity: 0.8 }).addTo(_scMap);
        _scMap.fitBounds([[pg.lat, pg.lon], [dg.lat, dg.lon]], { padding: [30, 30] });
        setTimeout(function(){ _scMap.invalidateSize(); }, 200);

        // Results
        document.getElementById('sc-dist-text').textContent = distMi.toLocaleString() + ' miles by road';
        document.getElementById('sc-cost-range').textContent = '$' + low.toLocaleString() + ' – $' + high.toLocaleString();

        // Show results container
        document.getElementById('shipping-calc-results').style.display = 'block';

        // Breakdown
        var brkHtml = '<div><strong>Distance:</strong> ' + distMi.toLocaleString() + ' mi</div>';
        brkHtml += '<div><strong>Base cost:</strong> $' + Math.round(base).toLocaleString() + '</div>';
        if (vAdj) brkHtml += '<div><strong>Vehicle adj (' + _scVehicle + '):</strong> +$' + vAdj + '</div>';
        if (eAdj) brkHtml += '<div><strong>Enclosed transport:</strong> +$' + eAdj.toLocaleString() + '</div>';
        if (iAdj) brkHtml += '<div><strong>Inoperable surcharge:</strong> +$' + iAdj + '</div>';
        document.getElementById('sc-breakdown').innerHTML = brkHtml;

      } catch (e) {
        scShowAlert('Something went wrong. Please try again.', 'error');
        console.error('[ShippingCalc]', e);
      } finally {
        btn.disabled = false;
        btn.innerHTML = '&#x1F4CD; Calculate Estimate';
      }
    }

    function scPrefillRequest() {
      if (!_scResult) return;
      navigateSection('deals');
      setTimeout(function() {
        var el = document.getElementById('shipping-request-card');
        if (el) el.scrollIntoView({ behavior: 'smooth' });
        var pf = document.getElementById('ship-pickup');
        var df = document.getElementById('ship-delivery');
        if (pf) pf.value = _scResult.pickup;
        if (df) df.value = _scResult.delivery;
      }, 300);
    }

    function scSaveEstimate() {
      if (!_scResult) return;
      var saved = JSON.parse(localStorage.getItem('sc_estimates') || '[]');
      saved.unshift({ date: new Date().toISOString(), pickup: _scResult.pickup, delivery: _scResult.delivery, distMi: _scResult.distMi, low: _scResult.low, high: _scResult.high });
      if (saved.length > 20) saved = saved.slice(0, 20);
      localStorage.setItem('sc_estimates', JSON.stringify(saved));
      var msg = document.getElementById('sc-save-msg');
      if (msg) { msg.style.display = 'block'; setTimeout(function(){ msg.style.display = 'none'; }, 3000); }
    }

    // ====== STATE ======
    let currentMember = null;

    // ====== INIT ======
    window.addEventListener('DOMContentLoaded', async () => {
      const urlParams = new URLSearchParams(window.location.search);
      const token = urlParams.get('token');
      const section = urlParams.get('section');

      if (token) {
        await autoLogin(token);
        window.history.replaceState({}, '', '/byrddawgsos' + (section ? `?section=${section}` : ''));
        if (section && currentMember) navigateSection(section);
        return;
      }

      const savedEmail = localStorage.getItem('byrddawgsos_email');
      if (savedEmail) {
        await login(savedEmail, true);
        if (section && currentMember) navigateSection(section);
      }
    });

    // ====== AUTH ======
    async function handleLogin() {
      const email = document.getElementById('login-email').value.trim();
      if (!email) return;
      await login(email, false);
    }

    async function autoLogin(token) {
      try {
        const res = await fetch(`/api/validate-login-token?token=${encodeURIComponent(token)}`);
        const data = await res.json();
        if (!data.success) { showLoginError('Invalid login token. Please log in manually.'); return; }
        currentMember = data.member;
        localStorage.setItem('byrddawgsos_email', data.member.email);
        showDashboard();
      } catch (e) {
        showLoginError('Auto-login failed. Please log in manually.');
      }
    }

    async function login(email, silent = false) {
      const btn = document.getElementById('login-btn');
      const errorEl = document.getElementById('login-error');

      if (!silent) {
        btn.disabled = true;
        btn.innerHTML = '<div class="spinner"></div> Checking...';
        errorEl.style.display = 'none';
      }

      try {
        const res = await fetch(`/api/member-status?email=${encodeURIComponent(email)}`);
        const data = await res.json();

        if (!data.success || !data.found) {
          if (!silent) showLoginError('No account found. Please apply on FlipLane first.');
          return;
        }

        if (data.member.status !== 'active' && data.member.status !== 'approved') {
          if (!silent) {
            showLoginError('Your membership is not active yet. Please complete payment.');
          }
          return;
        }

        currentMember = data.member;
        localStorage.setItem('byrddawgsos_email', email);
        showDashboard();

      } catch (e) {
        if (!silent) showLoginError('Connection error. Please try again.');
      }

      if (!silent) {
        btn.disabled = false;
        btn.textContent = 'Access Hub';
      }
    }

    function showLoginError(msg) {
      const el = document.getElementById('login-error');
      el.textContent = msg;
      el.style.display = 'block';
    }

    function handleLogout() {
      localStorage.removeItem('byrddawgsos_email');
      currentMember = null;
      document.getElementById('login-screen').style.display = 'flex';
      document.getElementById('dashboard-screen').style.display = 'none';
      document.getElementById('login-email').value = '';
      document.getElementById('login-error').style.display = 'none';
    }

    document.getElementById('login-email').addEventListener('keydown', e => {
      if (e.key === 'Enter') handleLogin();
    });

    // ====== DASHBOARD ======
    function showDashboard() {
      document.getElementById('login-screen').style.display = 'none';
      document.getElementById('dashboard-screen').style.display = 'block';

      const firstName = (currentMember.name || '').split(' ')[0] || 'Member';
      document.getElementById('member-first-name').textContent = firstName;
      document.getElementById('topbar-user-name').textContent = currentMember.name || currentMember.email;

      updateCertBadge(currentMember.is_certified);
      loadStats();
      prefillServiceForms();

      // Show AI floating button
      document.getElementById('ai-fab-btn').style.display = 'flex';

      // Show message bell and load unread count
      document.getElementById('msg-bell-btn').style.display = 'inline-flex';
      loadMemberUnreadCount();

      // Lock down UI for members not yet certified
      if (!currentMember.is_certified) {
        lockUncertifiedUI();
      }
    }

    function lockUncertifiedUI() {
      // Show lock banner at top of hub view
      const hubView = document.getElementById('hub-view');
      let lockBanner = document.getElementById('cert-lock-banner');
      if (!lockBanner) {
        lockBanner = document.createElement('div');
        lockBanner.id = 'cert-lock-banner';
        lockBanner.className = 'cert-lock-banner';
        lockBanner.innerHTML = '<span>🔒</span> <span>Complete your certification to unlock all ByrddawgsOS tools</span>';
        hubView.insertBefore(lockBanner, hubView.firstChild);
      }

      // Hide action buttons (Submit a Deal, Find Inventory, Contact Us)
      const actionBtns = document.querySelector('.action-buttons');
      if (actionBtns) actionBtns.style.display = 'none';

      // Hide the "Your Operations" category cards that are NOT training or support
      const restrictedSections = ['credentials', 'deals', 'game', 'messages'];
      restrictedSections.forEach(section => {
        const card = document.querySelector(`.cat-card[data-section="${section}"]`);
        if (card) card.style.display = 'none';
      });

      // Navigate directly to training section since that's all they can access
      navigateSection('training');
    }

    function updateCertBadge(isCertified) {
      const badge = document.getElementById('cert-badge');
      const trainingBadge = document.getElementById('training-cert-badge');
      const trainingText = document.getElementById('training-cert-text');

      if (isCertified) {
        badge.className = 'cert-badge certified';
        badge.innerHTML = '<span>✅</span> <span>Certified Member</span>';
        if (trainingBadge) {
          trainingBadge.className = 'cert-badge certified';
          trainingBadge.innerHTML = '<span>✅</span> <span>Certified Member</span>';
        }
        if (trainingText) trainingText.textContent = 'You\'re certified! You have full dealer access.';
      } else {
        badge.className = 'cert-badge in-training';
        badge.innerHTML = '<span>📚</span> <span>In Training</span>';
        if (trainingBadge) {
          trainingBadge.className = 'cert-badge in-training';
          trainingBadge.innerHTML = '<span>📚</span> <span>In Training</span>';
        }
        if (trainingText) trainingText.textContent = 'Complete the certification to unlock full dealer access.';
      }
    }

    async function loadStats() {
      // Load deal stats for co-op member
      try {
        const res = await fetch(`/api/affiliateos/dashboard?email=${encodeURIComponent(currentMember.email)}`);
        const data = await res.json();
        if (data.success) {
          document.getElementById('stat-deals').textContent = (data.deals.total || 0).toString();
        } else {
          document.getElementById('stat-deals').textContent = '0';
        }
      } catch (e) {
        document.getElementById('stat-deals').textContent = '0';
      }

      // Certification status
      const certEl = document.getElementById('stat-cert-status');
      if (certEl) certEl.textContent = currentMember.is_certified ? 'Certified' : 'In Training';

      // Member since
      const sinceEl = document.getElementById('stat-member-since');
      if (sinceEl) {
        const joinDate = currentMember.approved_at || currentMember.applied_at;
        if (joinDate) {
          sinceEl.textContent = new Date(joinDate).toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
        } else {
          sinceEl.textContent = 'Active';
        }
      }
    }

    // ====== NAVIGATION ======
    let currentSection = null;

    function navigateSection(section) {
      // Block uncertified members from all sections except 'training'
      if (!currentMember || (!currentMember.is_certified && section !== 'training')) {
        showToast('Complete your certification to unlock all ByrddawgsOS tools', true);
        return;
      }

      document.getElementById('hub-view').classList.add('hidden');
      document.querySelectorAll('.section-view').forEach(v => v.classList.remove('active'));

      const target = document.getElementById(`section-${section}`);
      if (target) {
        target.classList.add('active');
        window.scrollTo(0, 0);
      }

      currentSection = section;
      loadSectionData(section);
    }

    function navigateHub() {
      document.getElementById('hub-view').classList.remove('hidden');
      document.querySelectorAll('.section-view').forEach(v => v.classList.remove('active'));
      currentSection = null;
      window.scrollTo(0, 0);
    }

    function loadSectionData(section) {
      if (section === 'credentials') loadCredentials();
      if (section === 'deals') { loadDeals(); loadAcvHistory(); loadRoiHistory(); initLoanEstimator(); }
      if (section === 'support') {
        loadTickets();
        // Pre-fill contact form with member info
        if (currentMember) {
          const nameInput = document.getElementById('call-name');
          const emailInput = document.getElementById('call-email');
          if (nameInput && !nameInput.value) nameInput.value = currentMember.name || '';
          if (emailInput && !emailInput.value) emailInput.value = currentMember.email || '';
        }
      }
      if (section === 'training') {
        // Update cert badge in training section
        updateCertBadge(currentMember.is_certified);
      }
      if (section === 'messages') { loadMemberMessages(); loadMemberAnnouncements(); }
      if (section === 'vehicle-intel') { viInit(); }
    }

    // ====== INLINE TOS ACCEPTANCE (in ByrddawgsOS) ======
    function buildInlineTermsFlow() {
      const memberName = (currentMember && currentMember.name) || '';
      const today = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
      return `
        <div id="inline-tos-flow" style="background:var(--bg-card);border:1px solid var(--border);border-radius:12px;padding:24px;margin-top:8px;width:100%;">
          <h3 style="font-family:'Space Grotesk',sans-serif;font-size:1.05rem;font-weight:700;color:var(--text-primary);margin-bottom:12px;">
            ✍️ Sign Terms of Service
          </h3>
          <div id="tos-summary-box" style="background:var(--bg-secondary);border:1px solid var(--border);border-radius:8px;padding:16px;margin-bottom:16px;max-height:200px;overflow-y:auto;font-size:13px;color:var(--text-secondary);line-height:1.7;">
            <p style="color:var(--text-dim);text-align:center;">Loading terms…</p>
          </div>
          <a href="/terms" target="_blank" style="display:inline-block;font-size:12px;color:var(--green);margin-bottom:16px;text-decoration:underline;">Read full Terms of Service →</a>
          <div style="background:var(--bg-secondary);border:1px solid var(--border);border-radius:8px;padding:14px;margin-bottom:14px;">
            <label style="cursor:pointer;display:flex;align-items:flex-start;gap:10px;font-size:13px;color:var(--text-secondary);line-height:1.6;">
              <input type="checkbox" id="tos-agree-checkbox" style="accent-color:var(--green);width:18px;height:18px;margin-top:2px;cursor:pointer;flex-shrink:0;">
              <span>I have read, understood, and agree to be bound by the <strong style="color:var(--text-primary);">FlipLane Terms of Service &amp; Membership Agreement</strong>. I acknowledge this constitutes a legally binding electronic signature.</span>
            </label>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px;">
            <div>
              <label style="display:block;font-size:11px;font-weight:700;color:var(--text-dim);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:6px;">Full Legal Name *</label>
              <input type="text" id="tos-signer-name" value="${escapeHtml(memberName)}" placeholder="Type your full name" style="width:100%;padding:10px 12px;background:var(--bg-secondary);border:1px solid var(--border);border-radius:8px;color:var(--text-primary);font-size:14px;outline:none;" />
            </div>
            <div>
              <label style="display:block;font-size:11px;font-weight:700;color:var(--text-dim);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:6px;">Date</label>
              <input type="text" id="tos-sign-date" value="${escapeHtml(today)}" readonly style="width:100%;padding:10px 12px;background:var(--bg-secondary);border:1px solid var(--border);border-radius:8px;color:var(--text-dim);font-size:14px;outline:none;" />
            </div>
          </div>
          <button type="button" id="tos-submit-btn" disabled style="width:100%;padding:14px 24px;background:var(--green);color:#000;border:none;border-radius:10px;font-family:'Space Grotesk',sans-serif;font-size:1rem;font-weight:700;cursor:pointer;opacity:0.5;transition:opacity 0.2s,transform 0.1s;">
            ✍️ I Accept — Sign Terms of Service
          </button>
          <div id="tos-submit-status" style="margin-top:10px;font-size:13px;text-align:center;"></div>
        </div>
      `;
    }

    function wireInlineTermsForm() {
      // Load terms summary into the box
      loadTermsSummary();
      // Wire checkbox → enable/disable submit
      const cb = document.getElementById('tos-agree-checkbox');
      const nameInput = document.getElementById('tos-signer-name');
      const btn = document.getElementById('tos-submit-btn');
      if (!cb || !btn) return;

      function updateTosBtn() {
        const checked = cb.checked;
        const hasName = (nameInput && nameInput.value.trim().length >= 2);
        btn.disabled = !(checked && hasName);
        btn.style.opacity = btn.disabled ? '0.5' : '1';
        btn.style.cursor = btn.disabled ? 'not-allowed' : 'pointer';
      }

      cb.addEventListener('change', updateTosBtn);
      if (nameInput) nameInput.addEventListener('input', updateTosBtn);

      btn.addEventListener('click', async function() {
        if (btn.disabled) return;
        btn.disabled = true;
        btn.textContent = 'Recording signature…';
        btn.style.opacity = '0.7';
        const statusEl = document.getElementById('tos-submit-status');
        statusEl.textContent = '';
        statusEl.style.color = '';

        try {
          const resp = await fetch('/api/member/sign-terms', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              email: currentMember.email,
              type: 'member',
              termsVersion: window._inlineTermsVersion || 1
            })
          });
          const result = await resp.json();

          if (result.success) {
            statusEl.textContent = '✅ Terms accepted! Signature recorded.';
            statusEl.style.color = 'var(--green)';
            btn.textContent = '✅ Signed!';
            btn.style.background = 'rgba(0,230,118,0.15)';
            btn.style.color = 'var(--green)';
            showToast('Terms signed! Loading your credentials…');
            // Reload credentials after short delay (gate should now pass)
            setTimeout(function() { loadCredentials(); }, 1500);
          } else {
            statusEl.textContent = result.message || 'Failed to record signature. Please try again.';
            statusEl.style.color = '#ef4444';
            btn.disabled = false;
            btn.textContent = '✍️ I Accept — Sign Terms of Service';
            btn.style.opacity = '1';
          }
        } catch (err) {
          statusEl.textContent = 'Network error. Please check your connection and try again.';
          statusEl.style.color = '#ef4444';
          btn.disabled = false;
          btn.textContent = '✍️ I Accept — Sign Terms of Service';
          btn.style.opacity = '1';
        }
      });
    }

    async function loadTermsSummary() {
      const box = document.getElementById('tos-summary-box');
      if (!box) return;
      try {
        const resp = await fetch('/api/terms');
        const data = await resp.json();
        if (data.success && data.terms && data.terms.content) {
          window._inlineTermsVersion = data.terms.version;
          // Show a condensed version of the terms in the box
          box.innerHTML = data.terms.content;
        } else {
          box.innerHTML = '<p style="color:var(--text-dim);">Terms content unavailable. <a href="/terms" target="_blank" style="color:var(--green);">View full terms here.</a></p>';
        }
      } catch (e) {
        box.innerHTML = '<p style="color:var(--text-dim);">Could not load terms. <a href="/terms" target="_blank" style="color:var(--green);">View full terms here.</a></p>';
      }
    }

    // ====== CREDENTIALS ======
    async function loadCredentials() {
      const container = document.getElementById('auction-creds-list');
      try {
        const res = await fetch(`/api/byrddawgsos/auctions?email=${encodeURIComponent(currentMember.email)}`);
        const data = await res.json();

        if (!data.success) {
          const msg = data.message || 'Unable to load credentials.';
          const parts = [];

          if (data.requiresIdUpload && data.idUploadUrl) {
            parts.push(`<a href="${escapeHtml(data.idUploadUrl)}" class="btn btn-primary btn-sm" style="margin-bottom:14px;">Upload ID →</a>`);
          }

          if (data.requiresTerms) {
            // Inline TOS acceptance flow — no navigation away from ByrddawgsOS
            parts.push(buildInlineTermsFlow());
          }

          if (parts.length > 0) {
            container.innerHTML = `<div class="empty-state" style="text-align:left;">
              <div style="text-align:center;margin-bottom:16px;">
                <span class="empty-icon">🔒</span>
                <div style="color:var(--text-secondary);font-size:14px;">${escapeHtml(msg)}</div>
              </div>
              ${parts.join('')}
            </div>`;
            // Wire up inline TOS form events after inserting HTML
            wireInlineTermsForm();
          } else {
            container.innerHTML = `<div class="empty-state"><span class="empty-icon">🔒</span>${escapeHtml(msg)}</div>`;
          }
          return;
        }

        if (data.auctions && data.auctions.length > 0) {
          container.innerHTML = data.auctions.map(a => `
            <div class="cred-item">
              <div class="cred-header">
                <div class="cred-name">${escapeHtml(a.auction_name)}</div>
                ${a.website_url ? `<a href="${escapeHtml(a.website_url)}" target="_blank" class="btn btn-ghost btn-sm">Visit →</a>` : ''}
              </div>
              ${a.username ? `
                <div class="cred-fields">
                  <div class="cred-field">
                    <label>Username</label>
                    <div class="cred-value">
                      <span>${escapeHtml(a.username)}</span>
                      <button class="copy-mini" onclick="copyText('${escapeHtml(a.username)}', this)" title="Copy">📋</button>
                    </div>
                  </div>
                  <div class="cred-field">
                    <label>Password</label>
                    <div class="cred-value">
                      <span>${a.password ? escapeHtml(a.password) : '(pending — admin will add)'}</span>
                      ${a.password ? `<button class="copy-mini" onclick="copyText('${escapeHtml(a.password)}', this)" title="Copy">📋</button>` : ''}
                    </div>
                  </div>
                </div>
              ` : `<p style="font-size: 13px; color: var(--text-dim); margin-bottom: 8px;">Credentials pending — admin will add login details for this platform.</p>`}
              ${a.notes ? `<p style="font-size: 12px; color: var(--text-dim);">${escapeHtml(a.notes)}</p>` : ''}
            </div>
          `).join('');
        } else {
          container.innerHTML = `
            <div class="empty-state">
              <span class="empty-icon">🔑</span>
              No auction credentials added yet. Admin will populate platform logins here.
            </div>`;
        }
      } catch (e) {
        container.innerHTML = `<div class="empty-state"><span class="empty-icon">⚠️</span>Failed to load credentials. Please try again.</div>`;
      }
    }

    // ====== DEALS ======
    async function loadDeals() {
      const listContainer = document.getElementById('deal-list-container');
      try {
        const res = await fetch(`/api/affiliateos/deals?email=${encodeURIComponent(currentMember.email)}`);
        const data = await res.json();

        if (data.success) {
          renderDealList(data.deals);
        } else {
          listContainer.innerHTML = `<div class="empty-state"><span class="empty-icon">🚗</span>No deals yet. Submit your first deal above!</div>`;
        }
      } catch (e) {
        listContainer.innerHTML = `<div class="empty-state"><span class="empty-icon">⚠️</span>Failed to load deals.</div>`;
      }
    }

    function renderDealList(deals) {
      const container = document.getElementById('deal-list-container');

      if (!deals || deals.length === 0) {
        container.innerHTML = `<div class="empty-state"><span class="empty-icon">🚗</span>No deals submitted yet. Find a vehicle and submit it above!</div>`;
        return;
      }

      // Update pipeline counts
      const counts = { submitted: 0, reviewed: 0, closed: 0, commission_paid: 0 };
      deals.forEach(d => { if (counts[d.status] !== undefined) counts[d.status]++; });
      document.getElementById('pipe-submitted').textContent = counts.submitted;
      document.getElementById('pipe-reviewed').textContent = counts.reviewed;
      document.getElementById('pipe-closed').textContent = counts.closed;
      document.getElementById('pipe-paid').textContent = counts.commission_paid;

      container.innerHTML = deals.map(d => `
        <div class="deal-row">
          <div class="deal-dot ${d.status}"></div>
          <div class="deal-info">
            <div class="deal-title">${escapeHtml(d.vehicle_description)}</div>
            <div class="deal-meta">
              ${d.vin ? `<span>VIN: ${escapeHtml(d.vin)}</span>` : ''}
              ${d.source_name ? `<span>${escapeHtml(d.source_name)}</span>` : ''}
              <span>${timeAgo(d.created_at)}</span>
            </div>
          </div>
          ${d.price ? `<div class="deal-price">$${parseFloat(d.price).toLocaleString()}</div>` : ''}
          <span class="status-pill ${d.status}">${d.status.replace('_', ' ')}</span>
        </div>
      `).join('');
    }

    async function submitDeal(e) {
      e.preventDefault();
      const btn = document.getElementById('deal-submit-btn');
      btn.disabled = true;
      btn.innerHTML = '<div class="spinner"></div> Submitting...';

      try {
        const res = await fetch('/api/affiliateos/deals', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            email: currentMember.email,
            vin: document.getElementById('deal-vin').value.trim(),
            vehicle_description: document.getElementById('deal-description').value.trim(),
            price: document.getElementById('deal-price').value || null,
            source_url: document.getElementById('deal-source-url').value.trim(),
            source_name: document.getElementById('deal-source-name').value.trim(),
            notes: document.getElementById('deal-notes').value.trim()
          })
        });

        const data = await res.json();
        if (data.success) {
          showToast('Deal submitted! 🚗');
          document.getElementById('deal-form').reset();
          loadDeals();
          loadStats();
        } else {
          showToast(data.message || 'Failed to submit deal', true);
        }
      } catch (e) {
        showToast('Connection error. Try again.', true);
      }

      btn.disabled = false;
      btn.textContent = 'Submit Deal';
    }

    // ====== TICKETS ======
    async function loadTickets() {
      const container = document.getElementById('ticket-list');
      try {
        const res = await fetch(`/api/byrddawgsos/tickets?email=${encodeURIComponent(currentMember.email)}`);
        const data = await res.json();

        if (data.success && data.tickets.length > 0) {
          container.innerHTML = data.tickets.map(t => `
            <div class="ticket-item">
              <div class="ticket-subject">${escapeHtml(t.subject)}</div>
              <div class="ticket-body">${escapeHtml(t.message)}</div>
              <div class="ticket-meta">
                <span class="status-pill ${t.status === 'open' ? 'reviewed' : 'closed'}">${t.status}</span>
                <span>${timeAgo(t.created_at)}</span>
              </div>
            </div>
          `).join('');
        } else {
          container.innerHTML = `<div class="empty-state"><span class="empty-icon">🎫</span>No tickets yet.</div>`;
        }
      } catch (e) {
        container.innerHTML = `<div class="empty-state"><span class="empty-icon">⚠️</span>Failed to load tickets.</div>`;
      }
    }

    async function submitTicket(e) {
      e.preventDefault();
      const btn = document.getElementById('ticket-submit-btn');
      const alertEl = document.getElementById('ticket-alert');
      btn.disabled = true;
      btn.innerHTML = '<div class="spinner"></div> Sending...';
      alertEl.style.display = 'none';

      try {
        const res = await fetch('/api/byrddawgsos/tickets', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            email: currentMember.email,
            subject: document.getElementById('ticket-subject').value.trim(),
            message: document.getElementById('ticket-message').value.trim()
          })
        });

        const data = await res.json();
        if (data.success) {
          alertEl.style.cssText = 'display:block; background: var(--green-glow); border: 1px solid var(--green-border); color: var(--green); padding: 10px 14px; border-radius: 6px; font-size: 14px; margin-bottom: 16px;';
          alertEl.textContent = 'Ticket submitted! We\'ll respond soon.';
          document.getElementById('ticket-form').reset();
          loadTickets();
        } else {
          alertEl.style.cssText = 'display:block; background: var(--red-glow); border: 1px solid rgba(255,82,82,0.3); color: var(--red); padding: 10px 14px; border-radius: 6px; font-size: 14px; margin-bottom: 16px;';
          alertEl.textContent = data.message || 'Failed to submit ticket.';
        }
      } catch (e) {
        alertEl.style.cssText = 'display:block; background: var(--red-glow); border: 1px solid rgba(255,82,82,0.3); color: var(--red); padding: 10px 14px; border-radius: 6px; font-size: 14px; margin-bottom: 16px;';
        alertEl.textContent = 'Connection error. Please try again.';
      }

      btn.disabled = false;
      btn.textContent = 'Send Ticket';
    }

    // ====== AUDIENCE LANE SELECTOR ======
    function selectLane(lane) {
      // Update button states
      ['buyer', 'coop'].forEach(l => {
        const btn = document.getElementById(`lane-${l}`);
        if (btn) {
          if (l === lane) {
            btn.style.borderColor = 'var(--green)';
            btn.style.background = 'rgba(0, 230, 118, 0.07)';
          } else {
            btn.style.borderColor = 'var(--border-light)';
            btn.style.background = 'var(--bg-input)';
          }
        }
      });

      // Show the lane content area
      const contentEl = document.getElementById('lane-content');
      if (contentEl) contentEl.style.display = 'block';

      // Hide all panels, show selected
      document.querySelectorAll('.lane-panel').forEach(p => p.style.display = 'none');
      const targetPanel = document.getElementById(`lane-content-${lane}`);
      if (targetPanel) targetPanel.style.display = 'block';
    }

    // ====== PROFIT CALCULATOR ======
    function calcProfit() {
      const buy       = parseFloat(document.getElementById('calc-buy').value) || 0;
      const repairs   = parseFloat(document.getElementById('calc-repairs').value) || 0;
      const transport = parseFloat(document.getElementById('calc-transport').value) || 0;
      const titleReg  = parseFloat(document.getElementById('calc-title-reg').value) || 0;
      const holding   = parseFloat(document.getElementById('calc-holding').value) || 0;
      const fee       = 250; // FlipLane fee — always included
      const sell      = parseFloat(document.getElementById('calc-sell').value) || 0;

      // Need at least one meaningful number to show results
      if (!buy && !repairs && !sell && !transport && !titleReg && !holding) {
        document.getElementById('calc-result').style.display = 'none';
        return;
      }

      const totalCost   = buy + repairs + transport + titleReg + holding + fee;
      const profit      = sell - totalCost;
      const margin      = sell > 0 ? (profit / sell * 100) : 0;          // margin = profit / sell price
      const roi         = totalCost > 0 ? (profit / totalCost * 100) : 0; // ROI = profit / total cost

      const profitEl  = document.getElementById('calc-profit');
      const marginEl  = document.getElementById('calc-margin');
      const roiEl     = document.getElementById('calc-roi');
      const verdictEl = document.getElementById('calc-verdict');

      const fmtMoney = v => (v >= 0 ? '+$' : '-$') + Math.abs(Math.round(v)).toLocaleString();
      const fmtPct   = v => (v >= 0 ? '+' : '') + v.toFixed(1) + '%';

      document.getElementById('calc-cost').textContent = '$' + Math.round(totalCost).toLocaleString();
      profitEl.textContent = fmtMoney(profit);
      marginEl.textContent = fmtPct(margin);
      roiEl.textContent    = fmtPct(roi);

      const profitColor = profit > 0 ? 'var(--green)' : profit < 0 ? 'var(--red)' : 'var(--text-secondary)';
      profitEl.style.color = profitColor;
      marginEl.style.color = profitColor;
      roiEl.style.color    = profitColor;

      // ROI-based verdict (real-time)
      if (roi > 25) {
        verdictEl.style.cssText = 'background:var(--green-glow);border:1px solid var(--green-border);color:var(--green);margin-top:16px;text-align:center;font-size:14px;font-weight:600;padding:10px;border-radius:var(--radius-xs);';
        verdictEl.textContent = '🟢 Strong Deal — ROI > 25% — Submit it!';
      } else if (roi >= 10) {
        verdictEl.style.cssText = 'background:var(--yellow-glow);border:1px solid var(--yellow-border);color:var(--yellow);margin-top:16px;text-align:center;font-size:14px;font-weight:600;padding:10px;border-radius:var(--radius-xs);';
        verdictEl.textContent = '🟡 Profitable — ROI ' + roi.toFixed(1) + '% — worth considering';
      } else if (roi >= 0) {
        verdictEl.style.cssText = 'background:rgba(255,140,0,0.1);border:1px solid rgba(255,140,0,0.4);color:#ff8c00;margin-top:16px;text-align:center;font-size:14px;font-weight:600;padding:10px;border-radius:var(--radius-xs);';
        verdictEl.textContent = '🟠 Near Break-Even — ROI ' + roi.toFixed(1) + '% — thin margin';
      } else {
        verdictEl.style.cssText = 'background:var(--red-glow);border:1px solid rgba(255,82,82,0.3);color:var(--red);margin-top:16px;text-align:center;font-size:14px;font-weight:600;padding:10px;border-radius:var(--radius-xs);';
        verdictEl.textContent = '🔴 Losing Money — ROI ' + roi.toFixed(1) + '% — pass on this one';
      }

      document.getElementById('calc-result').style.display = 'block';

      // Reset save button if inputs change after saving
      var saveBtn = document.getElementById('profit-save-btn');
      if (saveBtn && saveBtn.textContent === '✅ Saved!') {
        saveBtn.textContent = '💾 Save Calculation';
        saveBtn.disabled = false;
      }
    }

    function clearCalc() {
      ['calc-buy','calc-repairs','calc-transport','calc-title-reg','calc-holding','calc-sell','calc-desc'].forEach(function(id) {
        var el = document.getElementById(id);
        if (el) el.value = '';
      });
      document.getElementById('calc-result').style.display = 'none';
      var al = document.getElementById('profit-save-alert');
      if (al) { al.style.display = 'none'; al.textContent = ''; }
    }

    async function saveProfitCalc() {
      if (!currentMember || !currentMember.email) {
        var al = document.getElementById('profit-save-alert');
        if (al) { al.style.display='block'; al.style.color='var(--red)'; al.textContent='Log in to save calculations.'; }
        return;
      }
      var btn = document.getElementById('profit-save-btn');
      var al  = document.getElementById('profit-save-alert');
      if (btn) { btn.disabled = true; btn.textContent = 'Saving…'; }

      var buy       = parseFloat(document.getElementById('calc-buy').value) || 0;
      var repairs   = parseFloat(document.getElementById('calc-repairs').value) || 0;
      var transport = parseFloat(document.getElementById('calc-transport').value) || 0;
      var titleReg  = parseFloat(document.getElementById('calc-title-reg').value) || 0;
      var holding   = parseFloat(document.getElementById('calc-holding').value) || 0;
      var fee       = 250;
      var sell      = parseFloat(document.getElementById('calc-sell').value) || 0;
      var desc      = (document.getElementById('calc-desc').value || '').trim();

      var totalCost = buy + repairs + transport + titleReg + holding + fee;
      var profit    = sell - totalCost;
      var margin    = sell > 0 ? (profit / sell * 100) : 0;
      var roi       = totalCost > 0 ? (profit / totalCost * 100) : 0;

      var verdict = roi > 25 ? 'Strong Deal' : roi >= 10 ? 'Profitable' : roi >= 0 ? 'Near Break-Even' : 'Losing Money';

      try {
        var res = await fetch('/api/profit-calculator', {
          method: 'POST',
          headers: {'Content-Type':'application/json'},
          body: JSON.stringify({
            member_email: currentMember.email,
            vehicle_description: desc || null,
            buy_price: buy, repairs, transport, title_reg_fees: titleReg,
            holding_costs: holding, fliplane_fee: fee, sell_price: sell,
            total_cost: totalCost, net_profit: profit,
            profit_margin_pct: parseFloat(margin.toFixed(4)),
            roi_pct: parseFloat(roi.toFixed(4)),
            verdict
          })
        });
        var d = await res.json();
        if (d.success) {
          if (btn) { btn.disabled = false; btn.textContent = '✅ Saved!'; }
          if (al) { al.style.display='block'; al.style.color='var(--green)'; al.textContent='Saved to your history.'; }
          _profitHistoryCache = null; // invalidate cache so next open reloads
          setTimeout(function(){ if(btn && btn.textContent==='✅ Saved!'){btn.textContent='💾 Save Calculation';} }, 3000);
        } else {
          throw new Error(d.message || 'Save failed');
        }
      } catch(err) {
        if (btn) { btn.disabled = false; btn.textContent = '💾 Save Calculation'; }
        if (al) { al.style.display='block'; al.style.color='var(--red)'; al.textContent='Save failed — try again.'; }
      }
    }

    var _profitHistoryCache = null;
    var _profitHistoryVisible = false;

    async function toggleProfitHistory() {
      var panel = document.getElementById('profit-history-panel');
      if (!panel) return;
      _profitHistoryVisible = !_profitHistoryVisible;
      panel.style.display = _profitHistoryVisible ? 'block' : 'none';
      var btn = document.getElementById('profit-history-btn');
      if (btn) btn.textContent = _profitHistoryVisible ? '📋 Hide History' : '📋 History';
      if (_profitHistoryVisible) await loadProfitHistory();
    }

    async function loadProfitHistory() {
      if (!currentMember || !currentMember.email) {
        var list = document.getElementById('profit-history-list');
        if (list) list.innerHTML = '<span style="color:var(--text-secondary)">Log in to see history.</span>';
        return;
      }
      var list = document.getElementById('profit-history-list');
      if (_profitHistoryCache) { renderProfitHistory(_profitHistoryCache); return; }
      if (list) list.textContent = 'Loading…';
      try {
        var res = await fetch('/api/profit-calculator/history?email=' + encodeURIComponent(currentMember.email));
        var d = await res.json();
        if (d.success) {
          _profitHistoryCache = d.history;
          renderProfitHistory(d.history);
        } else {
          if (list) list.innerHTML = '<span style="color:var(--red)">Failed to load history.</span>';
        }
      } catch(err) {
        if (list) list.innerHTML = '<span style="color:var(--red)">Network error.</span>';
      }
    }

    function renderProfitHistory(history) {
      var list = document.getElementById('profit-history-list');
      if (!list) return;
      if (!history || history.length === 0) {
        list.innerHTML = '<span style="color:var(--text-secondary)">No saved calculations yet.</span>';
        return;
      }
      var verdictColor = function(v) {
        if (!v) return 'var(--text-secondary)';
        if (v === 'Strong Deal') return 'var(--green)';
        if (v === 'Profitable') return '#e6c200';
        if (v === 'Near Break-Even') return '#ff8c00';
        return 'var(--red)';
      };
      var verdictEmoji = function(v) {
        if (!v) return '—';
        if (v === 'Strong Deal') return '🟢';
        if (v === 'Profitable') return '🟡';
        if (v === 'Near Break-Even') return '🟠';
        return '🔴';
      };
      var fmtDate = function(d) {
        var dt = new Date(d);
        return dt.toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});
      };
      var fmtMoney = function(v) {
        var n = parseFloat(v) || 0;
        return (n >= 0 ? '+$' : '-$') + Math.abs(Math.round(n)).toLocaleString();
      };
      var html = '<div style="display:flex;flex-direction:column;gap:10px;">';
      history.forEach(function(h) {
        html += '<div style="padding:12px 14px;background:var(--bg-card);border-radius:var(--radius-xs);border:1px solid var(--border);cursor:pointer;" onclick="loadProfitCalcFromHistory(' + h.id + ')">';
        html += '<div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;flex-wrap:wrap;">';
        html += '<div>';
        html += '<div style="font-size:13px;font-weight:600;color:var(--text-primary);">' + (h.vehicle_description ? h.vehicle_description : 'Deal — ' + fmtDate(h.created_at)) + '</div>';
        html += '<div style="font-size:11px;color:var(--text-secondary);margin-top:2px;">' + fmtDate(h.created_at) + ' · Buy $' + Math.round(parseFloat(h.buy_price)||0).toLocaleString() + ' · Sell $' + Math.round(parseFloat(h.sell_price)||0).toLocaleString() + '</div>';
        html += '</div>';
        html += '<div style="text-align:right;white-space:nowrap;">';
        html += '<div style="font-size:13px;font-weight:700;color:' + verdictColor(h.verdict) + ';">' + verdictEmoji(h.verdict) + ' ' + (h.verdict || '—') + '</div>';
        html += '<div style="font-size:12px;color:var(--text-secondary);">Net ' + fmtMoney(h.net_profit) + ' · ROI ' + (parseFloat(h.roi_pct)||0).toFixed(1) + '%</div>';
        html += '</div>';
        html += '</div></div>';
      });
      html += '</div><div style="font-size:11px;color:var(--text-secondary);margin-top:8px;text-align:right;">Tap a row to reload values.</div>';
      list.innerHTML = html;
      // Store for lookup
      list._historyData = history;
    }

    function loadProfitCalcFromHistory(id) {
      var list = document.getElementById('profit-history-list');
      var history = list && list._historyData;
      if (!history) return;
      var h = history.find(function(x){ return x.id === id; });
      if (!h) return;
      document.getElementById('calc-desc').value       = h.vehicle_description || '';
      document.getElementById('calc-buy').value        = parseFloat(h.buy_price) || '';
      document.getElementById('calc-repairs').value    = parseFloat(h.repairs) || '';
      document.getElementById('calc-transport').value  = parseFloat(h.transport) || '';
      document.getElementById('calc-title-reg').value  = parseFloat(h.title_reg_fees) || '';
      document.getElementById('calc-holding').value    = parseFloat(h.holding_costs) || '';
      document.getElementById('calc-sell').value       = parseFloat(h.sell_price) || '';
      calcProfit();
      // Scroll to calc card
      var card = document.getElementById('profit-calc-card');
      if (card) card.scrollIntoView({behavior:'smooth',block:'start'});
    }

    function scrollToMarketValue() {
      const card = document.getElementById('market-value-card');
      if (card) card.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    // ====== MARKET VALUE COMPARATOR ======
    let _lastMarketMid = null;

    function fillProfitCalcFromMarket() {
      if (!_lastMarketMid) return;
      document.getElementById('calc-sell').value = _lastMarketMid;
      calcProfit();
      // Scroll to profit calc
      const calcCard = document.querySelector('#section-deals .content-card');
      if (calcCard) calcCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function prefillMarketValueFromSourcing() {
      const make = document.getElementById('src-make').value.trim();
      const model = document.getElementById('src-model').value.trim();
      const yearMin = document.getElementById('src-year-min').value;
      const yearMax = document.getElementById('src-year-max').value;
      const mileage = document.getElementById('src-mileage').value;
      if (make) document.getElementById('mv-make').value = make;
      if (model) document.getElementById('mv-model').value = model;
      if (yearMin || yearMax) document.getElementById('mv-year').value = yearMax || yearMin;
      if (mileage) document.getElementById('mv-mileage').value = mileage;
      scrollToMarketValue();
    }

    async function submitMarketValue(e) {
      e.preventDefault();
      const btn = document.getElementById('mv-submit-btn');
      const alertEl = document.getElementById('mv-alert');
      alertEl.style.display = 'none';
      btn.disabled = true;
      btn.innerHTML = '<div class="spinner" style="width:14px;height:14px;border-width:2px;display:inline-block;margin-right:6px;vertical-align:middle;"></div> Looking up...';

      const vin = document.getElementById('mv-vin').value.trim();
      const year = document.getElementById('mv-year').value.trim();
      const make = document.getElementById('mv-make').value.trim();
      const model = document.getElementById('mv-model').value.trim();
      const trim = document.getElementById('mv-trim').value.trim();
      const mileage = document.getElementById('mv-mileage').value;
      const condition = document.getElementById('mv-condition').value;
      const targetPrice = document.getElementById('mv-target-price').value;

      if (!vin && (!year || !make || !model)) {
        alertEl.style.cssText = 'display:block; background: rgba(239,68,68,0.08); border: 1px solid rgba(239,68,68,0.3); color: #ef4444; padding: 10px 14px; border-radius: 6px; font-size: 14px; margin-bottom: 16px;';
        alertEl.textContent = 'Please enter a VIN or fill in Year, Make, and Model.';
        btn.disabled = false;
        btn.textContent = 'Get Market Value';
        return;
      }

      try {
        const body = { vin: vin || null, year: year || null, make: make || null, model: model || null, trim: trim || null };
        if (mileage) body.mileage = parseInt(mileage);
        if (condition) body.condition = condition;
        if (targetPrice) body.target_price = parseInt(targetPrice);
        if (currentMember?.email) body.member_email = currentMember.email;

        const res = await fetch('/api/market-value', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body)
        });
        const data = await res.json();

        if (!data.success) {
          alertEl.style.cssText = 'display:block; background: rgba(239,68,68,0.08); border: 1px solid rgba(239,68,68,0.3); color: #ef4444; padding: 10px 14px; border-radius: 6px; font-size: 14px; margin-bottom: 16px;';
          alertEl.textContent = data.message || 'Lookup failed. Please try again.';
          btn.disabled = false;
          btn.textContent = 'Get Market Value';
          return;
        }

        // Populate vehicle header
        const v = data.vehicle;
        const vehicleTitle = [v.year, v.make, v.model, v.trim].filter(Boolean).join(' ');
        document.getElementById('mv-vehicle-title').textContent = vehicleTitle + (v.vin ? ` — VIN: ${v.vin}` : '');

        const sourceLabels = { nhtsa: 'NHTSA VIN Decode', marketcheck: 'Marketcheck Listings', fred: 'FRED Loan Rate', estimated: 'Model Estimate' };
        document.getElementById('mv-data-sources').textContent = 'Data: ' + (data.data_sources || []).map(s => sourceLabels[s] || s).join(' · ');

        // Prices
        const fmt = (n) => n ? '$' + n.toLocaleString() : '—';
        document.getElementById('mv-price-low').textContent = fmt(data.market.estimated_low);
        document.getElementById('mv-price-mid').textContent = fmt(data.market.estimated_mid);
        document.getElementById('mv-price-high').textContent = fmt(data.market.estimated_high);
        _lastMarketMid = data.market.estimated_mid;

        // Listings
        if (data.market.similar_listings_count && !data.market.limited_data) {
          document.getElementById('mv-listings-count').textContent = data.market.similar_listings_count.toLocaleString() + ' active listings';
          document.getElementById('mv-listings-avg').textContent = data.market.similar_avg_price ? `Avg asking: ${fmt(data.market.similar_avg_price)}` : '';
          document.getElementById('mv-listings-box').style.display = 'block';
        } else {
          document.getElementById('mv-listings-box').style.display = 'none';
        }

        // Rate
        if (data.financing.avg_loan_rate) {
          document.getElementById('mv-loan-rate').textContent = data.financing.avg_loan_rate + '%';
          document.getElementById('mv-rate-box').style.display = 'block';
        } else {
          document.getElementById('mv-rate-box').style.display = 'none';
        }

        // Make stats-row visible if at least one box shows
        document.getElementById('mv-stats-row').style.display = 'grid';

        // Deal score
        if (data.deal_score) {
          const dsBox = document.getElementById('mv-deal-score-box');
          dsBox.style.cssText = `display:block; padding:16px; border-radius:var(--radius-sm); text-align:center; margin-bottom:16px; border: 2px solid ${data.deal_score.color}20; background: ${data.deal_score.color}10;`;
          document.getElementById('mv-deal-score-label').style.color = data.deal_score.color;
          document.getElementById('mv-deal-score-label').textContent = data.deal_score.label;
          const pct = data.deal_score.market_mid > 0 ? ((data.deal_score.target_price / data.deal_score.market_mid - 1) * 100).toFixed(1) : null;
          document.getElementById('mv-deal-score-detail').textContent = pct !== null
            ? `Your target ${fmt(data.deal_score.target_price)} is ${Math.abs(pct)}% ${parseFloat(pct) < 0 ? 'below' : 'above'} market mid (${fmt(data.deal_score.market_mid)})`
            : `Market mid: ${fmt(data.deal_score.market_mid)}`;
        } else {
          document.getElementById('mv-deal-score-box').style.display = 'none';
        }

        // Limited data notice
        document.getElementById('mv-limited-notice').style.display = data.market.limited_data ? 'block' : 'none';

        // Show results
        document.getElementById('mv-results').style.display = 'block';

        // Auto-fill year/make/model if they came from VIN decode
        if (v.year && !document.getElementById('mv-year').value) document.getElementById('mv-year').value = v.year;
        if (v.make && !document.getElementById('mv-make').value) document.getElementById('mv-make').value = v.make;
        if (v.model && !document.getElementById('mv-model').value) document.getElementById('mv-model').value = v.model;

      } catch (err) {
        alertEl.style.cssText = 'display:block; background: rgba(239,68,68,0.08); border: 1px solid rgba(239,68,68,0.3); color: #ef4444; padding: 10px 14px; border-radius: 6px; font-size: 14px; margin-bottom: 16px;';
        alertEl.textContent = 'Network error. Please try again.';
      } finally {
        btn.disabled = false;
        btn.textContent = 'Get Market Value';
      }
    }

    function clearMarketValue() {
      document.getElementById('mv-vin').value = '';
      document.getElementById('mv-year').value = '';
      document.getElementById('mv-make').value = '';
      document.getElementById('mv-model').value = '';
      document.getElementById('mv-trim').value = '';
      document.getElementById('mv-mileage').value = '';
      document.getElementById('mv-condition').value = '';
      document.getElementById('mv-target-price').value = '';
      document.getElementById('mv-results').style.display = 'none';
      document.getElementById('mv-alert').style.display = 'none';
      _lastMarketMid = null;
    }

    // ====== ACV CALCULATOR ======
    let _lastAcvMid = null;
    let _acvVinDecodeTimer = null;

    function acvAutoDecodeVin() {
      const vin = document.getElementById('acv-vin').value.trim();
      if (vin.length !== 17) return;
      clearTimeout(_acvVinDecodeTimer);
      _acvVinDecodeTimer = setTimeout(async () => {
        try {
          const res = await fetch(`https://vpic.nhtsa.dot.gov/api/vehicles/decodevin/${vin}?format=json`, { signal: AbortSignal.timeout(8000) });
          const data = await res.json();
          if (!data.Results) return;
          const get = (v) => { const r = data.Results.find(x => x.Variable === v && x.Value && x.Value !== 'Not Applicable' && x.Value !== '0'); return r ? r.Value : null; };
          const year = get('Model Year'), make = get('Make'), model = get('Model'), trim = get('Trim');
          if (year) document.getElementById('acv-year').value = year;
          if (make) document.getElementById('acv-make').value = make;
          if (model) document.getElementById('acv-model').value = model;
          if (trim) document.getElementById('acv-trim').value = trim;
        } catch (e) { /* silent fail */ }
      }, 800);
    }

    function scrollToLoanCalc() {
      var card = document.getElementById('loan-calc-card');
      if (card) card.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function acvToLoanCalc() {
      if (typeof _lastAcvMid === 'undefined' || !_lastAcvMid) { showToast('Run the ACV Calculator first', true); return; }
      var priceEl = document.getElementById('loan-a-price');
      if (priceEl) { priceEl.value = Math.round(_lastAcvMid); calcLoan('a'); }
      scrollToLoanCalc();
    }

        function scrollToAcvCalc() {
      const card = document.getElementById('acv-calculator-card');
      if (card) card.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function acvToProfitCalc() {
      if (!_lastAcvMid) return;
      document.getElementById('calc-sell').value = _lastAcvMid;
      calcProfit();
      const calcCard = document.querySelector('#section-deals .content-card');
      if (calcCard) calcCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function acvToSourcing() {
      const make = document.getElementById('acv-make').value.trim();
      const model = document.getElementById('acv-model').value.trim();
      const year = document.getElementById('acv-year').value.trim();
      if (make) document.getElementById('src-make').value = make;
      if (model) document.getElementById('src-model').value = model;
      if (year) { document.getElementById('src-year-min').value = year; document.getElementById('src-year-max').value = year; }
      // scroll to sourcing form
      const srcForm = document.querySelector('#section-deals #sourcing-form') || document.querySelector('[id="src-make"]');
      if (srcForm) srcForm.closest('.content-card')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function clearAcv() {
      ['acv-vin','acv-year','acv-make','acv-model','acv-trim','acv-mileage','acv-zip','acv-purchase-price'].forEach(id => {
        const el = document.getElementById(id); if (el) el.value = '';
      });
      document.getElementById('acv-condition').value = '';
      document.getElementById('acv-title').value = 'clean';
      document.getElementById('acv-accident').value = 'none';
      document.getElementById('acv-owners').value = '1';
      document.getElementById('acv-results').style.display = 'none';
      document.getElementById('acv-alert').style.display = 'none';
      _lastAcvMid = null;
    }

    async function submitAcv(e) {
      e.preventDefault();
      const btn = document.getElementById('acv-submit-btn');
      const alertEl = document.getElementById('acv-alert');
      alertEl.style.display = 'none';
      btn.disabled = true;
      btn.innerHTML = '<div class="spinner" style="width:14px;height:14px;border-width:2px;display:inline-block;margin-right:6px;vertical-align:middle;"></div> Calculating ACV...';

      const vin = document.getElementById('acv-vin').value.trim();
      const year = document.getElementById('acv-year').value.trim();
      const make = document.getElementById('acv-make').value.trim();
      const model = document.getElementById('acv-model').value.trim();
      const trim = document.getElementById('acv-trim').value.trim();
      const mileage = document.getElementById('acv-mileage').value;
      const condition = document.getElementById('acv-condition').value;
      const titleStatus = document.getElementById('acv-title').value;
      const accidentHistory = document.getElementById('acv-accident').value;
      const numOwners = document.getElementById('acv-owners').value;
      const zipCode = document.getElementById('acv-zip').value.trim();
      const purchasePrice = document.getElementById('acv-purchase-price').value;

      if (!vin && (!year || !make || !model)) {
        alertEl.style.cssText = 'display:block; background: rgba(239,68,68,0.08); border: 1px solid rgba(239,68,68,0.3); color: #ef4444; padding: 10px 14px; border-radius: 6px; font-size: 14px; margin-bottom: 16px;';
        alertEl.textContent = 'Please enter a VIN or fill in Year, Make, and Model.';
        btn.disabled = false; btn.innerHTML = '🏷️ Calculate ACV'; return;
      }
      if (!condition) {
        alertEl.style.cssText = 'display:block; background: rgba(239,68,68,0.08); border: 1px solid rgba(239,68,68,0.3); color: #ef4444; padding: 10px 14px; border-radius: 6px; font-size: 14px; margin-bottom: 16px;';
        alertEl.textContent = 'Please select a condition.';
        btn.disabled = false; btn.innerHTML = '🏷️ Calculate ACV'; return;
      }

      try {
        const body = {};
        if (vin) body.vin = vin;
        if (year) body.year = year;
        if (make) body.make = make;
        if (model) body.model = model;
        if (trim) body.trim = trim;
        if (mileage) body.mileage = parseInt(mileage);
        body.condition = condition;
        body.title_status = titleStatus;
        body.accident_history = accidentHistory;
        body.num_owners = parseInt(numOwners) || 1;
        if (zipCode) body.zip_code = zipCode;
        if (purchasePrice) body.purchase_price = parseInt(purchasePrice);
        if (currentMember?.email) body.member_email = currentMember.email;

        const res = await fetch('/api/acv', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body)
        });
        const data = await res.json();

        if (!data.success) {
          alertEl.style.cssText = 'display:block; background: rgba(239,68,68,0.08); border: 1px solid rgba(239,68,68,0.3); color: #ef4444; padding: 10px 14px; border-radius: 6px; font-size: 14px; margin-bottom: 16px;';
          alertEl.textContent = data.message || 'Calculation failed. Please try again.';
          btn.disabled = false; btn.innerHTML = '🏷️ Calculate ACV'; return;
        }

        const fmt = (n) => n != null ? '$' + Number(n).toLocaleString() : '—';
        const fmtAdj = (n) => {
          if (n == null) return '—';
          const v = Number(n);
          return (v >= 0 ? '+' : '') + '$' + Math.abs(v).toLocaleString();
        };

        // Vehicle header
        const v = data.vehicle;
        const vtitle = [v.year, v.make, v.model, v.trim].filter(Boolean).join(' ');
        document.getElementById('acv-vehicle-title').textContent = vtitle + (v.vin ? ` · ${v.vin}` : '');

        // Confidence badge
        const confBadge = document.getElementById('acv-confidence-badge');
        const confColors = { high: { bg: 'rgba(0,230,118,0.12)', border: 'rgba(0,230,118,0.3)', color: '#00e676' }, medium: { bg: 'rgba(255,215,64,0.12)', border: 'rgba(255,215,64,0.3)', color: '#ffd740' }, low: { bg: 'rgba(255,82,82,0.12)', border: 'rgba(255,82,82,0.3)', color: '#ff5252' } };
        const cc = confColors[data.confidence.score] || confColors.medium;
        confBadge.style.cssText = `background: ${cc.bg}; border: 1px solid ${cc.border}; color: ${cc.color}; font-size: 11px; font-weight: 700; padding: 3px 10px; border-radius: 10px;`;
        confBadge.textContent = data.confidence.label;

        // ACV Range
        document.getElementById('acv-price-low').textContent = fmt(data.acv.low);
        document.getElementById('acv-price-mid').textContent = fmt(data.acv.mid);
        document.getElementById('acv-price-high').textContent = fmt(data.acv.high);
        _lastAcvMid = data.acv.mid;

        // Auto-fill fields from VIN decode
        if (v.year && !document.getElementById('acv-year').value) document.getElementById('acv-year').value = v.year;
        if (v.make && !document.getElementById('acv-make').value) document.getElementById('acv-make').value = v.make;
        if (v.model && !document.getElementById('acv-model').value) document.getElementById('acv-model').value = v.model;

        // Depreciation Breakdown
        const dep = data.depreciation || {};
        const breakdownRows = [
          { label: 'Base MSRP (est. new price)', value: fmt(dep.base_msrp), note: '' },
          { label: `Age depreciation (${dep.age_years || 0} yrs)`, value: fmtAdj(dep.age_depreciation), note: '', isAdj: true },
          { label: 'Value after age', value: fmt(dep.value_after_age), note: '', isSub: true },
          { label: `Mileage adjustment (${dep.mileage_deviation > 0 ? '+' : ''}${(dep.mileage_deviation || 0).toLocaleString()} mi from avg)`, value: fmtAdj(dep.mileage_adjustment), note: '', isAdj: true },
          { label: `Condition (${dep.condition || condition})`, value: fmtAdj(dep.condition_adjustment), note: '', isAdj: true },
          { label: `Title (${dep.title_status || titleStatus})`, value: dep.title_adjustment !== 0 ? fmtAdj(dep.title_adjustment) : '—', note: '', isAdj: dep.title_adjustment !== 0 },
          { label: `Accident history (${dep.accident_history || accidentHistory})`, value: dep.accident_adjustment !== 0 ? fmtAdj(dep.accident_adjustment) : '—', note: '', isAdj: dep.accident_adjustment !== 0 },
          { label: `Owners (${dep.num_owners || 1})`, value: dep.owners_adjustment !== 0 ? fmtAdj(dep.owners_adjustment) : '—', note: '', isAdj: dep.owners_adjustment !== 0 },
          { label: '✅ ACV Mid (True Market Value)', value: fmt(data.acv.mid), note: '', isFinal: true }
        ];

        const rowsHtml = breakdownRows.map((r, i) => {
          const isAlt = i % 2 === 1;
          const bg = r.isFinal ? 'background: rgba(0,230,118,0.08); border-top: 1px solid rgba(0,230,118,0.2);' : (isAlt ? 'background: rgba(255,255,255,0.02);' : '');
          const valColor = r.isFinal ? 'color: var(--green); font-weight: 800; font-size: 16px;' : (r.isAdj && dep[r.key] < 0 ? 'color: var(--red);' : r.isAdj ? 'color: var(--green);' : '');
          return `<div style="display: flex; justify-content: space-between; align-items: center; padding: 9px 14px; font-size: 13px; ${bg}">
            <span style="color: var(--text-secondary);">${r.label}</span>
            <span style="font-weight: 600; ${valColor}">${r.value}</span>
          </div>`;
        }).join('');
        document.getElementById('acv-breakdown-rows').innerHTML = rowsHtml;

        // Market Context
        const hasMarket = data.market.avg_listing || data.market.avg_loan_rate;
        if (hasMarket) {
          const marketGridHtml = [
            data.market.avg_listing ? `<div style="padding: 12px 14px; background: var(--bg-input); border: 1px solid var(--border-light); border-radius: var(--radius-sm);"><div style="font-size: 10px; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px;">Avg Asking (Marketcheck)</div><div style="font-size: 18px; font-weight: 700;">${fmt(data.market.avg_listing)}</div>${data.market.listing_count ? `<div style="font-size: 11px; color: var(--text-secondary); margin-top: 2px;">${data.market.listing_count.toLocaleString()} active listings</div>` : ''}</div>` : '',
            data.market.avg_loan_rate ? `<div style="padding: 12px 14px; background: var(--bg-input); border: 1px solid var(--border-light); border-radius: var(--radius-sm);"><div style="font-size: 10px; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px;">Avg Auto Loan Rate</div><div style="font-size: 18px; font-weight: 700;">${data.market.avg_loan_rate}%</div><div style="font-size: 11px; color: var(--text-secondary); margin-top: 2px;">60-mo national avg (FRED)</div></div>` : ''
          ].filter(Boolean).join('');
          document.getElementById('acv-market-grid').innerHTML = marketGridHtml;
          document.getElementById('acv-market-section').style.display = 'block';
        } else {
          document.getElementById('acv-market-section').style.display = 'none';
        }

        // Flip Opportunity
        const flipEl = document.getElementById('acv-flip-section');
        if (data.flip_opportunity) {
          const fo = data.flip_opportunity;
          const verdictConfig = {
            strong: { bg: 'rgba(0,230,118,0.10)', border: 'rgba(0,230,118,0.3)', color: '#00e676', label: '🔥 Strong flip opportunity' },
            decent: { bg: 'rgba(255,215,64,0.10)', border: 'rgba(255,215,64,0.3)', color: '#ffd740', label: '✅ Decent spread' },
            thin: { bg: 'rgba(255,152,0,0.10)', border: 'rgba(255,152,0,0.3)', color: '#ff9800', label: '⚠️ Thin margin — proceed carefully' },
            underwater: { bg: 'rgba(255,82,82,0.10)', border: 'rgba(255,82,82,0.3)', color: '#ff5252', label: '❌ Buying above ACV — overpaying' }
          };
          const vc = verdictConfig[fo.verdict] || verdictConfig.thin;
          flipEl.innerHTML = `
            <div style="font-size: 11px; font-weight: 700; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 0.8px; margin-bottom: 10px;">💰 Flip Opportunity</div>
            <div style="padding: 16px; background: ${vc.bg}; border: 1px solid ${vc.border}; border-radius: var(--radius-sm);">
              <div style="font-size: 16px; font-weight: 800; color: ${vc.color}; margin-bottom: 10px;">${vc.label}</div>
              <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; text-align: center;">
                <div><div style="font-size: 10px; color: var(--text-secondary); text-transform: uppercase; margin-bottom: 3px;">Buy Price</div><div style="font-size: 18px; font-weight: 700;">${fmt(fo.buy_price)}</div></div>
                <div><div style="font-size: 10px; color: var(--text-secondary); text-transform: uppercase; margin-bottom: 3px;">ACV Mid</div><div style="font-size: 18px; font-weight: 700; color: var(--green);">${fmt(fo.acv_mid)}</div></div>
                <div><div style="font-size: 10px; color: var(--text-secondary); text-transform: uppercase; margin-bottom: 3px;">Spread</div><div style="font-size: 18px; font-weight: 700; color: ${fo.spread >= 0 ? 'var(--green)' : 'var(--red)'};">${fmtAdj(fo.spread)}</div>${fo.spread_pct != null ? `<div style="font-size: 10px; color: var(--text-secondary); margin-top: 2px;">${fo.spread_pct}% margin</div>` : ''}</div>
              </div>
            </div>`;
          flipEl.style.display = 'block';
        } else {
          flipEl.style.display = 'none';
        }

        // Data sources
        const srcLabels = { nhtsa: 'NHTSA VIN Decode', marketcheck: 'Marketcheck', fred: 'FRED Rate', depreciation_model: 'Depreciation Model', cache: 'Cached' };
        document.getElementById('acv-sources').textContent = 'Data sources: ' + (data.data_sources || []).map(s => srcLabels[s] || s).join(' · ');

        document.getElementById('acv-results').style.display = 'block';
        document.getElementById('acv-results').scrollIntoView({ behavior: 'smooth', block: 'nearest' });

        // Load history
        loadAcvHistory();
      } catch (err) {
        alertEl.style.cssText = 'display:block; background: rgba(239,68,68,0.08); border: 1px solid rgba(239,68,68,0.3); color: #ef4444; padding: 10px 14px; border-radius: 6px; font-size: 14px; margin-bottom: 16px;';
        alertEl.textContent = 'Network error. Please try again.';
      } finally {
        btn.disabled = false;
        btn.innerHTML = '🏷️ Calculate ACV';
      }
    }

    async function loadAcvHistory() {
      if (!currentMember?.email) return;
      try {
        const res = await fetch(`/api/acv/history?email=${encodeURIComponent(currentMember.email)}`);
        const data = await res.json();
        if (!data.success || !data.history || data.history.length === 0) return;
        const fmt = (n) => n != null ? '$' + Number(n).toLocaleString() : '—';
        const condLabels = { excellent: '⭐ Excellent', good: '✅ Good', fair: '⚠️ Fair', poor: '🔴 Poor', salvage: '💀 Salvage' };
        const rows = data.history.slice(0, 8).map(h => `
          <div style="display: flex; justify-content: space-between; align-items: center; padding: 10px 14px; border-bottom: 1px solid var(--border); font-size: 13px; flex-wrap: wrap; gap: 6px;">
            <div>
              <span style="font-weight: 600;">${[h.year, h.make, h.model, h.trim].filter(Boolean).join(' ')}</span>
              ${h.vin ? `<span style="font-size: 11px; color: var(--text-secondary); margin-left: 6px;">${h.vin}</span>` : ''}
              <div style="font-size: 11px; color: var(--text-secondary); margin-top: 2px;">${h.mileage ? h.mileage.toLocaleString() + ' mi' : ''} ${condLabels[h.condition] || h.condition || ''} ${h.title_status && h.title_status !== 'clean' ? '· ' + h.title_status + ' title' : ''}</div>
            </div>
            <div style="text-align: right;">
              <div style="font-weight: 700; color: var(--green);">${fmt(h.acv_mid)}</div>
              <div style="font-size: 11px; color: var(--text-secondary);">${fmt(h.acv_low)} – ${fmt(h.acv_high)}</div>
            </div>
          </div>`).join('');
        document.getElementById('acv-history-list').innerHTML = `<div style="background: var(--bg-input); border: 1px solid var(--border-light); border-radius: var(--radius-sm); overflow: hidden;">${rows}</div>`;
        document.getElementById('acv-history-section').style.display = 'block';
      } catch (e) { /* silent */ }
    }

    // ====== FAQ ACCORDION ======
    function toggleFaq(el) {
      el.classList.toggle('open');
    }

    // ====== CONTACT FORM ======
    async function submitCallRequest(e) {
      e.preventDefault();
      const btn = document.getElementById('call-submit-btn');
      const alertEl = document.getElementById('call-alert');
      btn.disabled = true;
      btn.innerHTML = '<div class="spinner" style="width:14px;height:14px;border-width:2px;display:inline-block;margin-right:6px;"></div> Sending...';
      alertEl.style.display = 'none';

      const name = document.getElementById('call-name').value.trim();
      const email = document.getElementById('call-email').value.trim();
      const message = document.getElementById('call-message').value.trim();

      try {
        const res = await fetch('/api/byrddawgsos/book-call', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name, email, message })
        });

        const data = await res.json();
        if (data.success) {
          alertEl.style.cssText = 'display:block; background: var(--green-glow); border: 1px solid var(--green-border); color: var(--green); padding: 10px 14px; border-radius: 6px; font-size: 14px; margin-bottom: 16px;';
          alertEl.textContent = '✅ Message sent! We\'ll get back to you within 24 hours.';
          document.getElementById('call-form').reset();
          // re-prefill name and email from logged-in member
          if (currentMember) {
            if (currentMember.name) document.getElementById('call-name').value = currentMember.name;
            if (currentMember.email) document.getElementById('call-email').value = currentMember.email;
          }
        } else {
          alertEl.style.cssText = 'display:block; background: var(--red-glow); border: 1px solid rgba(255,82,82,0.3); color: var(--red); padding: 10px 14px; border-radius: 6px; font-size: 14px; margin-bottom: 16px;';
          alertEl.textContent = data.message || 'Failed to send message.';
        }
      } catch (err) {
        alertEl.style.cssText = 'display:block; background: var(--red-glow); border: 1px solid rgba(255,82,82,0.3); color: var(--red); padding: 10px 14px; border-radius: 6px; font-size: 14px; margin-bottom: 16px;';
        alertEl.textContent = 'Connection error. Please try again.';
      }

      btn.disabled = false;
      btn.textContent = 'Send Message';
    }

    // ====== SERVICE REQUEST HELPER ======
    function showFormAlert(alertId, success, msg) {
      const el = document.getElementById(alertId);
      el.style.cssText = success
        ? 'display:block; background: var(--green-glow); border: 1px solid var(--green-border); color: var(--green); padding: 10px 14px; border-radius: 6px; font-size: 14px; margin-bottom: 16px;'
        : 'display:block; background: var(--red-glow); border: 1px solid rgba(255,82,82,0.3); color: var(--red); padding: 10px 14px; border-radius: 6px; font-size: 14px; margin-bottom: 16px;';
      el.textContent = msg;
    }

    async function postServiceRequest(endpoint, payload, btnId, alertId, successMsg, resetId) {
      const btn = document.getElementById(btnId);
      const origText = btn.textContent;
      btn.disabled = true;
      btn.innerHTML = '<div class="spinner" style="width:14px;height:14px;border-width:2px;display:inline-block;margin-right:6px;"></div> Submitting...';
      document.getElementById(alertId).style.display = 'none';
      try {
        const res = await fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
        const data = await res.json();
        if (data.success) {
          showFormAlert(alertId, true, successMsg);
          if (resetId) { document.getElementById(resetId).reset(); prefillServiceForms(); }
        } else {
          showFormAlert(alertId, false, data.message || 'Failed to submit. Please try again.');
        }
      } catch (e) {
        showFormAlert(alertId, false, 'Connection error. Please try again.');
      }
      btn.disabled = false;
      btn.textContent = origText;
    }

    function prefillServiceForms() {
      if (!currentMember) return;
      const fills = [
        ['ff-name','ff-email'],['ship-name','ship-email'],['title-name','title-email'],
        ['fin-name','fin-email'],['src-name','src-email'],['mkt-name','mkt-email']
      ];
      fills.forEach(([n, e]) => {
        const nel = document.getElementById(n); const eel = document.getElementById(e);
        if (nel && !nel.value && currentMember.name) nel.value = currentMember.name;
        if (eel && !eel.value && currentMember.email) eel.value = currentMember.email;
      });
      // Customer inquiry partner field
      const inqPartner = document.getElementById('inq-partner');
      if (inqPartner && !inqPartner.value && currentMember.name) inqPartner.value = currentMember.name;
    }

    // ====== FIX & FLIP ======
    async function submitFixFlip(e) {
      e.preventDefault();
      const year = document.getElementById('ff-year').value.trim();
      const make = document.getElementById('ff-make').value.trim();
      const model = document.getElementById('ff-model').value.trim();
      await postServiceRequest('/api/byrddawgsos/service-request', {
        request_type: 'fix_flip',
        form_data: {
          year, make, model,
          vin: document.getElementById('ff-vin').value.trim(),
          condition: document.getElementById('ff-condition').value,
          scope: document.getElementById('ff-scope').value.trim(),
          budget: document.getElementById('ff-budget').value,
          timeline: document.getElementById('ff-timeline').value,
          name: document.getElementById('ff-name').value.trim(),
          email: document.getElementById('ff-email').value.trim()
        }
      }, 'fixflip-submit-btn', 'fixflip-alert',
      "✅ Request submitted! We'll review and get back within 24 hours.", 'fixflip-form');
    }

    // ====== SHIPPING ======
    async function submitShipping(e) {
      e.preventDefault();
      const make = document.getElementById('ship-make').value.trim();
      const model = document.getElementById('ship-model').value.trim();
      const pickup = document.getElementById('ship-pickup').value.trim();
      const delivery = document.getElementById('ship-delivery').value.trim();
      await postServiceRequest('/api/byrddawgsos/service-request', {
        request_type: 'shipping',
        form_data: {
          year: document.getElementById('ship-year').value.trim(),
          make, model,
          vin: document.getElementById('ship-vin').value.trim(),
          pickup_location: pickup,
          delivery_location: delivery,
          condition: document.getElementById('ship-condition').value,
          preferred_date: document.getElementById('ship-date').value,
          instructions: document.getElementById('ship-instructions').value.trim(),
          name: document.getElementById('ship-name').value.trim(),
          email: document.getElementById('ship-email').value.trim()
        }
      }, 'shipping-submit-btn', 'shipping-alert',
      "✅ Shipping quote request received! We'll send options within 24–48 hours.", 'shipping-form');
    }

    // ====== TITLE & REG ======
    async function submitTitleReg(e) {
      e.preventDefault();
      const services = [];
      ['transfer','registration','temp','duplicate','lien','outofstate'].forEach(s => {
        if (document.getElementById(`title-svc-${s}`)?.checked) services.push(s);
      });
      const docs = [];
      ['bos','title','id','poa'].forEach(d => {
        if (document.getElementById(`title-doc-${d}`)?.checked) docs.push(d);
      });
      if (services.length === 0) {
        showFormAlert('title-alert', false, 'Please select at least one service needed.');
        return;
      }
      await postServiceRequest('/api/byrddawgsos/service-request', {
        request_type: 'title_reg',
        form_data: {
          year: document.getElementById('title-year').value.trim(),
          make: document.getElementById('title-make').value.trim(),
          model: document.getElementById('title-model').value.trim(),
          vin: document.getElementById('title-vin').value.trim(),
          state: document.getElementById('title-state').value.trim().toUpperCase(),
          services_needed: services,
          documents_in_hand: docs,
          notes: document.getElementById('title-notes').value.trim(),
          name: document.getElementById('title-name').value.trim(),
          email: document.getElementById('title-email').value.trim()
        }
      }, 'title-submit-btn', 'title-alert',
      "✅ Title/registration request submitted! We'll follow up within 24 hours.", 'title-form');
    }

    // ====== FINANCING ======
    async function submitFinancing(e) {
      e.preventDefault();
      await postServiceRequest('/api/byrddawgsos/service-request', {
        request_type: 'financing',
        form_data: {
          vehicle: document.getElementById('fin-vehicle').value.trim(),
          vehicle_price: document.getElementById('fin-price').value,
          down_payment: document.getElementById('fin-down').value,
          monthly_payment: document.getElementById('fin-monthly').value.trim(),
          credit_score: document.getElementById('fin-credit').value,
          employment_status: document.getElementById('fin-employment').value,
          annual_income: document.getElementById('fin-income').value,
          name: document.getElementById('fin-name').value.trim(),
          email: document.getElementById('fin-email').value.trim(),
          phone: document.getElementById('fin-phone').value.trim()
        }
      }, 'financing-submit-btn', 'financing-alert',
      "✅ Financing request submitted! We'll reach out with options soon.", 'financing-form');
    }

    // ====== SOURCING ======
    async function submitSourcing(e) {
      e.preventDefault();
      await postServiceRequest('/api/byrddawgsos/service-request', {
        request_type: 'sourcing',
        form_data: {
          year_min: document.getElementById('src-year-min').value,
          year_max: document.getElementById('src-year-max').value,
          make: document.getElementById('src-make').value.trim(),
          model: document.getElementById('src-model').value.trim(),
          body_type: document.getElementById('src-body').value,
          max_mileage: document.getElementById('src-mileage').value,
          max_budget: document.getElementById('src-budget').value,
          condition: document.getElementById('src-condition').value,
          features: document.getElementById('src-features').value.trim(),
          intended_use: document.getElementById('src-use').value,
          urgency: document.getElementById('src-urgency').value,
          name: document.getElementById('src-name').value.trim(),
          email: document.getElementById('src-email').value.trim()
        }
      }, 'sourcing-submit-btn', 'sourcing-alert',
      "✅ Sourcing request submitted! We'll start searching and follow up soon.", 'sourcing-form');
    }

    // ====== CUSTOMER INQUIRY ======
    async function submitCustomerInquiry(e) {
      e.preventDefault();
      await postServiceRequest('/api/byrddawgsos/service-request', {
        request_type: 'customer_inquiry',
        form_data: {
          customer_name: document.getElementById('inq-cust-name').value.trim(),
          customer_email: document.getElementById('inq-cust-email').value.trim(),
          customer_phone: document.getElementById('inq-cust-phone').value.trim(),
          vehicle_interest: document.getElementById('inq-vehicle').value.trim(),
          source: document.getElementById('inq-source').value,
          message: document.getElementById('inq-message').value.trim(),
          partner: document.getElementById('inq-partner').value.trim(),
          member_email: currentMember?.email || ''
        }
      }, 'inquiry-submit-btn', 'inquiry-alert',
      "✅ Customer inquiry submitted! We'll follow up with the customer promptly.", 'inquiry-form');
    }

    // ====== MARKETING SUPPORT ======
    async function submitMarketingSupport(e) {
      e.preventDefault();
      await postServiceRequest('/api/byrddawgsos/service-request', {
        request_type: 'marketing_support',
        form_data: {
          content_type: document.getElementById('mkt-type').value,
          description: document.getElementById('mkt-description').value.trim(),
          deadline: document.getElementById('mkt-deadline').value,
          name: document.getElementById('mkt-name').value.trim(),
          email: document.getElementById('mkt-email').value.trim()
        }
      }, 'marketing-submit-btn', 'marketing-alert',
      "✅ Marketing request submitted! We'll get started on your content.", 'marketing-form');
    }

    // ====== IFRAME MODAL ======
    function openIframe(id, url, title) {
      const modal = document.getElementById('iframe-modal');
      const iframe = document.getElementById('iframe-embed');
      const titleEl = document.getElementById('iframe-title');
      const fallback = document.getElementById('iframe-fallback');
      const fallbackLink = document.getElementById('iframe-fallback-link');

      titleEl.textContent = title;
      iframe.src = url;
      fallbackLink.href = url;
      fallback.classList.remove('active');
      iframe.style.display = 'block';
      modal.classList.add('active');

      let loaded = false;
      iframe.onload = () => {
        loaded = true;
        try {
          const doc = iframe.contentDocument || iframe.contentWindow.document;
          if (!doc || doc.body === null) showIframeFallback();
        } catch (e) { showIframeFallback(); }
      };

      setTimeout(() => { if (!loaded) showIframeFallback(); }, 5000);

      document.addEventListener('keydown', handleEscape);
    }

    function showIframeFallback() {
      document.getElementById('iframe-embed').style.display = 'none';
      document.getElementById('iframe-fallback').classList.add('active');
    }

    function closeIframe() {
      document.getElementById('iframe-modal').classList.remove('active');
      document.getElementById('iframe-embed').src = '';
      document.removeEventListener('keydown', handleEscape);
    }

    function handleEscape(e) { if (e.key === 'Escape') closeIframe(); }

    document.getElementById('iframe-modal').addEventListener('click', e => {
      if (e.target.id === 'iframe-modal') closeIframe();
    });

    // ====== UTILITIES ======
    function showToast(msg, isError = false) {
      const toast = document.getElementById('toast');
      toast.textContent = msg;
      toast.className = 'toast show' + (isError ? ' error' : '');
      setTimeout(() => { toast.className = 'toast'; }, 3000);
    }

    function copyText(text, btn) {
      navigator.clipboard.writeText(text).then(() => {
        const orig = btn.textContent;
        btn.textContent = '✓';
        showToast('Copied!');
        setTimeout(() => { btn.textContent = orig; }, 1500);
      });
    }

    function formatMoney(amount) {
      return '$' + parseFloat(amount || 0).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
    }

    function escapeHtml(str) {
      if (!str) return '';
      return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function timeAgo(dateStr) {
      const now = new Date();
      const date = new Date(dateStr);
      const s = Math.floor((now - date) / 1000);
      if (s < 60) return 'just now';
      if (s < 3600) return `${Math.floor(s / 60)}m ago`;
      if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
      if (s < 604800) return `${Math.floor(s / 86400)}d ago`;
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    }

    // ====== AI CHAT (SuperFlip — Co-op Member Context) ======
    let memberAiMsgs = [];
    let memberAiPanelOpen = false;
    let memberAiInitialized = false;

    // Detect if a message likely needs live web search
    const MEMBER_SEARCH_PATTERNS = [
      /\b(price|prices|pricing|market|worth|value|how much)\b/i,
      /\b(recall|recalls|nhtsa|safety)\b/i,
      /\b(news|trend|trends|trending|what.?s happening)\b/i,
      /\b(current|today|now|latest|recent|2026|2025)\b/i,
      /what.?s? (the |a )?(market|going rate|average price)\b/i,
      /\b(best cars? to flip|hot cars?|what.?s selling)\b/i,
      /\bused car market\b/i
    ];
    function memberNeedsSearch(text) {
      return MEMBER_SEARCH_PATTERNS.some(p => p.test(text));
    }

    function toggleAiPanel() {
      memberAiPanelOpen = !memberAiPanelOpen;
      const panel = document.getElementById('ai-chat-panel');
      if (memberAiPanelOpen) {
        panel.classList.add('open');
        if (!memberAiInitialized) {
          memberAiInitialized = true;
        }
        setTimeout(() => document.getElementById('ai-panel-input').focus(), 300);
      } else {
        panel.classList.remove('open');
      }
    }

    function sendMemberAiStarter(text) {
      document.getElementById('ai-panel-starters').style.display = 'none';
      document.getElementById('ai-panel-input').value = text;
      sendMemberAiMessage();
    }

    function handleMemberAiKeydown(e) {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMemberAiMessage();
      }
    }

    function autoResizeMemberInput(el) {
      el.style.height = 'auto';
      el.style.height = Math.min(el.scrollHeight, 80) + 'px';
    }

    async function sendMemberAiMessage() {
      const input = document.getElementById('ai-panel-input');
      const text = input.value.trim();
      if (!text) return;

      const sendBtn = document.getElementById('ai-panel-send');
      sendBtn.disabled = true;
      input.value = '';
      input.style.height = 'auto';

      document.getElementById('ai-panel-starters').style.display = 'none';

      appendMemberMsg('user', text);
      memberAiMsgs.push({ role: 'user', content: text });

      const typingId = showMemberTyping(memberNeedsSearch(text));

      const context = {};
      if (currentMember?.name) context.name = currentMember.name.split(' ')[0];
      if (currentMember?.certification_level) context.cert_level = currentMember.certification_level;

      try {
        const res = await fetch('/api/ai/member-chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ messages: memberAiMsgs, context })
        });
        const data = await res.json();
        removeMemberTyping(typingId);
        const reply = data.success ? data.message : 'Something went wrong. Try again.';
        appendMemberMsg('bot', reply, data.sources);
        memberAiMsgs.push({ role: 'assistant', content: reply });
      } catch (err) {
        removeMemberTyping(typingId);
        appendMemberMsg('bot', 'Connection error. Check your internet and try again.');
      }

      sendBtn.disabled = false;
    }

    function appendMemberMsg(role, text, sources) {
      const container = document.getElementById('ai-panel-messages');
      const icon = role === 'bot' ? '🤖' : '👤';
      const div = document.createElement('div');
      div.className = 'ai-msg ' + role;
      let sourceHtml = '';
      if (role === 'bot' && sources && sources.length > 0) {
        const links = sources.filter(s => s.url).map(s => {
          const display = s.url.replace(/^https?:\/\//, '').replace(/\/$/, '').split('/')[0];
          return `<a href="https://${s.url.replace(/^https?:\/\//, '')}" target="_blank" rel="noopener" style="color:#FF6B35;text-decoration:none;">${display}</a>`;
        }).join(' &middot; ');
        if (links) sourceHtml = `<div style="margin-top:8px;padding-top:7px;border-top:1px solid rgba(255,255,255,0.1);font-size:11px;color:#888;">🔍 Web sources: ${links}</div>`;
      }
      div.innerHTML = `
        <div class="ai-msg-icon">${icon}</div>
        <div class="ai-msg-bubble">${escapeHtml(text)}${sourceHtml}</div>
      `;
      container.appendChild(div);
      container.scrollTop = container.scrollHeight;
    }

    function showMemberTyping(isSearching) {
      const container = document.getElementById('ai-panel-messages');
      const id = 'mtyping-' + Date.now();
      const div = document.createElement('div');
      div.id = id;
      div.className = 'ai-msg bot';
      const bubbleContent = isSearching
        ? '<span style="font-size:11px;color:#aaa;">🔍 Searching the web&hellip;</span>'
        : '<div class="ai-dot-typing"><span></span><span></span><span></span></div>';
      div.innerHTML = `<div class="ai-msg-icon">🤖</div><div class="ai-msg-bubble">${bubbleContent}</div>`;
      container.appendChild(div);
      container.scrollTop = container.scrollHeight;
      return id;
    }

    function removeMemberTyping(id) {
      const el = document.getElementById(id);
      if (el) el.remove();
    }

    // ====== GAME SECTION AI CHAT ======
    let gameAiMsgs = [];
    let gameAiPanelOpen = false;

    function toggleGameAiPanel() {
      const aiSection = document.getElementById('game-ai-section');
      gameAiPanelOpen = !gameAiPanelOpen;
      aiSection.style.display = gameAiPanelOpen ? 'block' : 'none';
      if (gameAiPanelOpen) {
        setTimeout(() => document.getElementById('game-ai-input').focus(), 100);
      }
    }

    async function sendGameAiMessage() {
      const input = document.getElementById('game-ai-input');
      const text = input.value.trim();
      if (!text) return;

      input.value = '';
      appendGameAiMsg('user', text);
      gameAiMsgs.push({ role: 'user', content: text });

      const typingId = showGameAiTyping();

      try {
        const res = await fetch('/api/ai/member-chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            messages: gameAiMsgs,
            context: {
              domain: 'game_platform_guides',
              platforms: ['IAAI', 'Copart', 'Edge Pipeline', 'CarsForSale', 'OVE']
            }
          })
        });
        const data = await res.json();
        removeGameAiTyping(typingId);
        const reply = data.success ? data.message : 'Something went wrong. Try again.';
        appendGameAiMsg('bot', reply);
        gameAiMsgs.push({ role: 'assistant', content: reply });
      } catch (err) {
        removeGameAiTyping(typingId);
        appendGameAiMsg('bot', 'Connection error. Check your internet and try again.');
      }
    }

    function appendGameAiMsg(role, text) {
      const container = document.getElementById('game-ai-messages');
      const icon = role === 'bot' ? '🤖' : '👤';
      const bubbleStyle = role === 'bot'
        ? 'background: var(--purple-glow); border: 1px solid var(--purple-border); border-radius: 12px 12px 12px 0;'
        : 'background: var(--bg-input); border: 1px solid var(--border); border-radius: 12px 12px 0 12px;';
      const div = document.createElement('div');
      div.style.display = 'flex';
      div.style.gap = '10px';
      div.style.marginBottom = '12px';
      div.innerHTML = `
        <div style="font-size: 20px;">${icon}</div>
        <div style="${bubbleStyle} padding: 12px 14px; font-size: 13px; color: var(--text-primary);">${escapeHtml(text)}</div>
      `;
      container.appendChild(div);
      container.scrollTop = container.scrollHeight;
    }

    function showGameAiTyping() {
      const container = document.getElementById('game-ai-messages');
      const id = 'gtyping-' + Date.now();
      const div = document.createElement('div');
      div.id = id;
      div.style.display = 'flex';
      div.style.gap = '10px';
      div.innerHTML = `
        <div style="font-size: 20px;">🤖</div>
        <div style="background: var(--purple-glow); border: 1px solid var(--purple-border); padding: 12px 14px; border-radius: 12px 12px 12px 0;">
          <div class="ai-dot-typing"><span></span><span></span><span></span></div>
        </div>`;
      container.appendChild(div);
      container.scrollTop = container.scrollHeight;
      return id;
    }

    function removeGameAiTyping(id) {
      const el = document.getElementById(id);
      if (el) el.remove();
    }

    // Handle Enter key in Game AI input
    document.getElementById('game-ai-input')?.addEventListener('keydown', function(e) {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendGameAiMessage();
      }
    });

    // ====== MESSAGES ======
    async function loadMemberMessages() {
      if (!currentMember) return;
      const listEl = document.getElementById('member-messages-list');
      const replyCard = document.getElementById('member-reply-card');
      listEl.innerHTML = '<div class="loading-row"><div class="spinner"></div> Loading messages...</div>';

      try {
        const res = await fetch(`/api/member/messages?email=${encodeURIComponent(currentMember.email)}`);
        const data = await res.json();

        if (!data.success) {
          listEl.innerHTML = '<div style="color:var(--text-secondary);font-size:13px;padding:16px 0">Could not load messages.</div>';
          return;
        }

        // Refresh unread count
        loadMemberUnreadCount();

        if (!data.messages || !data.messages.length) {
          listEl.innerHTML = '<div style="color:var(--text-secondary);font-size:13px;padding:16px 0;text-align:center">No messages yet. The FlipLane team will reach out here!</div>';
          replyCard.style.display = 'block';
          return;
        }

        replyCard.style.display = 'block';
        listEl.innerHTML = data.messages.map(msg => {
          const isFromAdmin = msg.sender_type === 'admin';
          const time = new Date(msg.created_at).toLocaleString('en-US', {month:'short',day:'numeric',year:'numeric',hour:'numeric',minute:'2-digit'});
          const bgColor = isFromAdmin ? 'rgba(0, 230, 118, 0.06)' : 'rgba(68, 138, 255, 0.06)';
          const borderColor = isFromAdmin ? 'rgba(0, 230, 118, 0.2)' : 'rgba(68, 138, 255, 0.2)';
          const labelColor = isFromAdmin ? 'var(--green)' : 'var(--blue)';
          const label = isFromAdmin ? '✉️ FlipLane Team' : '👤 You';
          const subjectLine = msg.subject ? `<div style="font-weight:700;font-size:14px;margin-bottom:6px;color:var(--text-primary)">${escapeHtml(msg.subject)}</div>` : '';
          return `<div style="background:${bgColor};border:1px solid ${borderColor};border-radius:var(--radius-sm);padding:16px;margin-bottom:12px">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
              <span style="font-size:12px;font-weight:700;color:${labelColor};text-transform:uppercase;letter-spacing:.5px">${label}</span>
              <span style="font-size:11px;color:var(--text-dim)">${time}</span>
            </div>
            ${subjectLine}
            <div style="font-size:14px;color:var(--text-primary);line-height:1.6;white-space:pre-wrap">${escapeHtml(msg.body)}</div>
          </div>`;
        }).join('');

      } catch (err) {
        listEl.innerHTML = '<div style="color:var(--text-secondary);font-size:13px;padding:16px 0">Failed to load messages.</div>';
      }
    }

    async function sendMemberMessage() {
      if (!currentMember) return;
      const body = document.getElementById('member-msg-body').value.trim();
      if (!body) { showToast('Please enter a message.'); return; }

      try {
        const res = await fetch('/api/member/messages/reply', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: currentMember.email, body })
        });
        const data = await res.json();
        if (data.success) {
          document.getElementById('member-msg-body').value = '';
          showToast('Message sent!');
          loadMemberMessages();
        } else {
          showToast('Failed to send message.');
        }
      } catch (err) {
        showToast('Connection error. Try again.');
      }
    }

    async function loadMemberUnreadCount() {
      if (!currentMember) return;
      try {
        const res = await fetch(`/api/member/messages/unread-count?email=${encodeURIComponent(currentMember.email)}`);
        const data = await res.json();
        const count = data.count || 0;

        // Bell badge
        const bell = document.getElementById('msg-bell-badge');
        if (bell) {
          bell.textContent = count;
          bell.style.display = count > 0 ? 'block' : 'none';
        }

        // Hub card badge
        const hubBadge = document.getElementById('hub-msg-badge');
        if (hubBadge) {
          hubBadge.textContent = count;
          hubBadge.style.display = count > 0 ? 'inline-block' : 'none';
        }
      } catch (e) { /* ignore */ }
    }

    // Poll unread count every 60s
    setInterval(() => { if (currentMember) loadMemberUnreadCount(); }, 60000);

    // ====== ANNOUNCEMENTS ======
    async function loadMemberAnnouncements() {
      const card = document.getElementById('announcements-card');
      const listEl = document.getElementById('member-announcements-list');

      try {
        const res = await fetch('/api/announcements');
        const data = await res.json();

        if (!data.success || !data.announcements || !data.announcements.length) {
          card.style.display = 'none';
          return;
        }

        card.style.display = 'block';
        listEl.innerHTML = data.announcements.map(a => {
          const time = new Date(a.created_at).toLocaleString('en-US', {month:'short',day:'numeric',year:'numeric',hour:'numeric',minute:'2-digit'});
          return `<div style="background:rgba(0,230,118,0.05);border:1px solid rgba(0,230,118,0.15);border-radius:var(--radius-sm);padding:16px;margin-bottom:12px">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
              <span style="font-size:13px;font-weight:700;color:var(--green);text-transform:uppercase;letter-spacing:.5px">📢 ${escapeHtml(a.title)}</span>
              <span style="font-size:11px;color:var(--text-dim)">${time}</span>
            </div>
            <div style="font-size:14px;color:var(--text-primary);line-height:1.6;white-space:pre-wrap">${escapeHtml(a.body)}</div>
          </div>`;
        }).join('');
      } catch (err) {
        card.style.display = 'none';
      }
    }

    // Allow Enter in member reply textarea
    document.getElementById('member-msg-body')?.addEventListener('keydown', function(e) {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMemberMessage(); }
    });

    // ====== VEHICLE INTELLIGENCE ======
    let _viMode = 'ymm';
    let _viLastData = null;

    function viInit() {
      viLoadYears();
      viLoadHistory();
      viSetMode('ymm');
    }

    function viSetMode(mode) {
      _viMode = mode;
      document.getElementById('vi-ymm-fields').style.display = mode === 'ymm' ? 'block' : 'none';
      document.getElementById('vi-vin-fields').style.display = mode === 'vin' ? 'block' : 'none';
      document.getElementById('vi-mode-ymm').className = mode === 'ymm' ? 'btn' : 'btn btn-ghost';
      document.getElementById('vi-mode-ymm').style.cssText = mode === 'ymm'
        ? 'flex:1;padding:9px 12px;font-size:13px;background:var(--orange);color:#000;font-weight:700;'
        : 'flex:1;padding:9px 12px;font-size:13px;';
      document.getElementById('vi-mode-vin').className = mode === 'vin' ? 'btn' : 'btn btn-ghost';
      document.getElementById('vi-mode-vin').style.cssText = mode === 'vin'
        ? 'flex:1;padding:9px 12px;font-size:13px;background:var(--orange);color:#000;font-weight:700;'
        : 'flex:1;padding:9px 12px;font-size:13px;';
    }

    function viLoadYears() {
      const sel = document.getElementById('vi-year');
      const cur = new Date().getFullYear();
      let opts = '<option value="">Select year…</option>';
      for (let y = cur; y >= 1990; y--) opts += `<option value="${y}">${y}</option>`;
      sel.innerHTML = opts;
      document.getElementById('vi-make').disabled = false;
    }

    async function viLoadMakes() {
      const year = document.getElementById('vi-year').value;
      const makeEl = document.getElementById('vi-make');
      const modelEl = document.getElementById('vi-model');
      modelEl.innerHTML = '<option value="">Select model…</option>';
      modelEl.disabled = true;
      if (!year) { makeEl.innerHTML = '<option value="">Select make…</option>'; makeEl.disabled = true; return; }
      makeEl.innerHTML = '<option value="">Loading…</option>';
      makeEl.disabled = true;
      try {
        const resp = await fetch('/api/vehicle-intel/makes');
        const data = await resp.json();
        const makes = (data.makes || []).sort((a, b) => a.localeCompare(b));
        let opts = '<option value="">Select make…</option>';
        makes.forEach(m => { opts += `<option value="${m}">${m}</option>`; });
        makeEl.innerHTML = opts;
        makeEl.disabled = false;
      } catch (e) {
        makeEl.innerHTML = '<option value="">Error loading makes</option>';
        makeEl.disabled = false;
      }
    }

    async function viLoadModels() {
      const year = document.getElementById('vi-year').value;
      const make = document.getElementById('vi-make').value;
      const modelEl = document.getElementById('vi-model');
      if (!make) { modelEl.innerHTML = '<option value="">Select model…</option>'; modelEl.disabled = true; return; }
      modelEl.innerHTML = '<option value="">Loading…</option>';
      modelEl.disabled = true;
      try {
        const resp = await fetch(`/api/vehicle-intel/models?make=${encodeURIComponent(make)}&year=${encodeURIComponent(year)}`);
        const data = await resp.json();
        const models = (data.models || []).sort((a, b) => a.localeCompare(b));
        let opts = '<option value="">Select model…</option>';
        models.forEach(m => { opts += `<option value="${m}">${m}</option>`; });
        modelEl.innerHTML = opts;
        modelEl.disabled = false;
      } catch (e) {
        modelEl.innerHTML = '<option value="">Error loading models</option>';
        modelEl.disabled = false;
      }
    }

    async function viLookup() {
      let body = {};
      if (_viMode === 'vin') {
        const vin = (document.getElementById('vi-vin').value || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
        if (vin.length !== 17) { alert('Please enter a valid 17-character VIN.'); return; }
        body = { vin };
      } else {
        const year = document.getElementById('vi-year').value;
        const make = document.getElementById('vi-make').value;
        const model = document.getElementById('vi-model').value;
        if (!year || !make || !model) { alert('Please select Year, Make, and Model.'); return; }
        body = { year, make, model };
      }
      if (currentMember && currentMember.email) body.member_email = currentMember.email;

      document.getElementById('vi-input-card').style.display = 'none';
      document.getElementById('vi-loading').style.display = 'block';
      document.getElementById('vi-results').style.display = 'none';
      document.getElementById('vi-history-card').style.display = 'none';

      try {
        const resp = await fetch('/api/vehicle-intelligence/lookup', {
          method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
        });
        const data = await resp.json();
        if (!data.success) {
          document.getElementById('vi-loading').style.display = 'none';
          document.getElementById('vi-input-card').style.display = 'block';
          alert(data.message || 'Lookup failed. Please try again.');
          return;
        }
        _viLastData = data;
        viRenderResults(data);
      } catch (e) {
        document.getElementById('vi-loading').style.display = 'none';
        document.getElementById('vi-input-card').style.display = 'block';
        alert('Network error. Please try again.');
      }
    }

    function viRenderResults(data) {
      const v = data.vehicle || {};
      const title = [v.year, v.make, v.model].filter(Boolean).join(' ');
      document.getElementById('vi-vehicle-title').textContent = title || 'Vehicle';
      if (v.vin) document.getElementById('vi-vehicle-vin').textContent = `VIN: ${v.vin}`;

      // Badges
      const recallBadge = document.getElementById('vi-recall-badge');
      if (data.recallsCount > 0) {
        recallBadge.textContent = `⚠️ ${data.recallsCount} Recall${data.recallsCount !== 1 ? 's' : ''}`;
        recallBadge.style.display = 'inline-block';
      } else {
        recallBadge.style.display = 'none';
      }
      const safetyBadge = document.getElementById('vi-safety-badge');
      if (data.safetyRating) {
        safetyBadge.textContent = `⭐ ${data.safetyRating}/5 Safety`;
        safetyBadge.style.display = 'inline-block';
      } else {
        safetyBadge.style.display = 'none';
      }
      const complaintBadge = document.getElementById('vi-complaint-badge');
      if (data.complaintsCount > 0) {
        complaintBadge.textContent = `📢 ${data.complaintsCount} Complaint${data.complaintsCount !== 1 ? 's' : ''}`;
        complaintBadge.style.display = 'inline-block';
      } else {
        complaintBadge.style.display = 'none';
      }

      // Specs tab
      const specs = v.specs || {};
      const specItems = [
        { label: 'Body Style', val: specs.bodyStyle || v.bodyClass },
        { label: 'Doors', val: specs.doors || v.doors },
        { label: 'Seats', val: specs.seats },
        { label: 'Engine', val: specs.engineCC ? `${(specs.engineCC/1000).toFixed(1)}L ${specs.engineCylinders ? specs.engineCylinders + '-cyl' : ''}`.trim() : (v.engineDisplacement ? `${v.engineDisplacement}L` : null) },
        { label: 'Horsepower', val: specs.engineHP ? `${specs.engineHP} hp` : (v.engineHP ? `${v.engineHP} hp` : null) },
        { label: 'Fuel Type', val: specs.engineFuel || v.fuelType },
        { label: 'Drive Type', val: specs.driveType || v.driveType },
        { label: 'Transmission', val: specs.transmission || v.transmission },
        { label: 'Gears', val: specs.gears },
        { label: '0–60 mph', val: specs.zeroToSixty ? `${specs.zeroToSixty}s` : null },
        { label: 'Top Speed', val: specs.topSpeedKph ? `${Math.round(specs.topSpeedKph * 0.621)} mph` : null },
        { label: 'Fuel Cap', val: specs.fuelCapacity ? `${specs.fuelCapacity} gal` : null },
        { label: 'Length', val: specs.length ? `${specs.length}"` : null },
        { label: 'Width', val: specs.width ? `${specs.width}"` : null },
        { label: 'Wheelbase', val: specs.wheelbase ? `${specs.wheelbase}"` : null },
        { label: 'GVWR', val: v.gvwr },
        { label: 'Manufacturer', val: v.manufacturer },
        { label: 'Trim', val: v.trim || specs.modelName },
      ].filter(s => s.val);

      const specsEl = document.getElementById('vi-specs-content');
      if (specItems.length === 0) {
        specsEl.innerHTML = '<div style="color:var(--text-secondary);font-size:14px;">No spec data found for this vehicle.</div>';
      } else {
        specsEl.innerHTML = specItems.map(s =>
          `<div class="vi-spec-item"><div class="vi-spec-label">${s.label}</div><div class="vi-spec-value">${s.val}</div></div>`
        ).join('');
      }

      // Recalls tab
      const recalls = Array.isArray(data.recalls) ? data.recalls : [];
      const recallsEl = document.getElementById('vi-recalls-content');
      if (recalls.length === 0) {
        recallsEl.innerHTML = '<div style="color:#4caf50;font-size:14px;font-weight:600;">✅ No active recalls found for this vehicle.</div>';
      } else {
        recallsEl.innerHTML = recalls.map(r => `
          <div class="vi-recall-item">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;margin-bottom:8px;">
              <div style="font-weight:700;font-size:14px;color:var(--text-primary)">${r.component || 'Unknown Component'}</div>
              ${r.campaign ? `<div style="font-size:11px;color:var(--text-secondary);white-space:nowrap">Campaign ${r.campaign}</div>` : ''}
            </div>
            ${r.recallDate ? `<div style="font-size:11px;color:var(--text-secondary);margin-bottom:6px;">📅 ${r.recallDate}</div>` : ''}
            ${r.summary ? `<div style="font-size:13px;color:var(--text-secondary);margin-bottom:6px;">${r.summary}</div>` : ''}
            ${r.remedy ? `<div style="font-size:12px;color:var(--text-secondary);background:rgba(76,175,80,0.08);border-radius:4px;padding:6px 8px;margin-top:6px;"><strong>Remedy:</strong> ${r.remedy}</div>` : ''}
          </div>`).join('');
      }

      // Safety tab
      document.getElementById('vi-safety-content').innerHTML = viSafetyCard(data.safety || {}, data.safety && data.safety.variants);

      // Complaints tab
      const complaints = Array.isArray(data.complaints) ? data.complaints : [];
      const complaintsEl = document.getElementById('vi-complaints-content');
      if (complaints.length === 0) {
        complaintsEl.innerHTML = '<div style="color:var(--text-secondary);font-size:14px;">No complaints found for this vehicle.</div>';
      } else {
        complaintsEl.innerHTML = `<div style="color:var(--text-secondary);font-size:12px;margin-bottom:12px;">Showing ${complaints.length} complaints (capped at 50)</div>` +
          complaints.map(c => `
            <div class="vi-complaint-item">
              <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;margin-bottom:6px;">
                <div style="font-weight:700;font-size:13px;color:var(--text-primary)">${c.component || 'Unknown'}</div>
                <div style="font-size:11px;color:var(--text-secondary);white-space:nowrap">${c.date || ''}</div>
              </div>
              ${c.summary ? `<div style="font-size:13px;color:var(--text-secondary);margin-bottom:6px;">${c.summary.slice(0, 300)}${c.summary.length > 300 ? '…' : ''}</div>` : ''}
              <div style="display:flex;gap:10px;flex-wrap:wrap;font-size:11px;color:var(--text-secondary);">
                ${c.crash ? '<span style="color:#ff5252;font-weight:700;">🚨 CRASH</span>' : ''}
                ${c.fire ? '<span style="color:#ff9800;font-weight:700;">🔥 FIRE</span>' : ''}
                ${c.injuries > 0 ? `<span>${c.injuries} injur${c.injuries !== 1 ? 'ies' : 'y'}</span>` : ''}
                ${c.mileage ? `<span>${parseInt(c.mileage).toLocaleString()} mi</span>` : ''}
              </div>
            </div>`).join('');
      }

      // Fuel Economy tab
      const fuel = data.fuel || {};
      const fuelEl = document.getElementById('vi-fuel-content');
      if (!fuel.found) {
        fuelEl.innerHTML = '<div style="color:var(--text-secondary);font-size:14px;">No EPA fuel economy data found for this vehicle.</div>';
      } else {
        fuelEl.innerHTML = `
          <div class="vi-fuel-card">
            <div class="vi-fuel-mpg"><div class="vi-fuel-mpg-num">${fuel.cityMpg || '—'}</div><div class="vi-fuel-label">City MPG</div></div>
            <div class="vi-fuel-mpg"><div class="vi-fuel-mpg-num">${fuel.combMpg || '—'}</div><div class="vi-fuel-label">Combined</div></div>
            <div class="vi-fuel-mpg"><div class="vi-fuel-mpg-num">${fuel.hwMpg || '—'}</div><div class="vi-fuel-label">Highway</div></div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:4px;">
            ${fuel.fuelType ? `<div class="vi-spec-item"><div class="vi-spec-label">Fuel Type</div><div class="vi-spec-value">${fuel.fuelType}</div></div>` : ''}
            ${fuel.trany ? `<div class="vi-spec-item"><div class="vi-spec-label">Transmission</div><div class="vi-spec-value">${fuel.trany}</div></div>` : ''}
            ${fuel.drive ? `<div class="vi-spec-item"><div class="vi-spec-label">Drive</div><div class="vi-spec-value">${fuel.drive}</div></div>` : ''}
            ${fuel.cylinders ? `<div class="vi-spec-item"><div class="vi-spec-label">Cylinders</div><div class="vi-spec-value">${fuel.cylinders}</div></div>` : ''}
            ${fuel.displ ? `<div class="vi-spec-item"><div class="vi-spec-label">Displacement</div><div class="vi-spec-value">${fuel.displ}L</div></div>` : ''}
            ${fuel.annualFuelCost ? `<div class="vi-spec-item"><div class="vi-spec-label">Est. Annual Fuel Cost</div><div class="vi-spec-value">$${parseInt(fuel.annualFuelCost).toLocaleString()}</div></div>` : ''}
            ${fuel.co2 ? `<div class="vi-spec-item"><div class="vi-spec-label">CO₂ (g/mi)</div><div class="vi-spec-value">${fuel.co2}</div></div>` : ''}
          </div>
          ${data.loanRate ? `<div style="margin-top:16px;padding:12px 14px;background:rgba(79,110,247,0.07);border:1px solid rgba(79,110,247,0.2);border-radius:8px;font-size:13px;color:var(--text-secondary);">🏦 Current avg auto loan rate: <strong style="color:var(--text-primary)">${data.loanRate}%</strong> (FRED 60-mo new car)</div>` : ''}
        `;
      }

      document.getElementById('vi-loading').style.display = 'none';
      document.getElementById('vi-results').style.display = 'block';
      viTab('specs');
      viLoadHistory();
    }

    function viStars(count, max) {
      max = max || 5;
      const n = parseInt(count) || 0;
      let html = '';
      for (let i = 1; i <= max; i++) html += `<span class="${i <= n ? 'vi-star' : 'vi-star-empty'}">★</span>`;
      return html;
    }

    function viSafetyCard(safety, variants) {
      if (!safety || (!safety.overall && !safety.frontCrash && !safety.sideCrash)) {
        return '<div style="color:var(--text-secondary);font-size:14px;">No NHTSA safety rating data found for this vehicle.</div>';
      }
      const variantSelect = (variants && variants.length > 1) ? `
        <div style="margin-bottom:16px;">
          <label style="font-size:12px;color:var(--text-secondary);display:block;margin-bottom:6px;">Select variant:</label>
          <select onchange="viLoadSafetyDetail(this.value)" style="width:100%;padding:8px 10px;background:var(--input-bg);border:1px solid var(--border);border-radius:6px;color:var(--text-primary);font-size:13px;">
            ${variants.map((v, i) => `<option value="${v.id}"${i===0?' selected':''}>${v.description || 'Variant ' + (i+1)}</option>`).join('')}
          </select>
        </div>` : '';
      return `${variantSelect}
        ${safety.vehicleDescription ? `<div style="font-size:14px;font-weight:600;color:var(--text-primary);margin-bottom:14px;">${safety.vehicleDescription}</div>` : ''}
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:10px;">
          ${safety.overall ? `<div class="vi-spec-item"><div class="vi-spec-label">Overall</div><div style="font-size:22px;">${viStars(safety.overall)}</div><div style="font-size:12px;color:var(--text-secondary);margin-top:4px;">${safety.overall}/5 stars</div></div>` : ''}
          ${safety.frontCrash ? `<div class="vi-spec-item"><div class="vi-spec-label">Front Crash</div><div style="font-size:20px;">${viStars(safety.frontCrash)}</div></div>` : ''}
          ${safety.sideCrash ? `<div class="vi-spec-item"><div class="vi-spec-label">Side Crash</div><div style="font-size:20px;">${viStars(safety.sideCrash)}</div></div>` : ''}
          ${safety.rolloverStars ? `<div class="vi-spec-item"><div class="vi-spec-label">Rollover</div><div style="font-size:20px;">${viStars(safety.rolloverStars)}</div></div>` : ''}
          ${safety.rollover ? `<div class="vi-spec-item"><div class="vi-spec-label">Rollover Risk</div><div class="vi-spec-value">${safety.rollover}</div></div>` : ''}
        </div>
        ${safety.vehiclePicture ? `<div style="margin-top:16px;text-align:center;"><img src="${safety.vehiclePicture}" alt="Vehicle" style="max-width:280px;border-radius:8px;border:1px solid var(--border);" /></div>` : ''}`;
    }

    function viTab(tab) {
      ['specs','recalls','safety','complaints','fuel'].forEach(t => {
        document.getElementById(`vi-panel-${t}`).style.display = t === tab ? 'block' : 'none';
        const btn = document.getElementById(`vi-tab-${t}`);
        btn.className = t === tab ? 'vi-tab vi-tab-active' : 'vi-tab';
      });
    }

    async function viLoadSafetyDetail(vehicleId) {
      const safetyEl = document.getElementById('vi-safety-content');
      safetyEl.innerHTML = '<div style="color:var(--text-secondary);font-size:13px;padding:8px 0;">Loading…</div>';
      try {
        const resp = await fetch(`/api/vehicle-intelligence/safety-detail?vehicleId=${vehicleId}`);
        const data = await resp.json();
        if (data.success) {
          const variants = _viLastData && _viLastData.safety && _viLastData.safety.variants;
          safetyEl.innerHTML = viSafetyCard(data, variants);
        }
      } catch (e) {
        safetyEl.innerHTML = '<div style="color:var(--text-secondary);">Could not load safety detail.</div>';
      }
    }

    function viReset() {
      document.getElementById('vi-input-card').style.display = 'block';
      document.getElementById('vi-loading').style.display = 'none';
      document.getElementById('vi-results').style.display = 'none';
      _viLastData = null;
    }

    async function viLoadHistory() {
      if (!currentMember || !currentMember.email) return;
      try {
        const resp = await fetch(`/api/vehicle-intelligence/history?email=${encodeURIComponent(currentMember.email)}`);
        const data = await resp.json();
        if (!data.history || !data.history.length) return;
        const histCard = document.getElementById('vi-history-card');
        const histList = document.getElementById('vi-history-list');
        histList.innerHTML = data.history.map(h => {
          const label = [h.year, h.make, h.model].filter(Boolean).join(' ') || (h.vin ? `VIN: ${h.vin}` : 'Unknown');
          const when = h.looked_up_at ? new Date(h.looked_up_at).toLocaleDateString() : '';
          const recalls = h.recalls_count > 0 ? `<span class="vi-badge vi-badge-warn" style="margin-left:8px;">⚠️ ${h.recalls_count}</span>` : '';
          const safety = h.safety_rating ? `<span class="vi-badge vi-badge-info" style="margin-left:4px;">⭐ ${h.safety_rating}/5</span>` : '';
          return `<div class="vi-history-item" onclick="viHistoryLookup('${h.year||''}','${(h.make||'').replace(/'/g,"\\'")}','${(h.model||'').replace(/'/g,"\\'")}','${h.vin||''}')">
            <div style="font-size:18px;">🚗</div>
            <div style="flex:1;min-width:0;">
              <div style="font-weight:600;font-size:14px;color:var(--text-primary);">${label}${recalls}${safety}</div>
              <div style="font-size:11px;color:var(--text-secondary);margin-top:2px;">${when}</div>
            </div>
            <div style="font-size:12px;color:var(--orange);font-weight:600;">Re-run →</div>
          </div>`;
        }).join('');
        histCard.style.display = data.history.length > 0 ? 'block' : 'none';
      } catch (e) { /* non-fatal */ }
    }

    function viHistoryLookup(year, make, model, vin) {
      if (vin) {
        viSetMode('vin');
        document.getElementById('vi-vin').value = vin;
      } else {
        viSetMode('ymm');
        // Set dropdowns as best we can — populate year, then let user pick make/model
        const yearSel = document.getElementById('vi-year');
        if (year) yearSel.value = year;
      }
      viLookup();
    }


    // ====== LOAN & PAYMENT ESTIMATOR ======
    var _loanFredRate = null, _loanFredDate = null, _loanComparisonActive = false, _loanHistoryCache = [];

    async function initLoanEstimator() {
      try {
        var resp = await fetch('/api/fred-rate'); var data = await resp.json();
        if (data.success && data.rate) {
          _loanFredRate = data.rate; _loanFredDate = data.date || null;
          ['a','b'].forEach(function(s) { var el=document.getElementById('loan-'+s+'-rate'); if(el&&!el.value) el.value=_loanFredRate.toFixed(2); });
          var dl = _loanFredDate ? new Date(_loanFredDate).toLocaleDateString('en-US',{month:'short',year:'numeric'}) : '';
          var ht = 'Current avg: '+_loanFredRate.toFixed(2)+'%'+(dl?' · '+dl:'');
          ['a','b'].forEach(function(s){ var h=document.getElementById('loan-'+s+'-rate-hint'); if(h) h.textContent=ht; });
          var badge=document.getElementById('loan-fred-rate-badge');
          if(badge) badge.innerHTML='<div style="display:inline-flex;align-items:center;gap:8px;background:rgba(255,152,0,0.08);border:1px solid rgba(255,152,0,0.25);border-radius:8px;padding:6px 14px;font-size:12px;"><span style="color:var(--orange);">📊</span><span style="color:var(--text-secondary);">Avg 60-mo auto rate:</span><span style="color:var(--orange);font-weight:700;">'+_loanFredRate.toFixed(2)+'%</span>'+(dl?'<span style="color:var(--text-dim);font-size:11px;">('+dl+')</span>':'')+'<span style="color:var(--text-dim);font-size:11px;">· FRED / editable</span></div>';
        }
      } catch(e){}
      loadLoanHistory();
    }

    function calcLoan(scenario) {
      var p='loan-'+scenario+'-';
      var price=parseFloat(document.getElementById(p+'price').value)||0, down=parseFloat(document.getElementById(p+'down').value)||0;
      var trade=parseFloat(document.getElementById(p+'tradein').value)||0, taxPct=parseFloat(document.getElementById(p+'tax').value)||0;
      var term=parseInt(document.getElementById(p+'term').value)||60, apr=parseFloat(document.getElementById(p+'rate').value);
      var resultsEl=document.getElementById('loan-'+scenario+'-results');
      if (!price||isNaN(apr)||apr<0){if(resultsEl)resultsEl.style.display='none';updateLoanComparison();return;}
      var taxAmt=price*(taxPct/100), financed=Math.max(0,price+taxAmt-down-trade), mr=apr/12/100;
      var monthly=0,totalInterest=0,totalOOP=0;
      if(financed<=0){monthly=0;totalInterest=0;totalOOP=price+taxAmt;}
      else if(mr===0){monthly=financed/term;totalInterest=0;totalOOP=down+trade+financed;}
      else{var f=Math.pow(1+mr,term);monthly=financed*mr*f/(f-1);totalInterest=monthly*term-financed;totalOOP=down+trade+monthly*term;}
      var fi=0,fp=0,li=0,lp=0;
      if(financed>0&&mr>0){fi=financed*mr;fp=monthly-fi;var bal=financed*Math.pow(1+mr,term-1)-monthly*(Math.pow(1+mr,term-1)-1)/mr;li=Math.max(0,bal*mr);lp=Math.max(0,Math.min(bal,monthly-li));}
      else if(financed>0){fp=monthly;lp=monthly;}
      var fmt=function(n){return '$'+Math.abs(n).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});};
      var fmtI=function(n){return '$'+Math.abs(Math.round(n)).toLocaleString();};
      var isCash=financed<=0;
      if(resultsEl){
        resultsEl.innerHTML='<div style="display:grid;grid-template-columns:repeat(2,1fr);gap:16px;text-align:center;margin-bottom:'+(isCash?'0':'20px')+';"><div><div class="stat-label">Loan Amount</div><div class="stat-value" style="font-size:20px;">'+(isCash?'<span style="color:var(--green);">Cash Deal</span>':fmtI(financed))+'</div><div class="stat-sub">After down + trade-in + tax</div></div><div><div class="stat-label">Monthly Payment</div><div class="stat-value" style="font-size:26px;color:var(--green);">'+(isCash?'—':fmt(monthly))+'</div><div class="stat-sub">'+(isCash?'No financing':term+' mo @ '+apr.toFixed(2)+'% APR')+'</div></div><div><div class="stat-label">Total Interest</div><div class="stat-value" style="font-size:20px;color:'+(totalInterest>0?'var(--yellow)':'var(--green)')+';">'+fmtI(totalInterest)+'</div><div class="stat-sub">Cost of borrowing</div></div><div><div class="stat-label">Total Out of Pocket</div><div class="stat-value" style="font-size:20px;">'+fmtI(totalOOP)+'</div><div class="stat-sub">Down + all payments</div></div></div>'+(!isCash&&financed>0?'<div style="border-top:1px solid var(--border);padding-top:16px;"><div style="font-size:11px;font-weight:700;color:var(--text-secondary);text-transform:uppercase;letter-spacing:0.8px;margin-bottom:12px;">📋 Amortization Summary</div><div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;font-size:13px;"><div style="background:var(--bg-card);border:1px solid var(--border-light);border-radius:var(--radius-xs);padding:12px;"><div style="font-weight:600;font-size:12px;color:var(--text-secondary);margin-bottom:8px;">Payment #1</div><div style="display:flex;justify-content:space-between;margin-bottom:4px;"><span style="color:var(--text-secondary);">Interest</span><span style="color:var(--red);">'+fmt(fi)+'</span></div><div style="display:flex;justify-content:space-between;"><span style="color:var(--text-secondary);">Principal</span><span style="color:var(--green);">'+fmt(fp)+'</span></div></div><div style="background:var(--bg-card);border:1px solid var(--border-light);border-radius:var(--radius-xs);padding:12px;"><div style="font-weight:600;font-size:12px;color:var(--text-secondary);margin-bottom:8px;">Payment #'+term+'</div><div style="display:flex;justify-content:space-between;margin-bottom:4px;"><span style="color:var(--text-secondary);">Interest</span><span style="color:var(--red);">'+fmt(li)+'</span></div><div style="display:flex;justify-content:space-between;"><span style="color:var(--text-secondary);">Principal</span><span style="color:var(--green);">'+fmt(lp)+'</span></div></div></div></div>':'');
        resultsEl.style.display='block';
        resultsEl.dataset.financed=Math.round(financed); resultsEl.dataset.monthly=monthly.toFixed(2);
        resultsEl.dataset.totalInterest=Math.round(totalInterest); resultsEl.dataset.totalCost=Math.round(totalOOP);
        resultsEl.dataset.term=term; resultsEl.dataset.apr=apr;
      }
      updateLoanComparison();
    }

    function updateLoanComparison() {
      var cd=document.getElementById('loan-comparison-diff'); if(!cd||!_loanComparisonActive) return;
      var aR=document.getElementById('loan-a-results'), bR=document.getElementById('loan-b-results');
      if(!aR||aR.style.display==='none'||!bR||bR.style.display==='none'){cd.style.display='none';return;}
      var aI=parseInt(aR.dataset.totalInterest)||0,bI=parseInt(bR.dataset.totalInterest)||0;
      var aM=parseFloat(aR.dataset.monthly)||0,bM=parseFloat(bR.dataset.monthly)||0;
      var aC=parseInt(aR.dataset.totalCost)||0,bC=parseInt(bR.dataset.totalCost)||0;
      var fD=function(n){return '$'+Math.abs(Math.round(n)).toLocaleString();};
      cd.innerHTML='<div style="background:rgba(0,230,118,0.04);border:1px solid var(--green-border);border-radius:var(--radius-sm);padding:16px;margin-top:16px;"><div style="font-size:11px;font-weight:700;color:var(--green);text-transform:uppercase;letter-spacing:0.8px;margin-bottom:14px;">⚖️ Scenario Comparison</div><div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;text-align:center;"><div><div style="font-size:11px;color:var(--text-secondary);margin-bottom:4px;">Monthly diff</div><div style="font-weight:700;font-size:18px;">$'+Math.abs(aM-bM).toFixed(2)+'/mo</div><div style="font-size:11px;color:var(--green);margin-top:2px;">Scenario '+(aM<=bM?'A':'B')+' lower</div></div><div><div style="font-size:11px;color:var(--text-secondary);margin-bottom:4px;">Total interest diff</div><div style="font-weight:700;font-size:18px;color:var(--yellow);">'+fD(Math.abs(aI-bI))+'</div><div style="font-size:11px;color:var(--green);margin-top:2px;">Save w/ Scenario '+(aI<=bI?'A':'B')+'</div></div><div><div style="font-size:11px;color:var(--text-secondary);margin-bottom:4px;">Total cost diff</div><div style="font-weight:700;font-size:18px;">'+fD(Math.abs(aC-bC))+'</div><div style="font-size:11px;color:var(--green);margin-top:2px;">Scenario '+(aC<=bC?'A':'B')+' costs less</div></div></div></div>';
      cd.style.display='block';
    }

    function loanToggleComparison() {
      _loanComparisonActive=!_loanComparisonActive;
      var sB=document.getElementById('loan-scenario-b'),ct=document.getElementById('loan-scenarios-container');
      var cb=document.getElementById('loan-compare-btn'),al=document.getElementById('loan-a-label'),cd=document.getElementById('loan-comparison-diff');
      if(_loanComparisonActive){
        sB.style.display='block'; if(window.innerWidth>=700) ct.style.gridTemplateColumns='1fr 1fr';
        if(cb) cb.textContent='✕ Single Scenario'; if(al) al.style.display='inline-block';
        ['price','down','tradein','tax','rate'].forEach(function(f){var a=document.getElementById('loan-a-'+f),b=document.getElementById('loan-b-'+f);if(a&&b&&a.value&&!b.value)b.value=a.value;});
        var at=document.getElementById('loan-a-term'),bt=document.getElementById('loan-b-term'); if(at&&bt) bt.value=at.value;
        var ha=document.getElementById('loan-a-rate-hint'),hb=document.getElementById('loan-b-rate-hint'); if(ha&&hb) hb.textContent=ha.textContent;
        calcLoan('b');
      } else {
        sB.style.display='none'; ct.style.gridTemplateColumns='1fr';
        if(cb) cb.textContent='⚖️ Compare Scenarios'; if(al) al.style.display='none'; if(cd) cd.style.display='none';
      }
    }

    function loanFromAcvMid(scenario) {
      var mid=(typeof _lastAcvMid!=='undefined'&&_lastAcvMid)||(function(){var e=document.getElementById('acv-price-mid');if(!e||!e.textContent||e.textContent.trim()==='—')return null;return parseFloat(e.textContent.replace(/[$,\s]/g,''))||null;})();
      if(!mid||mid<=0){showToast('No ACV result yet — run the ACV Calculator first',true);return;}
      var pe=document.getElementById('loan-'+scenario+'-price'); if(pe){pe.value=Math.round(mid);calcLoan(scenario);showToast('ACV Mid $'+Math.round(mid).toLocaleString()+' loaded');}
    }

    function loanClear() {
      ['a','b'].forEach(function(s){
        ['price','down','tradein'].forEach(function(f){var e=document.getElementById('loan-'+s+'-'+f);if(e)e.value='';});
        var tx=document.getElementById('loan-'+s+'-tax');if(tx)tx.value='8.0';
        var tm=document.getElementById('loan-'+s+'-term');if(tm)tm.value='60';
        var rt=document.getElementById('loan-'+s+'-rate');if(rt)rt.value=_loanFredRate?_loanFredRate.toFixed(2):'';
        var rs=document.getElementById('loan-'+s+'-results');if(rs)rs.style.display='none';
      });
      var cd=document.getElementById('loan-comparison-diff');if(cd)cd.style.display='none';
    }

    async function saveLoanCalc() {
      var btn=document.getElementById('loan-save-btn'),al=document.getElementById('loan-save-alert');
      var price=parseFloat(document.getElementById('loan-a-price').value)||0,down=parseFloat(document.getElementById('loan-a-down').value)||0;
      var trade=parseFloat(document.getElementById('loan-a-tradein').value)||0,taxPct=parseFloat(document.getElementById('loan-a-tax').value)||0;
      var term=parseInt(document.getElementById('loan-a-term').value)||60,apr=parseFloat(document.getElementById('loan-a-rate').value);
      var re=document.getElementById('loan-a-results');
      if(!price||isNaN(apr)||!re||re.style.display==='none'){if(al){al.style.cssText='display:block;padding:10px 14px;border-radius:6px;font-size:14px;background:rgba(255,82,82,0.1);border:1px solid rgba(255,82,82,0.3);color:var(--red);';al.textContent='Calculate a loan first.';setTimeout(function(){al.style.display='none';},3000);}return;}
      if(btn){btn.disabled=true;btn.textContent='Saving…';}
      try{
        var pl={member_email:currentMember.email,vehicle_price:price,down_payment:down,trade_in_value:trade,tax_rate:taxPct,loan_term_months:term,interest_rate:apr,loan_amount:parseInt(re.dataset.financed),monthly_payment:parseFloat(re.dataset.monthly),total_interest:parseInt(re.dataset.totalInterest),total_cost:parseInt(re.dataset.totalCost)};
        if(_loanComparisonActive){var bR=document.getElementById('loan-b-results');if(bR&&bR.style.display!=='none')pl.scenario_b={term:parseInt(document.getElementById('loan-b-term').value),apr:parseFloat(document.getElementById('loan-b-rate').value),monthly_payment:parseFloat(bR.dataset.monthly),total_interest:parseInt(bR.dataset.totalInterest),total_cost:parseInt(bR.dataset.totalCost)};}
        var r=await fetch('/api/loan-calculator',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(pl)});
        var d=await r.json();
        if(d.success){if(btn){btn.disabled=false;btn.textContent='✅ Saved!';setTimeout(function(){btn.textContent='💾 Save';},2500);}if(al){al.style.cssText='display:block;padding:10px 14px;border-radius:6px;font-size:14px;background:rgba(0,230,118,0.08);border:1px solid rgba(0,230,118,0.3);color:var(--green);';al.textContent='✅ Saved to history.';setTimeout(function(){al.style.display='none';},3000);}loadLoanHistory();}
        else throw new Error(d.message||'Save failed');
      }catch(e){if(btn){btn.disabled=false;btn.textContent='💾 Save';}if(al){al.style.cssText='display:block;padding:10px 14px;border-radius:6px;font-size:14px;background:rgba(255,82,82,0.1);border:1px solid rgba(255,82,82,0.3);color:var(--red);';al.textContent='Failed: '+e.message;setTimeout(function(){al.style.display='none';},4000);}}
    }

    async function loadLoanHistory() {
      if(!currentMember||!currentMember.email) return;
      try{
        var r=await fetch('/api/loan-calculator/history?email='+encodeURIComponent(currentMember.email));
        var d=await r.json(); if(!d.success||!d.history||!d.history.length) return;
        _loanHistoryCache=d.history;
        var hs=document.getElementById('loan-history-section'),hl=document.getElementById('loan-history-list'); if(!hs||!hl) return;
        hl.innerHTML=d.history.map(function(h,i){
          var dt=new Date(h.created_at).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});
          var pr=h.vehicle_price?'$'+Math.round(h.vehicle_price).toLocaleString():'No price';
          var mo=h.monthly_payment?'$'+parseFloat(h.monthly_payment).toFixed(2)+'/mo':'—';
          return '<div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--border);cursor:pointer;" onclick="loanLoadHistory('+i+')"><div style="font-size:20px;">💳</div><div style="flex:1;min-width:0;"><div style="font-weight:600;font-size:14px;color:var(--text-primary);">'+(h.scenario_b?'⚖️ ':'')+pr+' · '+h.loan_term_months+'mo @ '+parseFloat(h.interest_rate).toFixed(2)+'%</div><div style="font-size:11px;color:var(--text-secondary);margin-top:2px;">'+mo+' · '+dt+'</div></div><div style="font-size:12px;color:var(--orange);font-weight:600;">Load →</div></div>';
        }).join('');
        hs.style.display='block';
      }catch(e){}
    }

    function loanLoadHistory(i) {
      var h=_loanHistoryCache[i]; if(!h) return;
      if(h.vehicle_price!=null) document.getElementById('loan-a-price').value=Math.round(h.vehicle_price);
      if(h.down_payment!=null)  document.getElementById('loan-a-down').value=h.down_payment||0;
      if(h.trade_in_value!=null)document.getElementById('loan-a-tradein').value=h.trade_in_value||'';
      if(h.tax_rate!=null)      document.getElementById('loan-a-tax').value=h.tax_rate||8.0;
      if(h.loan_term_months)    document.getElementById('loan-a-term').value=h.loan_term_months;
      if(h.interest_rate!=null) document.getElementById('loan-a-rate').value=parseFloat(h.interest_rate).toFixed(2);
      calcLoan('a');
      var card=document.getElementById('loan-calc-card'); if(card) card.scrollIntoView({behavior:'smooth',block:'start'});
    }

  