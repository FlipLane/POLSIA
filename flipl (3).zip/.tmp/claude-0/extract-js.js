const fs = require("fs");
const html = fs.readFileSync("public/byrddawgsos.html", "utf8");
const scripts = [];
const re = /<script[^>]*>([\s\S]*?)<\/script>/gi;
let m;
while ((m = re.exec(html)) !== null) {
  scripts.push(m[1]);
}
const combined = scripts.join("\n");
fs.writeFileSync(".tmp/claude-0/byrddawgsos-script.js", combined);
console.log("Extracted " + scripts.length + " script blocks, total " + combined.length + " chars");
