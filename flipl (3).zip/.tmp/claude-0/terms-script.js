
    !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
    n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
    n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
    t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
    document,'script','https://connect.facebook.net/en_US/fbevents.js');
    fbq('init', '1498257195051913');
    fbq('init', '1297854672218437');
    fbq('track', 'PageView');
    

    // ============================================================
    // Terms of Service — Dynamic loading + member acceptance
    // ============================================================

    // Parse URL params
    const urlParams = new URLSearchParams(window.location.search);
    const memberEmail = urlParams.get('email') || '';
    const memberType = urlParams.get('type') || 'member'; // 'member' | 'affiliate'
    const redirectAfter = urlParams.get('redirect') || '';

    let currentTermsVersion = null;
    let memberSignedVersion = null;
    let memberSignedAt = null;
    let hasSignedCurrent = false;
    let needsResign = false;
    let hasScrolledToBottom = false;

    // Format date
    function fmtDate(iso) {
        if (!iso) return '—';
        return new Date(iso).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
    }
    function fmtDateTime(iso) {
        if (!iso) return '—';
        return new Date(iso).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    }

    // Load Terms content
    async function loadTerms() {
        try {
            const resp = await fetch('/api/terms');
            const data = await resp.json();
            if (!data.success || !data.terms) {
                document.getElementById('terms-body').innerHTML = '<p style="color:#a0a0a0;text-align:center;padding:40px">Terms content unavailable. Please try again later.</p>';
                return;
            }

            const t = data.terms;
            currentTermsVersion = t.version;

            document.getElementById('terms-body').innerHTML = t.content || '';
            document.getElementById('terms-updated').textContent = t.created_at ? 'Last updated: ' + fmtDate(t.created_at) : '';

            if (t.version) {
                document.getElementById('terms-version-num').textContent = t.version;
                document.getElementById('terms-version-badge').style.display = 'block';
            }

            // Track scroll position for the accept button
            trackScroll();

            // Load member's signing status if email provided
            if (memberEmail) {
                await loadMemberStatus();
            }

        } catch (e) {
            console.error('Terms load error:', e);
            document.getElementById('terms-body').innerHTML = '<p style="color:#a0a0a0;text-align:center;padding:40px">Error loading Terms. Please refresh the page.</p>';
        }
    }

    // Check if member has signed
    async function loadMemberStatus() {
        try {
            const resp = await fetch(`/api/member/terms-check?email=${encodeURIComponent(memberEmail)}&type=${memberType}`);
            if (!resp.ok) {
                // Not found — show accept button if version exists
                if (currentTermsVersion) showAcceptButton();
                return;
            }
            const data = await resp.json();
            if (!data.success) {
                if (currentTermsVersion) showAcceptButton();
                return;
            }

            hasSignedCurrent = data.signed;
            needsResign = data.needsResign;
            memberSignedVersion = data.signedVersion;
            memberSignedAt = data.signedAt;

            renderAcceptanceSection();

        } catch (e) {
            console.warn('Member status check failed:', e.message);
            if (currentTermsVersion) showAcceptButton();
        }
    }

    function renderAcceptanceSection() {
        const section = document.getElementById('acceptance-section');
        section.style.display = 'block';

        if (hasSignedCurrent) {
            // Already signed current version
            section.className = 'acceptance-section signed';
            section.innerHTML = `
                <div class="signed-badge">
                    <div class="checkmark">✅</div>
                    <div class="signed-text">
                        <h3>You've signed Version ${memberSignedVersion}</h3>
                        <p>Signed on ${fmtDateTime(memberSignedAt)} &middot; ${memberEmail}</p>
                    </div>
                </div>
                <p style="font-size:0.88rem;color:var(--text-dim);margin-top:8px">Your electronic signature is recorded in our system. You're all set.</p>
                ${redirectAfter ? `<div style="margin-top:16px"><a href="${escapeHtml(redirectAfter)}" style="display:inline-block;padding:12px 24px;background:var(--green);color:#000;font-weight:700;border-radius:10px;text-decoration:none;font-size:0.95rem;">Continue to Dashboard →</a></div>` : ''}
            `;
        } else if (needsResign) {
            // Signed old version — needs to re-sign
            section.className = 'acceptance-section needs-resign';
            section.innerHTML = `
                <div class="resign-banner">
                    <strong>⚠️ Updated Terms Available</strong><br>
                    You signed Version ${memberSignedVersion}, but the Terms have been updated to Version ${currentTermsVersion}. Please review and accept the new version to continue using your dashboard.
                </div>
                ${buildAcceptForm()}
            `;
            wireAcceptButton();
        } else {
            // Hasn't signed yet
            showAcceptButton();
        }
    }

    function showAcceptButton() {
        if (!currentTermsVersion) return;
        const section = document.getElementById('acceptance-section');
        section.style.display = 'block';
        section.innerHTML = buildAcceptForm();
        wireAcceptButton();
    }

    function buildAcceptForm() {
        return `
            <h3 style="font-family:'Space Grotesk',sans-serif;font-size:1.1rem;font-weight:700;margin-bottom:16px;color:var(--text-primary)">
                ${memberEmail ? 'Accept These Terms' : 'Electronic Acceptance'}
            </h3>
            ${!memberEmail ? `<p style="font-size:0.9rem;color:var(--text-secondary);margin-bottom:16px">To accept these terms, return to your dashboard and sign in, or visit <a href="/terms?email=YOUR_EMAIL&type=member" style="color:var(--green)">this page with your email</a>.</p>` : `
            <div class="accept-confirm">
                <label style="cursor:pointer;display:flex;align-items:flex-start;gap:10px">
                    <input type="checkbox" id="accept-checkbox" onchange="updateAcceptBtn()">
                    <span>I have read, understood, and agree to be bound by the FlipLane Terms of Service &amp; Membership Agreement (Version ${currentTermsVersion}). I acknowledge this constitutes a legally binding electronic signature on behalf of <strong>${escapeHtml(memberEmail)}</strong>.</span>
                </label>
            </div>
            <button class="accept-btn" id="accept-btn" onclick="submitAcceptance()" disabled>
                ✍️ I Accept These Terms — Version ${currentTermsVersion}
            </button>
            <div class="accept-status" id="accept-status"></div>
            <p class="scroll-note">Please scroll through the full Terms before accepting.</p>
            `}
        `;
    }

    function wireAcceptButton() {
        // Nothing extra needed — onclick is inline
    }

    function updateAcceptBtn() {
        const btn = document.getElementById('accept-btn');
        const cb = document.getElementById('accept-checkbox');
        if (btn && cb) btn.disabled = !cb.checked;
    }

    async function submitAcceptance() {
        const btn = document.getElementById('accept-btn');
        const status = document.getElementById('accept-status');
        if (!btn || btn.disabled) return;

        btn.disabled = true;
        btn.textContent = 'Recording signature…';
        status.textContent = '';
        status.className = 'accept-status';

        try {
            const resp = await fetch('/api/member/sign-terms', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    email: memberEmail,
                    type: memberType,
                    termsVersion: currentTermsVersion
                })
            });
            const data = await resp.json();

            if (data.success) {
                status.textContent = '✅ Terms accepted! Signature recorded.';
                status.className = 'accept-status success';
                hasSignedCurrent = true;
                memberSignedVersion = currentTermsVersion;
                memberSignedAt = new Date().toISOString();

                setTimeout(() => {
                    renderAcceptanceSection();
                    // Auto-redirect after signing
                    if (redirectAfter) {
                        window.location.href = redirectAfter;
                    } else if (memberType === 'member') {
                        // Redirect back to ByrddawgsOS (member dashboard) after signing
                        window.location.href = '/byrddawgsos?section=credentials';
                    } else {
                        window.location.href = '/affiliateos?email=' + encodeURIComponent(memberEmail);
                    }
                }, 1500);
            } else {
                status.textContent = data.message || 'Failed to record acceptance. Please try again.';
                status.className = 'accept-status error';
                btn.disabled = false;
                btn.textContent = '✍️ I Accept These Terms — Version ' + currentTermsVersion;
            }
        } catch (e) {
            status.textContent = 'Network error. Please check your connection and try again.';
            status.className = 'accept-status error';
            btn.disabled = false;
            btn.textContent = '✍️ I Accept These Terms — Version ' + currentTermsVersion;
        }
    }

    // Track scroll to encourage reading
    function trackScroll() {
        const onScroll = () => {
            const scrolled = window.scrollY + window.innerHeight;
            const total = document.body.scrollHeight;
            if (scrolled >= total - 200) {
                hasScrolledToBottom = true;
                window.removeEventListener('scroll', onScroll);
            }
        };
        window.addEventListener('scroll', onScroll, { passive: true });
    }

    function escapeHtml(str) {
        return String(str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }

    // Init
    loadTerms();
    