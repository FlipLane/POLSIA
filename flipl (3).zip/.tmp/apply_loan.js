const fs = require('fs');
const lines = fs.readFileSync('./public/byrddawgsos.html', 'utf8').split('\n');

// Take only the first valid copy (ends at first </html> tag)
let firstHtmlEnd = -1;
for (let i = 0; i < lines.length; i++) {
  if (lines[i].trim() === '</html>') {
    firstHtmlEnd = i + 1;
    break;
  }
}
console.log('First </html> at line:', firstHtmlEnd);
let html = lines.slice(0, firstHtmlEnd).join('\n');

console.log('Base lines:', html.split('\n').length);
console.log('Has ROI Analyzer:', html.includes('deal-roi-analyzer-card'));
console.log('Has Shipping:', html.includes('Shipping'));
console.log('Has Loan Estimator already:', html.includes('loan-calc-card'));

if (html.includes('loan-calc-card')) {
  console.log('Loan estimator already present, skipping HTML changes');
  fs.writeFileSync('./public/byrddawgsos.html', html);
  console.log('Fixed corrupted HTML. Lines:', html.split('\n').length);
  process.exit(0);
}

// CHANGE 1: Add "Estimate Loan" button to profit calculator
html = html.replace(
  'onclick="scrollToMarketValue()">📊 Market Value →</button>\n          </div>',
  'onclick="scrollToMarketValue()">📊 Market Value →</button>\n            <button type="button" class="btn btn-secondary" style="font-size: 12px; padding: 6px 14px;" onclick="scrollToLoanCalc()">💳 Estimate Loan →</button>\n          </div>'
);

// CHANGE 2: Add Estimate Loan button to ACV results
html = html.replace(
  'onclick="acvToProfitCalc()">📊 Calculate Profit →</button>',
  'onclick="acvToProfitCalc()">📊 Calculate Profit →</button>\n                <button class="btn btn-secondary" style="font-size: 12px; padding: 7px 14px;" onclick="acvToLoanCalc()">💳 Estimate Loan →</button>'
);

// CHANGE 3: Insert Loan Estimator HTML before "Submit a Vehicle Deal"
const submitDealMarker = '        <div class="content-card">\n          <div class="content-card-title">📝 Submit a Vehicle Deal</div>';
const loanHtml = `
        <!-- ====== LOAN & PAYMENT ESTIMATOR ====== -->
        <div class="content-card" id="loan-calc-card">
          <div style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:4px;">
            <div>
              <div class="content-card-title" style="margin-bottom:6px;">💳 Loan &amp; Payment Estimator</div>
              <p style="font-size:13px;color:var(--text-secondary);margin:0;">Calculate monthly payments, total interest, and compare financing scenarios side by side.</p>
            </div>
            <button type="button" onclick="loanToggleComparison()" id="loan-compare-btn" class="btn btn-secondary" style="font-size:12px;white-space:nowrap;flex-shrink:0;">⚖️ Compare Scenarios</button>
          </div>
          <div id="loan-fred-rate-badge" style="margin:14px 0 18px;"></div>
          <div id="loan-scenarios-container" style="display:grid;grid-template-columns:1fr;gap:20px;">
            <div id="loan-scenario-a">
              <div id="loan-a-label" style="display:none;font-size:11px;font-weight:700;color:var(--orange);text-transform:uppercase;letter-spacing:0.8px;margin-bottom:14px;padding:6px 12px;background:rgba(255,152,0,0.08);border:1px solid rgba(255,152,0,0.25);border-radius:6px;display:inline-block;">Scenario A</div>
              <div class="form-grid" style="margin-top:12px;">
                <div class="form-group">
                  <label>Vehicle Price ($)</label>
                  <div style="display:flex;gap:8px;">
                    <input type="number" id="loan-a-price" placeholder="e.g., 18500" step="100" min="0" oninput="calcLoan('a')" style="flex:1;min-width:0;" />
                    <button type="button" class="btn btn-secondary" style="font-size:11px;padding:0 10px;white-space:nowrap;height:42px;" onclick="loanFromAcvMid('a')">ACV Mid</button>
                  </div>
                </div>
                <div class="form-group">
                  <label>Down Payment ($)</label>
                  <input type="number" id="loan-a-down" placeholder="e.g., 3000" step="100" min="0" oninput="calcLoan('a')" />
                </div>
                <div class="form-group">
                  <label>Trade-in Value ($) <span style="color:var(--text-secondary);font-weight:400;">(optional)</span></label>
                  <input type="number" id="loan-a-tradein" placeholder="e.g., 2000" step="100" min="0" oninput="calcLoan('a')" />
                </div>
                <div class="form-group">
                  <label>Sales Tax Rate (%)</label>
                  <input type="number" id="loan-a-tax" value="8.0" placeholder="e.g., 8.5" step="0.1" min="0" max="20" oninput="calcLoan('a')" />
                </div>
                <div class="form-group">
                  <label>Loan Term</label>
                  <select id="loan-a-term" onchange="calcLoan('a')">
                    <option value="24">24 months (2 yr)</option>
                    <option value="36">36 months (3 yr)</option>
                    <option value="48">48 months (4 yr)</option>
                    <option value="60" selected>60 months (5 yr)</option>
                    <option value="72">72 months (6 yr)</option>
                    <option value="84">84 months (7 yr)</option>
                  </select>
                </div>
                <div class="form-group">
                  <label>Interest Rate (% APR) <span id="loan-a-rate-hint" style="font-size:11px;color:var(--orange);font-weight:400;"></span></label>
                  <input type="number" id="loan-a-rate" placeholder="e.g., 7.50" step="0.01" min="0" max="30" oninput="calcLoan('a')" />
                </div>
              </div>
              <div id="loan-a-results" style="display:none;margin-top:20px;padding:20px;background:var(--bg-input);border-radius:var(--radius-sm);border:1px solid var(--border-light);"></div>
            </div>
            <div id="loan-scenario-b" style="display:none;">
              <div style="font-size:11px;font-weight:700;color:var(--blue);text-transform:uppercase;letter-spacing:0.8px;margin-bottom:14px;padding:6px 12px;background:rgba(68,138,255,0.08);border:1px solid rgba(68,138,255,0.25);border-radius:6px;display:inline-block;">Scenario B</div>
              <div class="form-grid" style="margin-top:12px;">
                <div class="form-group">
                  <label>Vehicle Price ($)</label>
                  <div style="display:flex;gap:8px;">
                    <input type="number" id="loan-b-price" placeholder="e.g., 18500" step="100" min="0" oninput="calcLoan('b')" style="flex:1;min-width:0;" />
                    <button type="button" class="btn btn-secondary" style="font-size:11px;padding:0 10px;white-space:nowrap;height:42px;" onclick="loanFromAcvMid('b')">ACV Mid</button>
                  </div>
                </div>
                <div class="form-group">
                  <label>Down Payment ($)</label>
                  <input type="number" id="loan-b-down" placeholder="e.g., 3000" step="100" min="0" oninput="calcLoan('b')" />
                </div>
                <div class="form-group">
                  <label>Trade-in Value ($) <span style="color:var(--text-secondary);font-weight:400;">(optional)</span></label>
                  <input type="number" id="loan-b-tradein" placeholder="e.g., 2000" step="100" min="0" oninput="calcLoan('b')" />
                </div>
                <div class="form-group">
                  <label>Sales Tax Rate (%)</label>
                  <input type="number" id="loan-b-tax" value="8.0" placeholder="e.g., 8.5" step="0.1" min="0" max="20" oninput="calcLoan('b')" />
                </div>
                <div class="form-group">
                  <label>Loan Term</label>
                  <select id="loan-b-term" onchange="calcLoan('b')">
                    <option value="24">24 months (2 yr)</option>
                    <option value="36">36 months (3 yr)</option>
                    <option value="48">48 months (4 yr)</option>
                    <option value="60" selected>60 months (5 yr)</option>
                    <option value="72">72 months (6 yr)</option>
                    <option value="84">84 months (7 yr)</option>
                  </select>
                </div>
                <div class="form-group">
                  <label>Interest Rate (% APR) <span id="loan-b-rate-hint" style="font-size:11px;color:var(--orange);font-weight:400;"></span></label>
                  <input type="number" id="loan-b-rate" placeholder="e.g., 7.50" step="0.01" min="0" max="30" oninput="calcLoan('b')" />
                </div>
              </div>
              <div id="loan-b-results" style="display:none;margin-top:20px;padding:20px;background:var(--bg-input);border-radius:var(--radius-sm);border:1px solid rgba(68,138,255,0.2);"></div>
            </div>
          </div>
          <div id="loan-comparison-diff" style="display:none;"></div>
          <div style="margin-top:20px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">
            <div style="display:flex;gap:10px;flex-wrap:wrap;">
              <button type="button" class="btn btn-primary" onclick="saveLoanCalc()" id="loan-save-btn" style="min-width:100px;">💾 Save</button>
              <button type="button" class="btn btn-secondary" onclick="loanClear()">Clear</button>
            </div>
            <a href="https://secure.carsforsale.com/ssfinance.aspx?jesxel=741035" target="_blank" rel="noopener" class="btn btn-secondary" style="font-size:12px;text-decoration:none;">🏦 Apply for Financing →</a>
          </div>
          <div id="loan-save-alert" style="display:none;margin-top:12px;padding:10px 14px;border-radius:var(--radius-xs);font-size:14px;"></div>
          <div id="loan-history-section" style="display:none;margin-top:24px;border-top:1px solid var(--border);padding-top:20px;">
            <div style="font-size:11px;font-weight:700;color:var(--text-secondary);text-transform:uppercase;letter-spacing:0.8px;margin-bottom:12px;">📋 Recent Calculations</div>
            <div id="loan-history-list"></div>
          </div>
        </div>

`;

if (html.includes(submitDealMarker)) {
  html = html.replace(submitDealMarker, loanHtml + submitDealMarker);
  console.log('✅ Loan estimator HTML inserted');
} else {
  console.log('WARNING: submit deal marker not found, trying alternate insertion');
  // Just before the first "Submit a Vehicle Deal" occurrence
  const idx = html.indexOf('Submit a Vehicle Deal');
  if (idx > 0) {
    // Find the start of that content-card
    const cardStart = html.lastIndexOf('        <div class="content-card">', idx);
    html = html.slice(0, cardStart) + loanHtml + html.slice(cardStart);
    console.log('✅ Loan HTML inserted via fallback at position:', cardStart);
  }
}

// CHANGE 4: Add initLoanEstimator() to loadSectionData
html = html.replace(
  "if (section === 'deals') { loadDeals(); loadAcvHistory(); loadRoiHistory(); }",
  "if (section === 'deals') { loadDeals(); loadAcvHistory(); loadRoiHistory(); initLoanEstimator(); }"
);
html = html.replace(
  "if (section === 'deals') { loadDeals(); loadAcvHistory(); }",
  "if (section === 'deals') { loadDeals(); loadAcvHistory(); initLoanEstimator(); }"
);

// CHANGE 5: Add scrollToLoanCalc and acvToLoanCalc before scrollToAcvCalc
const scrollAcvFn = "    function scrollToAcvCalc() {";
if (html.includes(scrollAcvFn)) {
  html = html.replace(
    scrollAcvFn,
    `    function scrollToLoanCalc() {
      var card = document.getElementById('loan-calc-card');
      if (card) card.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function acvToLoanCalc() {
      if (typeof _lastAcvMid === 'undefined' || !_lastAcvMid) { showToast('Run the ACV Calculator first', true); return; }
      var priceEl = document.getElementById('loan-a-price');
      if (priceEl) { priceEl.value = Math.round(_lastAcvMid); calcLoan('a'); }
      scrollToLoanCalc();
    }

    ` + scrollAcvFn
  );
  console.log('✅ scrollToLoanCalc + acvToLoanCalc added');
}

// CHANGE 6: Insert Loan JS before last </script>
const loanJS = `
    // ====== LOAN & PAYMENT ESTIMATOR ======
    var _loanFredRate = null, _loanFredDate = null, _loanComparisonActive = false, _loanHistoryCache = [];

    async function initLoanEstimator() {
      try {
        var resp = await fetch('/api/fred-rate'); var data = await resp.json();
        if (data.success && data.rate) {
          _loanFredRate = data.rate; _loanFredDate = data.date || null;
          ['a','b'].forEach(function(s) { var el=document.getElementById('loan-'+s+'-rate'); if(el&&!el.value) el.value=_loanFredRate.toFixed(2); });
          var dl = _loanFredDate ? new Date(_loanFredDate).toLocaleDateString('en-US',{month:'short',year:'numeric'}) : '';
          var ht = 'Current avg: '+_loanFredRate.toFixed(2)+'%'+(dl?' · '+dl:'');
          ['a','b'].forEach(function(s){ var h=document.getElementById('loan-'+s+'-rate-hint'); if(h) h.textContent=ht; });
          var badge=document.getElementById('loan-fred-rate-badge');
          if(badge) badge.innerHTML='<div style="display:inline-flex;align-items:center;gap:8px;background:rgba(255,152,0,0.08);border:1px solid rgba(255,152,0,0.25);border-radius:8px;padding:6px 14px;font-size:12px;"><span style="color:var(--orange);">📊</span><span style="color:var(--text-secondary);">Avg 60-mo auto rate:</span><span style="color:var(--orange);font-weight:700;">'+_loanFredRate.toFixed(2)+'%</span>'+(dl?'<span style="color:var(--text-dim);font-size:11px;">('+dl+')</span>':'')+'<span style="color:var(--text-dim);font-size:11px;">· FRED / editable</span></div>';
        }
      } catch(e){}
      loadLoanHistory();
    }

    function calcLoan(scenario) {
      var p='loan-'+scenario+'-';
      var price=parseFloat(document.getElementById(p+'price').value)||0, down=parseFloat(document.getElementById(p+'down').value)||0;
      var trade=parseFloat(document.getElementById(p+'tradein').value)||0, taxPct=parseFloat(document.getElementById(p+'tax').value)||0;
      var term=parseInt(document.getElementById(p+'term').value)||60, apr=parseFloat(document.getElementById(p+'rate').value);
      var resultsEl=document.getElementById('loan-'+scenario+'-results');
      if (!price||isNaN(apr)||apr<0){if(resultsEl)resultsEl.style.display='none';updateLoanComparison();return;}
      var taxAmt=price*(taxPct/100), financed=Math.max(0,price+taxAmt-down-trade), mr=apr/12/100;
      var monthly=0,totalInterest=0,totalOOP=0;
      if(financed<=0){monthly=0;totalInterest=0;totalOOP=price+taxAmt;}
      else if(mr===0){monthly=financed/term;totalInterest=0;totalOOP=down+trade+financed;}
      else{var f=Math.pow(1+mr,term);monthly=financed*mr*f/(f-1);totalInterest=monthly*term-financed;totalOOP=down+trade+monthly*term;}
      var fi=0,fp=0,li=0,lp=0;
      if(financed>0&&mr>0){fi=financed*mr;fp=monthly-fi;var bal=financed*Math.pow(1+mr,term-1)-monthly*(Math.pow(1+mr,term-1)-1)/mr;li=Math.max(0,bal*mr);lp=Math.max(0,Math.min(bal,monthly-li));}
      else if(financed>0){fp=monthly;lp=monthly;}
      var fmt=function(n){return '$'+Math.abs(n).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});};
      var fmtI=function(n){return '$'+Math.abs(Math.round(n)).toLocaleString();};
      var isCash=financed<=0;
      if(resultsEl){
        resultsEl.innerHTML='<div style="display:grid;grid-template-columns:repeat(2,1fr);gap:16px;text-align:center;margin-bottom:'+(isCash?'0':'20px')+';"><div><div class="stat-label">Loan Amount</div><div class="stat-value" style="font-size:20px;">'+(isCash?'<span style="color:var(--green);">Cash Deal</span>':fmtI(financed))+'</div><div class="stat-sub">After down + trade-in + tax</div></div><div><div class="stat-label">Monthly Payment</div><div class="stat-value" style="font-size:26px;color:var(--green);">'+(isCash?'—':fmt(monthly))+'</div><div class="stat-sub">'+(isCash?'No financing':term+' mo @ '+apr.toFixed(2)+'% APR')+'</div></div><div><div class="stat-label">Total Interest</div><div class="stat-value" style="font-size:20px;color:'+(totalInterest>0?'var(--yellow)':'var(--green)')+';">'+fmtI(totalInterest)+'</div><div class="stat-sub">Cost of borrowing</div></div><div><div class="stat-label">Total Out of Pocket</div><div class="stat-value" style="font-size:20px;">'+fmtI(totalOOP)+'</div><div class="stat-sub">Down + all payments</div></div></div>'+(!isCash&&financed>0?'<div style="border-top:1px solid var(--border);padding-top:16px;"><div style="font-size:11px;font-weight:700;color:var(--text-secondary);text-transform:uppercase;letter-spacing:0.8px;margin-bottom:12px;">📋 Amortization Summary</div><div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;font-size:13px;"><div style="background:var(--bg-card);border:1px solid var(--border-light);border-radius:var(--radius-xs);padding:12px;"><div style="font-weight:600;font-size:12px;color:var(--text-secondary);margin-bottom:8px;">Payment #1</div><div style="display:flex;justify-content:space-between;margin-bottom:4px;"><span style="color:var(--text-secondary);">Interest</span><span style="color:var(--red);">'+fmt(fi)+'</span></div><div style="display:flex;justify-content:space-between;"><span style="color:var(--text-secondary);">Principal</span><span style="color:var(--green);">'+fmt(fp)+'</span></div></div><div style="background:var(--bg-card);border:1px solid var(--border-light);border-radius:var(--radius-xs);padding:12px;"><div style="font-weight:600;font-size:12px;color:var(--text-secondary);margin-bottom:8px;">Payment #'+term+'</div><div style="display:flex;justify-content:space-between;margin-bottom:4px;"><span style="color:var(--text-secondary);">Interest</span><span style="color:var(--red);">'+fmt(li)+'</span></div><div style="display:flex;justify-content:space-between;"><span style="color:var(--text-secondary);">Principal</span><span style="color:var(--green);">'+fmt(lp)+'</span></div></div></div></div>':'');
        resultsEl.style.display='block';
        resultsEl.dataset.financed=Math.round(financed); resultsEl.dataset.monthly=monthly.toFixed(2);
        resultsEl.dataset.totalInterest=Math.round(totalInterest); resultsEl.dataset.totalCost=Math.round(totalOOP);
        resultsEl.dataset.term=term; resultsEl.dataset.apr=apr;
      }
      updateLoanComparison();
    }

    function updateLoanComparison() {
      var cd=document.getElementById('loan-comparison-diff'); if(!cd||!_loanComparisonActive) return;
      var aR=document.getElementById('loan-a-results'), bR=document.getElementById('loan-b-results');
      if(!aR||aR.style.display==='none'||!bR||bR.style.display==='none'){cd.style.display='none';return;}
      var aI=parseInt(aR.dataset.totalInterest)||0,bI=parseInt(bR.dataset.totalInterest)||0;
      var aM=parseFloat(aR.dataset.monthly)||0,bM=parseFloat(bR.dataset.monthly)||0;
      var aC=parseInt(aR.dataset.totalCost)||0,bC=parseInt(bR.dataset.totalCost)||0;
      var fD=function(n){return '$'+Math.abs(Math.round(n)).toLocaleString();};
      cd.innerHTML='<div style="background:rgba(0,230,118,0.04);border:1px solid var(--green-border);border-radius:var(--radius-sm);padding:16px;margin-top:16px;"><div style="font-size:11px;font-weight:700;color:var(--green);text-transform:uppercase;letter-spacing:0.8px;margin-bottom:14px;">⚖️ Scenario Comparison</div><div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;text-align:center;"><div><div style="font-size:11px;color:var(--text-secondary);margin-bottom:4px;">Monthly diff</div><div style="font-weight:700;font-size:18px;">$'+Math.abs(aM-bM).toFixed(2)+'/mo</div><div style="font-size:11px;color:var(--green);margin-top:2px;">Scenario '+(aM<=bM?'A':'B')+' lower</div></div><div><div style="font-size:11px;color:var(--text-secondary);margin-bottom:4px;">Total interest diff</div><div style="font-weight:700;font-size:18px;color:var(--yellow);">'+fD(Math.abs(aI-bI))+'</div><div style="font-size:11px;color:var(--green);margin-top:2px;">Save w/ Scenario '+(aI<=bI?'A':'B')+'</div></div><div><div style="font-size:11px;color:var(--text-secondary);margin-bottom:4px;">Total cost diff</div><div style="font-weight:700;font-size:18px;">'+fD(Math.abs(aC-bC))+'</div><div style="font-size:11px;color:var(--green);margin-top:2px;">Scenario '+(aC<=bC?'A':'B')+' costs less</div></div></div></div>';
      cd.style.display='block';
    }

    function loanToggleComparison() {
      _loanComparisonActive=!_loanComparisonActive;
      var sB=document.getElementById('loan-scenario-b'),ct=document.getElementById('loan-scenarios-container');
      var cb=document.getElementById('loan-compare-btn'),al=document.getElementById('loan-a-label'),cd=document.getElementById('loan-comparison-diff');
      if(_loanComparisonActive){
        sB.style.display='block'; if(window.innerWidth>=700) ct.style.gridTemplateColumns='1fr 1fr';
        if(cb) cb.textContent='✕ Single Scenario'; if(al) al.style.display='inline-block';
        ['price','down','tradein','tax','rate'].forEach(function(f){var a=document.getElementById('loan-a-'+f),b=document.getElementById('loan-b-'+f);if(a&&b&&a.value&&!b.value)b.value=a.value;});
        var at=document.getElementById('loan-a-term'),bt=document.getElementById('loan-b-term'); if(at&&bt) bt.value=at.value;
        var ha=document.getElementById('loan-a-rate-hint'),hb=document.getElementById('loan-b-rate-hint'); if(ha&&hb) hb.textContent=ha.textContent;
        calcLoan('b');
      } else {
        sB.style.display='none'; ct.style.gridTemplateColumns='1fr';
        if(cb) cb.textContent='⚖️ Compare Scenarios'; if(al) al.style.display='none'; if(cd) cd.style.display='none';
      }
    }

    function loanFromAcvMid(scenario) {
      var mid=(typeof _lastAcvMid!=='undefined'&&_lastAcvMid)||(function(){var e=document.getElementById('acv-price-mid');if(!e||!e.textContent||e.textContent.trim()==='—')return null;return parseFloat(e.textContent.replace(/[$,\\s]/g,''))||null;})();
      if(!mid||mid<=0){showToast('No ACV result yet — run the ACV Calculator first',true);return;}
      var pe=document.getElementById('loan-'+scenario+'-price'); if(pe){pe.value=Math.round(mid);calcLoan(scenario);showToast('ACV Mid $'+Math.round(mid).toLocaleString()+' loaded');}
    }

    function loanClear() {
      ['a','b'].forEach(function(s){
        ['price','down','tradein'].forEach(function(f){var e=document.getElementById('loan-'+s+'-'+f);if(e)e.value='';});
        var tx=document.getElementById('loan-'+s+'-tax');if(tx)tx.value='8.0';
        var tm=document.getElementById('loan-'+s+'-term');if(tm)tm.value='60';
        var rt=document.getElementById('loan-'+s+'-rate');if(rt)rt.value=_loanFredRate?_loanFredRate.toFixed(2):'';
        var rs=document.getElementById('loan-'+s+'-results');if(rs)rs.style.display='none';
      });
      var cd=document.getElementById('loan-comparison-diff');if(cd)cd.style.display='none';
    }

    async function saveLoanCalc() {
      var btn=document.getElementById('loan-save-btn'),al=document.getElementById('loan-save-alert');
      var price=parseFloat(document.getElementById('loan-a-price').value)||0,down=parseFloat(document.getElementById('loan-a-down').value)||0;
      var trade=parseFloat(document.getElementById('loan-a-tradein').value)||0,taxPct=parseFloat(document.getElementById('loan-a-tax').value)||0;
      var term=parseInt(document.getElementById('loan-a-term').value)||60,apr=parseFloat(document.getElementById('loan-a-rate').value);
      var re=document.getElementById('loan-a-results');
      if(!price||isNaN(apr)||!re||re.style.display==='none'){if(al){al.style.cssText='display:block;padding:10px 14px;border-radius:6px;font-size:14px;background:rgba(255,82,82,0.1);border:1px solid rgba(255,82,82,0.3);color:var(--red);';al.textContent='Calculate a loan first.';setTimeout(function(){al.style.display='none';},3000);}return;}
      if(btn){btn.disabled=true;btn.textContent='Saving…';}
      try{
        var pl={member_email:currentMember.email,vehicle_price:price,down_payment:down,trade_in_value:trade,tax_rate:taxPct,loan_term_months:term,interest_rate:apr,loan_amount:parseInt(re.dataset.financed),monthly_payment:parseFloat(re.dataset.monthly),total_interest:parseInt(re.dataset.totalInterest),total_cost:parseInt(re.dataset.totalCost)};
        if(_loanComparisonActive){var bR=document.getElementById('loan-b-results');if(bR&&bR.style.display!=='none')pl.scenario_b={term:parseInt(document.getElementById('loan-b-term').value),apr:parseFloat(document.getElementById('loan-b-rate').value),monthly_payment:parseFloat(bR.dataset.monthly),total_interest:parseInt(bR.dataset.totalInterest),total_cost:parseInt(bR.dataset.totalCost)};}
        var r=await fetch('/api/loan-calculator',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(pl)});
        var d=await r.json();
        if(d.success){if(btn){btn.disabled=false;btn.textContent='✅ Saved!';setTimeout(function(){btn.textContent='💾 Save';},2500);}if(al){al.style.cssText='display:block;padding:10px 14px;border-radius:6px;font-size:14px;background:rgba(0,230,118,0.08);border:1px solid rgba(0,230,118,0.3);color:var(--green);';al.textContent='✅ Saved to history.';setTimeout(function(){al.style.display='none';},3000);}loadLoanHistory();}
        else throw new Error(d.message||'Save failed');
      }catch(e){if(btn){btn.disabled=false;btn.textContent='💾 Save';}if(al){al.style.cssText='display:block;padding:10px 14px;border-radius:6px;font-size:14px;background:rgba(255,82,82,0.1);border:1px solid rgba(255,82,82,0.3);color:var(--red);';al.textContent='Failed: '+e.message;setTimeout(function(){al.style.display='none';},4000);}}
    }

    async function loadLoanHistory() {
      if(!currentMember||!currentMember.email) return;
      try{
        var r=await fetch('/api/loan-calculator/history?email='+encodeURIComponent(currentMember.email));
        var d=await r.json(); if(!d.success||!d.history||!d.history.length) return;
        _loanHistoryCache=d.history;
        var hs=document.getElementById('loan-history-section'),hl=document.getElementById('loan-history-list'); if(!hs||!hl) return;
        hl.innerHTML=d.history.map(function(h,i){
          var dt=new Date(h.created_at).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});
          var pr=h.vehicle_price?'$'+Math.round(h.vehicle_price).toLocaleString():'No price';
          var mo=h.monthly_payment?'$'+parseFloat(h.monthly_payment).toFixed(2)+'/mo':'—';
          return '<div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--border);cursor:pointer;" onclick="loanLoadHistory('+i+')"><div style="font-size:20px;">💳</div><div style="flex:1;min-width:0;"><div style="font-weight:600;font-size:14px;color:var(--text-primary);">'+(h.scenario_b?'⚖️ ':'')+pr+' · '+h.loan_term_months+'mo @ '+parseFloat(h.interest_rate).toFixed(2)+'%</div><div style="font-size:11px;color:var(--text-secondary);margin-top:2px;">'+mo+' · '+dt+'</div></div><div style="font-size:12px;color:var(--orange);font-weight:600;">Load →</div></div>';
        }).join('');
        hs.style.display='block';
      }catch(e){}
    }

    function loanLoadHistory(i) {
      var h=_loanHistoryCache[i]; if(!h) return;
      if(h.vehicle_price!=null) document.getElementById('loan-a-price').value=Math.round(h.vehicle_price);
      if(h.down_payment!=null)  document.getElementById('loan-a-down').value=h.down_payment||0;
      if(h.trade_in_value!=null)document.getElementById('loan-a-tradein').value=h.trade_in_value||'';
      if(h.tax_rate!=null)      document.getElementById('loan-a-tax').value=h.tax_rate||8.0;
      if(h.loan_term_months)    document.getElementById('loan-a-term').value=h.loan_term_months;
      if(h.interest_rate!=null) document.getElementById('loan-a-rate').value=parseFloat(h.interest_rate).toFixed(2);
      calcLoan('a');
      var card=document.getElementById('loan-calc-card'); if(card) card.scrollIntoView({behavior:'smooth',block:'start'});
    }

`;

var lsc = html.lastIndexOf('  </script>');
if (lsc !== -1) {
  html = html.slice(0, lsc) + loanJS + html.slice(lsc);
  console.log('✅ Loan JS inserted');
} else {
  console.log('❌ Could not find </script> closing tag');
}

// Save
fs.writeFileSync('./public/byrddawgsos.html', html);
var fl = html.split('\n').length;
console.log('Final file size:', fl, 'lines');

// Verify
['loan-calc-card','initLoanEstimator','calcLoan','loanToggleComparison','/api/fred-rate','/api/loan-calculator',
 'scrollToLoanCalc','acvToLoanCalc','loan-comparison-diff','ROI Analyzer','Shipping','deal-roi-analyzer-card'].forEach(function(k){
  console.log((html.includes(k)?'✅':'❌ MISSING') + ' ' + k);
});
