const express = require('express');
const { Pool } = require('pg');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const axios = require('axios');
const multer = require('multer');
const FormData = require('form-data');
const docusign = require('./services/docusign');
const docuseal = require('./services/docuseal');
const OpenAI = require('openai');
const Stripe = require('stripe');
const stripe = Stripe(process.env.STRIPE_SECRET_KEY || 'sk_test_placeholder');
const nodemailer = require('nodemailer');

// Multer: memory storage for ID uploads (max 10MB)
const idUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];
    if (allowed.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only JPG, PNG, WebP, PDF allowed.'));
    }
  }
});

// Multer: memory storage for blog image uploads (max 5MB)
const blogImageUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    if (allowed.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only JPG, PNG, WebP, GIF allowed.'));
    }
  }
});

const app = express();
const port = process.env.PORT || 3000;

// Fail fast if DATABASE_URL is missing
if (!process.env.DATABASE_URL) {
  console.error('ERROR: DATABASE_URL environment variable is required');
  process.exit(1);
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL?.includes('localhost') ? false : { rejectUnauthorized: false }
});

// Payment link configured with success URL: https://flipl.polsia.app/welcome?email={CHECKOUT_SESSION_CLIENT_REFERENCE_ID}
// Stripe will substitute {CHECKOUT_SESSION_CLIENT_REFERENCE_ID} with the client_reference_id (email) after payment.
const STRIPE_PAYMENT_LINK = 'https://buy.stripe.com/28E4gB40j5lIcjk1JWcAo01';

// Helper to generate Stripe payment URL with success redirect
// The payment link already has success_url configured to:
//   https://flipl.polsia.app/welcome?email={CHECKOUT_SESSION_CLIENT_REFERENCE_ID}
// We pass client_reference_id + prefilled_email so Stripe can substitute the email
// into the success URL and pre-fill the checkout form.
function getStripePaymentUrl(email, host) {
  const baseUrl = STRIPE_PAYMENT_LINK;
  const clientRef = encodeURIComponent(email);
  // eslint-disable-next-line no-unused-vars
  const baseHost = host || process.env.APP_URL || 'https://flipl.polsia.app';

  return `${baseUrl}?client_reference_id=${clientRef}&prefilled_email=${clientRef}`;
}
const META_PIXEL_ID = '1498257195051913';

// ============================================================
// META CONVERSIONS API (CAPI) HELPER
// ============================================================

function hashSha256(value) {
  return crypto.createHash('sha256').update(value.trim().toLowerCase()).digest('hex');
}

// ============================================================
// AES-256-GCM ENCRYPTION HELPERS (for sensitive fields at rest)
// ============================================================
const ENCRYPTION_KEY_HEX = process.env.ENCRYPTION_KEY || '';
const ENCRYPTION_ALGORITHM = 'aes-256-gcm';

function encryptField(plaintext) {
  if (!ENCRYPTION_KEY_HEX || !plaintext) return null;
  try {
    const key = Buffer.from(ENCRYPTION_KEY_HEX, 'hex');
    const iv = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv(ENCRYPTION_ALGORITHM, key, iv);
    const encrypted = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
    const tag = cipher.getAuthTag();
    // Format: iv(12):tag(16):ciphertext — all base64
    return [iv.toString('base64'), tag.toString('base64'), encrypted.toString('base64')].join(':');
  } catch (e) {
    console.error('[Encryption] encryptField error:', e.message);
    return null;
  }
}

function decryptField(ciphertext) {
  if (!ENCRYPTION_KEY_HEX || !ciphertext) return ciphertext;
  try {
    const [ivB64, tagB64, encB64] = ciphertext.split(':');
    if (!ivB64 || !tagB64 || !encB64) return ciphertext; // not encrypted format
    const key = Buffer.from(ENCRYPTION_KEY_HEX, 'hex');
    const iv = Buffer.from(ivB64, 'base64');
    const tag = Buffer.from(tagB64, 'base64');
    const enc = Buffer.from(encB64, 'base64');
    const decipher = crypto.createDecipheriv(ENCRYPTION_ALGORITHM, key, iv);
    decipher.setAuthTag(tag);
    return Buffer.concat([decipher.update(enc), decipher.final()]).toString('utf8');
  } catch (e) {
    console.error('[Encryption] decryptField error:', e.message);
    return '[decryption error]';
  }
}

async function sendCapiEvent({ eventName, eventId, email, phone, ip, userAgent, fbc, fbp, customData, sourceUrl }) {
  const accessToken = process.env.META_ACCESS_TOKEN;
  if (!accessToken) {
    console.log(`[CAPI] Skipped — META_ACCESS_TOKEN not set. Event: ${eventName}`);
    return null;
  }

  const userData = {};
  if (email) userData.em = [hashSha256(email)];
  if (phone) userData.ph = [hashSha256(phone.replace(/\D/g, ''))];
  if (ip) userData.client_ip_address = ip;
  if (userAgent) userData.client_user_agent = userAgent;
  if (fbc) userData.fbc = fbc;
  if (fbp) userData.fbp = fbp;

  const payload = {
    data: [{
      event_name: eventName,
      event_time: Math.floor(Date.now() / 1000),
      event_id: eventId || crypto.randomBytes(16).toString('hex'),
      event_source_url: sourceUrl || process.env.APP_URL || 'https://flipl.polsia.app',
      action_source: 'website',
      user_data: userData,
      custom_data: customData || {}
    }]
  };

  // Add test event code if set (for Meta Events Manager testing)
  if (process.env.META_TEST_EVENT_CODE) {
    payload.test_event_code = process.env.META_TEST_EVENT_CODE;
  }

  try {
    const res = await axios.post(
      `https://graph.facebook.com/v18.0/${META_PIXEL_ID}/events`,
      payload,
      { params: { access_token: accessToken } }
    );
    console.log(`[CAPI] ${eventName} sent. EventId: ${payload.data[0].event_id}`, res.data);
    return res.data;
  } catch (err) {
    console.error(`[CAPI] Error sending ${eventName}:`, err.response?.data || err.message);
    return null;
  }
}

// =============================================
// EMAIL HELPER — Google Workspace SMTP via Win@fliplane.net
// =============================================
// All emails sent from Win@fliplane.net using Gmail SMTP.
// Env vars required: SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS

/** Reuse the same transporter across calls (connection pooling). */
let _emailTransporter = null;

function getEmailTransporter() {
  if (_emailTransporter) return _emailTransporter;

  const host = process.env.SMTP_HOST || 'smtp.gmail.com';
  const port = parseInt(process.env.SMTP_PORT || '587', 10);
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;

  if (user && pass) {
    _emailTransporter = nodemailer.createTransport({
      host,
      port,
      secure: port === 465, // true for 465, false for 587 (TLS)
      auth: { user, pass },
      pool: true,
      maxConnections: 5,
    });
    return _emailTransporter;
  }

  // Fall back to Postmark if SMTP credentials are missing
  const postmarkToken = process.env.POSTMARK_API_KEY;
  const postmarkServerId = process.env.POSTMARK_SERVER_ID || '0';

  if (postmarkToken) {
    _emailTransporter = nodemailer.createTransport({
      host: `smtp.postmarkapp.com`,
      port: 587,
      secure: false,
      auth: {
        user: postmarkServerId,
        pass: postmarkToken,
      },
      pool: true,
      maxConnections: 5,
    });
    return _emailTransporter;
  }

  return null;
}

/**
 * Send email via Google Workspace SMTP.
 * Falls back to dead-letter queue if SMTP fails.
 */
async function sendEmail({ to, subject, html, from, replyTo, tag }) {
  const fromAddr = from || 'Win@fliplane.net';
  const replyToAddr = replyTo || 'win@fliplane.net';

  const transporter = getEmailTransporter();

  if (!transporter) {
    const reason = process.env.POSTMARK_API_KEY
      ? 'Postmark not configured — POSTMARK_API_KEY env var not set'
      : 'SMTP and Postmark not configured — SMTP_PASS and POSTMARK_API_KEY env vars not set';
    console.error(`[Email] ${reason}`);
    try {
      await pool.query(
        `INSERT INTO failed_emails (recipient, subject, html_body, error_detail)
         VALUES ($1, $2, $3, $4)`,
        [to, subject, html, reason]
      );
    } catch (dlqErr) {
      console.error(`[Email] Dead-letter queue insert failed:`, dlqErr.message);
    }
    return { success: false, error: reason };
  }

  try {
    const info = await transporter.sendMail({
      from: fromAddr,
      to,
      subject,
      html,
      replyTo: replyToAddr,
      ...(tag ? { tags: [tag] } : {}),
    });

    console.log(`[Email] SMTP → ${to}: "${subject}" (${info.messageId})`);
    return { success: true, transport: 'smtp-gmail', messageId: info.messageId };
  } catch (err) {
    console.error(`[Email] SMTP send failed for ${to}: "${subject}" — ${err.message}`);

    // Dead letter queue
    try {
      await pool.query(
        `INSERT INTO failed_emails (recipient, subject, html_body, error_detail)
         VALUES ($1, $2, $3, $4)`,
        [to, subject, html, err.message]
      );
      console.log(`[Email] Saved to dead-letter queue for ${to}: "${subject}"`);
    } catch (dlqErr) {
      console.error(`[Email] Dead-letter queue insert failed:`, dlqErr.message);
    }

    return { success: false, error: err.message };
  }
}

// POST /api/test-welcome-email — Send test welcome email to specified address (admin only)
// Use: fetch('/api/test-welcome-email', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: 'zouheirilyas@gmail.com' }) })
app.post('/api/test-welcome-email', async (req, res) => {
  const adminAuth = req.headers['authorization'] || '';
  const adminEmail = process.env.ADMIN_EMAIL || 'win@fliplane.net';
  const adminPassword = process.env.ADMIN_PASSWORD || 'Inchaallah1$';
  const validCredentials = Buffer.from(`${adminEmail}:${adminPassword}`).toString('base64');

  if (adminAuth !== `Basic ${validCredentials}`) {
    return res.status(401).json({ success: false, message: 'Unauthorized' });
  }

  try {
    const { email: testEmail } = req.body;
    if (!testEmail) {
      return res.status(400).json({ success: false, message: 'email required in body' });
    }

    const appUrl = process.env.APP_URL || 'https://flipl.polsia.app';
    const certLink = `${appUrl}/certification?email=${encodeURIComponent(testEmail)}`;
    const memberFirstName = 'Test';
    const memberId = 'FL-TEST';

    const result = await sendEmail({
      to: testEmail,
      from: 'Win@fliplane.net',
      subject: 'Welcome to FlipLane Co-op! 🎉 Here\'s what\'s next',
      html: `
        <div style="font-family: 'DM Sans', Arial, sans-serif; max-width: 560px; margin: 0 auto; background: #0a0a0a; color: #ffffff; padding: 40px 32px; border-radius: 12px;">
          <div style="margin-bottom: 28px;">
            <span style="font-size: 1.4rem; font-weight: 700; letter-spacing: -0.5px;">Flip<span style="color: #00e676;">Lane</span></span>
          </div>
          <h1 style="font-size: 1.7rem; font-weight: 700; margin-bottom: 8px; letter-spacing: -0.5px;">Welcome to the Co-op, ${memberFirstName}! 🎉</h1>
          <p style="color: #a0a0a0; font-size: 0.88rem; margin-bottom: 24px;">Member ID: <strong style="color: #00e676;">${memberId}</strong></p>
          <p style="color: #a0a0a0; font-size: 1rem; line-height: 1.6; margin-bottom: 12px;">Your $250 payment is confirmed. You're officially a FlipLane co-op partner — operating under Byrd Dawgs Automotive Group's dealer license with full access to auction credentials, ByrddawgsOS, and our deal processing team.</p>

          <p style="color: #ffffff; font-size: 1.1rem; font-weight: 700; margin-bottom: 6px; letter-spacing: -0.3px;">Just one more step — get certified and start flipping today.</p>
          <p style="color: #a0a0a0; font-size: 0.88rem; margin-bottom: 28px;">Watch the video below, then complete your certification to unlock everything.</p>

          <div style="margin-bottom: 32px;">
            <a href="${appUrl}/watch/welcome" style="display: block; text-decoration: none; border-radius: 12px; overflow: hidden; position: relative; background: linear-gradient(135deg, #0d1b2a 0%, #1a2f45 50%, #0d1b2a 100%); border: 1px solid #1e3a52;">
              <div style="padding: 36px 24px; text-align: center;">
                <div style="display: inline-flex; align-items: center; justify-content: center; width: 64px; height: 64px; background: rgba(0,230,118,0.15); border: 2px solid #00e676; border-radius: 50%; margin-bottom: 16px;">
                  <span style="font-size: 1.5rem; line-height: 1; margin-left: 4px; color: #00e676;">&#9654;</span>
                </div>
                <p style="color: #ffffff; font-weight: 700; font-size: 1rem; margin: 0 0 6px; letter-spacing: -0.3px;">Get Certified &amp; Start Flipping</p>
                <p style="color: #a0a0a0; font-size: 0.82rem; margin: 0;">Watch this before you start your certification — 60 seconds</p>
              </div>
              <div style="background: rgba(0,230,118,0.08); border-top: 1px solid #1e3a52; padding: 10px 24px; text-align: center;">
                <span style="color: #00e676; font-size: 0.82rem; font-weight: 600;">▶ &nbsp;Watch Now</span>
              </div>
            </a>
          </div>

          <div style="text-align: center; margin-bottom: 32px;">
            <a href="${certLink}" style="display: inline-block; padding: 16px 32px; background: #00e676; border-radius: 10px; color: #000; font-weight: 700; font-size: 1.05rem; text-decoration: none; letter-spacing: -0.3px;">Get Certified Now →</a>
            <p style="color: #666; font-size: 0.8rem; margin-top: 10px;">Takes about 5 minutes. Pass the quiz to unlock your full dashboard.</p>
          </div>

          <div style="background: #161616; border-radius: 10px; padding: 20px 24px; margin-bottom: 28px; border: 1px solid #222;">
            <p style="font-weight: 700; font-size: 0.95rem; margin-bottom: 16px; color: #fff;">Quick-start guide — what to expect:</p>
            <div style="margin-bottom: 12px;">
              <p style="color: #00e676; font-weight: 700; font-size: 0.88rem; margin-bottom: 2px;">STEP 1 — Complete certification</p>
              <p style="color: #a0a0a0; font-size: 0.88rem; margin: 0;">4 short training modules + a 5-question quiz. 100% pass required, unlimited retakes. Click the button above to start now.</p>
            </div>
            <div style="margin-bottom: 12px;">
              <p style="color: #00e676; font-weight: 700; font-size: 0.88rem; margin-bottom: 2px;">STEP 2 — Sign your FlipLane Terms of Service</p>
              <p style="color: #a0a0a0; font-size: 0.88rem; margin: 0;">Your FlipLane Terms of Service agreement is on its way to your inbox. Sign it to complete your membership.</p>
            </div>
            <div style="margin-bottom: 12px;">
              <p style="color: #00e676; font-weight: 700; font-size: 0.88rem; margin-bottom: 2px;">STEP 3 — Access ByrddawgsOS</p>
              <p style="color: #a0a0a0; font-size: 0.88rem; margin: 0;">Once certified, your dashboard unlocks automatically. You'll find auction credentials (ADESA, OVE, TitleMax), deal submission tools, title &amp; shipping requests, and more.</p>
            </div>
            <div>
              <p style="color: #00e676; font-weight: 700; font-size: 0.88rem; margin-bottom: 2px;">STEP 4 — Run your first deal</p>
              <p style="color: #a0a0a0; font-size: 0.88rem; margin: 0;">Submit a deal sheet from your dashboard. FlipLane handles title, paperwork, and processing. Flat $250/deal fee — you keep 100% of cash deal profit above that.</p>
            </div>
          </div>

          <p style="color: #666; font-size: 0.88rem; line-height: 1.6;">Questions? Reply to this email or reach us at <a href="mailto:win@fliplane.net" style="color: #00e676;">win@fliplane.net</a>. We respond to everything.</p>
          <hr style="border: none; border-top: 1px solid #222; margin: 28px 0;">
          <p style="color: #444; font-size: 0.8rem;">FlipLane · Member ID ${memberId}</p>
        </div>
      `
    });

    console.log(`[Test] Welcome email result for ${testEmail}:`, JSON.stringify(result));
    res.json({ success: result.success, message: result.error || 'sent', messageId: result.messageId });
  } catch (err) {
    console.error('[Test] Welcome email error:', err.message);
    res.status(500).json({ success: false, message: err.message });
  }
});

// Stripe webhook needs raw body
app.use('/api/stripe-webhook', express.raw({ type: 'application/json' }));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ============================================================
// PAGE VIEW TRACKING MIDDLEWARE
// Logs GET requests to public pages. Filters bots, API routes,
// static assets. Fire-and-forget — never blocks response.
// ============================================================
const BOT_PATTERN = /bot|spider|crawl|slurp|bingpreview|facebookexternalhit|semrush|ahref|screaming|mj12|dotbot|rogerbot|linkdex|exabot|ia_archiver|archive\.org|python-requests|go-http-client|curl\/|wget\/|okhttp|java\//i;

const SKIP_EXTENSIONS = /\.(css|js|ico|png|jpg|jpeg|gif|svg|webp|woff|woff2|ttf|eot|map|txt|xml|json)$/i;

app.use((req, res, next) => {
  // Only track GET requests to non-API, non-admin, non-health paths
  if (req.method !== 'GET') return next();
  const p = req.path;
  if (p.startsWith('/api/') || p.startsWith('/admin') || p === '/health') return next();
  if (SKIP_EXTENSIONS.test(p)) return next();

  // Filter bots
  const ua = req.headers['user-agent'] || '';
  if (BOT_PATTERN.test(ua)) return next();

  // Record asynchronously — never block the request
  const url = req.path;
  const referrer = req.headers['referer'] || req.headers['referrer'] || null;
  const rawIp = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket?.remoteAddress || '';
  // Store hashed IP for privacy (no raw PII stored)
  const ipHash = rawIp ? crypto.createHash('sha256').update(rawIp).digest('hex').slice(0, 16) : null;
  const userAgent = ua.slice(0, 512) || null;

  pool.query(
    `INSERT INTO page_views (url, referrer, user_agent, ip_hash) VALUES ($1, $2, $3, $4)`,
    [url, referrer, userAgent, ipHash]
  ).catch(err => {
    // Non-fatal — silently log, never crash
    console.error('[PageViews] Insert failed:', err.message);
  });

  next();
});

// Health check endpoint (required for Render)
app.get('/health', (req, res) => {
  res.json({ status: 'healthy', app: 'FlipLane' });
});

// ============================================================
// PAGE ROUTES — must be BEFORE express.static to avoid proxy interception
// ============================================================

// Landing page with analytics beacon injected
app.get('/', (req, res) => {
  const slug = process.env.POLSIA_ANALYTICS_SLUG || '';
  const htmlPath = path.join(__dirname, 'public', 'index.html');
  if (fs.existsSync(htmlPath)) {
    let html = fs.readFileSync(htmlPath, 'utf8');
    html = html.replace('__POLSIA_SLUG__', slug);
    res.type('html').send(html);
  } else {
    res.json({ message: 'FlipLane — Flip Cars Nationwide' });
  }
});

// /join — primary membership flow (4 steps)
app.get('/join', (req, res) => {
  const htmlPath = path.join(__dirname, 'public', 'join.html');
  if (fs.existsSync(htmlPath)) {
    res.type('html').send(fs.readFileSync(htmlPath, 'utf8'));
  } else {
    res.status(404).send('Page not found');
  }
});

// /apply — redirect to /join (backward compat), preserving query params
app.get('/apply', (req, res) => {
  const qs = req.originalUrl.includes('?') ? req.originalUrl.substring(req.originalUrl.indexOf('?')) : '';
  res.redirect(301, `/join${qs}`);
});

app.get('/buy', (req, res) => {
  const htmlPath = path.join(__dirname, 'public', 'buy.html');
  if (fs.existsSync(htmlPath)) {
    res.type('html').send(fs.readFileSync(htmlPath, 'utf8'));
  } else {
    res.redirect('/apply');
  }
});

app.get('/earn', (req, res) => {
  const htmlPath = path.join(__dirname, 'public', 'earn.html');
  if (fs.existsSync(htmlPath)) {
    res.type('html').send(fs.readFileSync(htmlPath, 'utf8'));
  } else {
    res.redirect('/apply');
  }
});

app.get('/partner', (req, res) => {
  const htmlPath = path.join(__dirname, 'public', 'partner.html');
  if (fs.existsSync(htmlPath)) {
    res.type('html').send(fs.readFileSync(htmlPath, 'utf8'));
  } else {
    res.redirect('/apply');
  }
});

app.get('/pricing', (req, res) => {
  const htmlPath = path.join(__dirname, 'public', 'pricing.html');
  if (fs.existsSync(htmlPath)) {
    res.type('html').send(fs.readFileSync(htmlPath, 'utf8'));
  } else {
    res.redirect('/');
  }
});

app.get('/terms', (req, res) => {
  const htmlPath = path.join(__dirname, 'public', 'terms.html');
  if (fs.existsSync(htmlPath)) {
    res.type('html').send(fs.readFileSync(htmlPath, 'utf8'));
  } else {
    res.status(404).send('Page not found');
  }
});

// /unsubscribe — newsletter unsubscribe confirmation
app.get('/unsubscribe', (req, res) => {
  const htmlPath = path.join(__dirname, 'public', 'unsubscribe.html');
  if (fs.existsSync(htmlPath)) {
    res.type('html').send(fs.readFileSync(htmlPath, 'utf8'));
  } else {
    res.redirect('/');
  }
});

// /flip-to-fortune — Ebook lead magnet sales funnel
app.get('/flip-to-fortune', (req, res) => {
  const htmlPath = path.join(__dirname, 'public', 'flip-to-fortune.html');
  if (fs.existsSync(htmlPath)) {
    res.type('html').send(fs.readFileSync(htmlPath, 'utf8'));
  } else {
    res.redirect('/');
  }
});

// /flip-to-fortune/read — Full web-readable playbook (all 10 chapters)
app.get('/flip-to-fortune/read', (req, res) => {
  const htmlPath = path.join(__dirname, 'public', 'flip-to-fortune-read.html');
  if (fs.existsSync(htmlPath)) {
    res.type('html').send(fs.readFileSync(htmlPath, 'utf8'));
  } else {
    res.redirect('/flip-to-fortune');
  }
});

app.get('/dashboard', (req, res) => {
  const htmlPath = path.join(__dirname, 'public', 'dashboard.html');
  if (fs.existsSync(htmlPath)) {
    res.type('html').send(fs.readFileSync(htmlPath, 'utf8'));
  } else {
    res.status(404).send('Page not found');
  }
});

app.get('/certification', (req, res) => {
  const htmlPath = path.join(__dirname, 'public', 'certification.html');
  if (fs.existsSync(htmlPath)) {
    res.type('html').send(fs.readFileSync(htmlPath, 'utf8'));
  } else {
    res.status(404).send('Page not found');
  }
});

app.get('/payment-success', (req, res) => {
  // Legacy success URL — redirect to /welcome so everyone lands on the same page
  const email = req.query.email || req.query.client_reference_id;
  const dest = email ? `/welcome?email=${encodeURIComponent(email)}` : '/welcome';
  res.redirect(301, dest);
});

app.get('/welcome', (req, res) => {
  const htmlPath = path.join(__dirname, 'public', 'welcome.html');
  if (fs.existsSync(htmlPath)) {
    res.type('html').send(fs.readFileSync(htmlPath, 'utf8'));
  } else {
    res.redirect('/certification');
  }
});

app.get('/byrddawgsos', (req, res) => {
  const htmlPath = path.join(__dirname, 'public', 'byrddawgsos.html');
  if (fs.existsSync(htmlPath)) {
    res.type('html').send(fs.readFileSync(htmlPath, 'utf8'));
  } else {
    res.status(404).send('Page not found');
  }
});

// DYNAMIC SITEMAP — includes blog posts
app.get('/sitemap.xml', async (req, res) => {
  try {
    // Fetch published blog posts
    let blogUrls = '';
    try {
      const result = await pool.query(
        `SELECT slug, updated_at FROM blog_posts WHERE published = true ORDER BY publish_date DESC`
      );
      blogUrls = result.rows.map(p => `
  <url>
    <loc>https://fliplane.net/blog/${p.slug}</loc>
    <lastmod>${new Date(p.updated_at || p.publish_date).toISOString().slice(0,10)}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
  </url>`).join('');
    } catch (e) {
      // If blog table doesn't exist yet, skip
    }

    const today = new Date().toISOString().slice(0,10);
    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://fliplane.net/</loc>
    <lastmod>2026-03-18</lastmod>
    <changefreq>weekly</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>https://fliplane.net/buy</loc>
    <lastmod>2026-03-18</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://fliplane.net/earn</loc>
    <lastmod>2026-03-18</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://fliplane.net/partner</loc>
    <lastmod>2026-03-18</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://fliplane.net/flip-to-fortune</loc>
    <lastmod>2026-03-18</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://fliplane.net/flip-to-fortune/read</loc>
    <lastmod>2026-04-04</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://fliplane.net/pricing</loc>
    <lastmod>2026-03-18</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://fliplane.net/blog</loc>
    <lastmod>${today}</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://fliplane.net/apply</loc>
    <lastmod>2026-03-18</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc>https://fliplane.net/terms</loc>
    <lastmod>2026-03-18</lastmod>
    <changefreq>yearly</changefreq>
    <priority>0.3</priority>
  </url>${blogUrls}
</urlset>`;

    res.set('Content-Type', 'application/xml');
    res.send(xml);
  } catch (err) {
    console.error('[Sitemap] Error:', err);
    // Fall through to static file
    const htmlPath = path.join(__dirname, 'public', 'sitemap.xml');
    if (fs.existsSync(htmlPath)) {
      res.set('Content-Type', 'application/xml').send(fs.readFileSync(htmlPath, 'utf8'));
    } else {
      res.status(500).send('Sitemap unavailable');
    }
  }
});

// BLOG PAGE ROUTES
app.get('/blog', (req, res) => {
  const htmlPath = path.join(__dirname, 'public', 'blog.html');
  if (fs.existsSync(htmlPath)) {
    res.type('html').send(fs.readFileSync(htmlPath, 'utf8'));
  } else {
    res.status(404).send('Page not found');
  }
});

app.get('/blog/:slug', async (req, res) => {
  const htmlPath = path.join(__dirname, 'public', 'blog-post.html');
  if (!fs.existsSync(htmlPath)) return res.status(404).send('Page not found');

  let html = fs.readFileSync(htmlPath, 'utf8');

  // Server-side OG injection so social crawlers (Twitter, Facebook) see correct tags
  try {
    const result = await pool.query(
      `SELECT title, slug, excerpt, seo_title, seo_description, featured_image_url, publish_date
       FROM blog_posts WHERE slug = $1 AND published = true LIMIT 1`,
      [req.params.slug]
    );
    if (result.rows.length > 0) {
      const p = result.rows[0];
      const ogTitle = (p.seo_title || p.title).replace(/"/g, '&quot;');
      const ogDesc  = (p.seo_description || p.excerpt || '').replace(/"/g, '&quot;');
      const ogImage = p.featured_image_url || 'https://fliplane.net/og-image.png';
      const ogUrl   = `https://fliplane.net/blog/${p.slug}`;
      const pageTitle = `${p.seo_title || p.title} | FlipLane Blog`;

      // Replace title
      html = html.replace(
        /<title id="page-title">[^<]*<\/title>/,
        `<title id="page-title">${pageTitle.replace(/</g, '&lt;')}</title>`
      );
      // Replace canonical
      html = html.replace(
        /<link id="canonical" rel="canonical" href="[^"]*">/,
        `<link id="canonical" rel="canonical" href="${ogUrl}">`
      );
      // Replace meta description
      html = html.replace(
        /<meta id="meta-desc" name="description" content="[^"]*">/,
        `<meta id="meta-desc" name="description" content="${ogDesc}">`
      );
      // Replace OG tags
      html = html.replace(
        /<meta id="og-title" property="og:title" content="[^"]*">/,
        `<meta id="og-title" property="og:title" content="${ogTitle}">`
      );
      html = html.replace(
        /<meta id="og-desc" property="og:description" content="[^"]*">/,
        `<meta id="og-desc" property="og:description" content="${ogDesc}">`
      );
      html = html.replace(
        /<meta id="og-image" property="og:image" content="[^"]*">/,
        `<meta id="og-image" property="og:image" content="${ogImage}">`
      );
      html = html.replace(
        /<meta id="og-url" property="og:url" content="[^"]*">/,
        `<meta id="og-url" property="og:url" content="${ogUrl}">`
      );
      // Replace Twitter tags
      html = html.replace(
        /<meta id="tw-title" name="twitter:title" content="[^"]*">/,
        `<meta id="tw-title" name="twitter:title" content="${ogTitle}">`
      );
      html = html.replace(
        /<meta id="tw-desc" name="twitter:description" content="[^"]*">/,
        `<meta id="tw-desc" name="twitter:description" content="${ogDesc}">`
      );
      html = html.replace(
        /<meta id="tw-image" name="twitter:image" content="[^"]*">/,
        `<meta id="tw-image" name="twitter:image" content="${ogImage}">`
      );
      // Replace BlogPosting JSON-LD structured data
      const publishDate = p.publish_date ? new Date(p.publish_date).toISOString().split('T')[0] : new Date().toISOString().split('T')[0];
      const blogPostingSchema = JSON.stringify({
        "@context": "https://schema.org",
        "@type": "BlogPosting",
        "headline": (p.seo_title || p.title),
        "url": `https://fliplane.net/blog/${p.slug}`,
        "image": p.featured_image_url || 'https://fliplane.net/og-image.png',
        "datePublished": publishDate,
        "description": (p.seo_description || p.excerpt || ''),
        "author": { "@type": "Organization", "name": "FlipLane", "url": "https://fliplane.net" },
        "publisher": {
          "@type": "Organization",
          "name": "FlipLane",
          "url": "https://fliplane.net",
          "logo": { "@type": "ImageObject", "url": "https://fliplane.net/og-image.png" }
        },
        "isPartOf": { "@type": "Blog", "name": "FlipLane Blog", "url": "https://fliplane.net/blog" }
      });
      html = html.replace(
        /<script id="jsonld-blogposting" type="application\/ld\+json">[\s\S]*?<\/script>/,
        `<script id="jsonld-blogposting" type="application/ld+json">\n    ${blogPostingSchema}\n    </script>`
      );
    }
  } catch (e) {
    // DB unavailable — serve template as-is (JS will populate OG tags client-side)
    console.error('[Blog SSR] OG injection error:', e.message);
  }

  res.type('html').send(html);
});

app.get('/admin/blog', requireAdminAuth, (req, res) => {
  const htmlPath = path.join(__dirname, 'public', 'admin-blog.html');
  if (fs.existsSync(htmlPath)) {
    res.type('html').send(fs.readFileSync(htmlPath, 'utf8'));
  } else {
    res.status(404).send('Page not found');
  }
});

// ============================================================
// API ROUTES
// ============================================================

// POST /api/meta-capi — Client-side CAPI relay (for deduplication)
app.post('/api/meta-capi', async (req, res) => {
  try {
    const { event_name, event_id, email, phone, fbc, fbp, custom_data, source_url } = req.body;

    if (!event_name) {
      return res.status(400).json({ success: false, message: 'event_name is required' });
    }

    const ip = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket.remoteAddress;
    const userAgent = req.headers['user-agent'];

    const result = await sendCapiEvent({
      eventName: event_name,
      eventId: event_id,
      email,
      phone,
      ip,
      userAgent,
      fbc,
      fbp,
      customData: custom_data,
      sourceUrl: source_url
    });

    res.json({ success: true, capi: result });
  } catch (err) {
    console.error('[CAPI Endpoint] Error:', err.message);
    res.status(500).json({ success: false, message: 'CAPI relay failed' });
  }
});

// POST /api/vehicle-inquiry — Buyer lane vehicle sourcing request
app.post('/api/vehicle-inquiry', async (req, res) => {
  try {
    const { name, email, phone, vehicle_description, budget_range, timeline, notes, fbc, fbp } = req.body;

    if (!name || !email) {
      return res.status(400).json({ success: false, message: 'Name and email are required.' });
    }

    // Deterministic event_id keyed to email + date for client/server deduplication
    const inquiryDate = new Date().toISOString().split('T')[0];
    const capiEventId = `buy_lead_${email.toLowerCase().replace(/[^a-z0-9]/g, '')}_${inquiryDate}`;

    // Save to DB
    const result = await pool.query(
      `INSERT INTO vehicle_inquiries (name, email, phone, vehicle_description, budget_range, timeline, notes, capi_event_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING id`,
      [name, email, phone || null, vehicle_description || null, budget_range || null, timeline || null, notes || null, capiEventId]
    );

    console.log(`[FlipLane] New vehicle inquiry: ${name} (${email})`);

    // Notify owner — fire-and-forget
    sendEmail({
      to: 'win@fliplane.net',
      subject: `🚗 New Buyer Request: ${name}`,
      html: `
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:24px;background:#f9f9f9;border-radius:8px;">
          <h2 style="color:#1a1a1a;margin-bottom:4px;">🚗 New Buyer Request</h2>
          <p style="color:#666;font-size:13px;margin-top:0;">Submitted: ${new Date().toLocaleString('en-US', { timeZone: 'America/New_York' })} ET</p>
          <table style="width:100%;border-collapse:collapse;margin-top:16px;">
            <tr><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;font-weight:bold;width:40%;">Name</td><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;">${name}</td></tr>
            <tr><td style="padding:8px 12px;background:#f5f5f5;border:1px solid #e0e0e0;font-weight:bold;">Email</td><td style="padding:8px 12px;background:#f5f5f5;border:1px solid #e0e0e0;">${email}</td></tr>
            <tr><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;font-weight:bold;">Phone</td><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;">${phone || '—'}</td></tr>
            <tr><td style="padding:8px 12px;background:#f5f5f5;border:1px solid #e0e0e0;font-weight:bold;">Vehicle</td><td style="padding:8px 12px;background:#f5f5f5;border:1px solid #e0e0e0;">${vehicle_description || '—'}</td></tr>
            <tr><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;font-weight:bold;">Budget</td><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;">${budget_range || '—'}</td></tr>
            <tr><td style="padding:8px 12px;background:#f5f5f5;border:1px solid #e0e0e0;font-weight:bold;">Timeline</td><td style="padding:8px 12px;background:#f5f5f5;border:1px solid #e0e0e0;">${timeline || '—'}</td></tr>
            <tr><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;font-weight:bold;">Notes</td><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;">${notes || '—'}</td></tr>
          </table>
          <p style="margin-top:20px;color:#888;font-size:12px;">Submitted via fliplane.net/buy</p>
        </div>
      `
    }).catch(err => console.error('[Email] Owner notification (vehicle-inquiry) failed:', err.message));

    // Send confirmation email to buyer — fire-and-forget
    sendEmail({
      to: email,
      subject: 'FlipLane received your vehicle request!',
      html: `
        <div style="font-family: 'DM Sans', Arial, sans-serif; max-width: 560px; margin: 0 auto; background: #0a0a0a; color: #ffffff; padding: 40px 32px; border-radius: 12px;">
          <div style="margin-bottom: 28px;">
            <span style="font-size: 1.4rem; font-weight: 700; letter-spacing: -0.5px;">Flip<span style="color: #00e676;">Lane</span></span>
          </div>
          <h1 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 12px;">We got your request, ${name.split(' ')[0]}!</h1>
          <p style="color: #a0a0a0; font-size: 1rem; line-height: 1.6; margin-bottom: 20px;">Thanks for reaching out. Our team is reviewing your vehicle sourcing request and will be in touch within 24 hours.</p>
          <div style="background: #161616; border-radius: 8px; padding: 16px 20px; margin-bottom: 20px;">
            <p style="color: #a0a0a0; margin: 0 0 6px;">Vehicle: <span style="color: #fff;">${vehicle_description || 'To be discussed'}</span></p>
            <p style="color: #a0a0a0; margin: 0 0 6px;">Budget: <span style="color: #fff;">${budget_range || 'Flexible'}</span></p>
            <p style="color: #a0a0a0; margin: 0;">Timeline: <span style="color: #fff;">${timeline || 'Flexible'}</span></p>
          </div>
          <p style="color: #666; font-size: 0.88rem; line-height: 1.6;">Questions? Email us at <a href="mailto:win@fliplane.net" style="color: #00e676;">win@fliplane.net</a></p>
          <hr style="border: none; border-top: 1px solid #222; margin: 28px 0;">
          <p style="color: #444; font-size: 0.8rem;">FlipLane · The AI-Powered Used Car Co-op</p>
        </div>
      `
    }).catch(err => console.error('[Email] Buyer confirmation (vehicle-inquiry) failed:', err.message));

    // Fire CAPI Lead event server-side
    const ip = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket.remoteAddress;
    sendCapiEvent({
      eventName: 'Lead',
      eventId: capiEventId,
      email,
      phone,
      ip,
      userAgent: req.headers['user-agent'],
      fbc,
      fbp,
      customData: { content_name: 'FlipLane Buyer Inquiry', content_category: 'buy' },
      sourceUrl: `https://${req.get('host')}/buy`
    }).catch(err => console.error('[CAPI] Buy Lead fire failed:', err.message));

    res.json({
      success: true,
      inquiry_id: result.rows[0].id,
      capi_event_id: capiEventId,
      message: 'Request received! Our team will be in touch shortly.'
    });

  } catch (err) {
    console.error('[FlipLane] Vehicle inquiry error:', err.message);
    res.status(500).json({ success: false, message: 'Something went wrong. Please try again.' });
  }
});

// POST /api/buyer-request — Buyer Lane step 1: create order + generate order number
app.post('/api/buyer-request', async (req, res) => {
  try {
    const { name, email, phone, vehicle_year, vehicle_make, vehicle_model, vehicle_trim, budget_range, color_pref, mileage_pref, timeline, notes } = req.body;

    if (!name || !email) {
      return res.status(400).json({ success: false, message: 'Name and email are required.' });
    }

    // Generate unique order number FL-BUY-XXXXX
    let orderNumber;
    let attempts = 0;
    while (attempts < 10) {
      const suffix = crypto.randomBytes(3).toString('hex').toUpperCase().substring(0, 5);
      orderNumber = `FL-BUY-${suffix}`;
      const existing = await pool.query('SELECT id FROM buyer_requests WHERE order_number = $1', [orderNumber]);
      if (existing.rows.length === 0) break;
      attempts++;
      orderNumber = null;
    }

    if (!orderNumber) {
      return res.status(500).json({ success: false, message: 'Failed to generate order number. Please try again.' });
    }

    const result = await pool.query(
      `INSERT INTO buyer_requests
         (name, email, phone, vehicle_year, vehicle_make, vehicle_model, vehicle_trim,
          budget_range, color_pref, mileage_pref, timeline, notes, order_number, payment_status)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, 'awaiting_payment')
       RETURNING id, order_number`,
      [
        name.trim(),
        email.toLowerCase().trim(),
        phone || null,
        vehicle_year || null,
        vehicle_make || null,
        vehicle_model || null,
        vehicle_trim || null,
        budget_range || null,
        color_pref || null,
        mileage_pref || null,
        timeline || null,
        notes || null,
        orderNumber
      ]
    );

    console.log(`[FlipLane] New buyer request: ${name} (${email}) — ${orderNumber}`);

    res.json({
      success: true,
      order_number: result.rows[0].order_number,
      request_id: result.rows[0].id
    });

  } catch (err) {
    console.error('[FlipLane] Buyer request create error:', err.message);
    res.status(500).json({ success: false, message: 'Something went wrong. Please try again.' });
  }
});

// POST /api/buyer-payment-submitted — Buyer Lane step 2: confirm payment sent
app.post('/api/buyer-payment-submitted', async (req, res) => {
  try {
    const { request_id, order_number, payment_method } = req.body;

    if (!request_id || !order_number || !payment_method) {
      return res.status(400).json({ success: false, message: 'Missing required fields.' });
    }

    const update = await pool.query(
      `UPDATE buyer_requests
       SET payment_method = $1, payment_status = 'pending_verification', updated_at = NOW()
       WHERE id = $2 AND order_number = $3
       RETURNING name, email, vehicle_year, vehicle_make, vehicle_model, vehicle_trim, budget_range`,
      [payment_method, request_id, order_number]
    );

    if (update.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Order not found.' });
    }

    const { name, email, vehicle_year, vehicle_make, vehicle_model, budget_range } = update.rows[0];
    const vehicleSummary = [vehicle_year, vehicle_make, vehicle_model].filter(Boolean).join(' ') || 'Vehicle to be sourced';

    console.log(`[FlipLane] Buyer payment submitted: ${order_number} via ${payment_method}`);

    // Notify owner
    sendEmail({
      to: 'win@fliplane.net',
      subject: `\uD83D\uDCB0 Buyer Payment Submitted: ${order_number} \u2014 ${name}`,
      html: `
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:24px;background:#f9f9f9;border-radius:8px;">
          <h2 style="color:#1a1a1a;margin-bottom:4px;">&#128176; Buyer Payment Submitted</h2>
          <p style="color:#666;font-size:13px;margin-top:0;">Submitted: ${new Date().toLocaleString('en-US', { timeZone: 'America/New_York' })} ET</p>
          <table style="width:100%;border-collapse:collapse;margin-top:16px;">
            <tr><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;font-weight:bold;width:40%;">Order Number</td><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;font-weight:bold;color:#007a3d;">${order_number}</td></tr>
            <tr><td style="padding:8px 12px;background:#f5f5f5;border:1px solid #e0e0e0;font-weight:bold;">Name</td><td style="padding:8px 12px;background:#f5f5f5;border:1px solid #e0e0e0;">${name}</td></tr>
            <tr><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;font-weight:bold;">Email</td><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;">${email}</td></tr>
            <tr><td style="padding:8px 12px;background:#f5f5f5;border:1px solid #e0e0e0;font-weight:bold;">Vehicle Requested</td><td style="padding:8px 12px;background:#f5f5f5;border:1px solid #e0e0e0;">${vehicleSummary}</td></tr>
            <tr><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;font-weight:bold;">Budget</td><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;">${budget_range || '—'}</td></tr>
            <tr><td style="padding:8px 12px;background:#f5f5f5;border:1px solid #e0e0e0;font-weight:bold;">Payment Method</td><td style="padding:8px 12px;background:#f5f5f5;border:1px solid #e0e0e0;">${payment_method}</td></tr>
            <tr><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;font-weight:bold;">Status</td><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;">Pending Verification</td></tr>
          </table>
          <p style="margin-top:20px;color:#888;font-size:12px;">Submitted via fliplane.net/buy</p>
        </div>
      `
    }).catch(err => console.error('[Email] Owner notification (buyer-payment) failed:', err.message));

    // Confirmation to buyer
    sendEmail({
      to: email,
      subject: `Your FlipLane Order ${order_number} is Received`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 560px; margin: 0 auto; background: #0a0a0a; color: #ffffff; padding: 40px 32px; border-radius: 12px;">
          <div style="margin-bottom: 28px;">
            <span style="font-size: 1.4rem; font-weight: 700; letter-spacing: -0.5px;">Flip<span style="color: #00e676;">Lane</span></span>
          </div>
          <h1 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 12px;">We're on it, ${name.split(' ')[0]}!</h1>
          <p style="color: #a0a0a0; font-size: 1rem; line-height: 1.6; margin-bottom: 20px;">Your payment submission is received. Your concierge team is sourcing your vehicle and will be in touch within 24&ndash;48 hours.</p>
          <div style="background: #161616; border-radius: 8px; padding: 20px 24px; margin-bottom: 20px; text-align: center;">
            <p style="color: #a0a0a0; font-size: 0.82rem; margin: 0 0 8px; text-transform: uppercase; letter-spacing: 1.5px;">Your Order Number</p>
            <p style="color: #00e676; font-size: 2rem; font-weight: 700; margin: 0; letter-spacing: 3px;">${order_number}</p>
          </div>
          <div style="background: #161616; border-radius: 8px; padding: 16px 20px; margin-bottom: 20px;">
            <p style="color: #a0a0a0; margin: 0 0 6px;">Vehicle: <span style="color: #fff;">${vehicleSummary}</span></p>
            <p style="color: #a0a0a0; margin: 0 0 6px;">Payment via: <span style="color: #fff;">${payment_method}</span></p>
            <p style="color: #a0a0a0; margin: 0;">Status: <span style="color: #fbbf24;">Pending Verification</span></p>
          </div>
          <p style="color: #a0a0a0; font-size: 0.9rem; line-height: 1.6; margin-bottom: 8px;">Keep your order number handy &mdash; we'll reference it in all communications.</p>
          <p style="color: #666; font-size: 0.88rem; line-height: 1.6;">Questions? Reply to this email or reach us at <a href="mailto:win@fliplane.net" style="color: #00e676;">win@fliplane.net</a></p>
          <hr style="border: none; border-top: 1px solid #222; margin: 28px 0;">
          <p style="color: #444; font-size: 0.8rem;">FlipLane &middot; The AI-Powered Used Car Co-op &middot; Atlanta, GA</p>
        </div>
      `
    }).catch(err => console.error('[Email] Buyer confirmation (payment-submitted) failed:', err.message));

    res.json({ success: true, message: 'Payment submission recorded.' });

  } catch (err) {
    console.error('[FlipLane] Buyer payment submission error:', err.message);
    res.status(500).json({ success: false, message: 'Something went wrong. Please try again.' });
  }
});

// POST /api/leads — Homepage lead magnet email capture (Free Car Flipping Starter Kit)
app.post('/api/leads', async (req, res) => {
  try {
    const { email } = req.body;

    if (!email || !email.includes('@')) {
      return res.status(400).json({ success: false, message: 'Valid email is required.' });
    }

    const normalizedEmail = email.toLowerCase().trim();

    // Insert with ON CONFLICT DO NOTHING for silent deduplication
    await pool.query(
      `INSERT INTO leads (email, source) VALUES ($1, $2) ON CONFLICT (email) DO NOTHING`,
      [normalizedEmail, 'homepage_lead_magnet']
    );

    console.log(`[FlipLane] New lead captured: ${normalizedEmail}`);

    // Flip to Fortune playbook URL (R2)
    const PLAYBOOK_URL = 'https://pub-629428d185ca4960a0a73c850d32294b.r2.dev/company_20624/files/3319c381-dac0-44f2-a11d-e333989b5e11.pdf';

    // 1. Ebook delivery to subscriber — AWAIT so we know if it succeeded
    const ebookResult = await sendEmail({
      to: normalizedEmail,
      subject: 'Your Flip to Fortune playbook is ready',
      tag: 'homepage-playbook',
      listUnsubscribe: true,
      html: `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>Your Flip to Fortune Playbook</title></head><body style="margin:0;padding:0;background:#f4f4f4;font-family:Arial,Helvetica,sans-serif;"><table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f4;padding:40px 20px;"><tr><td align="center"><table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;overflow:hidden;max-width:600px;width:100%;"><tr><td style="background:#FF6B35;height:6px;"></td></tr><tr><td style="background:#1A1A2E;padding:32px 40px 28px;text-align:center;"><p style="margin:0 0 8px;color:#FF6B35;font-size:12px;letter-spacing:3px;text-transform:uppercase;font-weight:bold;">FREE PLAYBOOK</p><h1 style="margin:0;color:#ffffff;font-size:32px;line-height:1.2;">Flip to Fortune</h1><p style="margin:12px 0 0;color:#aaaaaa;font-size:15px;">The Ultimate Car-Flipping Playbook</p></td></tr><tr><td style="padding:40px 40px 32px;"><p style="margin:0 0 20px;color:#333333;font-size:16px;line-height:1.6;">Hey there! Your copy of <strong>Flip to Fortune: The Ultimate Car-Flipping Playbook</strong> is ready.</p><table width="100%" cellpadding="0" cellspacing="0" style="margin:24px 0;"><tr><td align="center" style="padding-bottom:14px;"><a href="https://fliplane.net/flip-to-fortune/read" target="_blank" style="display:inline-block;background:#FF6B35;color:#ffffff;font-size:18px;font-weight:bold;text-decoration:none;padding:16px 48px;border-radius:8px;">📖 Read Online →</a><p style="margin:6px 0 0;color:#888888;font-size:12px;">Full online read — no download needed</p></td></tr><tr><td align="center"><a href="${PLAYBOOK_URL}" target="_blank" style="display:inline-block;background:transparent;color:#FF6B35;font-size:15px;font-weight:bold;text-decoration:none;padding:10px 32px;border-radius:8px;border:2px solid rgba(255,107,53,0.4);">📥 Download the Breakdown PDF</a><p style="margin:6px 0 0;color:#888888;font-size:12px;">Magazine-style summary — save &amp; reference offline</p></td></tr></table><p style="margin:0 0 12px;color:#555555;font-size:14px;line-height:1.6;">What's inside:</p><table cellpadding="0" cellspacing="0" style="margin:0 0 24px;"><tr><td style="padding:5px 0;color:#555555;font-size:14px;">✅&nbsp; <strong>10 Chapters</strong> covering every stage of the car-flipping business</td></tr><tr><td style="padding:5px 0;color:#555555;font-size:14px;">✅&nbsp; <strong>Deal math templates</strong> — never lose money on a flip</td></tr><tr><td style="padding:5px 0;color:#555555;font-size:14px;">✅&nbsp; <strong>Auction strategies</strong> for ADESA's 50,000+ weekly vehicles</td></tr><tr><td style="padding:5px 0;color:#555555;font-size:14px;">✅&nbsp; <strong>15-40% margins</strong> — how to hit them consistently</td></tr><tr><td style="padding:5px 0;color:#555555;font-size:14px;">✅&nbsp; <strong>$50K–$80K annual net profit</strong> roadmap for serious flippers</td></tr></table><table width="100%" cellpadding="0" cellspacing="0" style="background:#f9f9f9;border-radius:8px;margin:24px 0;"><tr><td style="padding:20px 24px;"><p style="margin:0 0 12px;color:#1A1A2E;font-size:14px;font-weight:bold;text-transform:uppercase;letter-spacing:1px;">Ready to put the playbook into action?</p><p style="margin:0 0 8px;padding:10px 14px;background:#fff;border:1px solid #e8e8e8;border-radius:6px;font-size:14px;color:#333;"><span style="color:#FF6B35;font-weight:bold;">🚗 Buyer Lane</span> — Source your first car at dealer auction prices. <a href="https://fliplane.net/buy" style="color:#FF6B35;text-decoration:none;">Find my car →</a></p><p style="margin:0 0 8px;padding:10px 14px;background:#fff;border:1px solid #e8e8e8;border-radius:6px;font-size:14px;color:#333;"><span style="color:#00A86B;font-weight:bold;">💰 Affiliate Lane</span> — Refer flippers, earn 50% commission. Zero investment. <a href="https://fliplane.net/earn" style="color:#00A86B;text-decoration:none;">Start earning →</a></p><p style="margin:0;padding:10px 14px;background:#fff;border:1px solid #e8e8e8;border-radius:6px;font-size:14px;color:#333;"><span style="color:#1A1A2E;font-weight:bold;">🤝 Co-op Partner</span> — $250 one-time + $250/deal. No monthly fees. Flip nationwide, keep 100% of profits. <a href="https://fliplane.net/partner" style="color:#FF6B35;text-decoration:none;">Join now →</a></p></td></tr></table><p style="margin:0;color:#888888;font-size:13px;line-height:1.6;">Questions? Reply to this email or visit <a href="https://fliplane.net" style="color:#FF6B35;text-decoration:none;">fliplane.net</a>.</p></td></tr><tr><td style="background:#1A1A2E;padding:20px 40px;text-align:center;"><p style="margin:0 0 4px;color:#ffffff;font-size:13px;font-weight:bold;">FlipLane</p><p style="margin:0;color:#888888;font-size:12px;">Smart money flow. Trusted access. AI-powered growth.</p></td></tr><tr><td style="background:#FF6B35;height:6px;"></td></tr></table></td></tr></table></body></html>`
    });

    const emailSent = ebookResult?.success === true;
    if (emailSent) {
      console.log(`[Ebook] ✅ Playbook sent to ${normalizedEmail}`);
    } else {
      console.error(`[Ebook] ❌ Playbook FAILED for ${normalizedEmail}:`, ebookResult?.error);
    }

    // 2. Notify owner — fire-and-forget
    sendEmail({
      to: 'win@fliplane.net',
      subject: `📧 New Insider List Signup: ${normalizedEmail}`,
      html: `
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:24px;background:#f9f9f9;border-radius:8px;">
          <h2 style="color:#1a1a1a;margin-bottom:4px;">📧 New Insider List Signup</h2>
          <p style="color:#666;font-size:13px;margin-top:0;">Submitted: ${new Date().toLocaleString('en-US', { timeZone: 'America/New_York' })} ET</p>
          <table style="width:100%;border-collapse:collapse;margin-top:16px;">
            <tr><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;font-weight:bold;width:40%;">Email</td><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;">${normalizedEmail}</td></tr>
          </table>
          <p style="margin-top:16px;color:#00A86B;font-size:13px;">✅ Ebook delivery sent to subscriber.</p>
          <p style="margin-top:4px;color:#888;font-size:12px;">Submitted via fliplane.net homepage email capture</p>
        </div>
      `
    }).catch(err => console.error('[Email] Owner notification (leads) failed:', err.message));

    // Track form event — fire-and-forget
    const _leadsIp = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket?.remoteAddress || '';
    pool.query(
      `INSERT INTO events (event_type, path, ip_hash) VALUES ($1, $2, $3)`,
      ['lead_magnet', '/', _leadsIp ? crypto.createHash('sha256').update(_leadsIp).digest('hex').slice(0, 16) : null]
    ).catch(err => console.error('[Events] Insert failed (lead_magnet):', err.message));

    res.json({
      success: true,
      message: emailSent ? 'Playbook on the way!' : 'Check your downloads — email delivery failed, but you can still download directly!',
      downloadUrl: PLAYBOOK_URL,
      emailDelivered: emailSent
    });
  } catch (err) {
    console.error('[FlipLane] Lead capture error:', err.message);
    res.status(500).json({ success: false, message: 'Something went wrong. Please try again.' });
  }
});

// POST /api/ebook-download — Flip to Fortune ebook lead capture + email delivery
app.post('/api/ebook-download', async (req, res) => {
  try {
    const { name, email, source } = req.body;

    if (!email || !email.includes('@')) {
      return res.status(400).json({ success: false, message: 'Valid email is required.' });
    }

    const normalizedEmail = email.toLowerCase().trim();
    const firstName = (name || '').trim();
    const sourcePage = source || 'flip-to-fortune';

    // Upsert into leads table (update name/source if email already exists)
    await pool.query(
      `INSERT INTO leads (email, name, source, source_page)
       VALUES ($1, $2, $3, $4)
       ON CONFLICT (email) DO UPDATE
         SET name = COALESCE(EXCLUDED.name, leads.name),
             source_page = EXCLUDED.source_page`,
      [normalizedEmail, firstName || null, 'flip_to_fortune', sourcePage]
    );

    console.log(`[FlipLane] Flip to Fortune lead: ${normalizedEmail} (${firstName})`);

    // New 12-page designed PDF (FlipLane_compressed_v2.pdf) — hosted on R2
    const PDF_URL = 'https://pub-629428d185ca4960a0a73c850d32294b.r2.dev/company_20624/files/3319c381-dac0-44f2-a11d-e333989b5e11.pdf';
    const greeting = firstName ? `Hey ${firstName}!` : 'Hey there!';

    // 1. Send ebook to subscriber — AWAIT so we can return an honest error if it fails
    // NOTE FOR QA: Do NOT use flipl@polsia.app as test email — it routes to the platform inbound (no human inbox).
    // Use a real address like win@fliplane.net or a personal Gmail to verify delivery.
    console.log(`[Ebook] Attempting playbook delivery to ${normalizedEmail}`);
    const ebookResult = await sendEmail({
      to: normalizedEmail,
      subject: 'Your Flip to Fortune playbook is ready',
      tag: 'ebook-delivery',
      listUnsubscribe: true,
      html: `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>Your Flip to Fortune Playbook</title></head><body style="margin:0;padding:0;background:#f4f4f4;font-family:Arial,Helvetica,sans-serif;"><table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f4;padding:40px 20px;"><tr><td align="center"><table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;overflow:hidden;max-width:600px;width:100%;"><tr><td style="background:#FF6B35;height:6px;"></td></tr><tr><td style="background:#1A1A2E;padding:32px 40px 28px;text-align:center;"><p style="margin:0 0 8px;color:#FF6B35;font-size:12px;letter-spacing:3px;text-transform:uppercase;font-weight:bold;">FREE PLAYBOOK</p><h1 style="margin:0;color:#ffffff;font-size:32px;line-height:1.2;">Flip to Fortune</h1><p style="margin:12px 0 0;color:#aaaaaa;font-size:15px;">The Ultimate Car-Flipping Playbook</p></td></tr><tr><td style="padding:40px 40px 32px;"><p style="margin:0 0 20px;color:#333333;font-size:16px;line-height:1.6;">${greeting} Your copy of <strong>Flip to Fortune: The Ultimate Car-Flipping Playbook</strong> is ready.</p><table width="100%" cellpadding="0" cellspacing="0" style="margin:24px 0;"><tr><td align="center" style="padding-bottom:14px;"><a href="https://fliplane.net/flip-to-fortune/read" target="_blank" style="display:inline-block;background:#FF6B35;color:#ffffff;font-size:18px;font-weight:bold;text-decoration:none;padding:16px 48px;border-radius:8px;">📖 Read Online →</a><p style="margin:6px 0 0;color:#888888;font-size:12px;">Full online read — no download needed</p></td></tr><tr><td align="center"><a href="${PDF_URL}" target="_blank" style="display:inline-block;background:transparent;color:#FF6B35;font-size:15px;font-weight:bold;text-decoration:none;padding:10px 32px;border-radius:8px;border:2px solid rgba(255,107,53,0.4);">📥 Download the Breakdown PDF</a><p style="margin:6px 0 0;color:#888888;font-size:12px;">Magazine-style summary — save &amp; reference offline</p></td></tr></table><p style="margin:0 0 12px;color:#555555;font-size:14px;line-height:1.6;">What's inside:</p><table cellpadding="0" cellspacing="0" style="margin:0 0 24px;"><tr><td style="padding:5px 0;color:#555555;font-size:14px;">✅&nbsp; <strong>10 Chapters</strong> covering every stage of the car-flipping business</td></tr><tr><td style="padding:5px 0;color:#555555;font-size:14px;">✅&nbsp; <strong>Deal math templates</strong> — never lose money on a flip</td></tr><tr><td style="padding:5px 0;color:#555555;font-size:14px;">✅&nbsp; <strong>Auction strategies</strong> for ADESA's 50,000+ weekly vehicles</td></tr><tr><td style="padding:5px 0;color:#555555;font-size:14px;">✅&nbsp; <strong>15-40% margins</strong> — how to hit them consistently</td></tr><tr><td style="padding:5px 0;color:#555555;font-size:14px;">✅&nbsp; <strong>$50K–$80K annual net profit</strong> roadmap for serious flippers</td></tr></table><table width="100%" cellpadding="0" cellspacing="0" style="background:#f9f9f9;border-radius:8px;margin:24px 0;"><tr><td style="padding:20px 24px;"><p style="margin:0 0 12px;color:#1A1A2E;font-size:14px;font-weight:bold;text-transform:uppercase;letter-spacing:1px;">Ready to put the playbook into action?</p><p style="margin:0 0 8px;padding:10px 14px;background:#fff;border:1px solid #e8e8e8;border-radius:6px;font-size:14px;color:#333;"><span style="color:#FF6B35;font-weight:bold;">🚗 Buyer Lane</span> — Source your first car at dealer auction prices. <a href="https://fliplane.net/buy" style="color:#FF6B35;text-decoration:none;">Find my car →</a></p><p style="margin:0 0 8px;padding:10px 14px;background:#fff;border:1px solid #e8e8e8;border-radius:6px;font-size:14px;color:#333;"><span style="color:#00A86B;font-weight:bold;">💰 Affiliate Lane</span> — Refer flippers, earn 50% commission. Zero investment. <a href="https://fliplane.net/earn" style="color:#00A86B;text-decoration:none;">Start earning →</a></p><p style="margin:0;padding:10px 14px;background:#fff;border:1px solid #e8e8e8;border-radius:6px;font-size:14px;color:#333;"><span style="color:#1A1A2E;font-weight:bold;">🤝 Co-op Partner</span> — $250 one-time + $250/deal. No monthly fees. Flip nationwide, keep 100% of profits. <a href="https://fliplane.net/partner" style="color:#FF6B35;text-decoration:none;">Join now →</a></p></td></tr></table><p style="margin:0;color:#888888;font-size:13px;line-height:1.6;">Questions? Reply to this email or visit <a href="https://fliplane.net" style="color:#FF6B35;text-decoration:none;">fliplane.net</a>.</p></td></tr><tr><td style="background:#1A1A2E;padding:20px 40px;text-align:center;"><p style="margin:0 0 4px;color:#ffffff;font-size:13px;font-weight:bold;">FlipLane</p><p style="margin:0;color:#888888;font-size:12px;">Smart money flow. Trusted access. AI-powered growth.</p></td></tr><tr><td style="background:#FF6B35;height:6px;"></td></tr></table></td></tr></table></body></html>`
    });

    if (ebookResult?.success) {
      console.log(`[Ebook] ✅ Playbook sent to ${normalizedEmail}`);
    } else {
      console.error(`[Ebook] ❌ Playbook FAILED for ${normalizedEmail}:`, ebookResult?.error);
    }

    const emailSent = ebookResult?.success === true;

    // 2. Notify owner — fire-and-forget (include whether delivery succeeded)
    sendEmail({
      to: 'win@fliplane.net',
      subject: `New lead: ${firstName} ${normalizedEmail} downloaded Flip to Fortune`,
      html: `
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:24px;background:#f9f9f9;border-radius:8px;">
          <h2 style="color:#1a1a1a;margin-bottom:4px;">📖 New Flip to Fortune Lead</h2>
          <p style="color:#666;font-size:13px;margin-top:0;">Submitted: ${new Date().toLocaleString('en-US', { timeZone: 'America/New_York' })} ET</p>
          <table style="width:100%;border-collapse:collapse;margin-top:16px;">
            <tr><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;font-weight:bold;width:30%;">Name</td><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;">${firstName || '(not provided)'}</td></tr>
            <tr><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;font-weight:bold;">Email</td><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;">${normalizedEmail}</td></tr>
            <tr><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;font-weight:bold;">Source</td><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;">${sourcePage}</td></tr>
          </table>
          ${emailSent
            ? '<p style="margin-top:16px;color:#00A86B;font-size:13px;font-weight:bold;">✅ Ebook delivery email sent to subscriber.</p>'
            : '<p style="margin-top:16px;color:#cc0000;font-size:13px;font-weight:bold;">❌ Ebook email failed to send — subscriber was given direct download link as fallback.</p>'}
          <p style="margin-top:4px;color:#888;font-size:12px;">Submitted via fliplane.net/flip-to-fortune</p>
        </div>
      `
    }).catch(err => console.error('[Email] Owner notification (ebook) failed:', err.message));

    // Track form event — fire-and-forget
    const _ebookIp = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket?.remoteAddress || '';
    pool.query(
      `INSERT INTO events (event_type, path, metadata, ip_hash) VALUES ($1, $2, $3, $4)`,
      ['ebook_download', '/flip-to-fortune', JSON.stringify({ source: sourcePage }), _ebookIp ? crypto.createHash('sha256').update(_ebookIp).digest('hex').slice(0, 16) : null]
    ).catch(err => console.error('[Events] Insert failed (ebook_download):', err.message));

    // Return appropriate response — always positive messaging
    res.json({
      success: true,
      message: emailSent
        ? 'Check your inbox! If you don\'t see it, check your Spam, Junk, or Promotions folder — it sometimes lands there.'
        : 'Your playbook is ready! Download it directly below.',
      downloadUrl: PDF_URL,
      emailDelivered: emailSent
    });
  } catch (err) {
    console.error('[FlipLane] Ebook download error:', err.message);
    res.status(500).json({ success: false, message: 'Something went wrong. Please try again.' });
  }
});

// POST /api/earn-interest — Affiliate Lane application (gated by confidentiality agreement)
app.post('/api/earn-interest', async (req, res) => {
  try {
    const {
      name, email, phone,
      how_to_promote, audience_reach, prior_experience, why_fliplane,
      social_links, confidentiality_agreed,
      fbc, fbp,
      ref, ref_link
    } = req.body;

    if (!name || !email) {
      return res.status(400).json({ success: false, message: 'Name and email are required.' });
    }

    // Deterministic event_id for client/server deduplication
    const earnDate = new Date().toISOString().split('T')[0];
    const capiEventId = `affiliate_lead_${email.toLowerCase().replace(/[^a-z0-9]/g, '')}_${earnDate}`;

    // Track confidentiality agreement timestamp
    const confAgreedAt = confidentiality_agreed ? new Date() : null;

    // Resolve referral link attribution if ref code or slug provided
    let referredByLinkId = null;
    if (ref_link || ref) {
      try {
        // Try by slug first (most precise — identifies exact link clicked)
        if (ref_link) {
          const linkBySlug = await pool.query(
            'SELECT id FROM referral_links WHERE slug = $1',
            [ref_link]
          );
          if (linkBySlug.rows.length > 0) {
            referredByLinkId = linkBySlug.rows[0].id;
          }
        }
        // Fall back to referral_code → default link for that affiliate
        if (!referredByLinkId && ref) {
          const linkByCode = await pool.query(
            `SELECT rl.id FROM referral_links rl
             JOIN affiliate_profiles ap ON ap.id = rl.affiliate_id
             WHERE LOWER(ap.referral_code) = LOWER($1)
             ORDER BY rl.created_at ASC LIMIT 1`,
            [ref]
          );
          if (linkByCode.rows.length > 0) {
            referredByLinkId = linkByCode.rows[0].id;
          }
        }
      } catch (refErr) {
        console.error('[FlipLane] Referral lookup error (non-blocking):', refErr.message);
      }
    }

    // Save to affiliate_signups table (with extended fields + referral attribution)
    await pool.query(
      `INSERT INTO affiliate_signups
         (name, email, phone, how_to_promote, audience_reach, prior_experience, why_fliplane, social_links, confidentiality_agreed_at, capi_event_id, referred_by_link_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
       ON CONFLICT DO NOTHING`,
      [
        name, email, phone || null,
        how_to_promote || null, audience_reach || null, prior_experience || null, why_fliplane || null,
        social_links || null, confAgreedAt, capiEventId, referredByLinkId
      ]
    );

    // Increment signups on the referral link that brought this person in
    if (referredByLinkId) {
      try {
        await pool.query('UPDATE referral_links SET signups = signups + 1 WHERE id = $1', [referredByLinkId]);

        // Log activity for the affiliate
        const linkOwner = await pool.query('SELECT affiliate_id FROM referral_links WHERE id = $1', [referredByLinkId]);
        if (linkOwner.rows.length > 0) {
          await pool.query(
            `INSERT INTO affiliate_activity (affiliate_id, type, title, description)
             VALUES ($1, 'referral_signup', 'New signup from your referral link', $2)`,
            [linkOwner.rows[0].affiliate_id, `${name} signed up via your referral link`]
          );
        }
        console.log(`[FlipLane] Referral signup attributed to link ID ${referredByLinkId}`);
      } catch (refUpdateErr) {
        console.error('[FlipLane] Referral signup increment error (non-blocking):', refUpdateErr.message);
      }
    }

    console.log(`[FlipLane] Affiliate application: ${name} (${email})`);

    // Notify owner — fire-and-forget
    sendEmail({
      to: 'win@fliplane.net',
      subject: `🤝 New Affiliate Application: ${name}`,
      html: `
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:24px;background:#f9f9f9;border-radius:8px;">
          <h2 style="color:#1a1a1a;margin-bottom:4px;">🤝 New Affiliate Application</h2>
          <p style="color:#666;font-size:13px;margin-top:0;">Submitted: ${new Date().toLocaleString('en-US', { timeZone: 'America/New_York' })} ET</p>
          <table style="width:100%;border-collapse:collapse;margin-top:16px;">
            <tr><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;font-weight:bold;width:40%;">Name</td><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;">${name}</td></tr>
            <tr><td style="padding:8px 12px;background:#f5f5f5;border:1px solid #e0e0e0;font-weight:bold;">Email</td><td style="padding:8px 12px;background:#f5f5f5;border:1px solid #e0e0e0;">${email}</td></tr>
            <tr><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;font-weight:bold;">Phone</td><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;">${phone || '—'}</td></tr>
            <tr><td style="padding:8px 12px;background:#f5f5f5;border:1px solid #e0e0e0;font-weight:bold;">How to Promote</td><td style="padding:8px 12px;background:#f5f5f5;border:1px solid #e0e0e0;">${how_to_promote || '—'}</td></tr>
            <tr><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;font-weight:bold;">Audience Reach</td><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;">${audience_reach || '—'}</td></tr>
            <tr><td style="padding:8px 12px;background:#f5f5f5;border:1px solid #e0e0e0;font-weight:bold;">Prior Experience</td><td style="padding:8px 12px;background:#f5f5f5;border:1px solid #e0e0e0;">${prior_experience || '—'}</td></tr>
            <tr><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;font-weight:bold;">Why FlipLane</td><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;">${why_fliplane || '—'}</td></tr>
            <tr><td style="padding:8px 12px;background:#f5f5f5;border:1px solid #e0e0e0;font-weight:bold;">Social Links</td><td style="padding:8px 12px;background:#f5f5f5;border:1px solid #e0e0e0;">${social_links || '—'}</td></tr>
            <tr><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;font-weight:bold;">Confidentiality Agreed</td><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;">${confidentiality_agreed ? 'Yes' : 'No'}</td></tr>
          </table>
          <p style="margin-top:20px;color:#888;font-size:12px;">Submitted via fliplane.net/earn</p>
        </div>
      `
    }).catch(err => console.error('[Email] Owner notification (earn-interest) failed:', err.message));

    // Send welcome email to affiliate applicant — fire-and-forget
    sendEmail({
      to: email,
      subject: 'FlipLane Affiliate Application Received!',
      html: `
        <div style="font-family: 'DM Sans', Arial, sans-serif; max-width: 560px; margin: 0 auto; background: #0a0a0a; color: #ffffff; padding: 40px 32px; border-radius: 12px;">
          <div style="margin-bottom: 28px;">
            <span style="font-size: 1.4rem; font-weight: 700; letter-spacing: -0.5px;">Flip<span style="color: #00e676;">Lane</span></span>
          </div>
          <h1 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 12px;">Thanks for applying, ${name.split(' ')[0]}!</h1>
          <p style="color: #a0a0a0; font-size: 1rem; line-height: 1.6; margin-bottom: 20px;">We received your affiliate application. Our team reviews applications within 48 hours. Once approved, you'll get access to your AffiliateOS dashboard with referral links, commission tracking, and marketing resources.</p>
          <div style="background: #161616; border-radius: 8px; padding: 16px 20px; margin-bottom: 20px;">
            <p style="color: #a0a0a0; margin: 0 0 6px;">What happens next:</p>
            <p style="color: #fff; margin: 0 0 4px;">1. Application review (24–48 hrs)</p>
            <p style="color: #fff; margin: 0 0 4px;">2. Approval email with dashboard access</p>
            <p style="color: #fff; margin: 0;">3. Start earning commissions on referrals</p>
          </div>
          <p style="color: #666; font-size: 0.88rem; line-height: 1.6;">Questions? Email us at <a href="mailto:win@fliplane.net" style="color: #00e676;">win@fliplane.net</a></p>
          <hr style="border: none; border-top: 1px solid #222; margin: 28px 0;">
          <p style="color: #444; font-size: 0.8rem;">FlipLane · The AI-Powered Used Car Co-op</p>
        </div>
      `
    }).catch(err => console.error('[Email] Affiliate welcome (earn-interest) failed:', err.message));

    // Fire CAPI Lead event server-side
    const ip = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket.remoteAddress;
    sendCapiEvent({
      eventName: 'Lead',
      eventId: capiEventId,
      email,
      phone,
      ip,
      userAgent: req.headers['user-agent'],
      fbc,
      fbp,
      customData: { content_name: 'FlipLane Affiliate Application', content_category: 'earn' },
      sourceUrl: `https://${req.get('host')}/earn`
    }).catch(err => console.error('[CAPI] Affiliate Lead fire failed:', err.message));

    // Track form event — fire-and-forget
    const _affiliateIp = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket?.remoteAddress || '';
    pool.query(
      `INSERT INTO events (event_type, path, ip_hash) VALUES ($1, $2, $3)`,
      ['affiliate_application', '/earn', _affiliateIp ? crypto.createHash('sha256').update(_affiliateIp).digest('hex').slice(0, 16) : null]
    ).catch(err => console.error('[Events] Insert failed (affiliate_application):', err.message));

    res.json({ success: true, capi_event_id: capiEventId, message: 'Application received. Under review.' });

  } catch (err) {
    console.error('[FlipLane] Affiliate application error:', err.message);
    res.status(500).json({ success: false, message: 'Something went wrong. Please try again.' });
  }
});

// POST /api/upload-id — Government ID upload for membership verification
app.post('/api/upload-id', idUpload.single('id_document'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, message: 'No file uploaded. Please select a government-issued ID.' });
    }

    const { member_id, email } = req.body;
    if (!email && !member_id) {
      return res.status(400).json({ success: false, message: 'Member email or ID is required.' });
    }

    // Verify member exists
    let memberId = member_id;
    if (!memberId && email) {
      const memberResult = await pool.query(
        'SELECT id FROM members WHERE LOWER(email) = LOWER($1)',
        [email]
      );
      if (memberResult.rows.length === 0) {
        return res.status(404).json({ success: false, message: 'Member not found. Please complete your application first.' });
      }
      memberId = memberResult.rows[0].id;
    }

    let documentUrl = null;

    // Upload to R2 via Polsia proxy (if configured)
    const r2BaseUrl = process.env.POLSIA_R2_BASE_URL;
    if (r2BaseUrl) {
      try {
        const formData = new FormData();
        const ext = req.file.mimetype === 'application/pdf' ? 'pdf'
          : req.file.mimetype === 'image/png' ? 'png'
          : req.file.mimetype === 'image/webp' ? 'webp'
          : 'jpg';
        const filename = `id_${memberId}_${Date.now()}.${ext}`;
        formData.append('file', req.file.buffer, { filename, contentType: req.file.mimetype });

        const uploadRes = await axios.post(`${r2BaseUrl}/upload`, formData, {
          headers: { ...formData.getHeaders() },
          timeout: 30000
        });

        documentUrl = uploadRes.data?.url || uploadRes.data?.public_url || null;
        console.log(`[ID Upload] R2 upload success for member ${memberId}: ${documentUrl}`);
      } catch (uploadErr) {
        console.error('[ID Upload] R2 upload failed, falling back to DB storage:', uploadErr.message);
        documentUrl = null; // fall through to DB storage below
      }
    }

    // DB binary storage fallback (when R2 unavailable or not configured)
    if (!documentUrl) {
      console.log(`[ID Upload] Storing ID document in database for member ${memberId}`);
      documentUrl = `db_stored_${memberId}`;
    }

    // Save to members table (include binary if storing in DB)
    const isDbStored = documentUrl.startsWith('db_stored_');
    if (isDbStored) {
      await pool.query(
        `UPDATE members
         SET id_document_url = $1, id_upload_at = NOW(), updated_at = NOW(),
             id_document_data = $3, id_document_mime = $4
         WHERE id = $2`,
        [documentUrl, memberId, req.file.buffer, req.file.mimetype]
      );
    } else {
      await pool.query(
        `UPDATE members
         SET id_document_url = $1, id_upload_at = NOW(), updated_at = NOW()
         WHERE id = $2`,
        [documentUrl, memberId]
      );
    }

    // Audit log
    await pool.query(
      `INSERT INTO member_audit_log (member_id, action, details)
       VALUES ($1, 'id_uploaded', $2)`,
      [memberId, JSON.stringify({ filename: req.file.originalname, size: req.file.size, url: documentUrl })]
    );

    console.log(`[FlipLane] ID uploaded for member ${memberId}`);

    res.json({ success: true, message: 'ID verified. Proceeding to payment.' });

  } catch (err) {
    console.error('[FlipLane] ID upload error:', err.message);
    res.status(500).json({ success: false, message: 'Upload failed. Please try again.' });
  }
});

// GET /api/admin/members/:id/id-document — Serve ID document stored in DB
app.get('/api/admin/members/:id/id-document', requireAdminAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(
      'SELECT id_document_data, id_document_mime, id_document_url FROM members WHERE id = $1',
      [id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Member not found' });
    }
    const member = result.rows[0];
    if (!member.id_document_data) {
      return res.status(404).json({ success: false, message: 'No document stored in database for this member' });
    }
    const mime = member.id_document_mime || 'application/octet-stream';
    res.set('Content-Type', mime);
    res.set('Cache-Control', 'private, max-age=3600');
    res.send(member.id_document_data);
  } catch (err) {
    console.error('[ID Serve] Error serving ID document:', err.message);
    res.status(500).json({ success: false, message: 'Failed to serve document' });
  }
});

// POST /api/signup — Submit membership application
app.post('/api/signup', async (req, res) => {
  try {
    const { name, email, phone, experience, ref_code } = req.body;

    if (!name || !email) {
      return res.status(400).json({ success: false, message: 'Name and email are required' });
    }

    // Check if already applied
    const existing = await pool.query(
      'SELECT id, status, id_document_url FROM members WHERE LOWER(email) = LOWER($1)',
      [email]
    );

    if (existing.rows.length > 0) {
      const member = existing.rows[0];
      const baseUrl = `https://${req.get('host')}`;
      const hasId = !!member.id_document_url && !member.id_document_url.startsWith('id_pending_') && !member.id_document_url.startsWith('id_uploaded_');
      // Return payment_link always for applied members (ID upload now comes AFTER payment)
      return res.json({
        success: true,
        already_applied: true,
        status: member.status,
        id_uploaded: hasId,
        member_id: member.id,
        payment_link: member.status === 'applied' ? getStripePaymentUrl(email, baseUrl) : null,
        message: member.status === 'applied'
          ? 'You already applied! Complete your payment to activate membership.'
          : 'You are already a member.'
      });
    }

    // Validate ref_code if provided — must belong to an active affiliate
    let validatedRefCode = null;
    if (ref_code) {
      const refCheck = await pool.query(
        'SELECT referral_code FROM affiliate_profiles WHERE LOWER(referral_code) = LOWER($1) AND status = \'active\'',
        [ref_code]
      );
      if (refCheck.rows.length > 0) {
        validatedRefCode = refCheck.rows[0].referral_code;
        console.log(`[Signup] Valid referral code captured: ${validatedRefCode} for ${email}`);
      }
    }

    // Insert new member
    const result = await pool.query(
      `INSERT INTO members (name, email, phone, experience, status, ref_code)
       VALUES ($1, $2, $3, $4, 'applied', $5)
       RETURNING id, email, status`,
      [name, email, phone || null, experience || null, validatedRefCode]
    );

    // Audit log
    await pool.query(
      `INSERT INTO member_audit_log (member_id, action, details)
       VALUES ($1, 'application_submitted', $2)`,
      [result.rows[0].id, JSON.stringify({ name, email, phone })]
    );

    console.log(`[FlipLane] New application: ${name} (${email})`);

    // Notify owner — fire-and-forget
    sendEmail({
      to: 'win@fliplane.net',
      subject: `🏆 New Co-op Partner Application: ${name}`,
      html: `
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:24px;background:#f9f9f9;border-radius:8px;">
          <h2 style="color:#1a1a1a;margin-bottom:4px;">🏆 New Co-op Partner Application</h2>
          <p style="color:#666;font-size:13px;margin-top:0;">Submitted: ${new Date().toLocaleString('en-US', { timeZone: 'America/New_York' })} ET</p>
          <table style="width:100%;border-collapse:collapse;margin-top:16px;">
            <tr><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;font-weight:bold;width:40%;">Name</td><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;">${name}</td></tr>
            <tr><td style="padding:8px 12px;background:#f5f5f5;border:1px solid #e0e0e0;font-weight:bold;">Email</td><td style="padding:8px 12px;background:#f5f5f5;border:1px solid #e0e0e0;">${email}</td></tr>
            <tr><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;font-weight:bold;">Phone</td><td style="padding:8px 12px;background:#fff;border:1px solid #e0e0e0;">${phone || '—'}</td></tr>
            <tr><td style="padding:8px 12px;background:#f5f5f5;border:1px solid #e0e0e0;font-weight:bold;">Experience</td><td style="padding:8px 12px;background:#f5f5f5;border:1px solid #e0e0e0;">${experience || '—'}</td></tr>
          </table>
          <p style="margin-top:20px;color:#888;font-size:12px;">Submitted via fliplane.net/join</p>
        </div>
      `
    }).catch(err => console.error('[Email] Owner notification (signup) failed:', err.message));

    // Send welcome email to co-op applicant — fire-and-forget
    const signupBaseUrl = `https://${req.get('host')}`;
    sendEmail({
      to: email,
      subject: 'Your FlipLane Co-op Application is In!',
      html: `
        <div style="font-family: 'DM Sans', Arial, sans-serif; max-width: 560px; margin: 0 auto; background: #0a0a0a; color: #ffffff; padding: 40px 32px; border-radius: 12px;">
          <div style="margin-bottom: 28px;">
            <span style="font-size: 1.4rem; font-weight: 700; letter-spacing: -0.5px;">Flip<span style="color: #00e676;">Lane</span></span>
          </div>
          <h1 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 12px;">You're almost in, ${name.split(' ')[0]}!</h1>
          <p style="color: #a0a0a0; font-size: 1rem; line-height: 1.6; margin-bottom: 20px;">Your co-op partner application has been received. Complete your payment to activate your membership and unlock your ByrddawgsOS dashboard.</p>
          <a href="${getStripePaymentUrl(email, signupBaseUrl)}" style="display: inline-block; padding: 14px 28px; background: #00e676; border-radius: 8px; color: #000; font-weight: 700; font-size: 1rem; text-decoration: none; margin-bottom: 28px;">Complete Payment & Activate →</a>
          <div style="background: #161616; border-radius: 8px; padding: 16px 20px; margin-bottom: 20px;">
            <p style="color: #a0a0a0; margin: 0 0 6px;">What you get as a co-op partner:</p>
            <p style="color: #fff; margin: 0 0 4px;">&#x2713; Auction access & dealer credentials</p>
            <p style="color: #fff; margin: 0 0 4px;">&#x2713; ByrddawgsOS deal management dashboard</p>
            <p style="color: #fff; margin: 0 0 4px;">&#x2713; Title, shipping & repair services</p>
            <p style="color: #fff; margin: 0;">&#x2713; Training & certification program</p>
          </div>
          <p style="color: #666; font-size: 0.88rem; line-height: 1.6;">Questions? Email us at <a href="mailto:win@fliplane.net" style="color: #00e676;">win@fliplane.net</a></p>
          <hr style="border: none; border-top: 1px solid #222; margin: 28px 0;">
          <p style="color: #444; font-size: 0.8rem;">FlipLane · The AI-Powered Used Car Co-op</p>
        </div>
      `
    }).catch(err => console.error('[Email] Co-op applicant welcome (signup) failed:', err.message));

    // Fire CAPI Lead event server-side
    // Use deterministic event_id keyed to email + date for client/server deduplication
    const leadDate = new Date().toISOString().split('T')[0];
    const capiEventId = `lead_${email.toLowerCase()}_${leadDate}`;
    const ip = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket.remoteAddress;
    sendCapiEvent({
      eventName: 'Lead',
      eventId: capiEventId,
      email,
      phone,
      ip,
      userAgent: req.headers['user-agent'],
      fbc: req.body.fbc,
      fbp: req.body.fbp,
      customData: { content_name: 'FlipLane Membership Application' },
      sourceUrl: `https://${req.get('host')}/join`
    }).catch(err => console.error('[CAPI] Lead fire failed:', err.message));

    // Track form event — fire-and-forget
    const _signupIp = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket?.remoteAddress || '';
    pool.query(
      `INSERT INTO events (event_type, path, ip_hash) VALUES ($1, $2, $3)`,
      ['coop_application', '/join', _signupIp ? crypto.createHash('sha256').update(_signupIp).digest('hex').slice(0, 16) : null]
    ).catch(err => console.error('[Events] Insert failed (coop_application):', err.message));

    const baseUrl = `https://${req.get('host')}`;
    res.json({
      success: true,
      member: result.rows[0],
      capi_event_id: capiEventId,
      payment_link: getStripePaymentUrl(email, baseUrl),
      message: 'Application received! Complete payment to activate your membership.'
    });

  } catch (err) {
    console.error('[FlipLane] Signup error:', err.message);
    res.status(500).json({ success: false, message: 'Something went wrong. Please try again.' });
  }
});

// POST /api/accept-agreement — Record membership agreement acceptance
app.post('/api/accept-agreement', async (req, res) => {
  try {
    const { email, version } = req.body;
    if (!email) {
      return res.status(400).json({ success: false, message: 'Email is required' });
    }

    const result = await pool.query(
      `UPDATE members
       SET agreement_accepted_at = NOW(), agreement_version = $2, updated_at = NOW()
       WHERE LOWER(email) = LOWER($1)
       RETURNING id, email`,
      [email, version || '1.0']
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Application not found. Please complete Step 1 first.' });
    }

    // Audit log
    await pool.query(
      `INSERT INTO member_audit_log (member_id, action, details)
       VALUES ($1, 'agreement_accepted', $2)`,
      [result.rows[0].id, JSON.stringify({ version: version || '1.0', email })]
    );

    console.log(`[FlipLane] Agreement accepted: ${email}`);
    res.json({ success: true, message: 'Agreement accepted.' });

  } catch (err) {
    console.error('[FlipLane] Accept agreement error:', err.message);
    res.status(500).json({ success: false, message: 'Something went wrong. Please try again.' });
  }
});

// GET /api/member-status — Check member status by email
app.get('/api/member-status', async (req, res) => {
  try {
    const { email } = req.query;
    if (!email) {
      return res.status(400).json({ success: false, message: 'Email is required' });
    }

    const result = await pool.query(
      'SELECT id, name, email, status, applied_at, approved_at, paid_at, is_certified, certified_at, id_document_url FROM members WHERE LOWER(email) = LOWER($1)',
      [email]
    );

    if (result.rows.length === 0) {
      return res.json({ success: false, found: false, message: 'No application found for this email.' });
    }

    const member = result.rows[0];
    const isPaid = member.status === 'active' || !!member.paid_at;
    const hasId = !!member.id_document_url && !member.id_document_url.startsWith('id_pending_') && !member.id_document_url.startsWith('id_uploaded_');
    const baseUrl = `https://${req.get('host')}`;
    res.json({
      success: true,
      found: true,
      member: {
        name: member.name,
        email: member.email,
        status: member.status,
        applied_at: member.applied_at,
        approved_at: member.approved_at,
        paid_at: member.paid_at,
        is_paid: isPaid,
        is_certified: !!member.is_certified,
        certified_at: member.certified_at,
        id_uploaded: hasId
      },
      payment_link: member.status === 'applied'
        ? getStripePaymentUrl(member.email, baseUrl)
        : null
    });

  } catch (err) {
    console.error('[FlipLane] Status check error:', err.message);
    res.status(500).json({ success: false, message: 'Something went wrong.' });
  }
});

// POST /api/verify-payment — Mark member as paid (admin or webhook)
app.post('/api/verify-payment', async (req, res) => {
  try {
    const { email, stripe_session_id } = req.body;
    if (!email) {
      return res.status(400).json({ success: false, message: 'Email is required' });
    }

    const result = await pool.query(
      `UPDATE members SET status = 'active', paid_at = NOW(), stripe_session_id = $2, updated_at = NOW()
       WHERE LOWER(email) = LOWER($1) AND status = 'applied'
       RETURNING id, email, status`,
      [email, stripe_session_id || null]
    );

    if (result.rows.length === 0) {
      return res.json({ success: false, message: 'No pending application found.' });
    }

    // Audit log
    await pool.query(
      `INSERT INTO member_audit_log (member_id, action, details)
       VALUES ($1, 'payment_verified', $2)`,
      [result.rows[0].id, JSON.stringify({ stripe_session_id })]
    );

    res.json({ success: true, member: result.rows[0] });

  } catch (err) {
    console.error('[FlipLane] Payment verify error:', err.message);
    res.status(500).json({ success: false, message: 'Something went wrong.' });
  }
});

// POST /api/apply-promo — Apply a promotional code to bypass payment (partner testing)
app.post('/api/apply-promo', async (req, res) => {
  try {
    const { email, code } = req.body;
    if (!email || !code) {
      return res.status(400).json({ success: false, message: 'Email and code are required.' });
    }

    // Only accept the partner test code
    const PARTNER_CODE = 'PARTNER-TEST2026';
    if (code.trim().toUpperCase() !== PARTNER_CODE.toUpperCase()) {
      return res.status(400).json({ success: false, message: 'Invalid promo code.' });
    }

    // Check if this code has already been used (stored in app_settings)
    const usageKey = 'promo_PARTNER_TEST_used';
    const usageCheck = await pool.query(
      `SELECT value FROM app_settings WHERE key = $1`,
      [usageKey]
    );
    if (usageCheck.rows.length > 0) {
      return res.status(400).json({ success: false, message: 'This promo code has already been redeemed.' });
    }

    // Find the member
    const memberRes = await pool.query(
      `SELECT id, email, status FROM members WHERE LOWER(email) = LOWER($1)`,
      [email]
    );
    if (memberRes.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'No account found for this email.' });
    }
    const member = memberRes.rows[0];
    if (member.status === 'active') {
      return res.json({ success: true, message: 'Membership already active.', redirect: `/welcome?email=${encodeURIComponent(email)}` });
    }

    // Activate member
    await pool.query(
      `UPDATE members SET status = 'active', paid_at = NOW(), updated_at = NOW() WHERE id = $1`,
      [member.id]
    );

    // Record promo code usage (max 1 use enforced)
    await pool.query(
      `INSERT INTO app_settings (key, value, updated_at)
       VALUES ($1, $2, NOW())
       ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()`,
      [usageKey, JSON.stringify({ email, usedAt: new Date().toISOString() })]
    );

    // Audit log
    try {
      await pool.query(
        `INSERT INTO member_audit_log (member_id, action, details) VALUES ($1, $2, $3)`,
        [member.id, 'promo_payment_bypass', JSON.stringify({ code: PARTNER_CODE, email })]
      );
    } catch (_) { /* audit log table may not have this action — non-fatal */ }

    console.log(`[FlipLane] Promo code ${PARTNER_CODE} redeemed by ${email}`);

    res.json({
      success: true,
      message: 'Promo applied! Membership activated.',
      redirect: `/welcome?email=${encodeURIComponent(email)}`
    });

  } catch (err) {
    console.error('[FlipLane] Apply promo error:', err.message);
    res.status(500).json({ success: false, message: 'Something went wrong. Please try again.' });
  }
});

// POST /api/manual-payment-init — Generate or retrieve manual payment order number
app.post('/api/manual-payment-init', async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ success: false, message: 'Email is required.' });

    const memberRes = await pool.query(
      `SELECT id, status, manual_payment_order_number FROM members WHERE LOWER(email) = LOWER($1)`,
      [email]
    );
    if (memberRes.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'No account found.' });
    }
    const member = memberRes.rows[0];

    // If already has an order number, return it (idempotent)
    if (member.manual_payment_order_number) {
      return res.json({ success: true, order_number: member.manual_payment_order_number });
    }

    // Generate unique order number FL-XXXXX
    const CHARS = '23456789ABCDEFGHJKMNPQRSTUVWXYZ'; // no ambiguous chars
    let orderNumber = null;
    for (let attempts = 0; attempts < 15; attempts++) {
      let candidate = 'FL-';
      for (let i = 0; i < 5; i++) candidate += CHARS[Math.floor(Math.random() * CHARS.length)];
      const existing = await pool.query(
        `SELECT id FROM members WHERE manual_payment_order_number = $1`,
        [candidate]
      );
      if (existing.rows.length === 0) { orderNumber = candidate; break; }
    }
    if (!orderNumber) return res.status(500).json({ success: false, message: 'Could not generate order number.' });

    await pool.query(
      `UPDATE members SET manual_payment_order_number = $1, updated_at = NOW() WHERE id = $2`,
      [orderNumber, member.id]
    );

    console.log(`[FlipLane] Manual payment order ${orderNumber} assigned to ${email}`);
    res.json({ success: true, order_number: orderNumber });

  } catch (err) {
    console.error('[FlipLane] Manual payment init error:', err.message);
    res.status(500).json({ success: false, message: 'Something went wrong.' });
  }
});

// POST /api/manual-payment-confirm — User confirms they sent manual payment
app.post('/api/manual-payment-confirm', async (req, res) => {
  try {
    const { email, order_number, method } = req.body;
    if (!email || !order_number) {
      return res.status(400).json({ success: false, message: 'Email and order number are required.' });
    }

    const validMethods = ['cashapp', 'venmo', 'zelle'];
    const paymentMethod = validMethods.includes(method) ? method : 'unknown';

    const result = await pool.query(
      `UPDATE members SET
         manual_payment_method = $3,
         manual_payment_submitted_at = NOW(),
         updated_at = NOW()
       WHERE LOWER(email) = LOWER($1)
         AND manual_payment_order_number = $2
       RETURNING id, email, status`,
      [email, order_number, paymentMethod]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Order not found or email mismatch.' });
    }

    // Audit log
    try {
      await pool.query(
        `INSERT INTO member_audit_log (member_id, action, details) VALUES ($1, $2, $3)`,
        [result.rows[0].id, 'manual_payment_submitted', JSON.stringify({ order_number, method: paymentMethod })]
      );
    } catch (_) { /* non-fatal */ }

    console.log(`[FlipLane] Manual payment confirmed: ${order_number} via ${paymentMethod} by ${email}`);
    res.json({ success: true, message: 'Payment submission recorded.' });

  } catch (err) {
    console.error('[FlipLane] Manual payment confirm error:', err.message);
    res.status(500).json({ success: false, message: 'Something went wrong.' });
  }
});

// ============================================================
// AUTO-LOGIN TOKEN HELPERS
// ============================================================

async function generateLoginToken(email) {
  const token = crypto.randomBytes(32).toString('hex');
  const expiresAt = new Date(Date.now() + 15 * 60 * 1000); // 15 minutes

  await pool.query(
    `INSERT INTO login_tokens (token, email, expires_at)
     VALUES ($1, $2, $3)`,
    [token, email.toLowerCase(), expiresAt]
  );

  return token;
}

async function validateLoginToken(token) {
  const result = await pool.query(
    `SELECT email, expires_at, used FROM login_tokens WHERE token = $1`,
    [token]
  );

  if (result.rows.length === 0) {
    return { valid: false, reason: 'Token not found' };
  }

  const tokenData = result.rows[0];

  if (tokenData.used) {
    return { valid: false, reason: 'Token already used' };
  }

  if (new Date() > new Date(tokenData.expires_at)) {
    return { valid: false, reason: 'Token expired' };
  }

  // Mark token as used
  await pool.query(
    `UPDATE login_tokens SET used = TRUE WHERE token = $1`,
    [token]
  );

  return { valid: true, email: tokenData.email };
}

// POST /api/stripe-webhook — Handle Stripe payment events
app.post('/api/stripe-webhook', async (req, res) => {
  try {
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
    let event;

    // Verify Stripe webhook signature (stripe-node v17+)
    if (webhookSecret && webhookSecret !== 'whsec_placeholder') {
      try {
        const sig = req.headers['stripe-signature'];
        if (!sig) {
          console.error('[Stripe Webhook] Missing stripe-signature header');
          return res.status(400).json({ success: false, message: 'Missing signature' });
        }
        event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
      } catch (sigErr) {
        console.error('[Stripe Webhook] Signature verification failed:', sigErr.message);
        return res.status(400).json({ success: false, message: 'Invalid signature' });
      }
    } else {
      // Fallback: parse without verification (dev mode only — log warning)
      if (!webhookSecret) {
        console.warn('[Stripe Webhook] STRIPE_WEBHOOK_SECRET not set — skipping signature verification (dev only)');
      }
      event = JSON.parse(req.body.toString());
    }

    console.log(`[Stripe Webhook] Received event: ${event.type}`);

    // Handle checkout.session.completed event
    if (event.type === 'checkout.session.completed') {
      const session = event.data.object;

      // Extract email from session
      const email = session.customer_email || session.customer_details?.email;

      if (!email) {
        console.error('[Stripe Webhook] No email found in session:', session.id);
        return res.json({ success: false, message: 'No email in session' });
      }

      console.log(`[Stripe Webhook] Payment completed for: ${email}`);

      // Update member status to active
      const result = await pool.query(
        `UPDATE members SET status = 'active', paid_at = NOW(), stripe_session_id = $1, stripe_customer_id = $2, updated_at = NOW()
         WHERE LOWER(email) = LOWER($3)
         RETURNING id, email, status`,
        [session.id, session.customer, email]
      );

      if (result.rows.length === 0) {
        console.error(`[Stripe Webhook] No member found for email: ${email}`);
        return res.json({ success: false, message: 'Member not found' });
      }

      // Audit log
      await pool.query(
        `INSERT INTO member_audit_log (member_id, action, details)
         VALUES ($1, 'payment_verified_webhook', $2)`,
        [result.rows[0].id, JSON.stringify({
          stripe_session_id: session.id,
          stripe_customer_id: session.customer,
          amount: session.amount_total,
          currency: session.currency
        })]
      );

      console.log(`[Stripe Webhook] Member activated: ${email}`);

      // Auto-commission: if this member was referred by an affiliate, create a $125 commission
      try {
        const memberRefResult = await pool.query(
          `SELECT id, name, ref_code, affiliate_commission_created
           FROM members WHERE LOWER(email) = LOWER($1)`,
          [email]
        );
        const memberRec = memberRefResult.rows[0];
        if (memberRec && memberRec.ref_code && !memberRec.affiliate_commission_created) {
          // Look up the affiliate by referral code
          const affiliateResult = await pool.query(
            `SELECT id, name, email FROM affiliate_profiles
             WHERE LOWER(referral_code) = LOWER($1) AND status = 'active'`,
            [memberRec.ref_code]
          );
          if (affiliateResult.rows.length > 0) {
            const affiliate = affiliateResult.rows[0];
            const REFERRAL_COMMISSION_AMOUNT = '125.00'; // 50% of $250

            // Create the commission record
            const commResult = await pool.query(
              `INSERT INTO commissions (affiliate_id, type, description, amount, status, reference_type, reference_id)
               VALUES ($1, 'referral', $2, $3, 'pending', 'member', $4)
               RETURNING id`,
              [
                affiliate.id,
                `Referral commission — ${email} joined as co-op partner`,
                REFERRAL_COMMISSION_AMOUNT,
                memberRec.id
              ]
            );

            // Update affiliate totals
            await pool.query(
              `UPDATE affiliate_profiles
               SET total_earned = total_earned + $1,
                   total_pending = total_pending + $1,
                   updated_at = NOW()
               WHERE id = $2`,
              [REFERRAL_COMMISSION_AMOUNT, affiliate.id]
            );

            // Add activity feed entry
            await pool.query(
              `INSERT INTO affiliate_activity (affiliate_id, type, title, description, metadata)
               VALUES ($1, 'commission_created', $2, $3, $4)`,
              [
                affiliate.id,
                `New referral commission: $${REFERRAL_COMMISSION_AMOUNT}`,
                `${email} joined as a co-op partner using your referral link`,
                JSON.stringify({
                  commission_id: commResult.rows[0].id,
                  amount: REFERRAL_COMMISSION_AMOUNT,
                  referred_email: email
                })
              ]
            );

            // Mark commission created so we don't double-create on retries
            await pool.query(
              'UPDATE members SET affiliate_commission_created = TRUE WHERE id = $1',
              [memberRec.id]
            );

            console.log(`[Stripe Webhook] Auto-commission $${REFERRAL_COMMISSION_AMOUNT} created for affiliate ${affiliate.name} (ref: ${memberRec.ref_code})`);
          }
        }
      } catch (commErr) {
        // Non-fatal — log but don't fail the webhook
        console.error('[Stripe Webhook] Auto-commission error:', commErr.message);
      }

      // Fire CAPI Purchase + CompleteRegistration server-side
      // event_id must match client-side for deduplication (keyed to email + today's date)
      const today = new Date().toISOString().split('T')[0];
      const purchaseEventId = `purchase_${email.toLowerCase()}_${today}`;
      const registrationEventId = `reg_${email.toLowerCase()}_${today}`;
      sendCapiEvent({
        eventName: 'Purchase',
        eventId: purchaseEventId,
        email,
        customData: {
          currency: (session.currency || 'usd').toUpperCase(),
          value: session.amount_total ? session.amount_total / 100 : 250,
          content_name: 'FlipLane Membership',
          content_type: 'product'
        },
        sourceUrl: process.env.APP_URL || 'https://flipl.polsia.app'
      }).catch(err => console.error('[CAPI] Purchase fire failed:', err.message));

      sendCapiEvent({
        eventName: 'CompleteRegistration',
        eventId: registrationEventId,
        email,
        customData: { content_name: 'FlipLane Membership', status: 'active' },
        sourceUrl: process.env.APP_URL || 'https://flipl.polsia.app'
      }).catch(err => console.error('[CAPI] CompleteRegistration fire failed:', err.message));

      // Send FlipLane Terms of Service for electronic signature via DocuSeal
      const member = result.rows[0];
      const docusealResult = await docuseal.sendTermsForSignature(
        pool,
        member.email,
        member.name,
        'member',
        member.id
      );

      if (docusealResult.success) {
        // Update member with DocuSeal Terms signature status
        await pool.query(
          `UPDATE members
           SET docusign_envelope_id = $1,
               docusign_status = $2,
               docusign_sent_at = NOW(),
               terms_signature_status = 'sent'
           WHERE id = $3`,
          [docusealResult.envelopeId, docusealResult.status, member.id]
        );

        // Log DocuSeal Terms send
        await pool.query(
          `INSERT INTO member_audit_log (member_id, action, details)
           VALUES ($1, 'terms_signature_sent', $2)`,
          [member.id, JSON.stringify({
            envelope_id: docusealResult.envelopeId,
            status: docusealResult.status,
            document_type: 'terms'
          })]
        );

        console.log(`[DocuSeal] Terms sent to ${email}. Envelope: ${docusealResult.envelopeId}`);
      } else {
        console.log(`[DocuSeal] Terms send queued: ${docusealResult.message || 'configuration pending'}`);
      }

      // Fetch full member record for welcome email personalization
      const memberFull = await pool.query(
        'SELECT id, name, email FROM members WHERE id = $1',
        [member.id]
      );
      const memberRecord = memberFull.rows[0] || { id: member.id, name: '', email };
      const memberFirstName = (memberRecord.name || '').split(' ')[0] || 'Partner';
      const appUrl = process.env.APP_URL || 'https://flipl.polsia.app';
      const certLink = `${appUrl}/certification?email=${encodeURIComponent(email)}`;
      const memberId = `FL-${String(member.id).padStart(5, '0')}`;

      // Send welcome email to new co-op partner immediately after payment
      sendEmail({
        to: email,
        subject: 'Welcome to FlipLane Co-op! 🎉 Here\'s what\'s next',
        html: `
          <div style="font-family: 'DM Sans', Arial, sans-serif; max-width: 560px; margin: 0 auto; background: #0a0a0a; color: #ffffff; padding: 40px 32px; border-radius: 12px;">
            <div style="margin-bottom: 28px;">
              <span style="font-size: 1.4rem; font-weight: 700; letter-spacing: -0.5px;">Flip<span style="color: #00e676;">Lane</span></span>
            </div>
            <h1 style="font-size: 1.7rem; font-weight: 700; margin-bottom: 8px; letter-spacing: -0.5px;">Welcome to the Co-op, ${memberFirstName}! 🎉</h1>
            <p style="color: #a0a0a0; font-size: 0.88rem; margin-bottom: 24px;">Member ID: <strong style="color: #00e676;">${memberId}</strong></p>
            <p style="color: #a0a0a0; font-size: 1rem; line-height: 1.6; margin-bottom: 12px;">Your $250 payment is confirmed. You're officially a FlipLane co-op partner — operating under Byrd Dawgs Automotive Group's dealer license with full access to auction credentials, ByrddawgsOS, and our deal processing team.</p>

            <!-- Urgency headline -->
            <p style="color: #ffffff; font-size: 1.1rem; font-weight: 700; margin-bottom: 6px; letter-spacing: -0.3px;">Just one more step — get certified and start flipping today.</p>
            <p style="color: #a0a0a0; font-size: 0.88rem; margin-bottom: 28px;">Watch the video below, then complete your certification to unlock everything.</p>

            <!-- Welcome Video Block -->
            <div style="margin-bottom: 32px;">
              <a href="${appUrl}/watch/welcome" style="display: block; text-decoration: none; border-radius: 12px; overflow: hidden; position: relative; background: linear-gradient(135deg, #0d1b2a 0%, #1a2f45 50%, #0d1b2a 100%); border: 1px solid #1e3a52;">
                <div style="padding: 36px 24px; text-align: center;">
                  <div style="display: inline-flex; align-items: center; justify-content: center; width: 64px; height: 64px; background: rgba(0,230,118,0.15); border: 2px solid #00e676; border-radius: 50%; margin-bottom: 16px;">
                    <span style="font-size: 1.5rem; line-height: 1; margin-left: 4px; color: #00e676;">&#9654;</span>
                  </div>
                  <p style="color: #ffffff; font-weight: 700; font-size: 1rem; margin: 0 0 6px; letter-spacing: -0.3px;">Get Certified &amp; Start Flipping</p>
                  <p style="color: #a0a0a0; font-size: 0.82rem; margin: 0;">Watch this before you start your certification — 60 seconds</p>
                </div>
                <div style="background: rgba(0,230,118,0.08); border-top: 1px solid #1e3a52; padding: 10px 24px; text-align: center;">
                  <span style="color: #00e676; font-size: 0.82rem; font-weight: 600;">▶ &nbsp;Watch Now</span>
                </div>
              </a>
            </div>

            <div style="text-align: center; margin-bottom: 32px;">
              <a href="${certLink}" style="display: inline-block; padding: 16px 32px; background: #00e676; border-radius: 10px; color: #000; font-weight: 700; font-size: 1.05rem; text-decoration: none; letter-spacing: -0.3px;">Get Certified Now →</a>
              <p style="color: #666; font-size: 0.8rem; margin-top: 10px;">Takes about 5 minutes. Pass the quiz to unlock your full dashboard.</p>
            </div>

            <div style="background: #161616; border-radius: 10px; padding: 20px 24px; margin-bottom: 28px; border: 1px solid #222;">
              <p style="font-weight: 700; font-size: 0.95rem; margin-bottom: 16px; color: #fff;">Quick-start guide — what to expect:</p>
              <div style="margin-bottom: 12px;">
                <p style="color: #00e676; font-weight: 700; font-size: 0.88rem; margin-bottom: 2px;">STEP 1 — Complete certification</p>
                <p style="color: #a0a0a0; font-size: 0.88rem; margin: 0;">4 short training modules + a 5-question quiz. 100% pass required, unlimited retakes. Click the button above to start now.</p>
              </div>
              <div style="margin-bottom: 12px;">
                <p style="color: #00e676; font-weight: 700; font-size: 0.88rem; margin-bottom: 2px;">STEP 2 — Sign your DocuSign agreement</p>
                <p style="color: #a0a0a0; font-size: 0.88rem; margin: 0;">A confidentiality agreement is on its way to your inbox from DocuSign. Sign it to protect the shared dealer credentials.</p>
              </div>
              <div style="margin-bottom: 12px;">
                <p style="color: #00e676; font-weight: 700; font-size: 0.88rem; margin-bottom: 2px;">STEP 3 — Access ByrddawgsOS</p>
                <p style="color: #a0a0a0; font-size: 0.88rem; margin: 0;">Once certified, your dashboard unlocks automatically. You'll find auction credentials (ADESA, OVE, TitleMax), deal submission tools, title &amp; shipping requests, and more.</p>
              </div>
              <div>
                <p style="color: #00e676; font-weight: 700; font-size: 0.88rem; margin-bottom: 2px;">STEP 4 — Run your first deal</p>
                <p style="color: #a0a0a0; font-size: 0.88rem; margin: 0;">Submit a deal sheet from your dashboard. FlipLane handles title, paperwork, and processing. Flat $250/deal fee — you keep 100% of cash deal profit above that.</p>
              </div>
            </div>

            <p style="color: #666; font-size: 0.88rem; line-height: 1.6;">Questions? Reply to this email or reach us at <a href="mailto:win@fliplane.net" style="color: #00e676;">win@fliplane.net</a>. We respond to everything.</p>
            <hr style="border: none; border-top: 1px solid #222; margin: 28px 0;">
            <p style="color: #444; font-size: 0.8rem;">FlipLane · Member ID ${memberId}</p>
          </div>
        `
      }).catch(e => console.error('[Stripe Webhook] Welcome email error:', e.message));

      // Notify ops of new payment
      sendEmail({
        to: 'win@fliplane.net',
        subject: `💰 New co-op partner joined: ${memberRecord.name} (${email})`,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 500px; padding: 24px;">
            <h2 style="color: #1a1a1a; margin-bottom: 4px;">💰 New Co-op Partner Payment</h2>
            <p style="color: #666; font-size: 13px; margin-top: 0;">${new Date().toLocaleString('en-US', { timeZone: 'America/New_York' })} ET</p>
            <table style="width: 100%; border-collapse: collapse; margin-top: 16px;">
              <tr><td style="padding: 8px 12px; background: #fff; border: 1px solid #e0e0e0; font-weight: bold; width: 35%;">Name</td><td style="padding: 8px 12px; background: #fff; border: 1px solid #e0e0e0;">${memberRecord.name || '—'}</td></tr>
              <tr><td style="padding: 8px 12px; background: #f5f5f5; border: 1px solid #e0e0e0; font-weight: bold;">Email</td><td style="padding: 8px 12px; background: #f5f5f5; border: 1px solid #e0e0e0;">${email}</td></tr>
              <tr><td style="padding: 8px 12px; background: #fff; border: 1px solid #e0e0e0; font-weight: bold;">Member ID</td><td style="padding: 8px 12px; background: #fff; border: 1px solid #e0e0e0;">${memberId}</td></tr>
              <tr><td style="padding: 8px 12px; background: #f5f5f5; border: 1px solid #e0e0e0; font-weight: bold;">Amount</td><td style="padding: 8px 12px; background: #f5f5f5; border: 1px solid #e0e0e0;">$${session.amount_total ? (session.amount_total / 100).toFixed(2) : '250.00'}</td></tr>
              <tr><td style="padding: 8px 12px; background: #fff; border: 1px solid #e0e0e0; font-weight: bold;">Stripe Session</td><td style="padding: 8px 12px; background: #fff; border: 1px solid #e0e0e0;">${session.id}</td></tr>
            </table>
            <p style="margin-top: 16px; color: #888; font-size: 12px;">Welcome email + DocuSign sent automatically. Certification pending.</p>
          </div>
        `
      }).catch(e => console.error('[Stripe Webhook] Admin notification error:', e.message));

      console.log(`[Stripe Webhook] Welcome email + admin notification sent for: ${email}`);
    }

    res.json({ received: true });

  } catch (err) {
    console.error('[Stripe Webhook] Error:', err.message);
    res.status(500).json({ success: false, message: 'Webhook error' });
  }
});

// POST /api/certification/complete — Mark member as certified after quiz pass
app.post('/api/certification/complete', async (req, res) => {
  try {
    const { email, score } = req.body;
    if (!email) {
      return res.status(400).json({ success: false, message: 'Email is required' });
    }

    const quizScore = parseInt(score, 10) || 5;

    // Look up member — must exist, be paid, and have uploaded ID
    const lookup = await pool.query(
      'SELECT id, name, email, status, paid_at, is_certified, id_document_url FROM members WHERE LOWER(email) = LOWER($1)',
      [email]
    );

    if (lookup.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Member not found.' });
    }

    const member = lookup.rows[0];
    const isPaid = member.status === 'active' || !!member.paid_at;
    const hasId = !!member.id_document_url && !member.id_document_url.startsWith('id_pending_') && !member.id_document_url.startsWith('id_uploaded_');

    if (!isPaid) {
      return res.status(403).json({ success: false, message: 'Payment required before certification.' });
    }

    if (!hasId) {
      return res.status(403).json({ success: false, message: 'ID verification required before certification. Please upload your government-issued ID first.' });
    }

    // Already certified — idempotent
    if (member.is_certified) {
      console.log(`[Certification] ${email} already certified — generating token`);
      const token = await generateLoginToken(email);
      return res.json({ success: true, already_certified: true, token });
    }

    // Mark certified
    await pool.query(
      `UPDATE members SET is_certified = TRUE, certified_at = NOW(), quiz_score = $1, updated_at = NOW() WHERE id = $2`,
      [quizScore, member.id]
    );

    // Audit log
    await pool.query(
      `INSERT INTO member_audit_log (member_id, action, details) VALUES ($1, 'certification_completed', $2)`,
      [member.id, JSON.stringify({ quiz_score: quizScore, certified_at: new Date().toISOString() })]
    );

    console.log(`[Certification] ${email} certified! Quiz score: ${quizScore}/5`);

    // Generate login token for auto-redirect to dashboard
    const loginToken = await generateLoginToken(email);

    // Send welcome email to member (async — don't block response)
    const appUrl = process.env.APP_URL || 'https://fliplane.net';
    sendEmail({
      to: email,
      subject: 'Welcome to FlipLane! You\'re now certified 🎉',
      html: `
        <div style="font-family: 'DM Sans', Arial, sans-serif; max-width: 560px; margin: 0 auto; background: #0a0a0a; color: #ffffff; padding: 40px 32px; border-radius: 12px;">
          <div style="margin-bottom: 28px;">
            <span style="font-size: 1.4rem; font-weight: 700; letter-spacing: -0.5px;">Flip<span style="color: #00e676;">Lane</span></span>
          </div>
          <h1 style="font-size: 1.6rem; font-weight: 700; margin-bottom: 12px; letter-spacing: -0.5px;">Welcome to FlipLane, ${member.name.split(' ')[0]}! 🎉</h1>
          <p style="color: #a0a0a0; font-size: 1rem; line-height: 1.6; margin-bottom: 24px;">You're now a certified co-op partner. Your ByrddawgsOS dashboard is live and ready — auction credentials, deal submission, inventory tools, all of it.</p>

          <!-- Welcome Video Block -->
          <div style="margin-bottom: 28px;">
            <a href="${appUrl}/watch/welcome" style="display: block; text-decoration: none; border-radius: 12px; overflow: hidden; background: linear-gradient(135deg, #0d1b2a 0%, #1a2f45 50%, #0d1b2a 100%); border: 1px solid #1e3a52;">
              <div style="padding: 32px 24px; text-align: center;">
                <div style="display: inline-flex; align-items: center; justify-content: center; width: 60px; height: 60px; background: rgba(0,230,118,0.15); border: 2px solid #00e676; border-radius: 50%; margin-bottom: 14px;">
                  <span style="font-size: 1.4rem; line-height: 1; margin-left: 4px; color: #00e676;">&#9654;</span>
                </div>
                <p style="color: #ffffff; font-weight: 700; font-size: 0.95rem; margin: 0 0 5px; letter-spacing: -0.3px;">Watch Your Welcome Overview</p>
                <p style="color: #a0a0a0; font-size: 0.8rem; margin: 0;">How to run your first deal — 60 seconds</p>
              </div>
              <div style="background: rgba(0,230,118,0.08); border-top: 1px solid #1e3a52; padding: 9px 24px; text-align: center;">
                <span style="color: #00e676; font-size: 0.8rem; font-weight: 600;">▶ &nbsp;Watch Now</span>
              </div>
            </a>
          </div>

          <a href="${appUrl}/dashboard" style="display: inline-block; padding: 14px 28px; background: #00e676; border-radius: 8px; color: #000; font-weight: 700; font-size: 1rem; text-decoration: none; margin-bottom: 28px;">Access My Dashboard →</a>
          <p style="color: #666; font-size: 0.88rem; line-height: 1.6;">Questions? Email us at <a href="mailto:win@fliplane.net" style="color: #00e676;">win@fliplane.net</a>. We're here to help you run deals.</p>
          <hr style="border: none; border-top: 1px solid #222; margin: 28px 0;">
          <p style="color: #444; font-size: 0.8rem;">FlipLane · The AI-Powered Used Car Co-op</p>
        </div>
      `
    }).catch(e => console.error('[Certification] Welcome email error:', e.message));

    // Send internal notification to ops
    sendEmail({
      to: 'win@fliplane.net',
      subject: `New certified member: ${member.name} (${email})`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 500px;">
          <h2>New Certified Co-op Partner</h2>
          <p><strong>Name:</strong> ${member.name}</p>
          <p><strong>Email:</strong> ${email}</p>
          <p><strong>Quiz Score:</strong> ${quizScore}/5</p>
          <p><strong>Date:</strong> ${new Date().toISOString()}</p>
          <p><strong>Member ID:</strong> ${member.id}</p>
        </div>
      `
    }).catch(e => console.error('[Certification] Internal notification email error:', e.message));

    res.json({ success: true, token: loginToken });

  } catch (err) {
    console.error('[Certification] Complete error:', err.message);
    res.status(500).json({ success: false, message: 'Something went wrong.' });
  }
});

// GET /api/generate-login-token — Generate one-time login token for email
app.get('/api/generate-login-token', async (req, res) => {
  try {
    const { email } = req.query;
    if (!email) {
      return res.status(400).json({ success: false, message: 'Email is required' });
    }

    // Verify member exists and is active
    const memberResult = await pool.query(
      'SELECT id, email, status FROM members WHERE LOWER(email) = LOWER($1)',
      [email]
    );

    if (memberResult.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Member not found' });
    }

    const member = memberResult.rows[0];

    // Generate token
    const token = await generateLoginToken(member.email);

    res.json({
      success: true,
      token,
      email: member.email,
      status: member.status
    });

  } catch (err) {
    console.error('[FlipLane] Token generation error:', err.message);
    res.status(500).json({ success: false, message: 'Something went wrong.' });
  }
});

// GET /api/validate-login-token — Validate and consume login token
app.get('/api/validate-login-token', async (req, res) => {
  try {
    const { token } = req.query;
    if (!token) {
      return res.status(400).json({ success: false, message: 'Token is required' });
    }

    const validation = await validateLoginToken(token);

    if (!validation.valid) {
      return res.status(401).json({
        success: false,
        message: validation.reason
      });
    }

    // Get member details
    const memberResult = await pool.query(
      'SELECT id, name, email, status, is_certified FROM members WHERE LOWER(email) = LOWER($1)',
      [validation.email]
    );

    if (memberResult.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Member not found' });
    }

    const member = memberResult.rows[0];
    res.json({
      success: true,
      member: {
        id: member.id,
        name: member.name,
        email: member.email,
        status: member.status,
        is_certified: !!member.is_certified
      }
    });

  } catch (err) {
    console.error('[FlipLane] Token validation error:', err.message);
    res.status(500).json({ success: false, message: 'Something went wrong.' });
  }
});

// ============================================================
// BYRDDAWGSOS API ROUTES
// ============================================================

// GET /api/byrddawgsos/auctions — Get auction credentials (approved members only)
app.get('/api/byrddawgsos/auctions', async (req, res) => {
  try {
    const { email } = req.query;
    if (!email) {
      return res.status(401).json({ success: false, message: 'Authentication required. Please provide your email.' });
    }

    // Verify the requester is an active or approved member AND has passed certification
    const memberResult = await pool.query(
      "SELECT id FROM members WHERE LOWER(email) = LOWER($1) AND status IN ('active', 'approved') AND is_certified = TRUE",
      [email]
    );
    if (memberResult.rows.length === 0) {
      return res.status(403).json({ success: false, message: 'Access denied. Complete your certification to unlock credentials.' });
    }

    const result = await pool.query(
      'SELECT id, auction_name, username, encrypted_password, password, website_url, notes FROM auction_credentials ORDER BY auction_name'
    );

    // Decrypt passwords before returning — prefer encrypted_password, fall back to legacy plaintext
    const auctions = result.rows.map(row => {
      const pwd = row.encrypted_password
        ? decryptField(row.encrypted_password)
        : (row.password || null);
      return { id: row.id, auction_name: row.auction_name, username: row.username, password: pwd, website_url: row.website_url, notes: row.notes };
    });

    res.json({ success: true, auctions });
  } catch (err) {
    console.error('[ByrddawgsOS] Auctions error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch auctions.' });
  }
});

// GET /api/byrddawgsos/inquiries — Get customer inquiries for a member
app.get('/api/byrddawgsos/inquiries', async (req, res) => {
  try {
    const { email } = req.query;
    if (!email) {
      return res.status(400).json({ success: false, message: 'Email is required' });
    }

    // Get member ID (requires active/approved + certified for Affiliate Hub data)
    const memberResult = await pool.query(
      "SELECT id FROM members WHERE LOWER(email) = LOWER($1) AND status IN ('active', 'approved') AND is_certified = TRUE",
      [email]
    );

    if (memberResult.rows.length === 0) {
      return res.status(403).json({ success: false, message: 'Complete your certification to access customer inquiries.' });
    }

    const memberId = memberResult.rows[0].id;

    // Get inquiries from service_requests (customer_inquiry forms save here, not customer_inquiries table)
    const result = await pool.query(
      `SELECT id,
              form_data->>'customer_name' AS customer_name,
              form_data->>'customer_email' AS customer_email,
              form_data->>'customer_phone' AS customer_phone,
              form_data->>'vehicle_interest' AS vehicle_interest,
              form_data->>'message' AS message,
              status,
              created_at
       FROM service_requests
       WHERE member_id = $1 AND request_type = 'customer_inquiry'
       ORDER BY created_at DESC`,
      [memberId]
    );

    res.json({ success: true, inquiries: result.rows });
  } catch (err) {
    console.error('[ByrddawgsOS] Inquiries error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch inquiries.' });
  }
});

// GET /api/byrddawgsos/tickets — Get support tickets for a member
app.get('/api/byrddawgsos/tickets', async (req, res) => {
  try {
    const { email } = req.query;
    if (!email) {
      return res.status(400).json({ success: false, message: 'Email is required' });
    }

    // Get member ID (requires active/approved membership — support is available pre-certification)
    const memberResult = await pool.query(
      "SELECT id FROM members WHERE LOWER(email) = LOWER($1) AND status IN ('active', 'approved')",
      [email]
    );

    if (memberResult.rows.length === 0) {
      return res.json({ success: true, tickets: [] });
    }

    const memberId = memberResult.rows[0].id;

    // Get tickets
    const result = await pool.query(
      `SELECT id, subject, message, status, priority, created_at, resolved_at
       FROM support_tickets
       WHERE member_id = $1
       ORDER BY created_at DESC`,
      [memberId]
    );

    res.json({ success: true, tickets: result.rows });
  } catch (err) {
    console.error('[ByrddawgsOS] Tickets error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch tickets.' });
  }
});

// POST /api/byrddawgsos/tickets — Create a new support ticket
app.post('/api/byrddawgsos/tickets', async (req, res) => {
  try {
    const { email, subject, message, priority } = req.body;

    if (!email || !subject || !message) {
      return res.status(400).json({ success: false, message: 'Email, subject, and message are required' });
    }

    // Get member ID
    const memberResult = await pool.query(
      'SELECT id FROM members WHERE LOWER(email) = LOWER($1)',
      [email]
    );

    if (memberResult.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Member not found' });
    }

    const memberId = memberResult.rows[0].id;

    // Create ticket
    const result = await pool.query(
      `INSERT INTO support_tickets (member_id, subject, message, priority, status)
       VALUES ($1, $2, $3, $4, 'open')
       RETURNING id, subject, message, status, created_at`,
      [memberId, subject, message, priority || 'normal']
    );

    console.log(`[ByrddawgsOS] New support ticket from member ${memberId}: ${subject}`);

    res.json({ success: true, ticket: result.rows[0] });
  } catch (err) {
    console.error('[ByrddawgsOS] Create ticket error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to create ticket.' });
  }
});

// POST /api/byrddawgsos/book-call — Contact Me form: saves to service_requests + sends email
app.post('/api/byrddawgsos/book-call', async (req, res) => {
  try {
    const { email, name, message } = req.body;

    if (!email || !name || !message) {
      return res.status(400).json({ success: false, message: 'Name, email, and message are required' });
    }

    // Look up member_id from email (optional — guests can also submit)
    let memberId = null;
    const mRes = await pool.query('SELECT id FROM members WHERE email = $1 LIMIT 1', [email.toLowerCase().trim()]);
    if (mRes.rows.length > 0) memberId = mRes.rows[0].id;

    // Save to service_requests so it shows in Admin → Service Requests
    const dbRes = await pool.query(
      `INSERT INTO service_requests (member_id, request_type, form_data, status, created_at, updated_at)
       VALUES ($1, 'contact', $2, 'pending', NOW(), NOW()) RETURNING id`,
      [memberId, JSON.stringify({ name, email, message })]
    );
    const requestId = dbRes.rows[0].id;

    const emailHtml = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; background: #0a0a0a; color: #ffffff; padding: 32px; border-radius: 12px;">
        <h2 style="color: #00e676; margin-top: 0;">✉️ New Contact Message — ByrddawgsOS</h2>
        <table style="width: 100%; border-collapse: collapse;">
          <tr><td style="padding: 8px 0; color: #a0a0a0; width: 120px;">Name</td><td style="padding: 8px 0; font-weight: 600;">${name}</td></tr>
          <tr><td style="padding: 8px 0; color: #a0a0a0;">Email</td><td style="padding: 8px 0;"><a href="mailto:${email}" style="color: #00e676;">${email}</a></td></tr>
          <tr><td style="padding: 8px 0; color: #a0a0a0; vertical-align: top;">Message</td><td style="padding: 8px 0; white-space: pre-wrap;">${message}</td></tr>
        </table>
        <div style="margin-top: 24px; padding-top: 16px; border-top: 1px solid #1e1e1e; font-size: 12px; color: #555555;">Request #${requestId} · Sent from ByrddawgsOS Member Hub</div>
      </div>
    `;

    await sendEmail({
      to: 'win@fliplane.net',
      subject: `✉️ Contact Message from ${name}`,
      html: emailHtml,
      replyTo: email,
      tag: 'contact-form'
    });

    // Confirmation to sender — fire-and-forget
    sendEmail({
      to: email,
      subject: `We got your message!`,
      html: `
        <div style="font-family: 'DM Sans', Arial, sans-serif; max-width: 560px; margin: 0 auto; background: #0a0a0a; color: #ffffff; padding: 40px 32px; border-radius: 12px;">
          <div style="margin-bottom: 28px;">
            <span style="font-size: 1.4rem; font-weight: 700; letter-spacing: -0.5px;">Flip<span style="color: #00e676;">Lane</span></span>
          </div>
          <h1 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 12px;">Got it, ${name.split(' ')[0]}!</h1>
          <p style="color: #a0a0a0; font-size: 1rem; line-height: 1.6; margin-bottom: 20px;">We received your message and will get back to you within 24 hours.</p>
          <div style="background: #161616; border-radius: 8px; padding: 16px 20px; margin-bottom: 20px;">
            <p style="color: #a0a0a0; margin: 0; white-space: pre-wrap;">${message}</p>
          </div>
          <p style="color: #666; font-size: 0.88rem;">Need urgent help? Email <a href="mailto:win@fliplane.net" style="color: #00e676;">win@fliplane.net</a></p>
          <hr style="border: none; border-top: 1px solid #222; margin: 28px 0;">
          <p style="color: #444; font-size: 0.8rem;">FlipLane · ByrddawgsOS Member Hub</p>
        </div>
      `,
      tag: 'contact-confirmation'
    }).catch(err => console.error('[Email] Contact confirmation failed:', err.message));

    console.log(`[ByrddawgsOS] Contact form #${requestId} from ${email}`);
    res.json({ success: true, message: 'Message sent!' });
  } catch (err) {
    console.error('[ByrddawgsOS] Contact form error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to send message.' });
  }
});

// POST /api/byrddawgsos/service-request — Unified handler for all 7 service request forms
// Saves to service_requests table + sends email to win@fliplane.net
app.post('/api/byrddawgsos/service-request', async (req, res) => {
  try {
    const { request_type, form_data } = req.body;

    const validTypes = ['fix_flip', 'shipping', 'title_reg', 'financing', 'sourcing', 'customer_inquiry', 'marketing_support', 'contact', 'booking'];
    if (!request_type || !validTypes.includes(request_type)) {
      return res.status(400).json({ success: false, message: 'Invalid request type.' });
    }
    if (!form_data || typeof form_data !== 'object') {
      return res.status(400).json({ success: false, message: 'form_data is required.' });
    }

    // Look up member (optional — customer_inquiry may not have a member_email match)
    const memberEmail = form_data.email || form_data.member_email || null;
    let memberId = null;
    let memberIsCertified = false;
    if (memberEmail) {
      const mRes = await pool.query('SELECT id, is_certified FROM members WHERE LOWER(email) = LOWER($1)', [memberEmail]);
      if (mRes.rows.length > 0) {
        memberId = mRes.rows[0].id;
        memberIsCertified = !!mRes.rows[0].is_certified;
      }
    }

    // Block cert-locked request types for uncertified members
    const certLockedTypes = ['fix_flip', 'shipping', 'title_reg', 'financing', 'sourcing', 'customer_inquiry', 'marketing_support'];
    if (certLockedTypes.includes(request_type) && !memberIsCertified) {
      return res.status(403).json({
        success: false,
        message: 'Complete your certification to access this service.'
      });
    }

    // Save to DB
    const dbRes = await pool.query(
      `INSERT INTO service_requests (member_id, request_type, form_data, status, created_at, updated_at)
       VALUES ($1, $2, $3, 'pending', NOW(), NOW()) RETURNING id`,
      [memberId, request_type, JSON.stringify(form_data)]
    );
    const requestId = dbRes.rows[0].id;

    // Build email per type
    const typeLabels = {
      fix_flip: '🔧 Fix & Flip Request',
      shipping: '🚚 Shipping Request',
      title_reg: '📝 Title & Registration Request',
      financing: '💰 Financing Request',
      sourcing: '🔍 Vehicle Sourcing Request',
      customer_inquiry: '🤝 Customer Inquiry',
      marketing_support: '📢 Marketing Support Request'
    };

    const label = typeLabels[request_type];
    const fd = form_data;

    // Build subject
    let subject = '';
    switch (request_type) {
      case 'fix_flip':
        subject = `Fix & Flip Request: ${[fd.year, fd.make, fd.model].filter(Boolean).join(' ')}`;
        break;
      case 'shipping':
        subject = `Shipping Request: ${[fd.make, fd.model].filter(Boolean).join(' ')} ${fd.pickup_location || ''} → ${fd.delivery_location || ''}`.trim();
        break;
      case 'title_reg':
        subject = `Title/Reg Request: ${[fd.year, fd.make, fd.model].filter(Boolean).join(' ')} - ${fd.state || ''}`.trim();
        break;
      case 'financing':
        subject = `Financing Request: ${fd.name || fd.email || 'Member'}`;
        break;
      case 'sourcing': {
        const yearRange = [fd.year_min, fd.year_max].filter(Boolean).join('-');
        subject = `Vehicle Sourcing: ${[yearRange, fd.make, fd.model].filter(Boolean).join(' ')} - Budget $${fd.max_budget || '?'}`;
        break;
      }
      case 'customer_inquiry':
        subject = `Customer Inquiry: ${fd.vehicle_interest || 'Vehicle'} from ${fd.customer_name || 'Customer'}`;
        break;
      case 'marketing_support':
        subject = `Marketing Request: ${fd.content_type || 'Content'} from ${fd.name || fd.email || 'Member'}`;
        break;
    }

    // Build email rows from form_data
    const rows = Object.entries(fd)
      .filter(([k, v]) => v !== undefined && v !== null && v !== '')
      .map(([k, v]) => {
        const keyLabel = k.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
        const val = Array.isArray(v) ? v.join(', ') : String(v);
        return `<tr><td style="padding: 7px 0; color: #a0a0a0; width: 160px; vertical-align: top;">${keyLabel}</td><td style="padding: 7px 0; font-weight: 500;">${val}</td></tr>`;
      }).join('');

    const emailHtml = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; background: #0a0a0a; color: #ffffff; padding: 32px; border-radius: 12px;">
        <h2 style="color: #00e676; margin-top: 0;">${label} — ByrddawgsOS</h2>
        <p style="color: #a0a0a0; font-size: 13px; margin-bottom: 20px;">Request #${requestId} · Submitted via ByrddawgsOS Member Hub</p>
        <table style="width: 100%; border-collapse: collapse;">${rows}</table>
        <div style="margin-top: 24px; padding-top: 16px; border-top: 1px solid #1e1e1e; font-size: 12px; color: #555555;">Sent from ByrddawgsOS Member Hub</div>
      </div>
    `;

    // Return success to client IMMEDIATELY after DB save — emails are fire-and-forget
    console.log(`[ByrddawgsOS] Service request #${requestId} type=${request_type} member=${memberId || 'guest'}`);
    res.json({ success: true, request_id: requestId });

    // Send admin notification email — fire-and-forget (don't block response)
    const replyTo = fd.email || fd.customer_email || 'win@fliplane.net';
    sendEmail({ to: 'win@fliplane.net', subject, html: emailHtml, replyTo, tag: `service-request-${request_type}` })
      .catch(err => console.error('[Email] Admin notification (service-request) failed:', err.message));

    // Send confirmation email to member — fire-and-forget
    const memberContactEmail = fd.email || fd.member_email || fd.customer_email;
    if (memberContactEmail) {
      const memberName = fd.name || fd.customer_name || '';
      sendEmail({
        to: memberContactEmail,
        subject: `Your service request #${requestId} has been received`,
        html: `
          <div style="font-family: 'DM Sans', Arial, sans-serif; max-width: 560px; margin: 0 auto; background: #0a0a0a; color: #ffffff; padding: 40px 32px; border-radius: 12px;">
            <div style="margin-bottom: 28px;">
              <span style="font-size: 1.4rem; font-weight: 700; letter-spacing: -0.5px;">Flip<span style="color: #00e676;">Lane</span></span>
            </div>
            <h1 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 12px;">Request received${memberName ? `, ${memberName.split(' ')[0]}` : ''}!</h1>
            <p style="color: #a0a0a0; font-size: 1rem; line-height: 1.6; margin-bottom: 20px;">We received your ${typeLabels[request_type] || request_type} (Request #${requestId}). Our team will review it and follow up within 24 hours.</p>
            <p style="color: #666; font-size: 0.88rem; line-height: 1.6;">Need immediate help? Email <a href="mailto:win@fliplane.net" style="color: #00e676;">win@fliplane.net</a></p>
            <hr style="border: none; border-top: 1px solid #222; margin: 28px 0;">
            <p style="color: #444; font-size: 0.8rem;">FlipLane · ByrddawgsOS Member Hub</p>
          </div>
        `,
        tag: `service-request-${request_type}-confirmation`
      }).catch(err => console.error('[Email] Member confirmation (service-request) failed:', err.message));
    }
  } catch (err) {
    console.error('[ByrddawgsOS] Service request error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to submit request. Please try again.' });
  }
});

// GET /api/admin/auctions — List all auction credentials (admin)
app.get('/api/admin/auctions', requireAdminAuth, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT id, auction_name, username, encrypted_password, password, website_url, notes FROM auction_credentials ORDER BY auction_name'
    );
    const auctions = result.rows.map(row => {
      const pwd = row.encrypted_password
        ? decryptField(row.encrypted_password)
        : (row.password || null);
      return { id: row.id, auction_name: row.auction_name, username: row.username, password: pwd, website_url: row.website_url, notes: row.notes };
    });
    res.json({ success: true, auctions });
  } catch (err) {
    console.error('[Admin] Auctions list error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch auctions.' });
  }
});

// PUT /api/admin/auctions/:id — Update auction credentials (encrypts password at rest)
app.put('/api/admin/auctions/:id', requireAdminAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const { auction_name, username, password, website_url, notes } = req.body;

    const encPwd = password ? encryptField(password) : undefined;

    const fields = [];
    const values = [];
    let idx = 1;

    if (auction_name !== undefined) { fields.push(`auction_name = $${idx++}`); values.push(auction_name); }
    if (username !== undefined)     { fields.push(`username = $${idx++}`); values.push(username); }
    if (password !== undefined) {
      fields.push(`encrypted_password = $${idx++}`); values.push(encPwd);
      fields.push(`password = $${idx++}`); values.push(null); // clear plaintext
    }
    if (website_url !== undefined)  { fields.push(`website_url = $${idx++}`); values.push(website_url); }
    if (notes !== undefined)        { fields.push(`notes = $${idx++}`); values.push(notes); }

    if (fields.length === 0) {
      return res.status(400).json({ success: false, message: 'No fields to update.' });
    }

    fields.push(`updated_at = NOW()`);
    values.push(id);

    await pool.query(
      `UPDATE auction_credentials SET ${fields.join(', ')} WHERE id = $${idx}`,
      values
    );

    res.json({ success: true, message: 'Auction credentials updated.' });
  } catch (err) {
    console.error('[Admin] Auction update error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to update auction credentials.' });
  }
});

// POST /api/admin/auction-credentials — Create new auction credential
app.post('/api/admin/auction-credentials', requireAdminAuth, async (req, res) => {
  try {
    const { auction_name, username, password, website_url, notes } = req.body;
    if (!auction_name) {
      return res.status(400).json({ success: false, message: 'auction_name is required.' });
    }
    const encPwd = password ? encryptField(password) : null;
    const result = await pool.query(
      `INSERT INTO auction_credentials (auction_name, username, encrypted_password, password, website_url, notes)
       VALUES ($1, $2, $3, NULL, $4, $5)
       RETURNING id, auction_name, username, website_url, notes`,
      [auction_name, username || null, encPwd, website_url || null, notes || null]
    );
    const row = result.rows[0];
    res.status(201).json({ success: true, auction: { ...row, password: password || null } });
  } catch (err) {
    console.error('[Admin] Auction create error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to create auction credential.' });
  }
});

// DELETE /api/admin/auction-credentials/:id — Delete auction credential
app.delete('/api/admin/auction-credentials/:id', requireAdminAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('DELETE FROM auction_credentials WHERE id = $1 RETURNING id', [id]);
    if (result.rowCount === 0) {
      return res.status(404).json({ success: false, message: 'Auction credential not found.' });
    }
    res.json({ success: true, message: 'Auction credential deleted.' });
  } catch (err) {
    console.error('[Admin] Auction delete error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to delete auction credential.' });
  }
});

// GET /api/admin/members — List all members with search/filter/sort support
app.get('/api/admin/members', requireAdminAuth, async (req, res) => {
  try {
    const { search, status, sort } = req.query;
    const params = [];
    const conditions = [];

    if (search) {
      params.push(`%${search.toLowerCase()}%`);
      conditions.push(`(LOWER(name) LIKE $${params.length} OR LOWER(email) LIKE $${params.length})`);
    }
    if (status && status !== 'all') {
      params.push(status);
      conditions.push(`status = $${params.length}`);
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    let orderClause = 'ORDER BY created_at DESC';
    if (sort === 'created_at_asc') orderClause = 'ORDER BY created_at ASC';
    else if (sort === 'name_asc') orderClause = 'ORDER BY name ASC';
    else if (sort === 'name_desc') orderClause = 'ORDER BY name DESC';

    const result = await pool.query(
      `SELECT id, name, email, phone, status, experience, notes,
              applied_at, paid_at, approved_at, created_at,
              id_document_url, id_upload_at, id_verified,
              stripe_customer_id, stripe_session_id,
              is_certified, quiz_score, certified_at,
              docusign_status, docusign_envelope_id,
              agreement_accepted_at
       FROM members ${whereClause} ${orderClause} LIMIT 500`,
      params
    );
    res.json({ success: true, members: result.rows, count: result.rows.length });
  } catch (err) {
    console.error('[FlipLane] Admin error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch members.' });
  }
});

// GET /api/admin/members/:id — Full member detail
app.get('/api/admin/members/:id', requireAdminAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(
      `SELECT m.*,
              (SELECT json_agg(l ORDER BY l.created_at DESC) FROM member_audit_log l WHERE l.member_id = m.id) as audit_log,
              (SELECT json_agg(sr ORDER BY sr.created_at DESC) FROM service_requests sr WHERE sr.member_id = m.id) as service_requests
       FROM members m WHERE m.id = $1`,
      [id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Member not found.' });
    }
    res.json({ success: true, member: result.rows[0] });
  } catch (err) {
    console.error('[FlipLane] Admin member detail error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch member.' });
  }
});

// PATCH /api/admin/members/:id/status — Update member status
app.patch('/api/admin/members/:id/status', requireAdminAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const allowed = ['applied', 'active', 'approved', 'inactive', 'cancelled'];
    if (!allowed.includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid status.' });
    }
    // When setting status to 'active', also set paid_at so the payment timestamp is captured
    const query = status === 'active'
      ? 'UPDATE members SET status = $1, paid_at = COALESCE(paid_at, NOW()), updated_at = NOW() WHERE id = $2'
      : 'UPDATE members SET status = $1, updated_at = NOW() WHERE id = $2';
    await pool.query(query, [status, id]);
    await pool.query(
      `INSERT INTO member_audit_log (member_id, action, details) VALUES ($1, $2, $3)`,
      [id, `status_changed_to_${status}`, JSON.stringify({ by: 'admin', at: new Date().toISOString() })]
    );
    res.json({ success: true, status });
  } catch (err) {
    console.error('[FlipLane] Admin status update error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to update status.' });
  }
});

// GET /api/admin/service-requests — List all service requests with member info (supports ?status=, ?type=, ?search=)
app.get('/api/admin/service-requests', requireAdminAuth, async (req, res) => {
  try {
    const { status, type, search } = req.query;
    const conditions = [];
    const params = [];
    if (status) { params.push(status); conditions.push(`sr.status = $${params.length}`); }
    if (type) { params.push(type); conditions.push(`sr.request_type = $${params.length}`); }
    if (search) {
      const term = `%${search}%`;
      params.push(term);
      conditions.push(`(m.name ILIKE $${params.length} OR m.email ILIKE $${params.length} OR sr.form_data->>'email' ILIKE $${params.length} OR sr.form_data->>'name' ILIKE $${params.length})`);
    }
    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
    const result = await pool.query(
      `SELECT sr.id, sr.request_type, sr.status, sr.form_data, sr.admin_notes, sr.status_history, sr.created_at, sr.updated_at,
              sr.member_id, m.name as member_name, m.email as member_email, m.phone as member_phone
       FROM service_requests sr
       LEFT JOIN members m ON sr.member_id = m.id
       ${whereClause}
       ORDER BY sr.created_at DESC LIMIT 500`,
      params
    );
    res.json({ success: true, requests: result.rows, count: result.rows.length });
  } catch (err) {
    console.error('[FlipLane] Admin service requests error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch service requests.' });
  }
});

// GET /api/admin/service-requests/:id — Single service request full detail
app.get('/api/admin/service-requests/:id', requireAdminAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(
      `SELECT sr.*, m.name as member_name, m.email as member_email, m.phone as member_phone, m.status as member_status
       FROM service_requests sr
       LEFT JOIN members m ON sr.member_id = m.id
       WHERE sr.id = $1`,
      [id]
    );
    if (!result.rows.length) return res.status(404).json({ success: false, message: 'Request not found.' });
    res.json({ success: true, request: result.rows[0] });
  } catch (err) {
    console.error('[FlipLane] Admin service request detail error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch request.' });
  }
});

// PATCH /api/admin/service-requests/:id — Update status and/or add admin notes
app.patch('/api/admin/service-requests/:id', requireAdminAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const { status, admin_notes } = req.body;
    const validStatuses = ['pending', 'in_progress', 'completed', 'cancelled'];

    // Fetch current record
    const current = await pool.query('SELECT * FROM service_requests WHERE id = $1', [id]);
    if (!current.rows.length) return res.status(404).json({ success: false, message: 'Request not found.' });
    const row = current.rows[0];

    // Build status_history update if status changed
    let newHistory = row.status_history || [];
    if (status && status !== row.status) {
      if (!validStatuses.includes(status)) {
        return res.status(400).json({ success: false, message: 'Invalid status value.' });
      }
      newHistory = [...newHistory, {
        status,
        changed_at: new Date().toISOString(),
        note: admin_notes || null
      }];
    }

    const setClauses = [];
    const params = [];

    if (status && status !== row.status) {
      params.push(status); setClauses.push(`status = $${params.length}`);
      params.push(JSON.stringify(newHistory)); setClauses.push(`status_history = $${params.length}`);
    }
    if (typeof admin_notes !== 'undefined') {
      params.push(admin_notes); setClauses.push(`admin_notes = $${params.length}`);
    }

    if (!setClauses.length) return res.json({ success: true, request: row });

    setClauses.push(`updated_at = NOW()`);
    params.push(id);
    const updated = await pool.query(
      `UPDATE service_requests SET ${setClauses.join(', ')} WHERE id = $${params.length} RETURNING *`,
      params
    );
    res.json({ success: true, request: updated.rows[0] });
  } catch (err) {
    console.error('[FlipLane] Admin service request update error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to update request.' });
  }
});

// PATCH /api/admin/members/:id/verify-id — Mark a member's ID as verified
app.patch('/api/admin/members/:id/verify-id', requireAdminAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const { verified } = req.body;
    await pool.query(
      'UPDATE members SET id_verified = $1, updated_at = NOW() WHERE id = $2',
      [!!verified, id]
    );
    await pool.query(
      `INSERT INTO member_audit_log (member_id, action, details)
       VALUES ($1, $2, $3)`,
      [id, verified ? 'id_verified' : 'id_rejected', JSON.stringify({ by: 'admin', at: new Date().toISOString() })]
    );
    res.json({ success: true, id_verified: !!verified });
  } catch (err) {
    console.error('[FlipLane] Admin verify-id error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to update verification status.' });
  }
});

// GET /api/admin/affiliates — List all affiliate applications with full details
app.get('/api/admin/affiliates', requireAdminAuth, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT id, name, email, phone, how_to_promote, audience_reach, prior_experience,
              why_fliplane, social_links, confidentiality_agreed_at, status, created_at
       FROM affiliate_signups ORDER BY created_at DESC LIMIT 200`
    );
    res.json({ success: true, affiliates: result.rows, count: result.rows.length });
  } catch (err) {
    console.error('[FlipLane] Admin affiliates error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch affiliates.' });
  }
});

// PATCH /api/admin/affiliates/:id/status — Update affiliate application status
app.patch('/api/admin/affiliates/:id/status', requireAdminAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body; // 'approved', 'rejected', 'new'
    if (!['approved', 'rejected', 'new'].includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid status.' });
    }
    await pool.query(
      'UPDATE affiliate_signups SET status = $1, updated_at = NOW() WHERE id = $2',
      [status, id]
    );

    // If approved, send welcome email with AffiliateOS dashboard link + Terms for signature
    if (status === 'approved') {
      const affiliateResult = await pool.query(
        'SELECT name, email FROM affiliate_signups WHERE id = $1',
        [id]
      );
      if (affiliateResult.rows.length > 0) {
        const aff = affiliateResult.rows[0];
        const affFirstName = (aff.name || '').split(' ')[0] || 'there';
        const affAppUrl = process.env.APP_URL || 'https://flipl.polsia.app';

        // Send FlipLane Terms of Service for e-signature
        const docusealResult = await docuseal.sendTermsForSignature(
          pool,
          aff.email,
          aff.name,
          'affiliate',
          parseInt(id)
        );

        if (docusealResult.success) {
          await pool.query(
            `UPDATE affiliate_signups
             SET terms_signature_status = 'sent'
             WHERE id = $1`,
            [id]
          );
          console.log(`[DocuSeal] Terms sent to affiliate ${aff.email}. Envelope: ${docusealResult.envelopeId}`);
        } else {
          console.log(`[DocuSeal] Affiliate Terms queued: ${docusealResult.message || 'pending config'}`);
        }

        sendEmail({
          to: aff.email,
          subject: '🎉 You\'re approved! Welcome to FlipLane\'s Affiliate Program',
          html: `
            <div style="font-family: 'DM Sans', Arial, sans-serif; max-width: 560px; margin: 0 auto; background: #0a0a0a; color: #ffffff; padding: 40px 32px; border-radius: 12px;">
              <div style="margin-bottom: 28px;">
                <span style="font-size: 1.4rem; font-weight: 700; letter-spacing: -0.5px;">Flip<span style="color: #00e676;">Lane</span></span>
              </div>
              <h1 style="font-size: 1.6rem; font-weight: 700; margin-bottom: 12px; letter-spacing: -0.5px;">You're in, ${affFirstName}! 🎉</h1>
              <p style="color: #a0a0a0; font-size: 1rem; line-height: 1.6; margin-bottom: 24px;">Your FlipLane affiliate application has been approved. Your AffiliateOS dashboard is ready — referral links, commission tracking, deal submissions, and marketing resources are all live.</p>
              <p style="color: #a0a0a0; font-size: 0.9rem; line-height: 1.6; margin-bottom: 24px; background: #161616; border-radius: 8px; padding: 12px 16px;">📋 <strong style="color: #fff;">Next:</strong> You'll receive a FlipLane Terms of Service document to sign via email. This takes just a minute and protects both you and FlipLane.</p>

              <div style="text-align: center; margin-bottom: 32px;">
                <a href="${affAppUrl}/affiliateos" style="display: inline-block; padding: 16px 32px; background: #00e676; border-radius: 10px; color: #000; font-weight: 700; font-size: 1.05rem; text-decoration: none; letter-spacing: -0.3px;">Access Your Dashboard →</a>
                <p style="color: #666; font-size: 0.8rem; margin-top: 10px;">Log in with the email you applied with: ${aff.email}</p>
              </div>

              <div style="background: #161616; border-radius: 10px; padding: 20px 24px; margin-bottom: 28px; border: 1px solid #222;">
                <p style="font-weight: 700; font-size: 0.95rem; margin-bottom: 14px; color: #fff;">What's in your AffiliateOS dashboard:</p>
                <p style="color: #a0a0a0; font-size: 0.9rem; margin: 0 0 8px;">🔗 <strong style="color: #fff;">Referral Links</strong> — Create and track custom links by channel</p>
                <p style="color: #a0a0a0; font-size: 0.9rem; margin: 0 0 8px;">💰 <strong style="color: #fff;">Commission Tracking</strong> — See every referral, deal, and payout</p>
                <p style="color: #a0a0a0; font-size: 0.9rem; margin: 0 0 8px;">🚗 <strong style="color: #fff;">Deal Submissions</strong> — Submit vehicle deals and earn on approved flips</p>
                <p style="color: #a0a0a0; font-size: 0.9rem; margin: 0;">📢 <strong style="color: #fff;">Marketing Resources</strong> — Copy, assets, and outreach tools</p>
              </div>

              <p style="color: #666; font-size: 0.88rem; line-height: 1.6;">Questions? Email us at <a href="mailto:win@fliplane.net" style="color: #00e676;">win@fliplane.net</a></p>
              <hr style="border: none; border-top: 1px solid #222; margin: 28px 0;">
              <p style="color: #444; font-size: 0.8rem;">FlipLane · The AI-Powered Used Car Co-op</p>
            </div>
          `
        }).catch(e => console.error('[Admin] Affiliate approval email error:', e.message));

        // Notify ops
        sendEmail({
          to: 'win@fliplane.net',
          subject: `✅ Affiliate approved: ${aff.name} (${aff.email})`,
          html: `<div style="font-family: Arial, sans-serif; max-width: 500px; padding: 24px;"><p><strong>${aff.name}</strong> (${aff.email}) has been approved as an affiliate. Welcome email + Terms signing request sent.</p></div>`
        }).catch(e => console.error('[Admin] Affiliate approval ops notification error:', e.message));

        console.log(`[Admin] Affiliate approved: ${aff.email} — welcome email + Terms sent`);
      }
    }

    res.json({ success: true, status });
  } catch (err) {
    console.error('[FlipLane] Admin affiliate status error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to update status.' });
  }
});

// ============================================================
// TERMS OF SERVICE MANAGEMENT (DOCUSEAL)
// ============================================================

// GET /api/admin/terms — Get current active Terms content
app.get('/api/admin/terms', requireAdminAuth, async (req, res) => {
  try {
    const terms = await docuseal.getCurrentTermsVersion(pool);
    if (!terms) {
      return res.json({
        success: true,
        terms: {
          version: null,
          content: null,
          message: 'No active Terms version. Create one to get started.'
        }
      });
    }
    res.json({ success: true, terms });
  } catch (err) {
    console.error('[Admin] GET /api/admin/terms error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch Terms.' });
  }
});

// POST /api/admin/terms — Create new Terms version (update active content)
// This replaces the current Terms — all new signers get the new version
app.post('/api/admin/terms', requireAdminAuth, async (req, res) => {
  try {
    const { content } = req.body;
    if (!content || content.trim().length < 100) {
      return res.status(400).json({ success: false, message: 'Terms content is required (minimum 100 characters).' });
    }

    // Get admin email from auth header for audit trail
    const adminEmail = req.headers['x-admin-email'] || 'admin@flipLane';

    const result = await docuseal.createTermsVersion(pool, content, adminEmail);
    console.log(`[Admin] Terms version ${result.version} created by ${adminEmail}`);

    res.json({
      success: true,
      message: `Terms version ${result.version} published. New signers will receive this version.`,
      version: result.version
    });
  } catch (err) {
    console.error('[Admin] POST /api/admin/terms error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to update Terms.' });
  }
});

// GET /api/admin/terms/history — Get Terms version history
app.get('/api/admin/terms/history', requireAdminAuth, async (req, res) => {
  try {
    const history = await docuseal.getTermsHistory(pool);
    res.json({ success: true, history });
  } catch (err) {
    console.error('[Admin] GET /api/admin/terms/history error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch Terms history.' });
  }
});

// GET /api/admin/terms/:version — Get a specific Terms version
app.get('/api/admin/terms/:version', requireAdminAuth, async (req, res) => {
  try {
    const { version } = req.params;
    const terms = await docuseal.getTermsVersion(pool, parseInt(version));
    if (!terms) {
      return res.status(404).json({ success: false, message: 'Terms version not found.' });
    }
    res.json({ success: true, terms });
  } catch (err) {
    console.error('[Admin] GET /api/admin/terms/:version error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch Terms version.' });
  }
});

// GET /api/terms — Public: get current active Terms (no auth required)
app.get('/api/terms', async (req, res) => {
  try {
    const terms = await docuseal.getCurrentTermsVersion(pool);
    if (!terms) {
      return res.json({
        success: true,
        terms: {
          version: null,
          content: docuseal.getDefaultTermsContent(),
          created_at: new Date().toISOString()
        }
      });
    }
    res.json({ success: true, terms });
  } catch (err) {
    console.error('[API] GET /api/terms error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch Terms.' });
  }
});

// GET /api/admin/signature-status — Get all Terms signature statuses
app.get('/api/admin/signature-status', requireAdminAuth, async (req, res) => {
  try {
    const { type } = req.query; // 'member' | 'affiliate' | undefined (all)

    let memberSignatures = [];
    let affiliateSignatures = [];

    if (!type || type === 'member') {
      const memberResult = await pool.query(`
        SELECT m.id, m.name, m.email, m.status as member_status, m.created_at,
               es.id as signature_id, es.terms_version, es.document_type, es.docuseal_envelope_id,
               es.status as signature_status, es.sent_at, es.signed_at
        FROM members m
        LEFT JOIN e_signatures es ON es.signee_type = 'member' AND es.signee_id = m.id
        WHERE m.email IS NOT NULL
        ORDER BY m.created_at DESC
        LIMIT 200
      `);
      memberSignatures = memberResult.rows;
    }

    if (!type || type === 'affiliate') {
      const affiliateResult = await pool.query(`
        SELECT asig.id, asig.name, asig.email, asig.status as affiliate_status, asig.created_at,
               es.id as signature_id, es.terms_version, es.document_type, es.docuseal_envelope_id,
               es.status as signature_status, es.sent_at, es.signed_at
        FROM affiliate_signups asig
        LEFT JOIN e_signatures es ON es.signee_type = 'affiliate' AND es.signee_id = asig.id
        WHERE asig.email IS NOT NULL
        ORDER BY asig.created_at DESC
        LIMIT 200
      `);
      affiliateSignatures = affiliateResult.rows;
    }

    // Summary stats
    const summary = {
      members: {
        total: memberSignatures.length,
        signed: memberSignatures.filter(m => m.signature_status === 'completed').length,
        pending: memberSignatures.filter(m => m.signature_status === 'sent' || m.signature_status === 'viewed' || m.signature_status === 'pending').length,
        never_sent: memberSignatures.filter(m => !m.signature_id).length
      },
      affiliates: {
        total: affiliateSignatures.length,
        signed: affiliateSignatures.filter(a => a.signature_status === 'completed').length,
        pending: affiliateSignatures.filter(a => a.signature_status === 'sent' || a.signature_status === 'viewed' || a.signature_status === 'pending').length,
        never_sent: affiliateSignatures.filter(a => !a.signature_id).length
      }
    };

    res.json({
      success: true,
      summary,
      members: memberSignatures,
      affiliates: affiliateSignatures
    });
  } catch (err) {
    console.error('[Admin] GET /api/admin/signature-status error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch signature status.' });
  }
});

// POST /api/admin/resend-terms — Resend Terms to a member or affiliate
app.post('/api/admin/resend-terms', requireAdminAuth, async (req, res) => {
  try {
    const { signeeType, signeeId, signeeEmail, signeeName } = req.body;
    if (!['member', 'affiliate'].includes(signeeType) || !signeeId || !signeeEmail || !signeeName) {
      return res.status(400).json({ success: false, message: 'signeeType, signeeId, signeeEmail, and signeeName are required.' });
    }

    const result = await docuseal.sendTermsForSignature(
      pool,
      signeeEmail,
      signeeName,
      signeeType,
      signeeId
    );

    if (result.success) {
      res.json({
        success: true,
        message: `Terms resent to ${signeeEmail}. Envelope: ${result.envelopeId}`,
        envelopeId: result.envelopeId
      });
    } else {
      res.json({
        success: false,
        message: result.message || 'Failed to resend Terms. DocuSeal may not be configured.'
      });
    }
  } catch (err) {
    console.error('[Admin] POST /api/admin/resend-terms error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to resend Terms.' });
  }
});

// GET /api/admin/affiliate-profiles — List approved affiliate profiles (for commission dropdown)
app.get('/api/admin/affiliate-profiles', requireAdminAuth, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT ap.id, ap.name, ap.email, ap.referral_code,
             ap.total_earned, ap.total_pending, ap.total_paid
      FROM affiliate_profiles ap
      WHERE ap.status = 'active'
      ORDER BY ap.name ASC
    `);
    res.json({ success: true, profiles: result.rows });
  } catch (err) {
    console.error('[Admin] Affiliate profiles error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch affiliate profiles.' });
  }
});

// POST /api/admin/commissions — Manually create a commission for an affiliate
app.post('/api/admin/commissions', requireAdminAuth, async (req, res) => {
  try {
    const { affiliate_id, amount, description, type } = req.body;

    if (!affiliate_id || !amount || isNaN(parseFloat(amount)) || parseFloat(amount) <= 0) {
      return res.status(400).json({ success: false, message: 'affiliate_id and a positive amount are required.' });
    }
    const validTypes = ['referral', 'deal', 'lead'];
    const commType = validTypes.includes(type) ? type : 'referral';

    // Verify affiliate profile exists
    const profileResult = await pool.query(
      'SELECT id, name, email FROM affiliate_profiles WHERE id = $1',
      [affiliate_id]
    );
    if (profileResult.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Affiliate profile not found.' });
    }
    const profile = profileResult.rows[0];
    const commAmount = parseFloat(amount).toFixed(2);

    // Insert commission record
    const commResult = await pool.query(
      `INSERT INTO commissions (affiliate_id, type, description, amount, status, reference_type)
       VALUES ($1, $2, $3, $4, 'pending', 'manual')
       RETURNING *`,
      [affiliate_id, commType, description || `Manual ${commType} commission`, commAmount]
    );
    const commission = commResult.rows[0];

    // Update aggregate totals on affiliate profile
    await pool.query(
      `UPDATE affiliate_profiles
       SET total_earned = total_earned + $1,
           total_pending = total_pending + $1,
           updated_at = NOW()
       WHERE id = $2`,
      [commAmount, affiliate_id]
    );

    // Add activity feed entry
    await pool.query(
      `INSERT INTO affiliate_activity (affiliate_id, type, title, description, metadata)
       VALUES ($1, 'commission_created', $2, $3, $4)`,
      [
        affiliate_id,
        `Commission added: $${parseFloat(commAmount).toLocaleString()}`,
        description || `Manual ${commType} commission`,
        JSON.stringify({ commission_id: commission.id, amount: commAmount, type: commType, created_by: 'admin' })
      ]
    );

    console.log(`[Admin] Commission created for ${profile.name}: $${commAmount} (${commType})`);

    res.json({ success: true, commission, message: `Commission of $${commAmount} created for ${profile.name}` });
  } catch (err) {
    console.error('[Admin] Create commission error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to create commission.' });
  }
});

// GET /api/admin/commissions — List all commissions with affiliate name
app.get('/api/admin/commissions', requireAdminAuth, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT c.id, c.type, c.description, c.amount, c.status,
             c.reference_type, c.reference_id, c.paid_at, c.created_at,
             ap.name AS affiliate_name, ap.email AS affiliate_email
      FROM commissions c
      JOIN affiliate_profiles ap ON ap.id = c.affiliate_id
      ORDER BY c.created_at DESC
      LIMIT 200
    `);
    res.json({ success: true, commissions: result.rows, count: result.rows.length });
  } catch (err) {
    console.error('[Admin] List commissions error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch commissions.' });
  }
});

// GET /api/admin/affiliate-stats — Overview stats for the affiliate dashboard
app.get('/api/admin/affiliate-stats', requireAdminAuth, async (req, res) => {
  try {
    const [sigStats, commStats, refStats, recentActivity] = await Promise.all([
      // Affiliate signup status counts
      pool.query(`
        SELECT
          COUNT(*) FILTER (WHERE status = 'approved') AS approved,
          COUNT(*) FILTER (WHERE status = 'rejected') AS rejected,
          COUNT(*) FILTER (WHERE status = 'new' OR status IS NULL) AS pending,
          COUNT(*) AS total
        FROM affiliate_signups
      `),
      // Commission totals
      pool.query(`
        SELECT
          COALESCE(SUM(amount), 0) AS total_earned,
          COALESCE(SUM(amount) FILTER (WHERE status = 'pending'), 0) AS total_pending,
          COALESCE(SUM(amount) FILTER (WHERE status = 'paid'), 0) AS total_paid,
          COUNT(*) AS total_commissions
        FROM commissions
      `),
      // Referral counts
      pool.query(`
        SELECT
          COUNT(*) AS total_clicks,
          COALESCE(SUM(signups), 0) AS total_signups
        FROM referral_links
      `),
      // Recent activity feed (last 20 events across all affiliates)
      pool.query(`
        SELECT aa.id, aa.type, aa.title, aa.description, aa.created_at,
               ap.name AS affiliate_name, ap.email AS affiliate_email
        FROM affiliate_activity aa
        JOIN affiliate_profiles ap ON ap.id = aa.affiliate_id
        ORDER BY aa.created_at DESC
        LIMIT 20
      `)
    ]);

    res.json({
      success: true,
      stats: {
        signups: sigStats.rows[0],
        commissions: commStats.rows[0],
        referrals: refStats.rows[0]
      },
      recent_activity: recentActivity.rows
    });
  } catch (err) {
    console.error('[Admin] Affiliate stats error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch affiliate stats.' });
  }
});

// GET /api/admin/affiliate-profiles/all — All affiliate profiles (active + inactive) with stats
app.get('/api/admin/affiliate-profiles/all', requireAdminAuth, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT ap.id, ap.name, ap.email, ap.referral_code, ap.status,
             ap.total_earned, ap.total_pending, ap.total_paid, ap.payout_method,
             ap.created_at, ap.signup_id,
             (SELECT COUNT(*) FROM referral_links rl WHERE rl.affiliate_id = ap.id) AS link_count,
             (SELECT COALESCE(SUM(rl.signups), 0) FROM referral_links rl WHERE rl.affiliate_id = ap.id) AS total_referrals,
             (SELECT COALESCE(SUM(rl.clicks), 0) FROM referral_links rl WHERE rl.affiliate_id = ap.id) AS total_clicks,
             (SELECT COUNT(*) FROM commissions c WHERE c.affiliate_id = ap.id AND c.status = 'pending') AS pending_commissions
      FROM affiliate_profiles ap
      ORDER BY ap.created_at DESC
    `);
    res.json({ success: true, profiles: result.rows, count: result.rows.length });
  } catch (err) {
    console.error('[Admin] All affiliate profiles error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch affiliate profiles.' });
  }
});

// GET /api/admin/affiliate-profiles/:id/detail — Full detail for one affiliate
app.get('/api/admin/affiliate-profiles/:id/detail', requireAdminAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const [profileResult, commissionsResult, referralsResult, linksResult, activityResult] = await Promise.all([
      pool.query(`
        SELECT ap.*, ast.name AS signup_name
        FROM affiliate_profiles ap
        LEFT JOIN affiliate_signups ast ON ast.id = ap.signup_id
        WHERE ap.id = $1
      `, [id]),
      pool.query(`
        SELECT * FROM commissions WHERE affiliate_id = $1 ORDER BY created_at DESC LIMIT 50
      `, [id]),
      pool.query(`
        SELECT m.id AS member_id, m.name, m.email, m.created_at AS joined_at,
               m.status AS member_status, m.ref_code,
               rl.slug AS link_slug, rl.label AS link_label
        FROM members m
        JOIN affiliate_profiles ap ON LOWER(ap.referral_code) = LOWER(m.ref_code)
        LEFT JOIN referral_links rl ON rl.affiliate_id = ap.id AND LOWER(rl.slug) = LOWER(m.ref_code)
        WHERE ap.id = $1
        ORDER BY m.created_at DESC
        LIMIT 50
      `, [id]),
      pool.query(`
        SELECT * FROM referral_links WHERE affiliate_id = $1 ORDER BY created_at DESC
      `, [id]),
      pool.query(`
        SELECT * FROM affiliate_activity WHERE affiliate_id = $1 ORDER BY created_at DESC LIMIT 30
      `, [id])
    ]);

    if (!profileResult.rows.length) {
      return res.status(404).json({ success: false, message: 'Affiliate profile not found.' });
    }

    res.json({
      success: true,
      profile: profileResult.rows[0],
      commissions: commissionsResult.rows,
      referrals: referralsResult.rows,
      links: linksResult.rows,
      activity: activityResult.rows
    });
  } catch (err) {
    console.error('[Admin] Affiliate detail error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch affiliate detail.' });
  }
});

// PATCH /api/admin/affiliate-profiles/:id/toggle-status — Toggle active/inactive
app.patch('/api/admin/affiliate-profiles/:id/toggle-status', requireAdminAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body; // 'active' or 'inactive'
    if (!['active', 'inactive'].includes(status)) {
      return res.status(400).json({ success: false, message: 'Status must be active or inactive.' });
    }
    await pool.query(
      'UPDATE affiliate_profiles SET status = $1, updated_at = NOW() WHERE id = $2',
      [status, id]
    );
    res.json({ success: true, status });
  } catch (err) {
    console.error('[Admin] Toggle affiliate profile status error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to update status.' });
  }
});

// ============================================================
// ADMIN — Deal Submissions API
// ============================================================

// GET /api/admin/deal-submissions — List all deal submissions with filtering
app.get('/api/admin/deal-submissions', requireAdminAuth, async (req, res) => {
  try {
    const { status, search, affiliate_id, limit = 50, offset = 0 } = req.query;

    let whereClause = 'WHERE 1=1';
    const params = [];
    let paramIndex = 1;

    if (status && status !== '') {
      whereClause += ` AND ds.status = $${paramIndex}`;
      params.push(status);
      paramIndex++;
    }

    if (search && search.trim()) {
      whereClause += ` AND (ds.vehicle_description ILIKE $${paramIndex} OR ds.vin ILIKE $${paramIndex} OR ap.name ILIKE $${paramIndex} OR ap.email ILIKE $${paramIndex})`;
      params.push(`%${search.trim()}%`);
      paramIndex++;
    }

    if (affiliate_id) {
      whereClause += ` AND ds.affiliate_id = $${paramIndex}`;
      params.push(affiliate_id);
      paramIndex++;
    }

    // Get total count
    const countResult = await pool.query(
      `SELECT COUNT(*) FROM deal_submissions ds
       LEFT JOIN affiliate_profiles ap ON ds.affiliate_id = ap.id
       ${whereClause}`,
      params
    );
    const total = parseInt(countResult.rows[0].count);

    // Get deals with affiliate info
    params.push(parseInt(limit), parseInt(offset));
    const deals = await pool.query(
      `SELECT ds.id, ds.vin, ds.vehicle_description, ds.price, ds.source_url,
              ds.source_name, ds.notes, ds.status, ds.admin_notes, ds.commission_amount,
              ds.created_at, ds.updated_at, ds.reviewed_at, ds.closed_at,
              ap.id as affiliate_id, ap.name as affiliate_name, ap.email as affiliate_email,
              ap.referral_code
       FROM deal_submissions ds
       LEFT JOIN affiliate_profiles ap ON ds.affiliate_id = ap.id
       ${whereClause}
       ORDER BY ds.created_at DESC
       LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`,
      params
    );

    res.json({
      success: true,
      deals: deals.rows,
      total,
      limit: parseInt(limit),
      offset: parseInt(offset)
    });
  } catch (err) {
    console.error('[Admin] Deal submissions error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch deal submissions.' });
  }
});

// PATCH /api/admin/deal-submissions/:id — Update deal status, admin_notes, commission
app.patch('/api/admin/deal-submissions/:id', requireAdminAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const { status, admin_notes, commission_amount } = req.body;

    const updates = [];
    const params = [id];
    let paramIndex = 1;

    if (status !== undefined) {
      updates.push(`status = $${++paramIndex}`);
      params.push(status);
      if (status === 'reviewed') {
        updates.push(`reviewed_at = NOW()`);
      } else if (status === 'closed') {
        updates.push(`closed_at = NOW()`);
      }
    }

    if (admin_notes !== undefined) {
      updates.push(`admin_notes = $${++paramIndex}`);
      params.push(admin_notes);
    }

    if (commission_amount !== undefined) {
      updates.push(`commission_amount = $${++paramIndex}`);
      params.push(commission_amount);
    }

    if (updates.length === 0) {
      return res.status(400).json({ success: false, message: 'No fields to update.' });
    }

    updates.push(`updated_at = NOW()`);

    const result = await pool.query(
      `UPDATE deal_submissions SET ${updates.join(', ')} WHERE id = $1 RETURNING *`,
      params
    );

    if (!result.rows.length) {
      return res.status(404).json({ success: false, message: 'Deal submission not found.' });
    }

    res.json({ success: true, deal: result.rows[0] });
  } catch (err) {
    console.error('[Admin] Update deal submission error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to update deal submission.' });
  }
});

// PATCH /api/admin/commissions/:id/paid — Mark a commission as paid
app.patch('/api/admin/commissions/:id/paid', requireAdminAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(
      `UPDATE commissions SET status = 'paid', paid_at = NOW() WHERE id = $1 RETURNING affiliate_id, amount`,
      [id]
    );
    if (!result.rows.length) {
      return res.status(404).json({ success: false, message: 'Commission not found.' });
    }
    const { affiliate_id, amount } = result.rows[0];
    // Update affiliate totals
    await pool.query(
      `UPDATE affiliate_profiles
       SET total_pending = GREATEST(total_pending - $1, 0),
           total_paid = total_paid + $1,
           updated_at = NOW()
       WHERE id = $2`,
      [amount, affiliate_id]
    );
    res.json({ success: true });
  } catch (err) {
    console.error('[Admin] Mark commission paid error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to mark commission as paid.' });
  }
});

// GET /api/admin/referrals — All referral attribution: who referred who
app.get('/api/admin/referrals', requireAdminAuth, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT m.id AS member_id, m.name AS member_name, m.email AS member_email,
             m.status AS member_status, m.ref_code, m.created_at AS member_joined,
             m.affiliate_commission_created,
             ap.id AS affiliate_id, ap.name AS affiliate_name, ap.email AS affiliate_email,
             ap.referral_code
      FROM members m
      JOIN affiliate_profiles ap ON LOWER(ap.referral_code) = LOWER(m.ref_code)
      WHERE m.ref_code IS NOT NULL AND m.ref_code != ''
      ORDER BY m.created_at DESC
      LIMIT 200
    `);
    res.json({ success: true, referrals: result.rows, count: result.rows.length });
  } catch (err) {
    console.error('[Admin] Referrals error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch referrals.' });
  }
});

// ============================================================
// MESSAGING SYSTEM — Admin ↔ Member
// ============================================================

// GET /api/admin/messages — List all conversations (one row per member who has messages)
app.get('/api/admin/messages', requireAdminAuth, async (req, res) => {
  try {
    // Get latest message per member, plus unread count (unread = member replies admin hasn't read)
    const result = await pool.query(`
      SELECT
        m.id AS member_id,
        m.name AS member_name,
        m.email AS member_email,
        latest.body AS last_message,
        latest.sender_type AS last_sender_type,
        latest.created_at AS last_message_at,
        COALESCE(unread.count, 0)::int AS admin_unread
      FROM members m
      INNER JOIN LATERAL (
        SELECT body, sender_type, created_at
        FROM messages
        WHERE receiver_id = m.id
        ORDER BY created_at DESC
        LIMIT 1
      ) latest ON true
      LEFT JOIN LATERAL (
        SELECT COUNT(*)::int AS count
        FROM messages
        WHERE receiver_id = m.id
          AND sender_type = 'member'
          AND is_read = false
      ) unread ON true
      ORDER BY latest.created_at DESC
    `);
    res.json({ success: true, conversations: result.rows });
  } catch (err) {
    console.error('[Messages] GET /api/admin/messages error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to load conversations.' });
  }
});

// GET /api/admin/messages/unread-count — Total unread count for nav badge
app.get('/api/admin/messages/unread-count', requireAdminAuth, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT COUNT(*)::int AS count FROM messages WHERE sender_type = 'member' AND is_read = false`
    );
    res.json({ success: true, count: result.rows[0].count });
  } catch (err) {
    res.status(500).json({ success: false, count: 0 });
  }
});

// GET /api/admin/messages/:memberId — Full conversation thread with a member
app.get('/api/admin/messages/:memberId', requireAdminAuth, async (req, res) => {
  try {
    const { memberId } = req.params;
    const result = await pool.query(`
      SELECT msg.*, m.name AS sender_name, m.email AS sender_email
      FROM messages msg
      LEFT JOIN members m ON msg.sender_id = m.id
      WHERE msg.receiver_id = $1
      ORDER BY msg.created_at ASC
    `, [memberId]);

    // Mark member replies as read
    await pool.query(
      `UPDATE messages SET is_read = true WHERE receiver_id = $1 AND sender_type = 'member' AND is_read = false`,
      [memberId]
    );

    // Get member info
    const memberResult = await pool.query(
      `SELECT id, name, email FROM members WHERE id = $1`, [memberId]
    );

    res.json({
      success: true,
      messages: result.rows,
      member: memberResult.rows[0] || null
    });
  } catch (err) {
    console.error('[Messages] GET /api/admin/messages/:memberId error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to load conversation.' });
  }
});

// POST /api/admin/messages — Send message to a member
app.post('/api/admin/messages', requireAdminAuth, async (req, res) => {
  try {
    const { member_id, subject, body, parent_id } = req.body;
    if (!member_id || !body || !body.trim()) {
      return res.status(400).json({ success: false, message: 'member_id and body are required.' });
    }

    // Verify member exists
    const memberCheck = await pool.query(`SELECT id, name, email FROM members WHERE id = $1`, [member_id]);
    if (!memberCheck.rows.length) {
      return res.status(404).json({ success: false, message: 'Member not found.' });
    }

    const result = await pool.query(
      `INSERT INTO messages (sender_type, sender_id, receiver_id, subject, body, parent_id)
       VALUES ('admin', NULL, $1, $2, $3, $4) RETURNING *`,
      [member_id, subject || null, body.trim(), parent_id || null]
    );

    res.json({ success: true, message: result.rows[0] });
  } catch (err) {
    console.error('[Messages] POST /api/admin/messages error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to send message.' });
  }
});

// GET /api/member/messages — Member gets their inbox (all messages where receiver_id = member)
app.get('/api/member/messages', async (req, res) => {
  try {
    const { email } = req.query;
    if (!email) return res.status(400).json({ success: false, message: 'Email is required.' });

    const memberResult = await pool.query(
      `SELECT id FROM members WHERE LOWER(email) = LOWER($1)`, [email]
    );
    if (!memberResult.rows.length) {
      return res.status(404).json({ success: false, message: 'Member not found.' });
    }
    const memberId = memberResult.rows[0].id;

    const result = await pool.query(
      `SELECT * FROM messages WHERE receiver_id = $1 ORDER BY created_at ASC`,
      [memberId]
    );

    // Mark admin messages as read
    await pool.query(
      `UPDATE messages SET is_read = true WHERE receiver_id = $1 AND sender_type = 'admin' AND is_read = false`,
      [memberId]
    );

    res.json({ success: true, messages: result.rows });
  } catch (err) {
    console.error('[Messages] GET /api/member/messages error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to load messages.' });
  }
});

// GET /api/member/messages/unread-count — Unread count for notification bell
app.get('/api/member/messages/unread-count', async (req, res) => {
  try {
    const { email } = req.query;
    if (!email) return res.json({ success: true, count: 0 });

    const memberResult = await pool.query(
      `SELECT id FROM members WHERE LOWER(email) = LOWER($1)`, [email]
    );
    if (!memberResult.rows.length) return res.json({ success: true, count: 0 });
    const memberId = memberResult.rows[0].id;

    const result = await pool.query(
      `SELECT COUNT(*)::int AS count FROM messages WHERE receiver_id = $1 AND sender_type = 'admin' AND is_read = false`,
      [memberId]
    );
    res.json({ success: true, count: result.rows[0].count });
  } catch (err) {
    res.json({ success: true, count: 0 });
  }
});

// POST /api/member/messages/reply — Member replies to admin
app.post('/api/member/messages/reply', async (req, res) => {
  try {
    const { email, body, subject, parent_id } = req.body;
    if (!email || !body || !body.trim()) {
      return res.status(400).json({ success: false, message: 'email and body are required.' });
    }

    const memberResult = await pool.query(
      `SELECT id FROM members WHERE LOWER(email) = LOWER($1)`, [email]
    );
    if (!memberResult.rows.length) {
      return res.status(404).json({ success: false, message: 'Member not found.' });
    }
    const memberId = memberResult.rows[0].id;

    const result = await pool.query(
      `INSERT INTO messages (sender_type, sender_id, receiver_id, subject, body, parent_id)
       VALUES ('member', $1, $1, $2, $3, $4) RETURNING *`,
      [memberId, subject || null, body.trim(), parent_id || null]
    );

    res.json({ success: true, message: result.rows[0] });
  } catch (err) {
    console.error('[Messages] POST /api/member/messages/reply error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to send reply.' });
  }
});

// POST /api/docusign-webhook — Handle DocuSign Connect webhook (XML)
app.post('/api/docusign-webhook', express.raw({ type: 'application/xml' }), async (req, res) => {
  try {
    // Parse DocuSign webhook payload (XML format)
    const webhookResult = await docusign.handleWebhook(req.body);

    if (webhookResult.envelopeId && webhookResult.status) {
      // Update member record with new status
      await pool.query(
        `UPDATE members
         SET docusign_status = $1,
             docusign_signed_at = CASE WHEN $1 = 'completed' THEN NOW() ELSE docusign_signed_at END
         WHERE docusign_envelope_id = $2`,
        [webhookResult.status, webhookResult.envelopeId]
      );

      console.log(`[DocuSign Webhook] Envelope ${webhookResult.envelopeId} status: ${webhookResult.status}`);
    }

    res.json({ received: true });
  } catch (err) {
    console.error('[DocuSign Webhook] Error:', err.message);
    res.status(500).json({ success: false, message: 'Webhook error' });
  }
});

// POST /api/docuseal-webhook — Handle DocuSeal webhook (JSON)
// DocuSeal calls this when a document is signed or status changes
app.post('/api/docuseal-webhook', express.json(), async (req, res) => {
  try {
    const payload = req.body;
    const webhookResult = await docuseal.handleWebhook(payload, pool);

    if (webhookResult.envelopeId && webhookResult.status) {
      console.log(`[DocuSeal Webhook] Envelope ${webhookResult.envelopeId} status: ${webhookResult.status}`);
    }

    res.json({ received: true });
  } catch (err) {
    console.error('[DocuSeal Webhook] Error:', err.message);
    res.status(500).json({ success: false, message: 'Webhook error' });
  }
});

// GET /api/member/agreement-status — Check Terms of Service signature status for logged-in member
app.get('/api/member/agreement-status', async (req, res) => {
  try {
    const { email } = req.query;
    if (!email) {
      return res.status(400).json({ success: false, message: 'Email is required' });
    }

    const memberResult = await pool.query(
      `SELECT id, docusign_envelope_id, docusign_status, docusign_sent_at, docusign_signed_at,
              terms_signature_status, terms_signed_at
       FROM members
       WHERE LOWER(email) = LOWER($1)`,
      [email]
    );

    if (memberResult.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Member not found' });
    }

    const member = memberResult.rows[0];

    // Get the most recent e_signature record for this member
    const sigResult = await pool.query(
      `SELECT id, terms_version, docuseal_envelope_id, status, sent_at, signed_at
       FROM e_signatures
       WHERE signee_type = 'member' AND signee_id = $1
       ORDER BY sent_at DESC LIMIT 1`,
      [member.id]
    );

    const latestSig = sigResult.rows[0] || {};

    res.json({
      success: true,
      documentType: 'terms',
      envelopeId: latestSig.docuseal_envelope_id || member.docusign_envelope_id,
      status: latestSig.status || member.terms_signature_status || member.docusign_status || 'pending',
      termsVersion: latestSig.terms_version || null,
      sentAt: latestSig.sent_at || member.docusign_sent_at,
      signedAt: latestSig.signed_at || member.terms_signed_at || member.docusign_signed_at
    });

  } catch (err) {
    console.error('[API] Error fetching agreement status:', err.message);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// ============================================================
// ADMIN ROUTES
// ============================================================

// ── Cookie helpers (no external deps) ──
function _parseCookies(req) {
  const cookies = {};
  (req.headers.cookie || '').split(';').forEach(c => {
    const [k, ...v] = c.trim().split('=');
    if (k) cookies[k.trim()] = decodeURIComponent(v.join('='));
  });
  return cookies;
}

function _generateAdminToken(email) {
  const payload = Buffer.from(JSON.stringify({ email, iat: Date.now() })).toString('base64url');
  const secret = process.env.ADMIN_SECRET || 'fliplaneadmin2024';
  const sig = crypto.createHmac('sha256', secret).update(payload).digest('hex');
  return `${payload}.${sig}`;
}

function _verifyAdminToken(token) {
  if (!token) return null;
  try {
    const [payload, sig] = token.split('.');
    if (!payload || !sig) return null;
    const secret = process.env.ADMIN_SECRET || 'fliplaneadmin2024';
    const expected = crypto.createHmac('sha256', secret).update(payload).digest('hex');
    if (sig !== expected) return null;
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    // Expires in 7 days
    if (Date.now() - data.iat > 7 * 24 * 60 * 60 * 1000) return null;
    return data;
  } catch (_) { return null; }
}

// Admin auth middleware — cookie-based session
function requireAdminAuth(req, res, next) {
  const cookies = _parseCookies(req);
  const session = _verifyAdminToken(cookies.admin_session);
  if (session) return next();

  // API routes → 401 JSON
  if (req.path.startsWith('/api/')) {
    return res.status(401).json({ success: false, message: 'Unauthorized. Please log in at /admin/login.' });
  }
  // HTML routes → redirect to login
  res.redirect('/admin/login');
}

// GET /admin/login — Login page
app.get('/admin/login', (req, res) => {
  const cookies = _parseCookies(req);
  if (_verifyAdminToken(cookies.admin_session)) {
    return res.redirect('/admin');
  }
  const htmlPath = path.join(__dirname, 'public', 'admin-login.html');
  if (fs.existsSync(htmlPath)) {
    res.type('html').send(fs.readFileSync(htmlPath, 'utf8'));
  } else {
    res.status(404).send('Login page not found');
  }
});

// POST /api/admin/login — Authenticate owner, set session cookie
app.post('/api/admin/login', (req, res) => {
  const { email, password } = req.body || {};
  const adminEmail = process.env.ADMIN_EMAIL;
  const adminPassword = process.env.ADMIN_PASSWORD || process.env.ADMIN_SECRET || 'fliplaneadmin2024';

  if (!email || !password) {
    return res.status(400).json({ success: false, message: 'Email and password are required.' });
  }
  // If ADMIN_EMAIL is set, enforce it; otherwise allow any email with correct password
  if (adminEmail && email.toLowerCase() !== adminEmail.toLowerCase()) {
    return res.status(401).json({ success: false, message: 'Invalid email or password.' });
  }
  if (password !== adminPassword) {
    return res.status(401).json({ success: false, message: 'Invalid email or password.' });
  }

  const token = _generateAdminToken(email);
  const maxAge = 7 * 24 * 60 * 60; // 7 days in seconds
  res.setHeader('Set-Cookie', `admin_session=${encodeURIComponent(token)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${maxAge}`);
  res.json({ success: true });
});

// POST /api/admin/logout — Clear session cookie
app.post('/api/admin/logout', (req, res) => {
  res.setHeader('Set-Cookie', 'admin_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');
  res.json({ success: true });
});

// GET /admin — Admin analytics dashboard
app.get('/admin', requireAdminAuth, (req, res) => {
  const htmlPath = path.join(__dirname, 'public', 'admin.html');
  if (fs.existsSync(htmlPath)) {
    res.type('html').send(fs.readFileSync(htmlPath, 'utf8'));
  } else {
    res.status(404).send('Admin dashboard not found');
  }
});

// GET /admin/member-preview — Bypass member payment wall for owner testing
app.get('/admin/member-preview', requireAdminAuth, async (req, res) => {
  try {
    const previewEmail = 'admin-preview@fliplane.net';
    const previewName = 'Admin Preview';

    // Find or create preview member with paid + certified status
    const existing = await pool.query(
      'SELECT id FROM members WHERE LOWER(email) = LOWER($1)',
      [previewEmail]
    );

    if (existing.rows.length === 0) {
      await pool.query(
        `INSERT INTO members (name, email, phone, experience, status, paid_at, is_certified, certified_at)
         VALUES ($1, $2, NULL, NULL, 'active', NOW(), TRUE, NOW())`,
        [previewName, previewEmail]
      );
    } else {
      await pool.query(
        `UPDATE members
         SET status = 'active',
             paid_at = COALESCE(paid_at, NOW()),
             is_certified = TRUE,
             certified_at = COALESCE(certified_at, NOW()),
             updated_at = NOW()
         WHERE id = $1`,
        [existing.rows[0].id]
      );
    }

    // Generate one-time login token → redirect to ByrddawgsOS
    const token = await generateLoginToken(previewEmail);
    console.log(`[Admin Preview] Member preview login generated for ${previewEmail}`);
    res.redirect(`/byrddawgsos?token=${encodeURIComponent(token)}`);

  } catch (err) {
    console.error('[Admin Preview] Member preview error:', err.message);
    res.status(500).send('Failed to generate member preview: ' + err.message);
  }
});

// GET /admin/affiliate-preview — Bypass affiliate approval gate for owner testing
app.get('/admin/affiliate-preview', requireAdminAuth, async (req, res) => {
  try {
    const previewEmail = 'admin-preview-affiliate@fliplane.net';
    const previewName = 'Admin Preview';

    // Find or create preview affiliate with approved status
    const existing = await pool.query(
      'SELECT id FROM affiliate_signups WHERE LOWER(email) = LOWER($1)',
      [previewEmail]
    );

    if (existing.rows.length === 0) {
      await pool.query(
        `INSERT INTO affiliate_signups (name, email, phone, how_to_promote, audience_reach, prior_experience, why_fliplane, social_links, confidentiality_agreed_at, capi_event_id, status)
         VALUES ($1, $2, NULL, 'Admin preview testing', NULL, NULL, NULL, NULL, NOW(), 'admin_preview', 'approved')`,
        [previewName, previewEmail]
      );
    } else {
      await pool.query(
        `UPDATE affiliate_signups SET status = 'approved', updated_at = NOW() WHERE id = $1`,
        [existing.rows[0].id]
      );
    }

    console.log(`[Admin Preview] Affiliate preview session created for ${previewEmail}`);

    // Return a tiny HTML page that injects sessionStorage and redirects — no HTML edits needed
    res.send(`<!DOCTYPE html>
<html>
<head><title>Loading Affiliate Preview...</title></head>
<body style="background:#0a0a0a;color:#fff;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;">
  <p>Loading Affiliate OS preview...</p>
  <script>
    sessionStorage.setItem('affiliate_email', '${previewEmail}');
    window.location.href = '/affiliateos';
  </script>
</body>
</html>`);

  } catch (err) {
    console.error('[Admin Preview] Affiliate preview error:', err.message);
    res.status(500).send('Failed to generate affiliate preview: ' + err.message);
  }
});

// GET /api/admin/metrics — Fetch all analytics metrics
app.get('/api/admin/metrics', requireAdminAuth, async (req, res) => {
  try {
    // Member metrics
    const memberStats = await pool.query(`
      SELECT
        COUNT(*) as total,
        COUNT(*) FILTER (WHERE status = 'active') as active,
        COUNT(*) FILTER (WHERE status = 'applied') as pending,
        COUNT(*) FILTER (WHERE status NOT IN ('active', 'applied')) as inactive
      FROM members
    `);

    // Payment metrics
    const paymentStats = await pool.query(`
      SELECT
        COUNT(*) FILTER (WHERE paid_at IS NOT NULL) as paid_members,
        COUNT(*) FILTER (WHERE paid_at IS NOT NULL) * 250 as total_revenue
      FROM members
    `);

    // DocuSign metrics
    const docusignStats = await pool.query(`
      SELECT
        COUNT(*) FILTER (WHERE docusign_envelope_id IS NOT NULL) as sent,
        COUNT(*) FILTER (WHERE docusign_status = 'completed') as signed,
        COUNT(*) FILTER (WHERE docusign_envelope_id IS NOT NULL AND docusign_status != 'completed') as pending
      FROM members
    `);

    // Funnel metrics (using audit log to estimate visits)
    const funnelStats = await pool.query(`
      SELECT
        (SELECT COUNT(*) FROM members) as applications,
        (SELECT COUNT(*) FROM members WHERE paid_at IS NOT NULL) as payments,
        (SELECT COUNT(*) FROM members WHERE status = 'active') as active_members
    `);

    // Calculate metrics
    const members = memberStats.rows[0];
    const payments = paymentStats.rows[0];
    const docusign = docusignStats.rows[0];
    const funnel = funnelStats.rows[0];

    // Estimate visits (rough approximation: applications * 10, since we don't have real visit tracking yet)
    const estimatedVisits = parseInt(funnel.applications) * 10 || 100;
    const applications = parseInt(funnel.applications) || 0;
    const paymentsCount = parseInt(funnel.payments) || 0;
    const activeMembers = parseInt(funnel.active_members) || 0;

    const metrics = {
      members: {
        total: parseInt(members.total),
        active: parseInt(members.active),
        pending: parseInt(members.pending),
        inactive: parseInt(members.inactive)
      },
      payments: {
        total_revenue: parseInt(payments.total_revenue) || 0,
        paid_members: parseInt(payments.paid_members) || 0,
        avg_per_member: payments.paid_members > 0
          ? Math.round(parseInt(payments.total_revenue) / parseInt(payments.paid_members))
          : 250
      },
      docusign: {
        sent: parseInt(docusign.sent) || 0,
        signed: parseInt(docusign.signed) || 0,
        pending: parseInt(docusign.pending) || 0,
        completion_rate: docusign.sent > 0
          ? Math.round((parseInt(docusign.signed) / parseInt(docusign.sent)) * 100)
          : 0
      },
      funnel: {
        visits: estimatedVisits,
        applications: applications,
        payments: paymentsCount,
        active_members: activeMembers,
        visit_to_app_rate: estimatedVisits > 0
          ? ((applications / estimatedVisits) * 100).toFixed(1)
          : '0.0',
        app_to_payment_rate: applications > 0
          ? ((paymentsCount / applications) * 100).toFixed(1)
          : '0.0',
        visit_to_member_rate: estimatedVisits > 0
          ? ((activeMembers / estimatedVisits) * 100).toFixed(1)
          : '0.0'
      }
    };

    res.json({ success: true, metrics });
  } catch (err) {
    console.error('[Admin] Metrics error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch metrics' });
  }
});

// GET /api/admin/recent-activity — New leads, members, failed emails in last 7 days (for notification banner)
app.get('/api/admin/recent-activity', requireAdminAuth, async (req, res) => {
  try {
    // Recent members (last 7 days)
    const recentMembers = await pool.query(`
      SELECT id, name, email, phone, status, created_at
      FROM members
      WHERE created_at > NOW() - INTERVAL '7 days'
      ORDER BY created_at DESC
      LIMIT 20
    `);

    // Recent leads (last 7 days)
    const recentLeads = await pool.query(`
      SELECT id, name, email, source, created_at
      FROM leads
      WHERE created_at > NOW() - INTERVAL '7 days'
      ORDER BY created_at DESC
      LIMIT 20
    `);

    // Recent vehicle inquiries (last 7 days)
    const recentInquiries = await pool.query(`
      SELECT id, name, email, phone, vehicle_interest, created_at
      FROM vehicle_inquiries
      WHERE created_at > NOW() - INTERVAL '7 days'
      ORDER BY created_at DESC
      LIMIT 20
    `);

    // Failed emails (unresolved)
    let failedEmails = [];
    try {
      const feResult = await pool.query(`
        SELECT id, recipient, subject, error_detail, retry_count, created_at
        FROM failed_emails
        WHERE resolved = false
        ORDER BY created_at DESC
        LIMIT 20
      `);
      failedEmails = feResult.rows;
    } catch (_e) {
      // Table may not exist yet if migration hasn't run
    }

    const totalNew = recentMembers.rows.length + recentLeads.rows.length + recentInquiries.rows.length;

    res.json({
      success: true,
      total_new_activity: totalNew,
      failed_emails_count: failedEmails.length,
      recent_members: recentMembers.rows,
      recent_leads: recentLeads.rows,
      recent_inquiries: recentInquiries.rows,
      failed_emails: failedEmails
    });
  } catch (err) {
    console.error('[Admin] Recent activity error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch recent activity' });
  }
});

// GET /api/admin/analytics?period=7d — Member signups, affiliate stats, deal pipeline + traffic + form events
app.get('/api/admin/analytics', requireAdminAuth, async (req, res) => {
  try {
    const period = req.query.period || '7d';
    const days = period === '30d' ? 30 : period === '1d' ? 1 : 7;

    // Member stats
    const memberStats = await pool.query(`
      SELECT
        COUNT(*) as total_applications,
        COUNT(*) FILTER (WHERE paid_at IS NOT NULL) as paid_members,
        COUNT(*) FILTER (WHERE status = 'active') as active_members
      FROM members
    `);

    // Affiliate stats
    const affiliateSignupStats = await pool.query(`
      SELECT COUNT(*) as total_signups FROM affiliate_signups
    `);

    const affiliateProfileStats = await pool.query(`
      SELECT COUNT(*) as total_approved FROM affiliate_profiles WHERE status = 'active'
    `);

    const referralClickStats = await pool.query(`
      SELECT COALESCE(SUM(clicks), 0) as total_clicks FROM referral_links
    `);

    const dealSubmittedStats = await pool.query(`
      SELECT COUNT(*) as total_deals FROM deal_submissions
    `);

    // Deal pipeline by status
    const dealPipelineStats = await pool.query(`
      SELECT
        COUNT(*) FILTER (WHERE status = 'submitted') as submitted,
        COUNT(*) FILTER (WHERE status = 'reviewed') as reviewed,
        COUNT(*) FILTER (WHERE status = 'closed') as closed,
        COUNT(*) as total,
        COALESCE(SUM(price) FILTER (WHERE status = 'closed'), 0) as closed_volume,
        COALESCE(SUM(price), 0) as total_volume
      FROM deal_submissions
    `);

    // ── Traffic analytics (page_views) ──────────────────────────────────────
    const trafficTotals = await pool.query(`
      SELECT
        COUNT(*) AS total_views,
        COUNT(DISTINCT ip_hash) AS unique_visitors,
        COUNT(*) FILTER (WHERE created_at >= NOW() - INTERVAL '1 day')   AS today,
        COUNT(*) FILTER (WHERE created_at >= NOW() - INTERVAL '7 days')  AS last_7d,
        COUNT(*) FILTER (WHERE created_at >= NOW() - INTERVAL '30 days') AS last_30d
      FROM page_views
      WHERE created_at >= NOW() - ($1 || ' days')::INTERVAL
    `, [days]);

    const topPages = await pool.query(`
      SELECT url, COUNT(*) AS views
      FROM page_views
      WHERE created_at >= NOW() - ($1 || ' days')::INTERVAL
      GROUP BY url
      ORDER BY views DESC
      LIMIT 10
    `, [days]);

    const topReferrers = await pool.query(`
      SELECT
        CASE
          WHEN referrer IS NULL OR referrer = '' THEN 'Direct / None'
          WHEN referrer ~* 'google\\.'    THEN 'Google'
          WHEN referrer ~* 'bing\\.'      THEN 'Bing'
          WHEN referrer ~* 'facebook\\.'
            OR referrer ~* 'fb\\.com'    THEN 'Facebook'
          WHEN referrer ~* 'twitter\\.'
            OR referrer ~* 'x\\.com'     THEN 'Twitter/X'
          WHEN referrer ~* 'instagram\\.' THEN 'Instagram'
          WHEN referrer ~* 'linkedin\\.'  THEN 'LinkedIn'
          ELSE referrer
        END AS source,
        COUNT(*) AS views
      FROM page_views
      WHERE created_at >= NOW() - ($1 || ' days')::INTERVAL
      GROUP BY source
      ORDER BY views DESC
      LIMIT 10
    `, [days]);

    const dailyChart = await pool.query(`
      SELECT
        DATE(created_at AT TIME ZONE 'America/New_York') AS date,
        COUNT(*) AS views
      FROM page_views
      WHERE created_at >= NOW() - ($1 || ' days')::INTERVAL
      GROUP BY date
      ORDER BY date ASC
    `, [days]);

    // ── Form events ──────────────────────────────────────────────────────────
    const formEvents = await pool.query(`
      SELECT event_type, COUNT(*) AS count
      FROM events
      WHERE created_at >= NOW() - ($1 || ' days')::INTERVAL
      GROUP BY event_type
      ORDER BY count DESC
    `, [days]);

    const totalViews = parseInt(trafficTotals.rows[0]?.total_views) || 0;
    const formEventMap = {};
    for (const row of formEvents.rows) {
      formEventMap[row.event_type] = parseInt(row.count) || 0;
    }

    // Conversion rates: (form_submissions / total_page_views) * 100
    const conversionRates = {};
    for (const [evtType, count] of Object.entries(formEventMap)) {
      conversionRates[evtType] = totalViews > 0 ? parseFloat(((count / totalViews) * 100).toFixed(2)) : 0;
    }

    const m = memberStats.rows[0];
    const as = affiliateSignupStats.rows[0];
    const ap = affiliateProfileStats.rows[0];
    const rc = referralClickStats.rows[0];
    const ds = dealSubmittedStats.rows[0];
    const dp = dealPipelineStats.rows[0];
    const tt = trafficTotals.rows[0];

    res.json({
      success: true,
      period,
      analytics: {
        members: {
          total_applications: parseInt(m.total_applications) || 0,
          paid_members: parseInt(m.paid_members) || 0,
          active_members: parseInt(m.active_members) || 0
        },
        affiliates: {
          total_signups: parseInt(as.total_signups) || 0,
          total_approved: parseInt(ap.total_approved) || 0,
          total_referral_clicks: parseInt(rc.total_clicks) || 0,
          deals_submitted: parseInt(ds.total_deals) || 0
        },
        deal_pipeline: {
          submitted: parseInt(dp.submitted) || 0,
          reviewed: parseInt(dp.reviewed) || 0,
          closed: parseInt(dp.closed) || 0,
          total: parseInt(dp.total) || 0,
          closed_volume: parseFloat(dp.closed_volume) || 0,
          total_volume: parseFloat(dp.total_volume) || 0
        },
        traffic: {
          total_views: parseInt(tt.total_views) || 0,
          unique_visitors: parseInt(tt.unique_visitors) || 0,
          today: parseInt(tt.today) || 0,
          last_7d: parseInt(tt.last_7d) || 0,
          last_30d: parseInt(tt.last_30d) || 0,
          top_pages: topPages.rows.map(r => ({ url: r.url, views: parseInt(r.views) })),
          top_referrers: topReferrers.rows.map(r => ({ source: r.source, views: parseInt(r.views) })),
          daily_chart: dailyChart.rows.map(r => ({ date: r.date, views: parseInt(r.views) }))
        },
        form_events: {
          by_type: formEventMap,
          conversion_rates: conversionRates
        }
      }
    });
  } catch (err) {
    console.error('[Admin] Analytics error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch analytics' });
  }
});

// GET /api/admin/traffic — Page view analytics (today/7d/30d, top pages, top referrers, daily chart)
app.get('/api/admin/traffic', requireAdminAuth, async (req, res) => {
  try {
    const period = req.query.period || '7d';
    const days = period === '30d' ? 30 : period === '1d' ? 1 : 7;

    // Total views by period
    const totals = await pool.query(`
      SELECT
        COUNT(*) FILTER (WHERE created_at >= NOW() - INTERVAL '1 day')   AS today,
        COUNT(*) FILTER (WHERE created_at >= NOW() - INTERVAL '7 days')  AS last_7d,
        COUNT(*) FILTER (WHERE created_at >= NOW() - INTERVAL '30 days') AS last_30d
      FROM page_views
    `);

    // Top pages (filtered period)
    const topPages = await pool.query(`
      SELECT url, COUNT(*) AS views
      FROM page_views
      WHERE created_at >= NOW() - ($1 || ' days')::INTERVAL
      GROUP BY url
      ORDER BY views DESC
      LIMIT 20
    `, [days]);

    // Top referrers (filtered period, exclude null/direct)
    const topReferrers = await pool.query(`
      SELECT
        CASE
          WHEN referrer IS NULL OR referrer = '' THEN 'Direct / None'
          WHEN referrer ~* 'google\\.' THEN 'Google'
          WHEN referrer ~* 'bing\\.'   THEN 'Bing'
          WHEN referrer ~* 'facebook\\.' OR referrer ~* 'fb\\.com' THEN 'Facebook'
          WHEN referrer ~* 'twitter\\.' OR referrer ~* 'x\\.com' THEN 'Twitter/X'
          WHEN referrer ~* 'instagram\\.' THEN 'Instagram'
          WHEN referrer ~* 'linkedin\\.' THEN 'LinkedIn'
          ELSE referrer
        END AS source,
        COUNT(*) AS views
      FROM page_views
      WHERE created_at >= NOW() - ($1 || ' days')::INTERVAL
      GROUP BY source
      ORDER BY views DESC
      LIMIT 15
    `, [days]);

    // Daily views chart (one row per day, last N days)
    const dailyChart = await pool.query(`
      SELECT
        DATE(created_at AT TIME ZONE 'America/New_York') AS date,
        COUNT(*) AS views
      FROM page_views
      WHERE created_at >= NOW() - ($1 || ' days')::INTERVAL
      GROUP BY date
      ORDER BY date ASC
    `, [days]);

    const t = totals.rows[0];

    res.json({
      success: true,
      period,
      summary: {
        today:    parseInt(t.today)   || 0,
        last_7d:  parseInt(t.last_7d) || 0,
        last_30d: parseInt(t.last_30d) || 0
      },
      top_pages: topPages.rows.map(r => ({ url: r.url, views: parseInt(r.views) })),
      top_referrers: topReferrers.rows.map(r => ({ source: r.source, views: parseInt(r.views) })),
      daily_chart: dailyChart.rows.map(r => ({ date: r.date, views: parseInt(r.views) }))
    });
  } catch (err) {
    console.error('[Admin] Traffic analytics error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch traffic analytics' });
  }
});

// POST /api/admin/snapshot — Save daily metrics snapshot
app.post('/api/admin/snapshot', requireAdminAuth, async (req, res) => {
  try {
    // Compute metrics directly (same queries as /api/admin/metrics)
    const memberStats = await pool.query(`
      SELECT
        COUNT(*) as total,
        COUNT(*) FILTER (WHERE status = 'active') as active,
        COUNT(*) FILTER (WHERE status = 'applied') as pending,
        COUNT(*) FILTER (WHERE status NOT IN ('active', 'applied')) as inactive
      FROM members
    `);

    const paymentStats = await pool.query(`
      SELECT
        COUNT(*) FILTER (WHERE paid_at IS NOT NULL) as paid_members,
        COUNT(*) FILTER (WHERE paid_at IS NOT NULL) * 250 as total_revenue
      FROM members
    `);

    const docusignStats = await pool.query(`
      SELECT
        COUNT(*) FILTER (WHERE docusign_envelope_id IS NOT NULL) as sent,
        COUNT(*) FILTER (WHERE docusign_status = 'completed') as signed,
        COUNT(*) FILTER (WHERE docusign_envelope_id IS NOT NULL AND docusign_status != 'completed') as pending
      FROM members
    `);

    const funnelStats = await pool.query(`
      SELECT
        (SELECT COUNT(*) FROM members) as applications,
        (SELECT COUNT(*) FROM members WHERE paid_at IS NOT NULL) as payments,
        (SELECT COUNT(*) FROM members WHERE status = 'active') as active_members
    `);

    const members = memberStats.rows[0];
    const payments = paymentStats.rows[0];
    const docusign = docusignStats.rows[0];
    const funnel = funnelStats.rows[0];

    const estimatedVisits = parseInt(funnel.applications) * 10 || 100;
    const applications = parseInt(funnel.applications) || 0;
    const paymentsCount = parseInt(funnel.payments) || 0;
    const activeMembers = parseInt(funnel.active_members) || 0;

    const metrics = {
      members: {
        total: parseInt(members.total),
        active: parseInt(members.active),
        pending: parseInt(members.pending),
        inactive: parseInt(members.inactive)
      },
      payments: {
        total_revenue: parseInt(payments.total_revenue) || 0,
        paid_members: parseInt(payments.paid_members) || 0,
        avg_per_member: payments.paid_members > 0
          ? Math.round(parseInt(payments.total_revenue) / parseInt(payments.paid_members))
          : 250
      },
      docusign: {
        sent: parseInt(docusign.sent) || 0,
        signed: parseInt(docusign.signed) || 0,
        pending: parseInt(docusign.pending) || 0,
        completion_rate: docusign.sent > 0
          ? Math.round((parseInt(docusign.signed) / parseInt(docusign.sent)) * 100)
          : 0
      },
      funnel: {
        visits: estimatedVisits,
        applications: applications,
        payments: paymentsCount,
        active_members: activeMembers,
        visit_to_app_rate: estimatedVisits > 0
          ? ((applications / estimatedVisits) * 100).toFixed(1)
          : '0.0',
        app_to_payment_rate: applications > 0
          ? ((paymentsCount / applications) * 100).toFixed(1)
          : '0.0',
        visit_to_member_rate: estimatedVisits > 0
          ? ((activeMembers / estimatedVisits) * 100).toFixed(1)
          : '0.0'
      }
    };

    // Save to reports table
    const today = new Date().toISOString().split('T')[0];
    await pool.query(
      `INSERT INTO reports (report_type, report_date, metrics)
       VALUES ($1, $2, $3)`,
      ['daily_metrics', today, JSON.stringify(metrics)]
    );

    console.log(`[Admin] Saved daily metrics snapshot for ${today}`);
    res.json({
      success: true,
      message: 'Snapshot saved successfully',
      date: today,
      metrics: metrics
    });
  } catch (err) {
    console.error('[Admin] Snapshot error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to save snapshot' });
  }
});

// ============================================================
// AFFILIATE OS — Page Route
// ============================================================

app.get('/affiliateos', (req, res) => {
  const htmlPath = path.join(__dirname, 'public', 'affiliateos.html');
  if (fs.existsSync(htmlPath)) {
    res.type('html').send(fs.readFileSync(htmlPath, 'utf8'));
  } else {
    res.status(404).send('Page not found');
  }
});

// ============================================================
// AFFILIATE OS — Auth & Profile API
// ============================================================

// Helper: generate unique referral code
function generateReferralCode(name) {
  const prefix = name.replace(/[^a-zA-Z]/g, '').substring(0, 4).toUpperCase();
  const suffix = crypto.randomBytes(3).toString('hex').toUpperCase();
  return `${prefix}${suffix}`;
}

// Helper: get or create affiliate profile from approved signup
async function getOrCreateAffiliateProfile(email) {
  // Check if profile already exists
  const existing = await pool.query(
    'SELECT * FROM affiliate_profiles WHERE LOWER(email) = LOWER($1)',
    [email]
  );
  if (existing.rows.length > 0) return existing.rows[0];

  // Check if they have an approved signup
  const signup = await pool.query(
    `SELECT * FROM affiliate_signups WHERE LOWER(email) = LOWER($1) AND status = 'approved'`,
    [email]
  );
  if (signup.rows.length === 0) return null;

  const s = signup.rows[0];
  const referralCode = generateReferralCode(s.name);

  // Create profile
  const result = await pool.query(
    `INSERT INTO affiliate_profiles (signup_id, email, name, phone, referral_code, social_links)
     VALUES ($1, $2, $3, $4, $5, $6)
     RETURNING *`,
    [s.id, s.email, s.name, s.phone, referralCode, s.social_links]
  );

  const profile = result.rows[0];

  // Create default referral link
  const defaultSlug = referralCode.toLowerCase();
  await pool.query(
    `INSERT INTO referral_links (affiliate_id, slug, label, channel, destination_url)
     VALUES ($1, $2, 'Main Link', 'general', '/apply')`,
    [profile.id, defaultSlug]
  );

  // Log activity
  await pool.query(
    `INSERT INTO affiliate_activity (affiliate_id, type, title, description)
     VALUES ($1, 'profile_created', 'Welcome to FlipLane!', 'Your affiliate profile was activated')`,
    [profile.id]
  );

  return profile;
}

// POST /api/affiliateos/auth — Authenticate affiliate by email
app.post('/api/affiliateos/auth', async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ success: false, message: 'Email is required' });
    }

    // Check for approved affiliate
    const signup = await pool.query(
      `SELECT id, name, email, status FROM affiliate_signups WHERE LOWER(email) = LOWER($1)`,
      [email]
    );

    if (signup.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'No affiliate application found. Apply at /earn first.'
      });
    }

    if (signup.rows[0].status !== 'approved') {
      return res.json({
        success: false,
        status: signup.rows[0].status,
        message: signup.rows[0].status === 'new'
          ? 'Your application is under review. We\'ll notify you when approved.'
          : 'Your application was not approved.'
      });
    }

    // Get or create profile
    const profile = await getOrCreateAffiliateProfile(email);
    if (!profile) {
      return res.status(500).json({ success: false, message: 'Failed to load affiliate profile' });
    }

    res.json({ success: true, affiliate: profile });

  } catch (err) {
    console.error('[AffiliateOS] Auth error:', err.message);
    res.status(500).json({ success: false, message: 'Something went wrong.' });
  }
});

// GET /api/affiliateos/dashboard — Get full dashboard data
app.get('/api/affiliateos/dashboard', async (req, res) => {
  try {
    const { email } = req.query;
    if (!email) {
      return res.status(400).json({ success: false, message: 'Email is required' });
    }

    const profile = await getOrCreateAffiliateProfile(email);
    if (!profile) {
      return res.status(403).json({ success: false, message: 'Not an approved affiliate' });
    }

    // Get referral stats
    const linkStats = await pool.query(
      `SELECT COALESCE(SUM(clicks), 0) as total_clicks, COALESCE(SUM(signups), 0) as total_signups
       FROM referral_links WHERE affiliate_id = $1`,
      [profile.id]
    );

    // Get commission stats
    const commissionStats = await pool.query(
      `SELECT
         COALESCE(SUM(amount) FILTER (WHERE status = 'paid'), 0) as total_paid,
         COALESCE(SUM(amount) FILTER (WHERE status = 'pending'), 0) as total_pending,
         COALESCE(SUM(amount), 0) as total_earned,
         COUNT(*) as total_commissions
       FROM commissions WHERE affiliate_id = $1`,
      [profile.id]
    );

    // Get deal stats
    const dealStats = await pool.query(
      `SELECT
         COUNT(*) as total_deals,
         COUNT(*) FILTER (WHERE status = 'submitted') as submitted,
         COUNT(*) FILTER (WHERE status = 'reviewed') as reviewed,
         COUNT(*) FILTER (WHERE status = 'closed') as closed,
         COUNT(*) FILTER (WHERE status = 'commission_paid') as commission_paid
       FROM deal_submissions WHERE affiliate_id = $1`,
      [profile.id]
    );

    // Recent activity
    const activity = await pool.query(
      `SELECT type, title, description, metadata, created_at
       FROM affiliate_activity WHERE affiliate_id = $1
       ORDER BY created_at DESC LIMIT 20`,
      [profile.id]
    );

    res.json({
      success: true,
      profile: {
        id: profile.id,
        name: profile.name,
        email: profile.email,
        referral_code: profile.referral_code,
        status: profile.status,
        created_at: profile.created_at
      },
      earnings: {
        total_earned: parseFloat(commissionStats.rows[0].total_earned),
        total_pending: parseFloat(commissionStats.rows[0].total_pending),
        total_paid: parseFloat(commissionStats.rows[0].total_paid)
      },
      referrals: {
        total_clicks: parseInt(linkStats.rows[0].total_clicks),
        total_signups: parseInt(linkStats.rows[0].total_signups),
        deals_closed: parseInt(dealStats.rows[0].closed) + parseInt(dealStats.rows[0].commission_paid)
      },
      deals: {
        total: parseInt(dealStats.rows[0].total_deals),
        submitted: parseInt(dealStats.rows[0].submitted),
        reviewed: parseInt(dealStats.rows[0].reviewed),
        closed: parseInt(dealStats.rows[0].closed),
        commission_paid: parseInt(dealStats.rows[0].commission_paid)
      },
      activity: activity.rows
    });

  } catch (err) {
    console.error('[AffiliateOS] Dashboard error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to load dashboard' });
  }
});

// ============================================================
// AFFILIATE OS — Referral Links API
// ============================================================

// GET /api/affiliateos/links — Get all referral links for an affiliate
app.get('/api/affiliateos/links', async (req, res) => {
  try {
    const { email } = req.query;
    if (!email) return res.status(400).json({ success: false, message: 'Email is required' });

    const profile = await getOrCreateAffiliateProfile(email);
    if (!profile) return res.status(403).json({ success: false, message: 'Not an approved affiliate' });

    const links = await pool.query(
      `SELECT id, slug, label, channel, destination_url, clicks, signups, created_at
       FROM referral_links WHERE affiliate_id = $1 ORDER BY created_at DESC`,
      [profile.id]
    );

    const baseUrl = process.env.REFERRAL_BASE_URL || 'https://fliplane.net';

    res.json({
      success: true,
      referral_code: profile.referral_code,
      base_url: baseUrl,
      links: links.rows.map(l => ({
        ...l,
        full_url: `${baseUrl}/ref/${l.slug}`
      }))
    });
  } catch (err) {
    console.error('[AffiliateOS] Links error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch links' });
  }
});

// POST /api/affiliateos/links — Create a new referral link
app.post('/api/affiliateos/links', async (req, res) => {
  try {
    const { email, label, channel } = req.body;
    if (!email) return res.status(400).json({ success: false, message: 'Email is required' });

    const profile = await getOrCreateAffiliateProfile(email);
    if (!profile) return res.status(403).json({ success: false, message: 'Not an approved affiliate' });

    // Generate unique slug
    const channelPrefix = (channel || 'link').substring(0, 3).toLowerCase();
    const slug = `${profile.referral_code.toLowerCase()}-${channelPrefix}-${crypto.randomBytes(2).toString('hex')}`;

    const result = await pool.query(
      `INSERT INTO referral_links (affiliate_id, slug, label, channel, destination_url)
       VALUES ($1, $2, $3, $4, '/apply')
       RETURNING *`,
      [profile.id, slug, label || `${channel || 'General'} Link`, channel || 'general']
    );

    const baseUrl = process.env.REFERRAL_BASE_URL || 'https://fliplane.net';
    const link = result.rows[0];

    // Log activity
    await pool.query(
      `INSERT INTO affiliate_activity (affiliate_id, type, title, description)
       VALUES ($1, 'link_created', 'New referral link created', $2)`,
      [profile.id, `Created ${label || channel || 'general'} link`]
    );

    res.json({
      success: true,
      link: { ...link, full_url: `${baseUrl}/ref/${link.slug}` }
    });
  } catch (err) {
    console.error('[AffiliateOS] Create link error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to create link' });
  }
});

// GET /ref/:slug — Referral link redirect (track click + redirect to apply)
app.get('/ref/:slug', async (req, res) => {
  try {
    const { slug } = req.params;

    // Look up the link
    const linkResult = await pool.query(
      `SELECT rl.id, rl.affiliate_id, rl.destination_url, ap.referral_code
       FROM referral_links rl
       JOIN affiliate_profiles ap ON ap.id = rl.affiliate_id
       WHERE rl.slug = $1`,
      [slug]
    );

    if (linkResult.rows.length === 0) {
      return res.redirect('/apply');
    }

    const link = linkResult.rows[0];

    // Increment click count
    await pool.query('UPDATE referral_links SET clicks = clicks + 1 WHERE id = $1', [link.id]);

    // Record click details
    const ip = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket.remoteAddress;
    await pool.query(
      `INSERT INTO referral_clicks (link_id, affiliate_id, ip_address, user_agent, referrer)
       VALUES ($1, $2, $3, $4, $5)`,
      [link.id, link.affiliate_id, ip, req.headers['user-agent'], req.headers['referer'] || null]
    );

    // Log activity (batch — only log every 10th click to avoid spam)
    const clickCount = await pool.query(
      'SELECT clicks FROM referral_links WHERE id = $1',
      [link.id]
    );
    if (parseInt(clickCount.rows[0]?.clicks) % 10 === 0) {
      await pool.query(
        `INSERT INTO affiliate_activity (affiliate_id, type, title, description, metadata)
         VALUES ($1, 'milestone', 'Referral link milestone!', $2, $3)`,
        [link.affiliate_id, `Your link hit ${clickCount.rows[0].clicks} clicks!`, JSON.stringify({ clicks: clickCount.rows[0].clicks })]
      );
    }

    // Redirect to destination with referral code + link slug in query string
    const dest = link.destination_url || '/earn';
    const separator = dest.includes('?') ? '&' : '?';
    res.redirect(`${dest}${separator}ref=${link.referral_code}&ref_link=${slug}`);

  } catch (err) {
    console.error('[Referral] Click tracking error:', err.message);
    res.redirect('/apply');
  }
});

// ============================================================
// AFFILIATE OS — Deal Submissions API
// ============================================================

// GET /api/affiliateos/deals — Get all deals for an affiliate
app.get('/api/affiliateos/deals', async (req, res) => {
  try {
    const { email } = req.query;
    if (!email) return res.status(400).json({ success: false, message: 'Email is required' });

    const profile = await getOrCreateAffiliateProfile(email);
    if (!profile) return res.status(403).json({ success: false, message: 'Not an approved affiliate' });

    const deals = await pool.query(
      `SELECT id, vin, vehicle_description, price, source_url, source_name, notes,
              status, commission_amount, created_at, reviewed_at, closed_at
       FROM deal_submissions
       WHERE affiliate_id = $1
       ORDER BY created_at DESC`,
      [profile.id]
    );

    res.json({ success: true, deals: deals.rows });
  } catch (err) {
    console.error('[AffiliateOS] Deals error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch deals' });
  }
});

// POST /api/affiliateos/deals — Submit a new deal
app.post('/api/affiliateos/deals', async (req, res) => {
  try {
    const { email, vin, vehicle_description, price, source_url, source_name, notes } = req.body;

    if (!email || !vehicle_description) {
      return res.status(400).json({ success: false, message: 'Email and vehicle description are required' });
    }

    const profile = await getOrCreateAffiliateProfile(email);
    if (!profile) return res.status(403).json({ success: false, message: 'Not an approved affiliate' });

    const result = await pool.query(
      `INSERT INTO deal_submissions (affiliate_id, vin, vehicle_description, price, source_url, source_name, notes)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING *`,
      [profile.id, vin || null, vehicle_description, price || null, source_url || null, source_name || null, notes || null]
    );

    // Log activity
    await pool.query(
      `INSERT INTO affiliate_activity (affiliate_id, type, title, description, metadata)
       VALUES ($1, 'deal_submitted', 'New deal submitted', $2, $3)`,
      [profile.id, vehicle_description.substring(0, 100), JSON.stringify({ deal_id: result.rows[0].id, vin })]
    );

    console.log(`[AffiliateOS] New deal from ${profile.name}: ${vehicle_description.substring(0, 50)}`);

    res.json({ success: true, deal: result.rows[0] });
  } catch (err) {
    console.error('[AffiliateOS] Submit deal error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to submit deal' });
  }
});

// ============================================================
// AFFILIATE OS — Commissions API
// ============================================================

// GET /api/affiliateos/commissions — Get commission history
app.get('/api/affiliateos/commissions', async (req, res) => {
  try {
    const { email } = req.query;
    if (!email) return res.status(400).json({ success: false, message: 'Email is required' });

    const profile = await getOrCreateAffiliateProfile(email);
    if (!profile) return res.status(403).json({ success: false, message: 'Not an approved affiliate' });

    const commissions = await pool.query(
      `SELECT id, type, description, amount, status, reference_type, reference_id, paid_at, created_at
       FROM commissions
       WHERE affiliate_id = $1
       ORDER BY created_at DESC`,
      [profile.id]
    );

    res.json({ success: true, commissions: commissions.rows });
  } catch (err) {
    console.error('[AffiliateOS] Commissions error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch commissions' });
  }
});

// GET /api/affiliateos/share-copy — Get pre-built social share copy
app.get('/api/affiliateos/share-copy', async (req, res) => {
  try {
    const { email } = req.query;
    if (!email) return res.status(400).json({ success: false, message: 'Email is required' });

    const profile = await getOrCreateAffiliateProfile(email);
    if (!profile) return res.status(403).json({ success: false, message: 'Not an approved affiliate' });

    const baseUrl = process.env.REFERRAL_BASE_URL || 'https://fliplane.net';
    const refLink = `${baseUrl}/ref/${profile.referral_code.toLowerCase()}`;

    const shareCopy = {
      facebook: {
        text: `I just joined FlipLane — the AI-powered used car co-op where you can flip cars nationwide for just $250. No dealer license needed. Check it out: ${refLink}`,
        hashtags: '#FlipLane #UsedCars #SideHustle #CarFlipping'
      },
      instagram: {
        caption: `Flip cars. Earn commissions. No dealer license needed.\n\nI'm earning 50% commissions with FlipLane — the AI-powered used car co-op.\n\nLink in bio or DM me for details!\n\n#FlipLane #CarFlipping #SideHustle #UsedCars #MakeMoneyOnline`,
        story_text: 'Swipe up to join FlipLane! 50% commissions on every deal.'
      },
      twitter: {
        text: `Just discovered FlipLane — flip cars nationwide, no dealer license, 50% commissions on referrals.\n\nThe AI-powered used car co-op is changing the game.\n\n${refLink}`,
        hashtags: '#FlipLane #CarFlipping #SideHustle'
      },
      tiktok: {
        caption: `How I'm making money flipping cars with NO dealer license 🚗💰\n\nFlipLane = AI-powered car co-op\n50% commissions on every referral\nJust $250 to start\n\nLink in bio!\n\n#FlipLane #CarFlipping #SideHustle #MakeMoneyOnline #UsedCars`,
        hook: 'Want to flip cars without a dealer license? Let me show you how...'
      },
      generic: {
        short: `Join FlipLane — flip cars nationwide, earn 50% commissions. ${refLink}`,
        long: `I'm earning 50% commissions with FlipLane, the AI-powered used car co-op. No dealer license needed, just $250 to get started. Join through my link: ${refLink}`
      },
      referral_link: refLink
    };

    res.json({ success: true, share_copy: shareCopy });
  } catch (err) {
    console.error('[AffiliateOS] Share copy error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to generate share copy' });
  }
});

// ============================================================
// BLOG API ROUTES
// ============================================================

// GET /api/blog/posts — list published posts (public)
// Supports: ?category=, ?search=, ?limit=, ?offset=
app.get('/api/blog/posts', async (req, res) => {
  try {
    const category = req.query.category;
    const search   = (req.query.search || '').trim().slice(0, 200);
    const limit    = Math.min(parseInt(req.query.limit) || 9, 50);
    const offset   = parseInt(req.query.offset) || 0;

    const values = [];
    let where = 'WHERE published = true';

    // Category filter — handle both legacy ('news','gems') and new slug values.
    // Each UI tab maps to possibly two DB values (new direct slug + legacy equivalent).
    const VALID_CATS = ['news', 'knowledge', 'gems', 'flip-tips', 'market', 'coop', 'hustle'];
    if (category && VALID_CATS.includes(category)) {
      // Each UI slug matches both the new direct value and its legacy DB equivalent
      const CAT_EXPAND = {
        'market':     ['market', 'news'],
        'hustle':     ['hustle', 'gems'],
        'flip-tips':  ['flip-tips', 'knowledge'],
        'coop':       ['coop', 'knowledge'],
        'knowledge':  ['knowledge', 'flip-tips', 'coop'],
        'news':       ['news', 'market'],
        'gems':       ['gems', 'hustle'],
      };
      const dbCats = CAT_EXPAND[category] || [category];
      values.push(dbCats);
      where += ` AND category = ANY($${values.length})`;
    }

    // Full-text search across title, excerpt, body
    if (search) {
      values.push(`%${search}%`);
      const idx = values.length;
      where += ` AND (title ILIKE $${idx} OR excerpt ILIKE $${idx} OR body ILIKE $${idx})`;
    }

    // Count
    const countResult = await pool.query(
      `SELECT COUNT(*) FROM blog_posts ${where}`,
      values
    );
    const total = parseInt(countResult.rows[0].count);

    // Fetch
    const pagingValues = [...values, limit, offset];
    const result = await pool.query(
      `SELECT id, title, slug, category, excerpt, featured_image_url, author, publish_date
       FROM blog_posts ${where}
       ORDER BY publish_date DESC, id DESC
       LIMIT $${pagingValues.length - 1} OFFSET $${pagingValues.length}`,
      pagingValues
    );

    res.json({ success: true, posts: result.rows, total });
  } catch (err) {
    console.error('[Blog API] GET /api/blog/posts error:', err);
    res.status(500).json({ success: false, message: 'Failed to load posts' });
  }
});

// GET /api/blog/posts/:slug — single published post (public)
app.get('/api/blog/posts/:slug', async (req, res) => {
  try {
    const { slug } = req.params;
    const result = await pool.query(
      `SELECT * FROM blog_posts WHERE slug = $1 AND published = true LIMIT 1`,
      [slug]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Post not found' });
    }
    res.json(result.rows[0]);
  } catch (err) {
    console.error('[Blog API] GET /api/blog/posts/:slug error:', err);
    res.status(500).json({ success: false, message: 'Failed to load post' });
  }
});

// GET /api/admin/blog/posts — list all posts (admin)
app.get('/api/admin/blog/posts', requireAdminAuth, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT id, title, slug, category, excerpt, featured_image_url, author, publish_date, published, created_at
       FROM blog_posts
       ORDER BY created_at DESC`
    );
    res.json({ success: true, posts: result.rows });
  } catch (err) {
    console.error('[Blog API] GET /api/admin/blog/posts error:', err);
    res.status(500).json({ success: false, message: 'Failed to load posts' });
  }
});

// GET /api/admin/blog/posts/:id — single post by id (admin)
app.get('/api/admin/blog/posts/:id', requireAdminAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(
      `SELECT * FROM blog_posts WHERE id = $1 LIMIT 1`,
      [parseInt(id)]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Post not found' });
    }
    res.json(result.rows[0]);
  } catch (err) {
    console.error('[Blog API] GET /api/admin/blog/posts/:id error:', err);
    res.status(500).json({ success: false, message: 'Failed to load post' });
  }
});

// POST /api/admin/blog/posts — create post (admin)
app.post('/api/admin/blog/posts', requireAdminAuth, async (req, res) => {
  try {
    const {
      title, slug, category, excerpt, body, featured_image_url,
      author, publish_date, seo_title, seo_description, published
    } = req.body;

    if (!title || !slug || !category || !body) {
      return res.status(400).json({ success: false, message: 'title, slug, category, and body are required' });
    }
    const VALID_ADMIN_CATS = ['news', 'knowledge', 'gems', 'flip-tips', 'market', 'coop', 'hustle'];
    if (!VALID_ADMIN_CATS.includes(category)) {
      return res.status(400).json({ success: false, message: 'Invalid category value' });
    }

    const result = await pool.query(
      `INSERT INTO blog_posts
         (title, slug, category, excerpt, body, featured_image_url, author, publish_date, seo_title, seo_description, published)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
       RETURNING *`,
      [
        title, slug, category, excerpt || null, body,
        featured_image_url || null,
        author || 'FlipLane Team',
        publish_date || new Date().toISOString().slice(0, 10),
        seo_title || null, seo_description || null,
        published || false
      ]
    );

    res.status(201).json({ success: true, post: result.rows[0] });
  } catch (err) {
    if (err.code === '23505') {
      return res.status(409).json({ success: false, message: 'A post with this slug already exists' });
    }
    console.error('[Blog API] POST /api/admin/blog/posts error:', err);
    res.status(500).json({ success: false, message: 'Failed to create post' });
  }
});

// PUT /api/admin/blog/posts/:id — update post (admin)
app.put('/api/admin/blog/posts/:id', requireAdminAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const {
      title, slug, category, excerpt, body, featured_image_url,
      author, publish_date, seo_title, seo_description, published
    } = req.body;

    if (!title || !slug || !category || !body) {
      return res.status(400).json({ success: false, message: 'title, slug, category, and body are required' });
    }
    const VALID_ADMIN_CATS_PUT = ['news', 'knowledge', 'gems', 'flip-tips', 'market', 'coop', 'hustle'];
    if (!VALID_ADMIN_CATS_PUT.includes(category)) {
      return res.status(400).json({ success: false, message: 'Invalid category value' });
    }

    const result = await pool.query(
      `UPDATE blog_posts SET
         title = $1, slug = $2, category = $3, excerpt = $4, body = $5,
         featured_image_url = $6, author = $7, publish_date = $8,
         seo_title = $9, seo_description = $10, published = $11,
         updated_at = CURRENT_TIMESTAMP
       WHERE id = $12
       RETURNING *`,
      [
        title, slug, category, excerpt || null, body,
        featured_image_url || null,
        author || 'FlipLane Team',
        publish_date || new Date().toISOString().slice(0, 10),
        seo_title || null, seo_description || null,
        published || false,
        parseInt(id)
      ]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Post not found' });
    }

    res.json({ success: true, post: result.rows[0] });
  } catch (err) {
    if (err.code === '23505') {
      return res.status(409).json({ success: false, message: 'A post with this slug already exists' });
    }
    console.error('[Blog API] PUT /api/admin/blog/posts/:id error:', err);
    res.status(500).json({ success: false, message: 'Failed to update post' });
  }
});

// DELETE /api/admin/blog/posts/:id — delete post (admin)
app.delete('/api/admin/blog/posts/:id', requireAdminAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(
      `DELETE FROM blog_posts WHERE id = $1 RETURNING id`,
      [parseInt(id)]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Post not found' });
    }
    res.json({ success: true, message: 'Post deleted' });
  } catch (err) {
    console.error('[Blog API] DELETE /api/admin/blog/posts/:id error:', err);
    res.status(500).json({ success: false, message: 'Failed to delete post' });
  }
});

// POST /api/admin/blog/upload-image — upload a blog image to R2
app.post('/api/admin/blog/upload-image', requireAdminAuth, blogImageUpload.single('image'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, message: 'No image file provided' });
    }

    const r2BaseUrl = process.env.POLSIA_R2_BASE_URL;
    if (!r2BaseUrl) {
      console.warn('[Blog Image] POLSIA_R2_BASE_URL not set');
      return res.status(500).json({ success: false, message: 'Image storage not configured' });
    }

    const ext = req.file.mimetype === 'image/png' ? 'png'
      : req.file.mimetype === 'image/webp' ? 'webp'
      : req.file.mimetype === 'image/gif' ? 'gif'
      : 'jpg';
    const filename = `blog_${Date.now()}_${Math.random().toString(36).slice(2, 8)}.${ext}`;

    const formData = new FormData();
    formData.append('file', req.file.buffer, { filename, contentType: req.file.mimetype });

    const uploadRes = await axios.post(`${r2BaseUrl}/upload`, formData, {
      headers: { ...formData.getHeaders() },
      timeout: 30000
    });

    const imageUrl = uploadRes.data?.url || uploadRes.data?.public_url || null;
    if (!imageUrl) {
      throw new Error('No URL returned from upload');
    }

    console.log(`[Blog Image] Upload success: ${imageUrl}`);
    res.json({ success: true, url: imageUrl });
  } catch (err) {
    console.error('[Blog Image] Upload failed:', err.message);
    res.status(500).json({ success: false, message: 'Image upload failed: ' + err.message });
  }
});

// GET /api/blog/posts/:slug/related — related posts by same category (public)
app.get('/api/blog/posts/:slug/related', async (req, res) => {
  try {
    const { slug } = req.params;
    const limit = Math.min(parseInt(req.query.limit) || 3, 6);

    // Look up the current post's category
    const postResult = await pool.query(
      `SELECT id, category FROM blog_posts WHERE slug = $1 AND published = true LIMIT 1`,
      [slug]
    );
    if (postResult.rows.length === 0) {
      return res.json({ success: true, posts: [] });
    }
    const { id: currentId, category } = postResult.rows[0];

    // Fetch related posts: same category, excluding current, most recent first
    const result = await pool.query(
      `SELECT id, title, slug, category, excerpt, featured_image_url, author, publish_date
       FROM blog_posts
       WHERE published = true AND category = $1 AND id != $2
       ORDER BY publish_date DESC, id DESC
       LIMIT $3`,
      [category, currentId, limit]
    );

    // If fewer than requested, backfill with posts from any category
    let posts = result.rows;
    if (posts.length < limit) {
      const needed = limit - posts.length;
      const excludeIds = [currentId, ...posts.map(p => p.id)];
      const placeholders = excludeIds.map((_, i) => `$${i + 1}`).join(',');
      const backfill = await pool.query(
        `SELECT id, title, slug, category, excerpt, featured_image_url, author, publish_date
         FROM blog_posts
         WHERE published = true AND id NOT IN (${placeholders})
         ORDER BY publish_date DESC, id DESC
         LIMIT $${excludeIds.length + 1}`,
        [...excludeIds, needed]
      );
      posts = [...posts, ...backfill.rows];
    }

    res.json({ success: true, posts });
  } catch (err) {
    console.error('[Blog API] GET /api/blog/posts/:slug/related error:', err);
    res.status(500).json({ success: false, message: 'Failed to load related posts' });
  }
});

// POST /api/newsletter/subscribe — newsletter opt-in (public)
app.post('/api/newsletter/subscribe', async (req, res) => {
  try {
    const { email, source } = req.body || {};
    if (!email || typeof email !== 'string') {
      return res.status(400).json({ success: false, message: 'Valid email is required' });
    }
    const normalizedEmail = email.trim().toLowerCase().slice(0, 320);
    // Basic format check
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)) {
      return res.status(400).json({ success: false, message: 'Invalid email format' });
    }

    await pool.query(
      `INSERT INTO newsletter_subscribers (email, source)
       VALUES ($1, $2)
       ON CONFLICT (email) DO NOTHING`,
      [normalizedEmail, (source || 'blog').slice(0, 100)]
    );

    res.json({ success: true, message: 'Subscribed successfully' });
  } catch (err) {
    // Handle case where table doesn't exist yet (migration pending)
    if (err.code === '42P01') {
      console.warn('[Newsletter] newsletter_subscribers table not yet created — subscription skipped');
      return res.json({ success: true, message: 'Subscribed' });
    }
    console.error('[Newsletter] POST /api/newsletter/subscribe error:', err);
    res.status(500).json({ success: false, message: 'Subscription failed' });
  }
});

// ============================================================
// INTERNAL — one-time applicant follow-up trigger (task #490977)
// Protected by secret query param. Safe to leave in — idempotent.
// ============================================================
app.post('/api/internal/trigger-applicant-followup', async (req, res) => {
  const SECRET = 'flipl-followup-2026-03-27';
  if (req.query.secret !== SECRET) {
    return res.status(403).json({ success: false, message: 'Forbidden' });
  }

  const applicants = [
    {
      id: 1,
      name: 'Ilyas zouheir',
      firstName: 'Ilyas',
      email: 'zouheirilyas@gmail.com',
      experience: 'experienced',
      uploadedId: true,
    }
  ];

  const results = [];
  const PARTNER_URL = 'https://fliplane.net/partner';

  for (const a of applicants) {
    const html = `
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"></head>
<body style="margin:0;padding:0;background:#f5f5f5;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f5f5;padding:40px 20px;"><tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:8px;overflow:hidden;max-width:600px;width:100%;">
<tr><td style="background:#1a1a2e;padding:32px 40px;text-align:center;">
  <p style="margin:0;font-size:22px;font-weight:700;color:#fff;letter-spacing:1px;">FlipLane</p>
  <p style="margin:6px 0 0;font-size:13px;color:#888cb4;">The AI-Powered Used Car Co-op</p>
</td></tr>
<tr><td style="padding:40px 40px 32px;">
  <p style="margin:0 0 20px;font-size:16px;color:#1a1a2e;">Hey ${a.firstName},</p>
  <p style="margin:0 0 16px;font-size:15px;line-height:1.7;color:#333;">You applied to join FlipLane's Co-op Partner network back on March 7th — and we dropped the ball on following up. That's on us.</p>
  <p style="margin:0 0 16px;font-size:15px;line-height:1.7;color:#333;">${a.uploadedId ? "You've already submitted your ID, which tells us you're serious. Let's get you across the finish line." : "Your application is ready to move forward."}</p>
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f8f9ff;border-radius:6px;margin:24px 0;">
    <tr><td style="padding:24px;">
      <p style="margin:0 0 14px;font-size:13px;font-weight:700;color:#1a1a2e;text-transform:uppercase;letter-spacing:1px;">What You Get as a Co-op Partner</p>
      <p style="margin:6px 0;font-size:14px;color:#333;line-height:1.5;"><span style="color:#4f6ef7;font-weight:700;">✓</span> Dealer credentials — no $15K+ state license required</p>
      <p style="margin:6px 0;font-size:14px;color:#333;line-height:1.5;"><span style="color:#4f6ef7;font-weight:700;">✓</span> Full ADESA auction access (50,000+ vehicles weekly)</p>
      <p style="margin:6px 0;font-size:14px;color:#333;line-height:1.5;"><span style="color:#4f6ef7;font-weight:700;">✓</span> Nationwide transaction processing — we handle the backend</p>
      <p style="margin:6px 0;font-size:14px;color:#333;line-height:1.5;"><span style="color:#4f6ef7;font-weight:700;">✓</span> Keep 100% profit on your own deals</p>
      <p style="margin:6px 0;font-size:14px;color:#333;line-height:1.5;"><span style="color:#4f6ef7;font-weight:700;">✓</span> Partner shipping network included</p>
    </td></tr>
  </table>
  <p style="margin:0 0 16px;font-size:15px;line-height:1.7;color:#333;">One-time membership fee is <strong>$250</strong>. No monthly fees, no revenue splits on your deals.</p>
  <p style="margin:0 0 28px;font-size:15px;line-height:1.7;color:#333;">Click below to complete your membership and get activated:</p>
  <table width="100%" cellpadding="0" cellspacing="0"><tr><td align="center">
    <a href="${PARTNER_URL}" style="display:inline-block;background:#4f6ef7;color:#fff;font-size:15px;font-weight:700;padding:14px 36px;border-radius:6px;text-decoration:none;letter-spacing:0.5px;">Complete My Membership →</a>
  </td></tr></table>
  <p style="margin:28px 0 0;font-size:14px;line-height:1.7;color:#666;">Questions? Just reply to this email — it goes straight to the team.</p>
</td></tr>
<tr><td style="padding:24px 40px;border-top:1px solid #eee;text-align:center;">
  <p style="margin:0;font-size:12px;color:#999;">FlipLane · Byrd Dawgs Automotive Group<br>
  <a href="${PARTNER_URL}" style="color:#4f6ef7;text-decoration:none;">fliplane.net/partner</a></p>
</td></tr>
</table></td></tr></table>
</body></html>`.trim();

    try {
      const result = await sendEmail({
        to: a.email,
        subject: `${a.firstName}, your FlipLane co-op application — next steps`,
        html,
        tag: 'applicant-followup',
        listUnsubscribe: true
      });
      console.log(`[Followup] ✅ Sent to ${a.email}: ${JSON.stringify(result)}`);
      results.push({ id: a.id, name: a.name, email: a.email, status: result.skipped ? 'skipped' : 'sent', result });
    } catch (err) {
      console.error(`[Followup] ❌ Failed for ${a.email}:`, err.message);
      results.push({ id: a.id, name: a.name, email: a.email, status: 'failed', error: err.message });
    }
  }

  res.json({ success: true, sent: results.filter(r => r.status === 'sent').length, results });
});

// ============================================================
// WEB SEARCH HELPERS — DuckDuckGo (no API key required)
// ============================================================

const WEB_SEARCH_PATTERNS = [
  /\b(price|prices|pricing|market|worth|value|how much)\b/i,
  /\b(recall|recalls|nhtsa|safety bulletin|safety issue)\b/i,
  /\b(news|trend|trends|trending|what.?s happening)\b/i,
  /\b(current|today|now|latest|recent|2026|2025)\b/i,
  /what.?s? (the |a )?(market|going rate|average price)\b/i,
  /\b(best cars? to flip|hot cars?|good cars? to flip|what.?s selling)\b/i,
  /\bused car market\b/i,
  /\b(auction prices?|auction results?|kbb|kelley blue book|cargurus|edmunds)\b/i
];

function needsWebSearch(message) {
  return WEB_SEARCH_PATTERNS.some(p => p.test(message));
}

function buildAutomotiveSearchQuery(message) {
  const year = new Date().getFullYear();
  if (/\brecall\b/i.test(message)) {
    return `${message} NHTSA recall ${year}`;
  }
  if (/\b(price|worth|value|market|how much)\b/i.test(message)) {
    return `${message} used car market ${year}`;
  }
  if (/\b(flip|flipping|best cars?|what.?s selling)\b/i.test(message)) {
    return `${message} used car market ${year} automotive`;
  }
  return `${message} automotive used car ${year}`;
}

async function searchDuckDuckGo(query, maxResults = 4) {
  try {
    const encoded = encodeURIComponent(query);
    const response = await axios.get(`https://html.duckduckgo.com/html/?q=${encoded}`, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml',
        'Accept-Language': 'en-US,en;q=0.9'
      },
      timeout: 8000
    });

    const html = response.data;

    // Parse result titles, snippets, and display URLs from DDG HTML
    const titleRe = /<a\s+[^>]*\bclass="result__a"[^>]*>([\s\S]*?)<\/a>/g;
    const snippetRe = /<a\s+[^>]*\bclass="result__snippet"[^>]*>([\s\S]*?)<\/a>/g;
    const urlRe = /<span\s+[^>]*\bclass="result__url"[^>]*>([\s\S]*?)<\/span>/g;

    const titles = [...html.matchAll(titleRe)].map(m => m[1].replace(/<[^>]+>/g, '').trim());
    const snippets = [...html.matchAll(snippetRe)].map(m => m[1].replace(/<[^>]+>/g, '').trim());
    const urls = [...html.matchAll(urlRe)].map(m => m[1].replace(/<[^>]+>/g, '').trim());

    const results = [];
    const count = Math.min(titles.length, snippets.length, maxResults);
    for (let i = 0; i < count; i++) {
      if (titles[i] && snippets[i]) {
        results.push({ title: titles[i], url: urls[i] || '', snippet: snippets[i] });
      }
    }

    console.log(`[Search] DuckDuckGo: ${results.length} results for "${query.substring(0, 60)}"`);
    return results;
  } catch (err) {
    console.error('[Search] DuckDuckGo error:', err.message);
    return [];
  }
}

function buildSearchContextPrompt(results, query) {
  if (!results || results.length === 0) return '';
  const today = new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
  let ctx = `\n\n---\nLIVE WEB SEARCH RESULTS\nQuery: "${query}" | Retrieved: ${today}\n---\n\n`;
  results.forEach((r, i) => {
    ctx += `[${i + 1}] ${r.title}\n`;
    if (r.url) ctx += `Source: ${r.url}\n`;
    ctx += `${r.snippet}\n\n`;
  });
  ctx += `INSTRUCTIONS: Use these real-time search results to give a current, accurate answer. When referencing specific data from results, cite the source by name (e.g., "According to KBB..."). These supplement — don't replace — your core automotive expertise.\n---`;
  return ctx;
}

// ============================================================
// SUPERFLIP AI CHAT AGENT
// ============================================================

const openaiClient = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
  baseURL: process.env.OPENAI_BASE_URL || undefined
});

const SUPERFLIP_SYSTEM_PROMPT = `You are SuperFlip — a confident, street-smart car flipping mentor built by FlipLane. You've personally flipped hundreds of vehicles, you know every auction trick in the book, and you talk like a seasoned operator who's seen it all.

You have deep expertise from the Flip to Fortune playbook — a 92-page guide covering every stage of the car flipping business. Here is your complete knowledge base:

---
FLIP TO FORTUNE — COMPLETE KNOWLEDGE BASE
---

## CHAPTER 1: THE FLIP MENTALITY

Car flipping is the #1 underrated side hustle in 2026. The average dealer markup on used cars is $3,000–$5,000. That's money left on the table that flippers capture. Unlike stocks or crypto, cars are tangible — you can touch, inspect, and control your risk.

The mindset shift: Stop thinking like a buyer. Think like an investor. Every car is a deal with a math problem. Emotion is your enemy. The moment you fall in love with a car, you lose money.

Three types of flippers:
- Hobbyists: Flip 1–2 cars/year, treat it casually, make $1,000–$3,000/year
- Operators: Flip 2–4 cars/month systematically, $2,000–$5,000/month
- Scalers: 5–10+ cars/month, $50K–$150K+/year, treat it like a real business

The key mindset rules:
1. Buy on math, not emotion
2. Never fall in love with inventory
3. Speed of capital rotation beats margin on individual deals
4. Your first deal is just proof of concept — don't make your money back on deal #1, make it back on deal #5
5. Consistency beats luck

Why car flipping beats other hustles: Low startup capital ($250–$2,000), proven demand, physical asset with recoverable value, scalable, no employer/employee relationship, works everywhere in the US.

## CHAPTER 2: AUCTION MASTERY

The secret weapon of every profitable flipper is auction access. Retail buyers pay retail prices. Flippers buy at dealer wholesale — 20–40% below retail.

**Key Auction Platforms:**
- **ADESA**: Physical dealer auctions across the US. High volume, mixed quality, great for $8K–$25K vehicles
- **OVE (Online Vehicle Exchange)**: ADESA's online platform — bid from anywhere, 24/7
- **Copart**: Salvage/damaged vehicles. Higher risk, higher reward. Needs repair knowledge.
- **IAAI (Insurance Auto Auctions)**: Similar to Copart, insurance totals
- **Manheim**: Largest dealer auction network, requires dealer license (FlipLane co-op members get access through the co-op)

**MMR (Manheim Market Report)**: The industry standard valuation. Always anchor to MMR. If you're paying more than 90% of MMR, walk away unless you have a specific buyer lined up.

**Auction Bidding Rules:**
1. Set your max bid BEFORE the auction starts. Write it down.
2. Factor in all costs BEFORE bidding: arbitration fee ($295–$495), transportation ($150–$400), reconditioning estimate, title/tags, your time
3. The "20% rule": Your all-in acquisition cost should be ≤80% of your target sale price
4. Watch 3–5 auctions before bidding. Learn the lanes, the pacing, the run list
5. Early morning lanes (7–9am) often have less competition
6. Thursday/Friday lanes are higher volume, more competition
7. Avoid bidding on cars you can't inspect first unless you know the grade and run condition

**Auction Grades (ADESA/Manheim scale 1–5):**
- 5: Excellent — like new, no visible damage
- 4: Good — minor cosmetic issues, fully functional
- 3: Average — normal wear, may need light recon
- 2: Rough — significant cosmetic or mechanical issues
- 1: Parts only / heavy damage

Target Grade 3–4 vehicles for the best risk/reward ratio.

**Online Auction Strategy (OVE):**
- Set alerts for specific makes/models/years in your price range
- Use buy-it-now (BIN) prices for fast capital deployment
- Condition reports are everything — read them carefully, look for "as-is" flags
- Book transport through the auction platform for convenience, or use uShip for better pricing

**FlipLane Co-op Advantage**: FlipLane members get ADESA access through the co-op's dealer credentials — no need for your own $15K+ dealer license. This is the biggest unlock. Retail-to-wholesale arbitrage becomes available from day one.

## CHAPTER 3: THE REAL COST OF A FLIP — DEAL MATH

The #1 mistake new flippers make: They forget costs. They buy a car for $8,000, sell it for $11,000, think they made $3,000, but forgot $2,400 in costs. Actual profit: $600.

**Complete Cost Framework:**

| Cost Category | Typical Range | Notes |
|--------------|---------------|-------|
| Purchase price | Variable | Your auction bid or private purchase |
| Auction fee | $295–$495 | Per vehicle, paid to auction house |
| Transportation | $150–$450 | Depends on distance, vehicle size |
| Title & registration | $75–$200 | State dependent |
| Reconditioning | $0–$3,000+ | Detail, mechanical, cosmetic |
| Photography | $0–$150 | DIY or professional |
| Listing costs | $0–$100 | Facebook Marketplace is free; Cars.com/AutoTrader cost money |
| Holding costs | $50–$200/month | Insurance, storage if applicable |
| Buyer negotiation buffer | 2–5% | Price cushion for negotiation |

**The Breakeven Formula:**
Minimum Sale Price = Purchase Price + All Costs + Target Profit

**Real Example — $12K Vehicle:**
- Purchase at auction: $10,500
- Auction fee: $395
- Transport (200 miles): $250
- Minor recon (detail + oil change + wiper blades): $350
- Total cost in: $11,495
- Target 20% margin: Sell for $13,794+
- Listed at: $14,200 (negotiation buffer)
- Accepted offer: $13,800
- **Net profit: $2,305**

**Sweet Spot Vehicle Range**: $8,000–$18,000 purchase price
- More buyers at this range (mass market)
- Lower risk than luxury vehicles
- Faster days-to-sell
- Less specialized knowledge required

**Vehicles to Avoid (for beginners):**
- Salvage/rebuilt titles (unless you specialize)
- Luxury vehicles over $30K (smaller buyer pool, longer days-on-lot)
- High-mileage diesel trucks without mechanics knowledge
- Electric vehicles with unknown battery health
- German luxury brands (BMW, Mercedes, Audi) — high repair costs

**Best Flip Vehicles (consistent profitability):**
- Toyota Camry/Corolla: Bulletproof demand, easy to recondition
- Honda Accord/Civic: Same — massive buyer pool
- Ford F-150 (2015–2020): Trucks move fast, premium prices
- Chevy Silverado (same era)
- Honda CR-V / Toyota RAV4: SUV demand is massive
- Hyundai Sonata/Elantra: Lower purchase price, good margins

## CHAPTER 4: INSPECTION & DUE DILIGENCE

The 15-point inspection protocol every flipper must run before buying:

**Pre-Auction (use photos/condition reports):**
1. VIN check (run Carfax or AutoCheck) — look for accidents, title issues, odometer rollback
2. Owner history (1–2 owners is ideal; fleet vehicles can be good)
3. Service records (if available)
4. ADESA/Manheim condition report review

**Physical Inspection (at auction or private seller):**
5. Walk the exterior — look for panel gaps, paint overspray, mismatched paint (signs of body work)
6. Check all 4 corners for rust (especially underbody on older vehicles)
7. Open all doors, hood, trunk — check for water stains, rust, damage
8. Start the car cold — listen for ticking, knocking, rough idle
9. Check all warning lights — OBD2 scan if possible ($20 reader from Amazon)
10. Test all electronics: windows, locks, AC/heat, radio, backup camera
11. Check tires (depth + even wear — uneven wear = alignment/suspension issue)
12. Test drive: acceleration, braking, steering, transmission shifts
13. Check for transmission slippage or hard shifts
14. Smell the interior — mold/mildew is expensive to fix
15. Check fluid levels and condition: oil, coolant, transmission fluid

**Red Flags — Walk Away:**
- Check engine light + won't read (cleared codes before auction)
- Frame damage on condition report
- Flood title
- Rebuilt title (unless you're buying specifically for that)
- Mismatched VINs (theft indicator)
- Transmission feels "slippy" or hesitates on test drive

**OBD2 Pro Tip:** A $20 OBD2 reader plugged into the diagnostic port will pull fault codes. If the battery was recently disconnected (common trick to clear codes), the readiness monitors will show "not ready" — meaning the car hasn't been driven enough to re-run emissions tests. This is a yellow flag.

## CHAPTER 5: RECONDITIONING FOR MAXIMUM ROI

The goal of reconditioning: Create perceived value that exceeds your investment. Every dollar spent should return $2–$3 at sale.

**High-ROI Reconditioning (always do these):**
1. Full detail (interior + exterior): $150–$200 professional or $30 DIY — returns $500–$1,000 in price premium
2. Fresh oil change with sticker: $35–$50 — buyers feel "taken care of"
3. New wiper blades: $20 — subtle but professional
4. New floor mats if stained/worn: $30–$50 — huge visual impact
5. Touch up paint chips (for visible areas): $20 in touch-up paint, $300+ visual improvement
6. Clean wheels: Often overlooked, but buyers notice

**Medium-ROI (do if cost is reasonable):**
- New tires (if <3/32 tread): Costs $400–$600, adds $1,000+ in buyer confidence
- Minor dent removal (PDR): $50–$200 per dent, adds $500+ in asking price
- Headlight restoration: $25–$50, makes car look years newer

**Low-ROI (skip unless critical):**
- Full paint correction/ceramic coat: $500–$1,500, rarely earns back in flipping context
- Major mechanical work: Cut your losses and price for the issue, or sell wholesale

**The Recon Math Rule:** Never spend more than 20% of your target profit on reconditioning. If your target profit is $2,000, cap recon at $400.

## CHAPTER 6: SELLING STRATEGIES

Speed = profit in car flipping. Days on lot = dollars lost in holding costs + opportunity cost.

**Pricing Strategy:**
- Price at MMR + recon investment + 15–20% margin
- Build in negotiation room (list 5–8% above your minimum)
- Competitive pricing beats holding out for top dollar

**Where to List:**
1. **Facebook Marketplace**: Free, massive reach, best for local sales. Best ROI.
2. **Craigslist**: Still works, especially for trucks and older vehicles
3. **OfferUp**: Mobile-first, great for quick private sales
4. **Cars.com / CarGurus**: Paid listings, worth it for $15K+ vehicles, reaches more serious buyers
5. **AutoTrader**: Premium pricing, serious buyers, worth it for $20K+ range

**Photography Rules:**
- Take at least 20 photos
- Always photograph in natural light (golden hour if possible — early morning or late afternoon)
- Background: Clean driveway, not a cluttered garage
- Must-shoot angles: Front, rear, both sides, front 3/4, rear 3/4, interior front, interior back, dashboard, odometer, engine, all 4 tires, any blemishes
- Clean the car right before photos, every time

**The Listing Description Formula:**
1. Lead with year/make/model + key specs
2. Mention ownership (1–2 owner, clean Carfax)
3. Call out recent service/maintenance
4. Describe condition honestly — buyers appreciate transparency
5. Price + "negotiable" or "firm"
6. "Cash or finance available" (FlipLane members can offer financing through co-op)
7. Include your phone number (serious buyers call, tire kickers text)

**Negotiation Rules:**
- Never come down more than $500 on the first counter-offer
- Counter at minimum $300 above your floor (never show your floor)
- "Best I can do is $X" — say it once, then be quiet
- If they walk, let them walk. They often come back.
- Never negotiate over text — get them on the phone or in person

**Closing the Deal:**
- Bill of sale is mandatory (protects you legally)
- Accept cash, cashier's check, or Zelle/Venmo (cash equivalent)
- NEVER take personal checks
- Transfer title same day — don't let them drive off without paperwork

## CHAPTER 7: SCALING TO $50K+/YEAR

Getting from 1 flip/month to 5–10 flips/month requires systems, not just hustle.

**Capital Strategy:**
- Start with $5,000–$10,000 working capital
- After 3 profitable flips, you're rolling on gross margins — don't pull all profit out
- Target: Keep 3–4 vehicles in inventory at all times (rotating capital)
- At 3 cars/month × $2,500 margin = $7,500/month = $90K/year

**Building Your Team/Vendor Network:**
- Trusted mechanic: Build a relationship with an independent shop. Get fleet pricing.
- Detail shop: Find a mobile detailer who gives you consistent pricing
- PDR technician: Paintless dent repair. Essential for door dings
- Title processing service: Some states are complex — use a title service ($50–$75/car)
- Transport broker: uShip or Montway for long-distance buys

**The 10-Car Month Math:**
- 10 cars × avg $2,000 margin = $20,000/month gross
- Operating costs (recon avg): 10 × $400 = $4,000
- Transport/fees: 10 × $200 = $2,000
- Net: $20,000 - $6,000 = **$14,000/month net**

**Scaling Tools:**
- CRM (even a spreadsheet) to track deals: Buy price, costs, list date, sale price, net
- Separate business bank account
- LLC formation (protects personal assets, enables business banking)
- Business insurance (dealer-level coverage through the co-op)

**Time Management:**
- Auction attendance: 4–6 hours/week
- Listing management: 2–3 hours/week
- Buyer communication: 1–2 hours/day when active listings are live
- Deal closing: 1–2 hours per sale

## CHAPTER 8: THE FLIPLANE ADVANTAGE — CO-OP MODEL

This is the game-changer that separates FlipLane members from solo flippers.

**What is the FlipLane Co-op?**
A dealer co-op that gives individual car flippers access to:
- **ADESA wholesale auction access** (normally requires a $15K+ dealer license)
- **Dealer credentials** — buy and sell at dealer auction prices
- **ByrddawgsOS** — the member operating system with deal tracking, resources, training, and community
- **FlipLane Bible** — the 200+ page member resource guide
- **Co-op financing** — purchase vehicles with no money down (for qualifying members)
- **Expert support** — real humans to help you through your first deals

**Cost:** $250 membership fee — no annual fees, no per-car fees

**The Math:**
- Cost: $250 once
- Savings per car vs retail: $2,000–$5,000
- Payback period: **Your first deal pays for membership 8–20x over**

**Member Results:**
- Raymond Little: 10 vehicles → $4–5K/month residual income
- Tony Tunstall: Franchise GM → works from home, same income
- Gloria: Turo fleet built with no money down through co-op
- Ronald Pennyman: 50% commission on every deal closed

**Co-op vs Dealer License:**
| Feature | Solo Dealer License | FlipLane Co-op |
|---------|---------------------|----------------|
| Cost | $15,000+ | $250 |
| Time to active | 6–12 months | 48 hours |
| Auction access | Full | ADESA + OVE + more |
| Support | None | FlipLane team |
| Legal complexity | High | Handled by co-op |

## CHAPTER 9: EXPORT, RENTAL ARBITRAGE & ADVANCED STRATEGIES

**Export Markets:**
West African, Caribbean, and Central American markets have strong demand for certain US vehicles:
- Toyota Camry/Corolla (2010–2016)
- Honda Accord/Civic (same era)
- American trucks and SUVs

Export flipping typically requires a dealer license (provided through the co-op). Margins are often $3,000–$8,000+ per vehicle.

**Rental Fleet Arbitrage (Turo/Getaround):**
Buy wholesale, rent on Turo, eventually sell. Triple dip:
1. Buy below retail
2. Generate rental income ($800–$2,000/month on right vehicle)
3. Sell above your wholesale cost when ready

Best Turo vehicles: Toyota Camry, Tesla Model 3, Toyota RAV4, Honda CR-V, sporty/unique vehicles for premium markets.

Gloria's model (FlipLane member): Built a 10-car Turo fleet using co-op financing — no money out of pocket.

**Wholesaling (Dealer-to-Dealer):**
Skip retail entirely. Buy at auction, sell to another dealer for quick $300–$800 profit per car. Lower margin, faster turns, scales without needing retail buyers.

## CHAPTER 10: COMMON MISTAKES & HOW TO AVOID THEM

**The 10 Deadly Sins of Car Flipping:**

1. **Buying on emotion**: That "perfect" car that's priced too high. Walk away.
2. **Skipping the inspection**: "It looked fine in the photos." Famous last words.
3. **Underestimating reconditioning**: Always estimate high, not low.
4. **Overlisting price**: Cars that sit kill your capital velocity. Price to move.
5. **Not doing a VIN check**: Flood titles, frame damage, odometer fraud all exist.
6. **Accepting personal checks**: People stop payment. Cash, Zelle, cashier's check only.
7. **No bill of sale**: You are liable for traffic tickets and accidents after a verbal sale.
8. **Pulling all profit out**: Reinvest to grow capital base. Let it compound.
9. **Going too big too fast**: Master 1–2 cars/month before scaling.
10. **Going alone**: The co-op exists so you don't have to figure this out solo.

**Mindset Traps:**
- "I'll make it up on the next deal" — bad deals compound if you don't cut losses
- "I just need one big score" — consistency beats lottery tickets
- "I don't need a system, I'll remember it" — you won't

---
END OF KNOWLEDGE BASE
---

## YOUR PERSONA & BEHAVIOR

**Communication style:**
- Talk like you're texting a friend who just asked you a real question
- Be direct and specific — no vague "it depends" without actually answering
- Use real numbers when you have them
- Occasionally use informal language: "real talk", "here's the thing", "this is key"
- Short paragraphs, easy to read on mobile
- Never say "Great question!" or be sycophantic

**When to mention FlipLane co-op:**
- Naturally, when the answer involves auction access (mention ADESA access through co-op)
- When discussing costs (mention $250 co-op fee as the cheapest route to dealer access)
- When someone asks about scaling (mention ByrddawgsOS, the member operating system)
- DON'T: Force it on every answer, repeat it multiple times, be pushy
- DO: Weave it in once per conversation when naturally relevant, link to /partner

**What you don't do:**
- Make up specific auction results you don't know
- Guarantee profit on specific deals
- Provide legal or tax advice (refer to professionals for that)
- Pretend to know information about a specific car without details

**End with action:** When appropriate, nudge toward the next step — whether that's learning more, doing deal math, or checking out FlipLane co-op at /partner.`;

// Rate limiting: simple in-memory per-IP (resets on server restart)
const chatRateLimits = new Map();
function checkChatRateLimit(ip) {
  const now = Date.now();
  const windowMs = 60 * 1000; // 1 minute
  const maxRequests = 10;
  const entry = chatRateLimits.get(ip) || { count: 0, resetAt: now + windowMs };
  if (now > entry.resetAt) {
    entry.count = 0;
    entry.resetAt = now + windowMs;
  }
  entry.count++;
  chatRateLimits.set(ip, entry);
  return entry.count <= maxRequests;
}

app.post('/api/superflip/chat', async (req, res) => {
  const ip = req.ip || req.connection.remoteAddress || 'unknown';
  if (!checkChatRateLimit(ip)) {
    return res.status(429).json({ success: false, message: 'Too many requests. Slow down.' });
  }

  const { messages } = req.body;
  if (!messages || !Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ success: false, message: 'messages array required' });
  }

  // Sanitize: only allow role/content, max 20 messages, max 1000 chars per message
  const sanitized = messages.slice(-20).map(m => ({
    role: m.role === 'user' ? 'user' : 'assistant',
    content: String(m.content || '').slice(0, 1000)
  })).filter(m => m.content.length > 0);

  if (sanitized.length === 0) {
    return res.status(400).json({ success: false, message: 'No valid messages' });
  }

  try {
    // Web search for real-time data
    const lastUserMsg = sanitized.filter(m => m.role === 'user').pop()?.content || '';
    let webResults = [];
    let searchQuery = null;
    if (needsWebSearch(lastUserMsg)) {
      searchQuery = buildAutomotiveSearchQuery(lastUserMsg);
      webResults = await searchDuckDuckGo(searchQuery);
    }

    const systemPrompt = SUPERFLIP_SYSTEM_PROMPT + buildSearchContextPrompt(webResults, searchQuery);

    const completion = await openaiClient.chat.completions.create({
      model: 'claude-sonnet-4-5',
      messages: [
        { role: 'system', content: systemPrompt },
        ...sanitized
      ],
      max_tokens: webResults.length > 0 ? 800 : 600,
      temperature: 0.7
    });

    const reply = completion.choices[0]?.message?.content || "Sorry, I couldn't process that. Try asking again.";
    res.json({
      success: true,
      message: reply,
      searched: webResults.length > 0,
      sources: webResults.length > 0 ? webResults.slice(0, 3).map(r => ({ title: r.title, url: r.url })) : null
    });
  } catch (err) {
    console.error('[SuperFlip] Chat error:', err.message);
    res.status(500).json({ success: false, message: "Something went sideways. Try again in a second." });
  }
});

// ============================================================
// CONTEXT-AWARE AI CHAT — AFFILIATE CONTEXT (AffiliateOS)
// ============================================================

const AFFILIATE_AI_SYSTEM_PROMPT = `You are FlipLane's AI assistant for affiliate partners. You help affiliates maximize their earnings through smart referral strategies and effective marketing.

Key facts about the FlipLane affiliate program:
- Affiliates earn 50% commissions on: referred buyers, referred co-op partners, found vehicle deals, and marketing-generated leads
- FlipLane is an AI-powered used car co-op where members get ADESA/OVE dealer auction access without a dealer license
- Co-op membership costs $250 to join
- Referral links send prospects to fliplane.net/earn to apply
- The Referral Toolkit creates channel-specific links (Facebook, Instagram, TikTok, YouTube, etc.)
- Deal Submissions: Find a vehicle deal anywhere, submit it, earn 50% commission if FlipLane closes it
- Marketing Support: Request custom copy/assets from the FlipLane team via Affiliate Hub

How to maximize earnings as an affiliate:
1. Target car enthusiasts, side-hustle seekers, underemployed mechanics, used car resellers, small car lots
2. Best platforms: TikTok (car flipping content gets massive reach), Facebook Groups, Instagram Reels, YouTube Shorts
3. Core message: "Flip cars without a dealer license" + "Start with $250" + "50% commissions on referrals"
4. Create multiple referral links for different channels and track which performs best
5. Warm intros always outperform cold posts — focus on your existing network first
6. Video content showing real deal math converts best

Be concise, tactical, and focused on helping affiliates earn more money. No fluff. Speak like a performance marketer who understands the vehicle business.`;

const _affiliateAiRateMap = new Map();

app.post('/api/ai/affiliate-chat', async (req, res) => {
  const ip = req.ip || req.connection?.remoteAddress || 'unknown';
  const now = Date.now();
  const windowMs = 60000;
  const rateLimit = 15;

  if (!_affiliateAiRateMap.has(ip)) _affiliateAiRateMap.set(ip, []);
  const hits = _affiliateAiRateMap.get(ip).filter(t => now - t < windowMs);
  if (hits.length >= rateLimit) {
    return res.status(429).json({ success: false, message: 'Too many requests. Slow down.' });
  }
  hits.push(now);
  _affiliateAiRateMap.set(ip, hits);

  const { messages, context } = req.body;
  if (!messages || !Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ success: false, message: 'messages array required' });
  }

  const sanitized = messages.slice(-20).map(m => ({
    role: m.role === 'user' ? 'user' : 'assistant',
    content: String(m.content || '').slice(0, 1000)
  })).filter(m => m.content.length > 0);

  if (sanitized.length === 0) {
    return res.status(400).json({ success: false, message: 'No valid messages' });
  }

  // Web search for real-time automotive data
  const lastUserMsgAffiliate = sanitized.filter(m => m.role === 'user').pop()?.content || '';
  let webResultsAffiliate = [];
  let searchQueryAffiliate = null;
  if (needsWebSearch(lastUserMsgAffiliate)) {
    searchQueryAffiliate = buildAutomotiveSearchQuery(lastUserMsgAffiliate);
    webResultsAffiliate = await searchDuckDuckGo(searchQueryAffiliate);
  }

  let systemPrompt = AFFILIATE_AI_SYSTEM_PROMPT;
  if (context?.name) systemPrompt += `\n\nYou are speaking with ${context.name}.`;
  if (context?.total_earned !== undefined) systemPrompt += ` They have earned $${context.total_earned} in commissions so far.`;
  if (context?.referral_signups !== undefined) systemPrompt += ` They have ${context.referral_signups} referred signups.`;
  systemPrompt += buildSearchContextPrompt(webResultsAffiliate, searchQueryAffiliate);

  try {
    const completion = await openaiClient.chat.completions.create({
      model: 'claude-sonnet-4-5',
      messages: [
        { role: 'system', content: systemPrompt },
        ...sanitized
      ],
      max_tokens: webResultsAffiliate.length > 0 ? 800 : 600,
      temperature: 0.7
    });

    const reply = completion.choices[0]?.message?.content || "Couldn't process that. Try again.";
    res.json({
      success: true,
      message: reply,
      searched: webResultsAffiliate.length > 0,
      sources: webResultsAffiliate.length > 0 ? webResultsAffiliate.slice(0, 3).map(r => ({ title: r.title, url: r.url })) : null
    });
  } catch (err) {
    console.error('[AffiliateAI] Chat error:', err.message);
    res.status(500).json({ success: false, message: 'Something went sideways. Try again.' });
  }
});

// ============================================================
// CONTEXT-AWARE AI CHAT — CO-OP MEMBER CONTEXT (ByrddawgsOS)
// ============================================================

const _memberAiRateMap = new Map();

app.post('/api/ai/member-chat', async (req, res) => {
  const ip = req.ip || req.connection?.remoteAddress || 'unknown';
  const now = Date.now();
  const windowMs = 60000;
  const rateLimit = 15;

  if (!_memberAiRateMap.has(ip)) _memberAiRateMap.set(ip, []);
  const hits = _memberAiRateMap.get(ip).filter(t => now - t < windowMs);
  if (hits.length >= rateLimit) {
    return res.status(429).json({ success: false, message: 'Too many requests. Slow down.' });
  }
  hits.push(now);
  _memberAiRateMap.set(ip, hits);

  const { messages, context } = req.body;
  if (!messages || !Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ success: false, message: 'messages array required' });
  }

  const sanitized = messages.slice(-20).map(m => ({
    role: m.role === 'user' ? 'user' : 'assistant',
    content: String(m.content || '').slice(0, 1000)
  })).filter(m => m.content.length > 0);

  if (sanitized.length === 0) {
    return res.status(400).json({ success: false, message: 'No valid messages' });
  }

  // Web search for real-time automotive data
  const lastUserMsgMember = sanitized.filter(m => m.role === 'user').pop()?.content || '';
  let webResultsMember = [];
  let searchQueryMember = null;
  if (needsWebSearch(lastUserMsgMember)) {
    searchQueryMember = buildAutomotiveSearchQuery(lastUserMsgMember);
    webResultsMember = await searchDuckDuckGo(searchQueryMember);
  }

  // Uses the full SuperFlip knowledge base + co-op member context
  let systemPrompt = SUPERFLIP_SYSTEM_PROMPT;
  systemPrompt += '\n\n---\nCO-OP MEMBER CONTEXT\n---\nThis person is a Byrd Dawgs co-op partner through FlipLane. They have access to ADESA and OVE via the co-op\'s shared dealer credentials — no personal dealer license required. They can use the Deal Center to submit deals to FlipLane for Fix & Flip, shipping, and title processing services. When relevant, remind them to check the Tools & Credentials section for auction login info.';
  if (context?.name) systemPrompt += `\n\nYou are speaking with ${context.name}.`;
  if (context?.cert_level) systemPrompt += ` Their certification level: ${context.cert_level}.`;
  systemPrompt += buildSearchContextPrompt(webResultsMember, searchQueryMember);

  try {
    const completion = await openaiClient.chat.completions.create({
      model: 'claude-sonnet-4-5',
      messages: [
        { role: 'system', content: systemPrompt },
        ...sanitized
      ],
      max_tokens: webResultsMember.length > 0 ? 900 : 700,
      temperature: 0.7
    });

    const reply = completion.choices[0]?.message?.content || "Couldn't process that. Try again.";
    res.json({
      success: true,
      message: reply,
      searched: webResultsMember.length > 0,
      sources: webResultsMember.length > 0 ? webResultsMember.slice(0, 3).map(r => ({ title: r.title, url: r.url })) : null
    });
  } catch (err) {
    console.error('[MemberAI] Chat error:', err.message);
    res.status(500).json({ success: false, message: 'Something went sideways. Try again.' });
  }
});

// ============================================================
// AFFILIATEOS SERVICE REQUESTS
// ============================================================

app.post('/api/affiliateos/service-request', async (req, res) => {
  const { email, request_type, form_data } = req.body;

  if (!email || !request_type || !form_data) {
    return res.status(400).json({ success: false, message: 'email, request_type, and form_data required' });
  }

  const allowed = ['customer_inquiry', 'marketing_support'];
  if (!allowed.includes(request_type)) {
    return res.status(400).json({ success: false, message: 'Invalid request type' });
  }

  try {
    // Verify affiliate exists
    const affiliateCheck = await pool.query(
      `SELECT ap.id, asig.name FROM affiliate_profiles ap
       JOIN affiliate_signups asig ON asig.id = ap.signup_id
       WHERE LOWER(asig.email) = LOWER($1)`,
      [email.trim()]
    );

    if (affiliateCheck.rows.length === 0) {
      return res.status(403).json({ success: false, message: 'Affiliate not found' });
    }

    const affiliateName = affiliateCheck.rows[0].name || email;

    // Save to service_requests table (member_id NULL, affiliate info in form_data)
    const result = await pool.query(
      `INSERT INTO service_requests (member_id, request_type, form_data)
       VALUES (NULL, $1, $2) RETURNING id`,
      [request_type, JSON.stringify({ ...form_data, affiliate_email: email, affiliate_name: affiliateName })]
    );
    const requestId = result.rows[0].id;

    // Build email notification
    const isCustomerInquiry = request_type === 'customer_inquiry';
    const subject = isCustomerInquiry
      ? `[AffiliateOS] Customer Inquiry — ${form_data.customer_name || 'Unknown'} via ${affiliateName}`
      : `[AffiliateOS] Marketing Support Request — ${affiliateName}`;

    const fieldRows = Object.entries({ ...form_data, affiliate_email: email, affiliate_name: affiliateName })
      .map(([k, v]) => `<tr><td style="padding:6px 10px;color:#888;font-size:13px;text-transform:capitalize;">${k.replace(/_/g, ' ')}</td><td style="padding:6px 10px;font-size:13px;color:#fff;">${v}</td></tr>`)
      .join('');

    const html = `
      <div style="font-family:'DM Sans',sans-serif;max-width:600px;background:#0a0a0a;color:#fff;padding:28px;border-radius:12px;border:1px solid #222;">
        <div style="color:#00e676;font-size:20px;font-weight:700;margin-bottom:6px;">${subject}</div>
        <div style="color:#555;font-size:12px;margin-bottom:20px;">Request ID: #${requestId} — Submitted via AffiliateOS</div>
        <table style="width:100%;border-collapse:collapse;background:#161616;border-radius:8px;overflow:hidden;">
          ${fieldRows}
        </table>
        <div style="color:#444;font-size:12px;margin-top:20px;">Reply to affiliate at: ${email}</div>
      </div>`;

    await sendEmail({ to: 'win@fliplane.net', subject, html });

    // Send confirmation email to affiliate — fire-and-forget
    sendEmail({
      to: email,
      subject: `Your ${isCustomerInquiry ? 'customer inquiry' : 'marketing support request'} has been received`,
      html: `
        <div style="font-family: 'DM Sans', Arial, sans-serif; max-width: 560px; margin: 0 auto; background: #0a0a0a; color: #ffffff; padding: 40px 32px; border-radius: 12px;">
          <div style="margin-bottom: 28px;">
            <span style="font-size: 1.4rem; font-weight: 700; letter-spacing: -0.5px;">Flip<span style="color: #00e676;">Lane</span></span>
          </div>
          <h1 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 12px;">Request received, ${affiliateName.split(' ')[0]}!</h1>
          <p style="color: #a0a0a0; font-size: 1rem; line-height: 1.6; margin-bottom: 20px;">We received your ${isCustomerInquiry ? 'customer inquiry' : 'marketing support request'} (Request #${requestId}). Our team will review and follow up within 24 hours.</p>
          <p style="color: #666; font-size: 0.88rem; line-height: 1.6;">Need immediate help? Email <a href="mailto:win@fliplane.net" style="color: #00e676;">win@fliplane.net</a></p>
          <hr style="border: none; border-top: 1px solid #222; margin: 28px 0;">
          <p style="color: #444; font-size: 0.8rem;">FlipLane · AffiliateOS</p>
        </div>
      `,
      tag: `affiliateos-${request_type}-confirmation`
    }).catch(err => console.error('[Email] Affiliate confirmation (affiliateos-service-request) failed:', err.message));

    res.json({ success: true, message: 'Request submitted! We\'ll follow up shortly.', request_id: requestId });
  } catch (err) {
    console.error('[AffiliateOS] Service request error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to submit request' });
  }
});

// ============================================================
// STATIC FILES — after page routes
// ============================================================
app.use(express.static(path.join(__dirname, 'public')));

// ============================================================
// HEALTH CHECK — email system status
// ============================================================
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.get('/api/health/email', async (req, res) => {
  const polsiaKey = process.env.POLSIA_API_KEY || process.env.POLSIA_API_TOKEN;
  const transports = [];

  if (polsiaKey) {
    transports.push({ name: 'polsia_bridge', status: 'configured', note: 'Polsia platform email bridge (primary transport)' });
  } else {
    transports.push({ name: 'polsia_bridge', status: 'not_configured' });
  }

  const hasWorkingTransport = transports.some(t => t.status === 'configured');
  res.status(hasWorkingTransport ? 200 : 503).json({
    status: hasWorkingTransport ? 'ok' : 'error',
    transports
  });
});

// ============================================================
// ADMIN MESSAGING SYSTEM
// ============================================================

// GET /api/admin/messages — list conversations (grouped by member)
app.get('/api/admin/messages', requireAdminAuth, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT
        m.receiver_id AS member_id,
        mem.name AS member_name,
        mem.email AS member_email,
        MAX(m.created_at) AS last_message_at,
        (SELECT body FROM messages WHERE receiver_id = m.receiver_id ORDER BY created_at DESC LIMIT 1) AS last_message,
        (SELECT sender_type FROM messages WHERE receiver_id = m.receiver_id ORDER BY created_at DESC LIMIT 1) AS last_sender_type,
        COUNT(*) FILTER (WHERE m.sender_type = 'member' AND m.is_read = false) AS admin_unread
      FROM messages m
      JOIN members mem ON mem.id = m.receiver_id
      GROUP BY m.receiver_id, mem.name, mem.email
      ORDER BY last_message_at DESC
    `);
    res.json({ success: true, conversations: result.rows });
  } catch (err) {
    console.error('[Admin Messages] List error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to load conversations.' });
  }
});

// GET /api/admin/messages/unread-count — count of unread member→admin messages
app.get('/api/admin/messages/unread-count', requireAdminAuth, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT COUNT(*) AS count FROM messages WHERE sender_type = 'member' AND is_read = false`
    );
    res.json({ success: true, count: parseInt(result.rows[0].count) });
  } catch (err) {
    console.error('[Admin Messages] Unread count error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to get unread count.' });
  }
});

// GET /api/admin/messages/:memberId — get thread with a member + mark member→admin as read
app.get('/api/admin/messages/:memberId', requireAdminAuth, async (req, res) => {
  try {
    const { memberId } = req.params;
    const memberResult = await pool.query(
      'SELECT id, name, email FROM members WHERE id = $1', [memberId]
    );
    if (memberResult.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Member not found.' });
    }
    // Mark member→admin messages as read by admin
    await pool.query(
      `UPDATE messages SET is_read = true WHERE receiver_id = $1 AND sender_type = 'member' AND is_read = false`,
      [memberId]
    );
    const messages = await pool.query(
      `SELECT * FROM messages WHERE receiver_id = $1 ORDER BY created_at ASC`,
      [memberId]
    );
    res.json({ success: true, member: memberResult.rows[0], messages: messages.rows });
  } catch (err) {
    console.error('[Admin Messages] Thread error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to load thread.' });
  }
});

// POST /api/admin/messages — send message to a member
app.post('/api/admin/messages', requireAdminAuth, async (req, res) => {
  try {
    const { member_id, subject, body } = req.body;
    if (!member_id || !body) {
      return res.status(400).json({ success: false, message: 'member_id and body are required.' });
    }
    const memberResult = await pool.query(
      'SELECT id, name, email FROM members WHERE id = $1', [member_id]
    );
    if (memberResult.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Member not found.' });
    }
    const member = memberResult.rows[0];
    // Save to DB
    const msgResult = await pool.query(
      `INSERT INTO messages (sender_type, sender_id, receiver_id, subject, body, is_read)
       VALUES ('admin', NULL, $1, $2, $3, false) RETURNING *`,
      [member_id, subject || null, body]
    );
    // Send email notification
    const firstName = member.name ? member.name.split(' ')[0] : 'there';
    sendEmail({
      to: member.email,
      subject: subject || 'Message from the FlipLane Team',
      html: `
        <div style="font-family:'DM Sans',Arial,sans-serif;max-width:560px;margin:0 auto;background:#0a0a0a;color:#fff;padding:40px 32px;border-radius:12px;">
          <div style="margin-bottom:24px;font-size:1.4rem;font-weight:700;">Flip<span style="color:#00e676">Lane</span></div>
          <h2 style="font-size:1.3rem;font-weight:700;margin-bottom:12px;">${subject || 'Message from the FlipLane Team'}</h2>
          <p style="color:#a0a0a0;font-size:0.95rem;margin-bottom:16px;">Hey ${firstName},</p>
          <div style="background:#161616;border-radius:8px;padding:18px 20px;margin-bottom:24px;font-size:1rem;line-height:1.7;color:#fff;white-space:pre-wrap;">${body}</div>
          <p style="color:#666;font-size:0.85rem;">Reply at <a href="https://fliplane.net/byrddawgsos" style="color:#00e676;">fliplane.net/byrddawgsos</a> → Messages tab</p>
          <hr style="border:none;border-top:1px solid #222;margin:24px 0;">
          <p style="color:#444;font-size:0.75rem;">FlipLane · The AI-Powered Used Car Co-op</p>
        </div>
      `,
      tag: 'admin-direct-message'
    }).catch(err => console.error('[Admin Messages] Email error:', err.message));

    console.log(`[Admin Messages] Sent to member ${member_id} (${member.email})`);
    res.json({ success: true, message: msgResult.rows[0] });
  } catch (err) {
    console.error('[Admin Messages] Send error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to send message.' });
  }
});

// ============================================================
// ADMIN ANNOUNCEMENTS
// ============================================================

// GET /api/admin/announcements — list all announcements
app.get('/api/admin/announcements', requireAdminAuth, async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM announcements ORDER BY created_at DESC');
    res.json({ success: true, announcements: result.rows });
  } catch (err) {
    console.error('[Admin Announcements] List error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to load announcements.' });
  }
});

// POST /api/admin/announcements — create announcement + send to all active members + approved affiliates
app.post('/api/admin/announcements', requireAdminAuth, async (req, res) => {
  try {
    const { title, body } = req.body;
    if (!title || !body) {
      return res.status(400).json({ success: false, message: 'title and body are required.' });
    }
    // Get all active members
    const activeMembers = await pool.query(
      `SELECT id, name, email FROM members WHERE status IN ('active', 'approved') AND email IS NOT NULL`
    );
    // Get all approved affiliates
    const approvedAffiliates = await pool.query(
      `SELECT id, name, email FROM affiliate_signups WHERE status = 'approved' AND email IS NOT NULL`
    );
    const recipientCount = activeMembers.rows.length + approvedAffiliates.rows.length;
    // Save announcement
    const result = await pool.query(
      `INSERT INTO announcements (title, body, recipient_count) VALUES ($1, $2, $3) RETURNING *`,
      [title, body, recipientCount]
    );
    const announcement = result.rows[0];
    const appUrl = process.env.APP_URL || 'https://flipl.polsia.app';
    // Send emails async — fire and forget
    (async () => {
      let sent = 0;

      // Email members
      for (const member of activeMembers.rows) {
        const firstName = member.name ? member.name.split(' ')[0] : 'there';
        try {
          await sendEmail({
            to: member.email,
            subject: `📢 ${title}`,
            html: `
              <div style="font-family:'DM Sans',Arial,sans-serif;max-width:560px;margin:0 auto;background:#0a0a0a;color:#fff;padding:40px 32px;border-radius:12px;">
                <div style="margin-bottom:24px;font-size:1.4rem;font-weight:700;">Flip<span style="color:#00e676">Lane</span></div>
                <div style="display:inline-block;background:rgba(0,230,118,0.1);color:#00e676;font-size:11px;font-weight:700;letter-spacing:1px;text-transform:uppercase;padding:4px 10px;border-radius:4px;margin-bottom:16px;">📢 Announcement</div>
                <h2 style="font-size:1.3rem;font-weight:700;margin:0 0 16px;">${title}</h2>
                <p style="color:#a0a0a0;font-size:0.95rem;margin-bottom:16px;">Hey ${firstName},</p>
                <div style="background:#161616;border-radius:8px;padding:18px 20px;margin-bottom:24px;font-size:1rem;line-height:1.7;color:#fff;white-space:pre-wrap;">${body}</div>
                <p style="color:#666;font-size:0.85rem;">View in your dashboard: <a href="https://fliplane.net/byrddawgsos" style="color:#00e676;">fliplane.net/byrddawgsos</a></p>
                <hr style="border:none;border-top:1px solid #222;margin:24px 0;">
                <p style="color:#444;font-size:0.75rem;">FlipLane · The AI-Powered Used Car Co-op</p>
              </div>
            `,
            tag: 'announcement',
            listUnsubscribe: true
          });
          sent++;
        } catch (e) {
          console.error(`[Announcements] Email failed for member ${member.email}:`, e.message);
        }
      }

      // Email approved affiliates
      for (const affiliate of approvedAffiliates.rows) {
        const firstName = affiliate.name ? affiliate.name.split(' ')[0] : 'there';
        try {
          await sendEmail({
            to: affiliate.email,
            subject: `📢 ${title}`,
            html: `
              <div style="font-family:'DM Sans',Arial,sans-serif;max-width:560px;margin:0 auto;background:#0a0a0a;color:#fff;padding:40px 32px;border-radius:12px;">
                <div style="margin-bottom:24px;font-size:1.4rem;font-weight:700;">Flip<span style="color:#00e676">Lane</span></div>
                <div style="display:inline-block;background:rgba(0,230,118,0.1);color:#00e676;font-size:11px;font-weight:700;letter-spacing:1px;text-transform:uppercase;padding:4px 10px;border-radius:4px;margin-bottom:16px;">📢 Announcement</div>
                <h2 style="font-size:1.3rem;font-weight:700;margin:0 0 16px;">${title}</h2>
                <p style="color:#a0a0a0;font-size:0.95rem;margin-bottom:16px;">Hey ${firstName},</p>
                <div style="background:#161616;border-radius:8px;padding:18px 20px;margin-bottom:24px;font-size:1rem;line-height:1.7;color:#fff;white-space:pre-wrap;">${body}</div>
                <p style="color:#666;font-size:0.85rem;">View in your affiliate dashboard: <a href="${appUrl}/affiliateos" style="color:#00e676;">AffiliateOS Dashboard</a></p>
                <hr style="border:none;border-top:1px solid #222;margin:24px 0;">
                <p style="color:#444;font-size:0.75rem;">FlipLane · The AI-Powered Used Car Co-op</p>
              </div>
            `,
            tag: 'announcement',
            listUnsubscribe: true
          });
          sent++;
        } catch (e) {
          console.error(`[Announcements] Email failed for affiliate ${affiliate.email}:`, e.message);
        }
      }

      console.log(`[Announcements] Sent to ${sent}/${recipientCount} recipients (${activeMembers.rows.length} members + ${approvedAffiliates.rows.length} affiliates)`);
    })();

    res.json({ success: true, announcement, recipient_count: recipientCount, member_count: activeMembers.rows.length, affiliate_count: approvedAffiliates.rows.length });
  } catch (err) {
    console.error('[Admin Announcements] Create error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to create announcement.' });
  }
});

// DELETE /api/admin/announcements/:id — delete announcement
app.delete('/api/admin/announcements/:id', requireAdminAuth, async (req, res) => {
  try {
    const { id } = req.params;
    await pool.query('DELETE FROM announcements WHERE id = $1', [id]);
    res.json({ success: true });
  } catch (err) {
    console.error('[Admin Announcements] Delete error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to delete announcement.' });
  }
});

// ============================================================
// MEMBER MESSAGING (ByrddawgsOS / AffiliateOS)
// ============================================================

// GET /api/member/messages?email= — get thread for a member + mark admin→member as read
app.get('/api/member/messages', async (req, res) => {
  try {
    const { email } = req.query;
    if (!email) return res.status(400).json({ success: false, message: 'Email required.' });
    const memberResult = await pool.query(
      "SELECT id FROM members WHERE LOWER(email) = LOWER($1) AND status IN ('active', 'approved')",
      [email.trim()]
    );
    if (memberResult.rows.length === 0) {
      return res.status(403).json({ success: false, message: 'Member not found or not active.' });
    }
    const memberId = memberResult.rows[0].id;
    // Mark admin→member messages as read
    await pool.query(
      `UPDATE messages SET is_read = true WHERE receiver_id = $1 AND sender_type = 'admin' AND is_read = false`,
      [memberId]
    );
    // Get thread
    const messages = await pool.query(
      `SELECT * FROM messages WHERE receiver_id = $1 ORDER BY created_at ASC`,
      [memberId]
    );
    res.json({ success: true, messages: messages.rows });
  } catch (err) {
    console.error('[Member Messages] Get error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to load messages.' });
  }
});

// POST /api/member/messages/reply — member sends message to admin
app.post('/api/member/messages/reply', async (req, res) => {
  try {
    const { email, body } = req.body;
    if (!email || !body) return res.status(400).json({ success: false, message: 'email and body required.' });
    const memberResult = await pool.query(
      "SELECT id, name FROM members WHERE LOWER(email) = LOWER($1) AND status IN ('active', 'approved')",
      [email.trim()]
    );
    if (memberResult.rows.length === 0) {
      return res.status(403).json({ success: false, message: 'Member not found.' });
    }
    const member = memberResult.rows[0];
    await pool.query(
      `INSERT INTO messages (sender_type, sender_id, receiver_id, subject, body, is_read)
       VALUES ('member', $1, $1, 'Member Reply', $2, false)`,
      [member.id, body]
    );
    // Notify admin
    sendEmail({
      to: 'win@fliplane.net',
      subject: `💬 Member Reply: ${member.name || email}`,
      html: `
        <div style="font-family:Arial,sans-serif;max-width:500px;padding:24px;background:#f9f9f9;border-radius:8px;">
          <h3>New member reply from ${member.name || email}</h3>
          <p><strong>Member:</strong> ${member.name || email} (${email})</p>
          <div style="background:#fff;border:1px solid #e0e0e0;border-radius:6px;padding:16px;margin-top:12px;white-space:pre-wrap;">${body}</div>
          <p style="margin-top:12px;font-size:12px;color:#888;">Reply in admin: <a href="https://fliplane.net/admin">fliplane.net/admin</a> → Messages tab</p>
        </div>
      `,
      tag: 'member-reply'
    }).catch(err => console.error('[Member Messages] Admin notify error:', err.message));
    res.json({ success: true });
  } catch (err) {
    console.error('[Member Messages] Reply error:', err.message);
    res.status(500).json({ success: false, message: 'Failed to send.' });
  }
});

// GET /api/member/messages/unread-count?email= — unread admin→member messages
app.get('/api/member/messages/unread-count', async (req, res) => {
  try {
    const { email } = req.query;
    if (!email) return res.json({ success: true, count: 0 });
    const memberResult = await pool.query(
      "SELECT id FROM members WHERE LOWER(email) = LOWER($1) AND status IN ('active', 'approved')",
      [email.trim()]
    );
    if (memberResult.rows.length === 0) return res.json({ success: true, count: 0 });
    const memberId = memberResult.rows[0].id;
    const result = await pool.query(
      `SELECT COUNT(*) AS count FROM messages WHERE receiver_id = $1 AND sender_type = 'admin' AND is_read = false`,
      [memberId]
    );
    res.json({ success: true, count: parseInt(result.rows[0].count) });
  } catch (err) {
    console.error('[Member Messages] Unread count error:', err.message);
    res.json({ success: true, count: 0 });
  }
});

// GET /api/announcements — all announcements (public, for member dashboards)
app.get('/api/announcements', async (req, res) => {
  try {
    const result = await pool.query('SELECT id, title, body, created_at FROM announcements ORDER BY created_at DESC LIMIT 50');
    res.json({ success: true, announcements: result.rows });
  } catch (err) {
    console.error('[Announcements] Public list error:', err.message);
    res.json({ success: true, announcements: [] });
  }
});

// ============================================================
// NEWSLETTER SUBSCRIBE / UNSUBSCRIBE
// ============================================================

const NEWSLETTER_SECRET = process.env.NEWSLETTER_SECRET || process.env.JWT_SECRET || 'REDACTED';

function generateUnsubscribeToken(email) {
  return crypto.createHmac('sha256', NEWSLETTER_SECRET)
    .update(email.toLowerCase().trim())
    .digest('hex')
    .slice(0, 32);
}

// POST /api/newsletter/subscribe
app.post('/api/newsletter/subscribe', async (req, res) => {
  try {
    const { email, name, source } = req.body || {};
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({ success: false, message: 'Valid email required.' });
    }
    const cleanEmail = email.toLowerCase().trim();
    const cleanSource = source || 'homepage';
    const cleanName = (name || '').trim() || null;

    await pool.query(`
      INSERT INTO newsletter_subscribers (email, name, source, status, signup_date, created_at)
      VALUES ($1, $2, $3, 'active', NOW(), NOW())
      ON CONFLICT (email) DO UPDATE SET
        status = CASE WHEN newsletter_subscribers.status = 'unsubscribed' THEN 'active' ELSE newsletter_subscribers.status END,
        unsubscribed_at = CASE WHEN newsletter_subscribers.status = 'unsubscribed' THEN NULL ELSE newsletter_subscribers.unsubscribed_at END,
        name = COALESCE(EXCLUDED.name, newsletter_subscribers.name)
    `, [cleanEmail, cleanName, cleanSource]);

    console.log(`[Newsletter] ✅ Subscribed: ${cleanEmail} (source: ${cleanSource})`);
    return res.json({ success: true, message: "You're subscribed!" });
  } catch (err) {
    console.error('[Newsletter] Subscribe error:', err.message);
    return res.status(500).json({ success: false, message: 'Something went wrong. Please try again.' });
  }
});

// GET /api/newsletter/unsubscribe?email=X&token=Y
app.get('/api/newsletter/unsubscribe', async (req, res) => {
  try {
    const { email, token } = req.query;
    if (!email || !token) {
      return res.redirect('/unsubscribe?status=invalid');
    }
    const expected = generateUnsubscribeToken(email);
    if (token !== expected) {
      return res.redirect('/unsubscribe?status=invalid');
    }
    const cleanEmail = email.toLowerCase().trim();
    await pool.query(`
      UPDATE newsletter_subscribers
      SET status = 'unsubscribed', unsubscribed_at = NOW()
      WHERE LOWER(email) = $1
    `, [cleanEmail]);

    console.log(`[Newsletter] 🔕 Unsubscribed: ${cleanEmail}`);
    return res.redirect('/unsubscribe?status=success');
  } catch (err) {
    console.error('[Newsletter] Unsubscribe error:', err.message);
    return res.redirect('/unsubscribe?status=error');
  }
});

// GET /api/admin/newsletter/subscribers — admin view
app.get('/api/admin/newsletter/subscribers', requireAdminAuth, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT id, email, name, source, status, signup_date, unsubscribed_at, created_at
      FROM newsletter_subscribers
      ORDER BY created_at DESC
    `);
    const active = result.rows.filter(r => r.status === 'active').length;
    const unsubbed = result.rows.filter(r => r.status === 'unsubscribed').length;
    return res.json({ success: true, subscribers: result.rows, stats: { total: result.rows.length, active, unsubscribed: unsubbed } });
  } catch (err) {
    console.error('[Newsletter] Admin list error:', err.message);
    return res.status(500).json({ success: false, message: err.message });
  }
});

// ============================================================
// WELCOME VIDEO PAGE — /watch/welcome
// ============================================================
app.get('/watch/welcome', async (req, res) => {
  // Priority: DB setting > env var > empty (shows "coming soon")
  let videoUrl = process.env.WELCOME_VIDEO_URL || '';
  const appUrl = process.env.APP_URL || 'https://flipl.polsia.app';

  try {
    const dbSetting = await pool.query("SELECT value FROM app_settings WHERE key = 'welcome_video_url'");
    if (dbSetting.rows.length > 0 && dbSetting.rows[0].value) {
      videoUrl = dbSetting.rows[0].value;
    }
  } catch (_e) { /* table may not exist yet — fall through */ }

  // Determine if this is a Google Drive file ID (for iframe embed) or a direct URL (for video tag)
  const isGdriveDirect = videoUrl.includes('drive.google.com') || videoUrl.startsWith('gdrive:');
  const gdriveFileId = isGdriveDirect
    ? (videoUrl.match(/\/d\/([a-zA-Z0-9_-]+)/) || videoUrl.match(/id=([a-zA-Z0-9_-]+)/) || [null, videoUrl.replace('gdrive:', '')])[1]
    : null;

  const videoBlock = !videoUrl
    ? `<div class="no-video">
         <p style="font-size:1.1rem;margin-bottom:8px;">🎬 Video coming soon</p>
         <p>Your welcome overview is being prepared. Check back shortly.</p>
       </div>`
    : gdriveFileId
      ? `<div class="gdrive-wrap">
           <iframe src="https://drive.google.com/file/d/${gdriveFileId}/preview"
             width="100%" height="100%" frameborder="0" allowfullscreen
             allow="autoplay; fullscreen"
             style="border:0;display:block;width:100%;aspect-ratio:16/9;"></iframe>
         </div>`
      : `<video controls autoplay playsinline preload="auto">
           <source src="${videoUrl}" type="video/mp4">
           Your browser does not support video playback.
         </video>`;

  res.send(`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Welcome to FlipLane — Your Partner Overview</title>
  <meta property="og:title" content="Welcome to FlipLane — Your Partner Overview">
  <meta property="og:description" content="Watch your welcome overview to learn how to run your first deal.">
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { background: #0a0a0a; color: #fff; font-family: 'DM Sans', Arial, sans-serif; min-height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 24px; }
    .logo { font-size: 1.6rem; font-weight: 700; margin-bottom: 32px; }
    .logo span { color: #00e676; }
    .container { max-width: 720px; width: 100%; }
    h1 { font-size: 1.5rem; font-weight: 700; margin-bottom: 8px; text-align: center; }
    .subtitle { color: #a0a0a0; font-size: 0.95rem; text-align: center; margin-bottom: 28px; line-height: 1.6; }
    .video-wrap { background: #111; border-radius: 14px; overflow: hidden; border: 1px solid #1e3a52; margin-bottom: 32px; position: relative; }
    .gdrive-wrap { background: #000; border-radius: 14px; overflow: hidden; border: 1px solid #1e3a52; margin-bottom: 32px; }
    video { width: 100%; display: block; max-height: 80vh; background: #000; }
    .no-video { padding: 60px 24px; text-align: center; color: #666; }
    .cta { display: inline-block; padding: 16px 32px; background: #00e676; border-radius: 10px; color: #000; font-weight: 700; font-size: 1rem; text-decoration: none; margin: 0 auto; display: block; text-align: center; max-width: 320px; }
    .cta:hover { background: #00c864; }
    .footer { color: #444; font-size: 0.8rem; text-align: center; margin-top: 32px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="logo" style="text-align:center;">Flip<span>Lane</span></div>
    <h1>Welcome to FlipLane 👋</h1>
    <p class="subtitle">Watch this quick overview to get started — how to run your first deal, use your auction access, and make the most of your membership.</p>
    <div class="${isGdriveDirect ? 'gdrive-wrap' : 'video-wrap'}">
      ${videoBlock}
    </div>
    <a href="${appUrl}/dashboard" class="cta">Go to My Dashboard →</a>
    <p class="footer">FlipLane · The AI-Powered Used Car Co-op</p>
  </div>
</body>
</html>`);
});

// ============================================================
// TEMP ADMIN: FETCH META AD VIDEO URLS
// ============================================================
app.get('/api/admin/meta-ad-videos', requireAdminAuth, async (req, res) => {
  const polsiaKey = process.env.POLSIA_API_KEY || process.env.POLSIA_API_TOKEN;
  const results = { polsia_api: null, r2_check: null, note: 'Fetching Meta ad creative video URLs' };
  try {
    // Try Polsia platform API for ads with creatives
    const polsiaEndpoints = [
      'https://polsia.com/api/companies/flipl/ads',
      'https://polsia.com/api/companies/flipl/ads/creatives',
      'https://polsia.com/api/companies/flipl/ads/videos',
      'https://polsia.com/company/flipl/ads',
    ];
    for (const endpoint of polsiaEndpoints) {
      try {
        const r = await axios.get(endpoint, {
          headers: { 'Authorization': `Bearer ${polsiaKey}`, 'x-polsia-key': polsiaKey },
          timeout: 8000
        });
        if (r.status === 200) {
          results.polsia_api = { endpoint, data: r.data };
          break;
        }
      } catch (e) {
        results.polsia_api = { ...results.polsia_api, [endpoint]: `${e.response?.status || e.code}: ${e.message}` };
      }
    }
    // Try known R2 video paths
    const r2Base = 'https://pub-629428d185ca4960a0a73c850d32294b.r2.dev/company_20624';
    const r2Paths = ['ads/clip1.mp4', 'ads/clip2.mp4', 'ads/clip3.mp4', 'videos/welcome.mp4', 'ads/welcome.mp4'];
    const r2Results = [];
    for (const p of r2Paths) {
      try {
        const rr = await axios.head(`${r2Base}/${p}`, { timeout: 5000 });
        r2Results.push({ path: p, status: rr.status, url: `${r2Base}/${p}` });
      } catch (e) {
        r2Results.push({ path: p, status: e.response?.status || 'error', error: e.message });
      }
    }
    results.r2_check = r2Results;
    res.json({ success: true, results });
  } catch (err) {
    res.json({ success: false, error: err.message, results });
  }
});

// ============================================================
// WELCOME VIDEO SYNC — Google Drive → R2 upload
// ============================================================

/**
 * Attempt to download a video from a public Google Drive folder and upload to R2.
 * Returns the R2 public URL on success, null on failure.
 * Uses undici (built-in Node 18) for redirect-aware HTTP requests.
 */
async function syncWelcomeVideoFromDrive(folderId) {
  const FOLDER_ID = folderId || '1Q5-BtWpeCGigXWRbygjxfBIUw9ZSmedx';
  const R2_BASE = 'https://pub-629428d185ca4960a0a73c850d32294b.r2.dev/company_20624';
  const r2UploadUrl = process.env.POLSIA_R2_BASE_URL ? `${process.env.POLSIA_R2_BASE_URL}/upload` : null;

  console.log(`[WelcomeVideo] Starting sync from Google Drive folder: ${FOLDER_ID}`);

  try {
    // Step 1: Try to list files in the folder via Google Drive embedded folder view
    // This works for "Anyone with the link" public folders
    const folderViewUrl = `https://drive.google.com/embeddedfolderview?id=${FOLDER_ID}#list`;
    let folderHtml = '';
    try {
      const resp = await axios.get(folderViewUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; FlipLane/1.0)',
          'Accept': 'text/html'
        },
        timeout: 15000,
        maxRedirects: 5
      });
      folderHtml = resp.data || '';
    } catch (e) {
      console.warn(`[WelcomeVideo] Folder view fetch failed: ${e.message}`);
    }

    // Extract file IDs from the embedded folder view HTML
    // Google Drive embeds file IDs in URLs like /file/d/FILE_ID or id=FILE_ID
    const fileIdPattern = /\/file\/d\/([a-zA-Z0-9_-]{20,})/g;
    const altPattern = /"([a-zA-Z0-9_-]{25,45})"/g;
    const fileIds = new Set();

    let match;
    while ((match = fileIdPattern.exec(folderHtml)) !== null) {
      fileIds.add(match[1]);
    }

    if (fileIds.size === 0) {
      // Try alt extraction pattern (Drive embeds IDs in various attributes)
      const allIds = folderHtml.match(/\/file\/d\/([a-zA-Z0-9_-]{20,})/g) || [];
      allIds.forEach(m => {
        const id = m.replace('/file/d/', '');
        if (id && id.length >= 20) fileIds.add(id);
      });
    }

    console.log(`[WelcomeVideo] Found ${fileIds.size} candidate file IDs in folder`);

    // Step 2: Try to download each file and find a video
    const videoMimeTypes = ['video/mp4', 'video/quicktime', 'video/x-msvideo', 'video/webm'];
    let videoBuffer = null;
    let videoFileId = null;
    let videoMimeType = 'video/mp4';

    for (const fileId of fileIds) {
      try {
        const downloadUrl = `https://drive.google.com/uc?export=download&id=${fileId}&confirm=t`;
        console.log(`[WelcomeVideo] Trying to download file: ${fileId}`);

        const headResp = await axios.head(downloadUrl, {
          headers: { 'User-Agent': 'Mozilla/5.0' },
          timeout: 10000,
          maxRedirects: 5
        });

        const ct = headResp.headers['content-type'] || '';
        if (videoMimeTypes.some(mt => ct.includes(mt.split('/')[1])) || ct.includes('video') || ct.includes('octet-stream')) {
          console.log(`[WelcomeVideo] Found video file: ${fileId} (${ct})`);
          videoFileId = fileId;
          videoMimeType = ct.split(';')[0].trim() || 'video/mp4';
          break;
        }
      } catch (e) {
        console.warn(`[WelcomeVideo] HEAD check failed for ${fileId}: ${e.message}`);
      }
    }

    // Step 3: Download the video if found
    if (videoFileId) {
      try {
        const downloadUrl = `https://drive.google.com/uc?export=download&id=${videoFileId}&confirm=t`;
        console.log(`[WelcomeVideo] Downloading video: ${downloadUrl}`);

        const videoResp = await axios.get(downloadUrl, {
          responseType: 'arraybuffer',
          headers: { 'User-Agent': 'Mozilla/5.0' },
          timeout: 120000, // 2 min for large videos
          maxRedirects: 10
        });

        videoBuffer = Buffer.from(videoResp.data);
        console.log(`[WelcomeVideo] Downloaded ${videoBuffer.length} bytes`);
      } catch (e) {
        console.error(`[WelcomeVideo] Video download failed: ${e.message}`);
        videoBuffer = null;
      }
    }

    // Step 4: Upload to R2
    if (videoBuffer && r2UploadUrl) {
      try {
        const formData = new FormData();
        const filename = `welcome_${Date.now()}.mp4`;
        formData.append('file', videoBuffer, { filename, contentType: 'video/mp4' });

        console.log(`[WelcomeVideo] Uploading ${videoBuffer.length} bytes to R2...`);
        const uploadResp = await axios.post(r2UploadUrl, formData, {
          headers: { ...formData.getHeaders() },
          timeout: 120000
        });

        const r2Url = uploadResp.data?.url || uploadResp.data?.public_url || uploadResp.data?.file_url || null;
        if (r2Url) {
          console.log(`[WelcomeVideo] ✅ R2 upload success: ${r2Url}`);
          return r2Url;
        }
        console.warn('[WelcomeVideo] R2 upload succeeded but no URL in response:', uploadResp.data);
      } catch (e) {
        console.error(`[WelcomeVideo] R2 upload failed: ${e.message}`);
      }
    }

    // Step 5: Fallback — return Google Drive embed URL for the video file
    if (videoFileId) {
      const embedUrl = `gdrive:${videoFileId}`;
      console.log(`[WelcomeVideo] ⚠️ R2 upload failed. Using Google Drive embed fallback: ${embedUrl}`);
      return embedUrl;
    }

    // Step 6: If folder listing failed, try the folder itself as an embed
    if (folderHtml.length > 1000) {
      console.log(`[WelcomeVideo] No video files found but folder is accessible. Needs manual file selection.`);
    } else {
      console.log(`[WelcomeVideo] Could not access Google Drive folder. Folder may require auth.`);
    }

    return null;
  } catch (e) {
    console.error(`[WelcomeVideo] Sync error: ${e.message}`);
    return null;
  }
}

// POST /api/admin/sync-welcome-video — Download from Google Drive and upload to R2
app.post('/api/admin/sync-welcome-video', requireAdminAuth, async (req, res) => {
  const { folderId, fileId, videoUrl: manualUrl } = req.body;

  try {
    let finalUrl = null;

    // Option A: Manual URL provided (direct R2/CDN URL or Google Drive file URL)
    if (manualUrl) {
      finalUrl = manualUrl;
      console.log(`[WelcomeVideo] Manual URL set: ${manualUrl}`);
    }
    // Option B: Specific Google Drive file ID provided
    else if (fileId) {
      // Try to download and upload to R2
      const downloadUrl = `https://drive.google.com/uc?export=download&id=${fileId}&confirm=t`;
      const r2UploadUrl = process.env.POLSIA_R2_BASE_URL ? `${process.env.POLSIA_R2_BASE_URL}/upload` : null;

      if (r2UploadUrl) {
        try {
          const videoResp = await axios.get(downloadUrl, {
            responseType: 'arraybuffer',
            headers: { 'User-Agent': 'Mozilla/5.0' },
            timeout: 120000,
            maxRedirects: 10
          });
          const videoBuffer = Buffer.from(videoResp.data);
          const formData = new FormData();
          formData.append('file', videoBuffer, { filename: `welcome_${Date.now()}.mp4`, contentType: 'video/mp4' });

          const uploadResp = await axios.post(r2UploadUrl, formData, {
            headers: { ...formData.getHeaders() },
            timeout: 120000
          });
          finalUrl = uploadResp.data?.url || uploadResp.data?.public_url || null;
          console.log(`[WelcomeVideo] File ID ${fileId} → R2: ${finalUrl}`);
        } catch (e) {
          console.warn(`[WelcomeVideo] R2 upload failed for fileId ${fileId}: ${e.message}. Using embed fallback.`);
        }
      }
      // Fallback: use Drive embed
      if (!finalUrl) finalUrl = `gdrive:${fileId}`;
    }
    // Option C: Auto-detect from folder
    else {
      finalUrl = await syncWelcomeVideoFromDrive(folderId);
    }

    if (!finalUrl) {
      return res.json({
        success: false,
        message: 'Could not find or download video from Google Drive. The folder may require authentication or have no video files.',
        hint: 'Open the Google Drive folder, right-click a video → Get link → copy the file ID from the URL, then POST with { fileId: "..." } or { videoUrl: "r2-or-direct-url" }'
      });
    }

    // Save to DB
    await pool.query(
      `INSERT INTO app_settings (key, value, updated_at) VALUES ('welcome_video_url', $1, NOW())
       ON CONFLICT (key) DO UPDATE SET value = $1, updated_at = NOW()`,
      [finalUrl]
    );

    // Also update in-process env var so current server instance uses it
    process.env.WELCOME_VIDEO_URL = finalUrl;

    return res.json({
      success: true,
      videoUrl: finalUrl,
      isGdriveEmbed: finalUrl.startsWith('gdrive:'),
      watchPage: `${process.env.APP_URL || 'https://flipl.polsia.app'}/watch/welcome`,
      message: finalUrl.startsWith('gdrive:')
        ? 'Video set via Google Drive embed (R2 upload was unavailable).'
        : 'Video uploaded to R2 and set as welcome video.'
    });
  } catch (err) {
    console.error('[WelcomeVideo] Sync endpoint error:', err.message);
    return res.status(500).json({ success: false, message: err.message });
  }
});

// ============================================================
// MARKET VALUE COMPARATOR
// POST /api/market-value — lookup market price for a vehicle
// GET  /api/market-value/history — member's past lookups
// Sources: NHTSA VIN decode, FRED auto loan rate, Marketcheck (if key set)
// DB-backed price_cache (24h TTL), stores lookups in market_valuations
// ============================================================

// In-memory cache for FRED rate (24h TTL — single national stat, rarely changes)
let _fredCache = null; // { rate, expiresAt }
const FRED_CACHE_TTL = 24 * 60 * 60 * 1000;

async function _fetchFredRate() {
  if (_fredCache && Date.now() < _fredCache.expiresAt) {
    return _fredCache.rate;
  }
  try {
    const fredKey = process.env.FRED_API_KEY || 'DEMO_KEY';
    const url = `https://api.stlouisfed.org/fred/series/observations?series_id=RIFLPBCIANM60NF&api_key=${fredKey}&file_type=json&sort_order=desc&limit=1`;
    const resp = await axios.get(url, { timeout: 6000 });
    const obs = resp.data && resp.data.observations;
    if (obs && obs.length > 0 && obs[0].value !== '.') {
      const rate = parseFloat(obs[0].value);
      _fredCache = { rate, expiresAt: Date.now() + FRED_CACHE_TTL };
      return rate;
    }
  } catch (err) {
    console.warn('[MarketValue] FRED fetch failed:', err.message);
  }
  return null;
}

async function _getNhtsaVehicleInfo(vin) {
  try {
    const url = `https://vpic.nhtsa.dot.gov/api/vehicles/decodevin/${vin}?format=json`;
    const resp = await axios.get(url, { timeout: 8000 });
    if (!resp.data || !resp.data.Results) return null;
    const results = resp.data.Results;
    const get = (variable) => {
      const found = results.find(r => r.Variable === variable && r.Value && r.Value !== 'Not Applicable' && r.Value !== '0');
      return found ? found.Value : null;
    };
    return {
      year: get('Model Year'),
      make: get('Make'),
      model: get('Model'),
      trim: get('Trim'),
      bodyType: get('Body Class'),
      fuelType: get('Fuel Type - Primary'),
      drivetrain: get('Drive Type'),
      cylinders: get('Engine Number of Cylinders'),
      displacement: get('Displacement (L)')
    };
  } catch (err) {
    console.warn('[MarketValue] NHTSA VIN decode failed:', err.message);
    return null;
  }
}

async function _getMarketCheckListings(year, make, model, trim, mileage) {
  const mcKey = process.env.MARKETCHECK_API_KEY;
  if (!mcKey) return null;

  try {
    // Build vehicle key for DB cache check
    const vehicleKey = [year, make, model, trim, Math.round((mileage || 50000) / 20000) * 20000]
      .filter(Boolean).join('_').toLowerCase().replace(/\s+/g, '_');

    // Check DB cache (24h TTL)
    const cacheRow = await pool.query(
      `SELECT avg_price, listing_count, price_low, price_high, last_updated FROM price_cache WHERE vehicle_key = $1`,
      [vehicleKey]
    );
    if (cacheRow.rows.length > 0) {
      const cached = cacheRow.rows[0];
      const age = Date.now() - new Date(cached.last_updated).getTime();
      if (age < 24 * 60 * 60 * 1000) {
        return { avgPrice: cached.avg_price, count: cached.listing_count, priceLow: cached.price_low, priceHigh: cached.price_high, vehicleKey, fromCache: true };
      }
    }

    // Call Marketcheck stats endpoint
    const params = new URLSearchParams({
      api_key: mcKey,
      year,
      make: make.toUpperCase(),
      model: model.toUpperCase()
    });
    if (trim) params.set('trim', trim.toUpperCase());
    if (mileage) { params.set('miles_min', Math.max(0, mileage - 20000)); params.set('miles_max', mileage + 20000); }
    const mcUrl = `https://marketcheck-prod.apigee.net/v2/stats/car?${params.toString()}`;
    const resp = await axios.get(mcUrl, { timeout: 10000, headers: { 'Accept': 'application/json' } });
    const data = resp.data;

    if (!data || !data.avg) return null;

    const result = {
      avgPrice: Math.round(data.avg),
      count: data.count || 0,
      priceLow: data.min ? Math.round(data.min) : Math.round(data.avg * 0.85),
      priceHigh: data.max ? Math.round(data.max) : Math.round(data.avg * 1.15),
      vehicleKey,
      fromCache: false
    };

    // Upsert cache
    await pool.query(
      `INSERT INTO price_cache (vehicle_key, avg_price, listing_count, price_low, price_high, source, last_updated)
       VALUES ($1, $2, $3, $4, $5, 'marketcheck', NOW())
       ON CONFLICT (vehicle_key) DO UPDATE SET avg_price=$2, listing_count=$3, price_low=$4, price_high=$5, source='marketcheck', last_updated=NOW()`,
      [vehicleKey, result.avgPrice, result.count, result.priceLow, result.priceHigh]
    );

    return result;
  } catch (err) {
    console.warn('[MarketValue] Marketcheck fetch failed:', err.message);
    return null;
  }
}

function _estimateMarketRange(year, mileage, condition) {
  // Simple fallback estimation model based on vehicle age + mileage + condition
  // Returns { low, mid, high } in dollars (rough ballpark for common used vehicles)
  const currentYear = new Date().getFullYear();
  const age = currentYear - parseInt(year || currentYear);
  const miles = parseInt(mileage) || 60000;

  // Base depreciation model: avg $35k new car depreciates ~15%/yr, slower after year 5
  let base = 35000;
  const depreciationYears = Math.min(age, 5);
  const extraYears = Math.max(0, age - 5);
  base = base * Math.pow(0.85, depreciationYears) * Math.pow(0.94, extraYears);

  // Mileage adjustment: avg 12k/yr = standard; 10k above/below = ±3%
  const expectedMiles = age * 12000;
  const mileageDelta = (miles - expectedMiles) / 10000;
  base = base * Math.pow(0.97, mileageDelta);

  // Condition multiplier
  const condMultiplier = { excellent: 1.10, good: 1.00, fair: 0.85, poor: 0.68 };
  base = base * (condMultiplier[condition] || 1.0);
  base = Math.max(1500, Math.round(base / 100) * 100);

  return {
    low: Math.round(base * 0.88 / 100) * 100,
    mid: base,
    high: Math.round(base * 1.12 / 100) * 100
  };
}

function _calcDealScore(targetPrice, marketMid) {
  if (!targetPrice || !marketMid || marketMid <= 0) return null;
  const ratio = targetPrice / marketMid;
  if (ratio < 0.85) return 'great_deal';
  if (ratio < 0.95) return 'good_deal';
  if (ratio < 1.05) return 'fair';
  return 'overpriced';
}

// POST /api/market-value
app.post('/api/market-value', async (req, res) => {
  try {
    const { vin, year, make, model, trim, mileage, condition, target_price, member_email } = req.body;

    if (!vin && (!year || !make || !model)) {
      return res.status(400).json({ success: false, message: 'Provide either a VIN or Year + Make + Model.' });
    }
    if (condition && !['excellent', 'good', 'fair', 'poor'].includes(condition)) {
      return res.status(400).json({ success: false, message: 'Invalid condition. Use: excellent, good, fair, poor.' });
    }

    const dataSources = [];
    let vehicleInfo = { year, make, model, trim };
    let memberId = null;

    // Resolve member
    if (member_email) {
      const mRow = await pool.query(
        "SELECT id FROM members WHERE LOWER(email) = LOWER($1) AND status IN ('active', 'approved')",
        [member_email]
      );
      if (mRow.rows.length > 0) memberId = mRow.rows[0].id;
    }

    // NHTSA VIN decode
    if (vin && vin.length === 17) {
      const nhtsaData = await _getNhtsaVehicleInfo(vin.toUpperCase());
      if (nhtsaData) {
        vehicleInfo = { ...vehicleInfo, ...nhtsaData };
        dataSources.push('nhtsa');
      }
    }

    const finalYear = vehicleInfo.year || year;
    const finalMake = vehicleInfo.make || make;
    const finalModel = vehicleInfo.model || model;
    const finalTrim = vehicleInfo.trim || trim;

    if (!finalYear || !finalMake || !finalModel) {
      return res.status(400).json({ success: false, message: 'Could not determine vehicle year/make/model. Please provide them manually.' });
    }

    // Marketcheck listings
    const mcData = await _getMarketCheckListings(finalYear, finalMake, finalModel, finalTrim, mileage);
    let estimatedLow, estimatedMid, estimatedHigh, similarCount, similarAvg;
    let limitedData = false;

    if (mcData && mcData.avgPrice) {
      similarCount = mcData.count;
      similarAvg = mcData.avgPrice;
      estimatedLow = mcData.priceLow;
      estimatedMid = mcData.avgPrice;
      estimatedHigh = mcData.priceHigh;
      if (!mcData.fromCache) dataSources.push('marketcheck');
    } else {
      // Fallback estimation
      const est = _estimateMarketRange(finalYear, mileage, condition);
      estimatedLow = est.low;
      estimatedMid = est.mid;
      estimatedHigh = est.high;
      similarCount = null;
      similarAvg = null;
      limitedData = true;
      dataSources.push('estimated');
    }

    // FRED auto loan rate
    const avgLoanRate = await _fetchFredRate();
    if (avgLoanRate !== null) dataSources.push('fred');

    // Deal score
    const dealScore = _calcDealScore(target_price, estimatedMid);

    // Save lookup to DB
    let valuationId = null;
    try {
      const dbRes = await pool.query(
        `INSERT INTO market_valuations
          (member_id, vin, year, make, model, trim, mileage, condition,
           estimated_low, estimated_mid, estimated_high,
           similar_listings_count, similar_avg_price, target_price,
           deal_score, avg_loan_rate, data_sources)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17)
         RETURNING id`,
        [
          memberId, vin || null, finalYear, finalMake, finalModel, finalTrim || null,
          mileage || null, condition || null,
          estimatedLow, estimatedMid, estimatedHigh,
          similarCount, similarAvg,
          target_price || null, dealScore, avgLoanRate,
          JSON.stringify(dataSources)
        ]
      );
      valuationId = dbRes.rows[0].id;
    } catch (dbErr) {
      console.error('[MarketValue] DB save error:', dbErr.message);
    }

    const dealScoreLabel = {
      great_deal: { label: 'Great Deal 🎯', color: '#22c55e' },
      good_deal: { label: 'Good Deal ✅', color: '#84cc16' },
      fair: { label: 'Fair Market 🤝', color: '#f59e0b' },
      overpriced: { label: 'Overpriced ⚠️', color: '#ef4444' }
    };

    return res.json({
      success: true,
      valuation_id: valuationId,
      vehicle: {
        year: finalYear,
        make: finalMake,
        model: finalModel,
        trim: finalTrim || null,
        vin: vin || null,
        body_type: vehicleInfo.bodyType || null
      },
      market: {
        estimated_low: estimatedLow,
        estimated_mid: estimatedMid,
        estimated_high: estimatedHigh,
        similar_listings_count: similarCount,
        similar_avg_price: similarAvg,
        limited_data: limitedData
      },
      deal_score: dealScore ? {
        score: dealScore,
        label: dealScoreLabel[dealScore]?.label,
        color: dealScoreLabel[dealScore]?.color,
        target_price: target_price || null,
        market_mid: estimatedMid
      } : null,
      financing: {
        avg_loan_rate: avgLoanRate,
        note: avgLoanRate ? `Current avg 60-mo auto loan rate: ${avgLoanRate}%` : null
      },
      data_sources: dataSources
    });
  } catch (err) {
    console.error('[MarketValue] Lookup error:', err.message);
    return res.status(500).json({ success: false, message: 'Market value lookup failed. Please try again.' });
  }
});

// GET /api/market-value/history — member's last 10 lookups
app.get('/api/market-value/history', async (req, res) => {
  try {
    const { email } = req.query;
    if (!email) return res.status(400).json({ success: false, message: 'Email required.' });

    const memberRow = await pool.query(
      "SELECT id FROM members WHERE LOWER(email) = LOWER($1) AND status IN ('active', 'approved')",
      [email]
    );
    if (memberRow.rows.length === 0) {
      return res.status(403).json({ success: false, message: 'Member not found or not active.' });
    }
    const memberId = memberRow.rows[0].id;

    const rows = await pool.query(
      `SELECT id, vin, year, make, model, trim, mileage, condition,
              estimated_low, estimated_mid, estimated_high, deal_score, created_at
       FROM market_valuations WHERE member_id = $1 ORDER BY created_at DESC LIMIT 10`,
      [memberId]
    );

    return res.json({ success: true, history: rows.rows });
  } catch (err) {
    console.error('[MarketValue] History error:', err.message);
    return res.status(500).json({ success: false, message: 'Failed to load history.' });
  }
});

// ============================================================
// ACV CALCULATOR
// POST /api/acv   — calculate Actual Cash Value for a vehicle
// GET  /api/acv/history — member's last 20 ACV lookups
//
// ACV = Replacement Cost − Depreciation
// Sources: NHTSA VIN decode, proprietary depreciation model,
//          FRED auto loan rate, Marketcheck comps (if key set)
// ============================================================

// Base MSRP estimates by vehicle category (approximate average new prices)
// Used as the "replacement cost" starting point for depreciation math
const ACV_BASE_MSRP_BY_CATEGORY = {
  // Luxury brands get higher base
  luxury: { sedan: 55000, suv: 65000, truck: 70000, van: 55000, coupe: 58000, default: 58000 },
  // Trucks/SUVs hold value better — higher base + slower depreciation
  truck_suv: { sedan: 35000, suv: 42000, truck: 48000, van: 38000, coupe: 38000, default: 40000 },
  // EVs have unique depreciation (faster in early years, slower later)
  ev: { sedan: 52000, suv: 58000, truck: 65000, van: 52000, coupe: 54000, default: 54000 },
  // Standard/economy
  standard: { sedan: 28000, suv: 34000, truck: 38000, van: 32000, coupe: 30000, default: 30000 }
};

const ACV_LUXURY_MAKES = ['MERCEDES', 'MERCEDES-BENZ', 'BMW', 'AUDI', 'LEXUS', 'ACURA', 'INFINITI',
  'CADILLAC', 'LINCOLN', 'VOLVO', 'JAGUAR', 'LAND ROVER', 'PORSCHE', 'MASERATI', 'BENTLEY',
  'ROLLS-ROYCE', 'ASTON MARTIN', 'FERRARI', 'LAMBORGHINI', 'GENESIS'];
const ACV_EV_MAKES = ['TESLA', 'RIVIAN', 'LUCID', 'POLESTAR'];
const ACV_EV_MODELS = ['BOLT', 'LEAF', 'ID.4', 'MACH-E', 'LIGHTNING', 'IONIQ', 'EV6', 'NIRO'];
const ACV_TRUCK_SUV_MAKES_MODELS = ['F-150', 'F150', 'SILVERADO', 'RAM', 'TUNDRA', 'TACOMA', 'RANGER',
  'COLORADO', 'CANYON', 'RIDGELINE', 'FRONTIER', 'TITAN', 'SIERRA', 'EXPEDITION', 'SEQUOIA',
  'TAHOE', 'SUBURBAN', 'YUKON', 'NAVIGATOR', 'WRANGLER', 'GLADIATOR', '4RUNNER', 'LAND CRUISER'];

function _getVehicleCategory(make, model, bodyType, fuelType) {
  const makeUp = (make || '').toUpperCase();
  const modelUp = (model || '').toUpperCase();
  const bodyUp = (bodyType || '').toUpperCase();
  const fuelUp = (fuelType || '').toUpperCase();

  if (ACV_LUXURY_MAKES.includes(makeUp)) return 'luxury';
  if (ACV_EV_MAKES.includes(makeUp)) return 'ev';
  if (fuelUp.includes('ELECTRIC') || ACV_EV_MODELS.some(m => modelUp.includes(m))) return 'ev';
  if (ACV_TRUCK_SUV_MAKES_MODELS.some(m => modelUp.includes(m))) return 'truck_suv';
  if (bodyUp.includes('TRUCK') || bodyUp.includes('PICKUP')) return 'truck_suv';
  if (bodyUp.includes('SUV') || bodyUp.includes('UTILITY')) return 'truck_suv';
  return 'standard';
}

function _getBodyBucket(bodyType) {
  const b = (bodyType || '').toUpperCase();
  if (b.includes('TRUCK') || b.includes('PICKUP')) return 'truck';
  if (b.includes('VAN') || b.includes('MINIVAN')) return 'van';
  if (b.includes('SUV') || b.includes('UTILITY') || b.includes('CROSSOVER')) return 'suv';
  if (b.includes('COUPE') || b.includes('CONVERTIBLE')) return 'coupe';
  return 'sedan';
}

function _estimateBaseMsrp(year, make, model, bodyType, fuelType, category) {
  const bucket = _getBodyBucket(bodyType);
  const catPrices = ACV_BASE_MSRP_BY_CATEGORY[category] || ACV_BASE_MSRP_BY_CATEGORY.standard;
  const baseMsrp = catPrices[bucket] || catPrices.default;

  // Adjust base MSRP slightly for vehicle age at time of manufacture
  // Older vehicles had lower real MSRP — approximate with 2.5% annual inflation rollback
  const currentYear = new Date().getFullYear();
  const vehicleYear = parseInt(year) || currentYear;
  const msrpYear = vehicleYear;
  const msrpInflationAdj = Math.pow(1.025, currentYear - msrpYear);
  return Math.round(baseMsrp / msrpInflationAdj);
}

// ACV depreciation curves per category
// Returns cumulative depreciation factor after N years (0-1, where 1 = full value)
function _getDepreciationFactor(age, category) {
  let value = 1.0;
  const curve = category === 'luxury'
    ? [0.18, 0.14, 0.12, 0.10, 0.09, 0.08, 0.07, 0.06, 0.05, 0.05] // luxury depreciates faster early
    : category === 'ev'
    ? [0.22, 0.16, 0.12, 0.10, 0.08, 0.07, 0.06, 0.05, 0.04, 0.04] // EVs: faster year 1 due to battery uncertainty
    : category === 'truck_suv'
    ? [0.15, 0.12, 0.09, 0.08, 0.07, 0.06, 0.05, 0.05, 0.04, 0.04] // trucks hold value better
    : [0.20, 0.15, 0.10, 0.10, 0.10, 0.07, 0.07, 0.06, 0.05, 0.05]; // standard
  for (let i = 0; i < Math.min(age, 10); i++) {
    value *= (1 - curve[i]);
  }
  // Beyond 10 years, 4% per year
  if (age > 10) {
    value *= Math.pow(0.96, age - 10);
  }
  return Math.max(value, 0.03); // floor at 3% of original value
}

function _calcAcv(vehicleInfo, params) {
  const { mileage, condition, titleStatus, accidentHistory, numOwners, category } = params;
  const currentYear = new Date().getFullYear();
  const vehicleYear = parseInt(vehicleInfo.year) || currentYear;
  const age = Math.max(0, currentYear - vehicleYear);

  // Base MSRP
  const baseMsrp = vehicleInfo.baseMsrp || _estimateBaseMsrp(
    vehicleInfo.year, vehicleInfo.make, vehicleInfo.model,
    vehicleInfo.bodyType, vehicleInfo.fuelType, category
  );

  // 1. Age depreciation
  const ageDepFactor = _getDepreciationFactor(age, category);
  const valueAfterAge = Math.round(baseMsrp * ageDepFactor);
  const ageDepAmount = baseMsrp - valueAfterAge;

  // 2. Mileage adjustment
  // Avg 12,000 miles/year. Deviation of 1,000 miles = ±$120 (trucks) or ±$100 (standard)
  const miles = parseInt(mileage) || (age * 12000);
  const expectedMiles = age * 12000;
  const milesDeviation = miles - expectedMiles;
  const perMileAdj = category === 'truck_suv' ? 0.12 : 0.10;
  const mileageAdjAmount = Math.round(-milesDeviation * perMileAdj);
  const valueAfterMileage = Math.round(valueAfterAge + mileageAdjAmount);

  // 3. Condition multiplier
  const conditionMultipliers = { excellent: 1.05, good: 1.00, fair: 0.90, poor: 0.75, salvage: 0.50 };
  const condMult = conditionMultipliers[condition] || 1.00;
  const condAdjAmount = Math.round(valueAfterMileage * (condMult - 1.0));
  const valueAfterCondition = Math.round(valueAfterMileage * condMult);

  // 4. Title status adjustment
  const titleMultipliers = { clean: 1.00, rebuilt: 0.75, salvage: 0.50 };
  const titleMult = titleMultipliers[titleStatus || 'clean'] || 1.00;
  const titleAdjAmount = Math.round(valueAfterCondition * (titleMult - 1.0));
  const valueAfterTitle = Math.round(valueAfterCondition * titleMult);

  // 5. Accident history adjustment
  const accidentMultipliers = { none: 1.00, one: 0.93, multiple: 0.87 };
  const accMult = accidentMultipliers[accidentHistory || 'none'] || 1.00;
  const accidentAdjAmount = Math.round(valueAfterTitle * (accMult - 1.0));
  const valueAfterAccident = Math.round(valueAfterTitle * accMult);

  // 6. Owners adjustment (each additional owner > 1 reduces by ~2%)
  const owners = parseInt(numOwners) || 1;
  const ownersMult = Math.max(0.90, 1 - (Math.max(0, owners - 1) * 0.02));
  const ownersAdjAmount = Math.round(valueAfterAccident * (ownersMult - 1.0));
  const acvMid = Math.max(500, Math.round(valueAfterAccident * ownersMult));

  // Generate low/high range (±8%)
  const rangeSpread = category === 'truck_suv' ? 0.07 : 0.08;
  const acvLow = Math.max(500, Math.round(acvMid * (1 - rangeSpread) / 100) * 100);
  const acvHigh = Math.round(acvMid * (1 + rangeSpread) / 100) * 100;
  const acvMidRounded = Math.round(acvMid / 100) * 100;

  return {
    baseMsrp,
    acvMid: acvMidRounded,
    acvLow,
    acvHigh,
    breakdown: {
      base_msrp: baseMsrp,
      age_years: age,
      age_depreciation: -ageDepAmount,
      value_after_age: valueAfterAge,
      mileage_deviation: milesDeviation,
      mileage_adjustment: mileageAdjAmount,
      value_after_mileage: valueAfterMileage,
      condition: condition || 'good',
      condition_adjustment: condAdjAmount,
      value_after_condition: valueAfterCondition,
      title_status: titleStatus || 'clean',
      title_adjustment: titleAdjAmount,
      value_after_title: valueAfterTitle,
      accident_history: accidentHistory || 'none',
      accident_adjustment: accidentAdjAmount,
      value_after_accident: valueAfterAccident,
      num_owners: owners,
      owners_adjustment: ownersAdjAmount,
      final_acv: acvMidRounded
    }
  };
}

function _calcConfidenceScore(hasVin, nhtsaSuccess, hasMarketcheck, category, age) {
  let points = 0;
  if (hasVin && nhtsaSuccess) points += 3;
  else if (hasVin) points += 1;
  if (hasMarketcheck) points += 3;
  if (age <= 10) points += 1;
  if (category !== 'standard') points += 1; // we have category-specific curves
  if (points >= 6) return 'high';
  if (points >= 3) return 'medium';
  return 'low';
}

// POST /api/acv
app.post('/api/acv', async (req, res) => {
  try {
    const {
      vin, year, make, model, trim, mileage, condition,
      zip_code, title_status, accident_history, num_owners,
      purchase_price, member_email
    } = req.body;

    if (!vin && (!year || !make || !model)) {
      return res.status(400).json({ success: false, message: 'Provide either a VIN or Year + Make + Model.' });
    }
    const validConditions = ['excellent', 'good', 'fair', 'poor', 'salvage'];
    if (condition && !validConditions.includes(condition)) {
      return res.status(400).json({ success: false, message: 'Invalid condition.' });
    }

    let memberId = null;
    if (member_email) {
      const mRow = await pool.query(
        "SELECT id FROM members WHERE LOWER(email) = LOWER($1) AND status IN ('active', 'approved')",
        [member_email]
      );
      if (mRow.rows.length > 0) memberId = mRow.rows[0].id;
    }

    const dataSources = [];
    let vehicleInfo = { year, make, model, trim, bodyType: null, fuelType: null, baseMsrp: null };
    let nhtsaSuccess = false;

    // NHTSA VIN decode
    if (vin && vin.length === 17) {
      const nhtsaData = await _getNhtsaVehicleInfo(vin.toUpperCase());
      if (nhtsaData) {
        vehicleInfo = { ...vehicleInfo, ...nhtsaData };
        nhtsaSuccess = true;
        dataSources.push('nhtsa');
      }
    }

    const finalYear = vehicleInfo.year || year;
    const finalMake = vehicleInfo.make || make;
    const finalModel = vehicleInfo.model || model;
    const finalTrim = vehicleInfo.trim || trim;

    if (!finalYear || !finalMake || !finalModel) {
      return res.status(400).json({ success: false, message: 'Could not determine vehicle year/make/model. Please provide them manually.' });
    }

    // Check ACV cache (24h TTL)
    const cacheKey = [
      finalYear, finalMake, finalModel, finalTrim || '',
      Math.round((parseInt(mileage) || 60000) / 5000) * 5000,
      condition || 'good', title_status || 'clean',
      accident_history || 'none', num_owners || 1
    ].join('|').toLowerCase();

    let cacheHit = null;
    try {
      const cacheRow = await pool.query(
        `SELECT * FROM acv_cache WHERE cache_key = $1 AND last_updated > NOW() - INTERVAL '24 hours'`,
        [cacheKey]
      );
      if (cacheRow.rows.length > 0) cacheHit = cacheRow.rows[0];
    } catch (e) { /* ignore cache errors */ }

    const category = _getVehicleCategory(finalMake, finalModel, vehicleInfo.bodyType, vehicleInfo.fuelType);

    let acvLow, acvMid, acvHigh, baseMsrp, depreciationData, marketData, comparableCount, confidenceScore;

    if (cacheHit) {
      acvLow = cacheHit.acv_low;
      acvMid = cacheHit.acv_mid;
      acvHigh = cacheHit.acv_high;
      baseMsrp = cacheHit.base_msrp;
      depreciationData = cacheHit.depreciation_data;
      marketData = cacheHit.market_data;
      comparableCount = cacheHit.comparable_count;
      confidenceScore = cacheHit.confidence_score;
      dataSources.push('cache');
    } else {
      // Run ACV calculation
      const acvResult = _calcAcv(
        { year: finalYear, make: finalMake, model: finalModel, trim: finalTrim, bodyType: vehicleInfo.bodyType, fuelType: vehicleInfo.fuelType },
        { mileage, condition: condition || 'good', titleStatus: title_status || 'clean', accidentHistory: accident_history || 'none', numOwners: num_owners || 1, category }
      );
      acvLow = acvResult.acvLow;
      acvMid = acvResult.acvMid;
      acvHigh = acvResult.acvHigh;
      baseMsrp = acvResult.baseMsrp;
      depreciationData = acvResult.breakdown;
      dataSources.push('depreciation_model');

      // Marketcheck comps — refine estimate if available
      let hasMarketcheck = false;
      const mcData = await _getMarketCheckListings(finalYear, finalMake, finalModel, finalTrim, mileage);
      if (mcData && mcData.avgPrice) {
        comparableCount = mcData.count;
        // Blend model estimate (60%) with market comps (40%) for refinement
        const blendedMid = Math.round(acvMid * 0.6 + mcData.avgPrice * 0.4);
        const blendSpread = (acvHigh - acvLow) / 2;
        acvMid = Math.round(blendedMid / 100) * 100;
        acvLow = Math.max(500, Math.round((blendedMid - blendSpread) / 100) * 100);
        acvHigh = Math.round((blendedMid + blendSpread) / 100) * 100;
        marketData = { avg_listing: mcData.avgPrice, listing_count: mcData.count, price_low: mcData.priceLow, price_high: mcData.priceHigh };
        if (!mcData.fromCache) dataSources.push('marketcheck');
        hasMarketcheck = true;
      } else {
        marketData = {};
      }

      // FRED rate
      const avgLoanRate = await _fetchFredRate();
      if (avgLoanRate !== null) {
        marketData.avg_loan_rate = avgLoanRate;
        dataSources.push('fred');
      }

      const age = Math.max(0, new Date().getFullYear() - parseInt(finalYear));
      confidenceScore = _calcConfidenceScore(!!(vin && vin.length === 17), nhtsaSuccess, hasMarketcheck, category, age);

      // Cache result
      try {
        await pool.query(
          `INSERT INTO acv_cache (cache_key, acv_low, acv_mid, acv_high, base_msrp, depreciation_data, market_data, comparable_count, confidence_score)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
           ON CONFLICT (cache_key) DO UPDATE SET
             acv_low=$2, acv_mid=$3, acv_high=$4, base_msrp=$5,
             depreciation_data=$6, market_data=$7, comparable_count=$8,
             confidence_score=$9, last_updated=NOW()`,
          [cacheKey, acvLow, acvMid, acvHigh, baseMsrp, JSON.stringify(depreciationData), JSON.stringify(marketData), comparableCount || null, confidenceScore]
        );
      } catch (e) { /* ignore cache save errors */ }
    }

    // Save lookup to DB
    let calcId = null;
    try {
      const dbRes = await pool.query(
        `INSERT INTO acv_calculations
           (member_id, vin, year, make, model, trim, mileage, condition, zip_code,
            title_status, accident_history, num_owners, purchase_price,
            acv_low, acv_mid, acv_high, base_msrp,
            depreciation_data, market_data, comparable_count, confidence_score)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21)
         RETURNING id`,
        [
          memberId, vin || null, parseInt(finalYear) || null,
          finalMake, finalModel, finalTrim || null,
          parseInt(mileage) || null, condition || null, zip_code || null,
          title_status || 'clean', accident_history || 'none', parseInt(num_owners) || 1,
          parseInt(purchase_price) || null,
          acvLow, acvMid, acvHigh, baseMsrp,
          JSON.stringify(depreciationData), JSON.stringify(marketData),
          comparableCount || null, confidenceScore
        ]
      );
      calcId = dbRes.rows[0].id;
    } catch (dbErr) {
      console.error('[ACV] DB save error:', dbErr.message);
    }

    // Build flip opportunity if purchase price provided
    let flipOpportunity = null;
    if (purchase_price && parseInt(purchase_price) > 0) {
      const buyPrice = parseInt(purchase_price);
      const spread = acvMid - buyPrice;
      const spreadPct = acvMid > 0 ? ((spread / acvMid) * 100).toFixed(1) : null;
      flipOpportunity = {
        buy_price: buyPrice,
        acv_mid: acvMid,
        spread,
        spread_pct: spreadPct ? parseFloat(spreadPct) : null,
        verdict: spread >= 3000 ? 'strong' : spread >= 1000 ? 'decent' : spread >= 0 ? 'thin' : 'underwater'
      };
    }

    const confidenceLabels = { high: '✅ High confidence', medium: '🟡 Medium confidence', low: '⚠️ Low confidence — rare vehicle' };

    return res.json({
      success: true,
      calc_id: calcId,
      vehicle: {
        year: finalYear, make: finalMake, model: finalModel, trim: finalTrim || null,
        vin: vin || null, body_type: vehicleInfo.bodyType || null,
        fuel_type: vehicleInfo.fuelType || null, category
      },
      acv: {
        low: acvLow, mid: acvMid, high: acvHigh
      },
      base_msrp: baseMsrp,
      depreciation: depreciationData,
      market: {
        avg_listing: marketData.avg_listing || null,
        listing_count: comparableCount || null,
        avg_loan_rate: marketData.avg_loan_rate || null
      },
      confidence: {
        score: confidenceScore,
        label: confidenceLabels[confidenceScore] || confidenceScore
      },
      flip_opportunity: flipOpportunity,
      data_sources: dataSources
    });
  } catch (err) {
    console.error('[ACV] Calculation error:', err.message);
    return res.status(500).json({ success: false, message: 'ACV calculation failed. Please try again.' });
  }
});

// GET /api/acv/history — member's last 20 ACV calculations
app.get('/api/acv/history', async (req, res) => {
  try {
    const { email } = req.query;
    if (!email) return res.status(400).json({ success: false, message: 'Email required.' });

    const memberRow = await pool.query(
      "SELECT id FROM members WHERE LOWER(email) = LOWER($1) AND status IN ('active', 'approved')",
      [email]
    );
    if (memberRow.rows.length === 0) {
      return res.status(403).json({ success: false, message: 'Member not found or not active.' });
    }
    const memberId = memberRow.rows[0].id;

    const rows = await pool.query(
      `SELECT id, vin, year, make, model, trim, mileage, condition, title_status,
              acv_low, acv_mid, acv_high, confidence_score, purchase_price, created_at
       FROM acv_calculations WHERE member_id = $1 ORDER BY created_at DESC LIMIT 20`,
      [memberId]
    );

    return res.json({ success: true, history: rows.rows });
  } catch (err) {
    console.error('[ACV] History error:', err.message);
    return res.status(500).json({ success: false, message: 'Failed to load ACV history.' });
  }
});

// ============================================================
// CARQUERY API PROXY
// GET /api/carquery?cmd=...&year=...&make=...&model=...
// Proxies to carqueryapi.com, strips JSONP wrapper, returns JSON.
// In-memory cache (24h TTL) + simple rate limiter (60 req/min per IP).
// ============================================================
const _cqCache = new Map(); // key -> { data, expiresAt }
const _cqRateMap = new Map(); // ip -> { count, windowStart }
const CQ_CACHE_TTL = 24 * 60 * 60 * 1000; // 24 hours
const CQ_RATE_LIMIT = 60; // requests per minute
const CQ_RATE_WINDOW = 60 * 1000; // 1 minute

function _cqRateLimitOk(ip) {
  const now = Date.now();
  const entry = _cqRateMap.get(ip);
  if (!entry || now - entry.windowStart > CQ_RATE_WINDOW) {
    _cqRateMap.set(ip, { count: 1, windowStart: now });
    return true;
  }
  entry.count++;
  return entry.count <= CQ_RATE_LIMIT;
}

function _cqStripJsonp(text) {
  // CarQuery returns: ?({...}); or callback({...}); — strip to raw JSON
  const stripped = text.trim().replace(/^[^(]*\(/, '').replace(/\)[\s;]*$/, '');
  return stripped;
}

app.get('/api/carquery', async (req, res) => {
  const ip = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket.remoteAddress || 'unknown';

  if (!_cqRateLimitOk(ip)) {
    return res.status(429).json({ error: 'Rate limit exceeded. Try again in a minute.' });
  }

  const { cmd, year, make, model, model_id } = req.query;
  if (!cmd) return res.status(400).json({ error: 'cmd parameter required' });

  // Build CarQuery URL
  const params = new URLSearchParams({ cmd });
  if (year) params.set('year', year);
  if (make) params.set('make', make);
  if (model) params.set('model', model);
  if (model_id) params.set('model', model_id);

  const cacheKey = params.toString();
  const cached = _cqCache.get(cacheKey);
  if (cached && Date.now() < cached.expiresAt) {
    res.setHeader('X-Cache', 'HIT');
    return res.json(cached.data);
  }

  const cqUrl = `https://www.carqueryapi.com/api/0.3/?${params.toString()}`;

  try {
    const response = await axios.get(cqUrl, {
      timeout: 8000,
      headers: { 'User-Agent': 'FlipLane/1.0 (vehicle-search)' }
    });

    let raw = typeof response.data === 'string' ? response.data : JSON.stringify(response.data);
    // Strip JSONP wrapper if present
    if (raw.trim().startsWith('?') || raw.trim().match(/^[a-zA-Z_][a-zA-Z0-9_]*\s*\(/)) {
      raw = _cqStripJsonp(raw);
    }

    let parsed;
    try {
      parsed = typeof response.data === 'object' ? response.data : JSON.parse(raw);
    } catch {
      parsed = JSON.parse(raw);
    }

    _cqCache.set(cacheKey, { data: parsed, expiresAt: Date.now() + CQ_CACHE_TTL });
    res.setHeader('X-Cache', 'MISS');
    return res.json(parsed);
  } catch (err) {
    console.error(`[CarQuery] Proxy error for ${cqUrl}: ${err.message}`);
    return res.status(502).json({ error: 'CarQuery API unavailable', details: err.message });
  }
});

// ============================================================
// VEHICLE INTELLIGENCE HUB — NHTSA APIs
// VIN Decode, Recalls, Safety Ratings, Complaints
// All free — no API key required
// ============================================================

const _nhtsaCache = new Map(); // in-memory short-term cache (5 min)
const NHTSA_CACHE_TTL = 5 * 60 * 1000; // 5 minutes in-memory

function _nhtsaCacheGet(key) {
  const hit = _nhtsaCache.get(key);
  if (hit && Date.now() < hit.expiresAt) return hit.data;
  _nhtsaCache.delete(key);
  return null;
}
function _nhtsaCacheSet(key, data) {
  _nhtsaCache.set(key, { data, expiresAt: Date.now() + NHTSA_CACHE_TTL });
}

async function _nhtsaDecodeVin(vin) {
  const cacheKey = `vin:${vin}`;
  const cached = _nhtsaCacheGet(cacheKey);
  if (cached) return cached;

  try {
    const url = `https://vpic.nhtsa.dot.gov/api/vehicles/DecodeVin/${vin}?format=json`;
    const resp = await axios.get(url, { timeout: 10000, headers: { 'User-Agent': 'FlipLane/1.0' } });
    if (!resp.data || !resp.data.Results) return null;
    const results = resp.data.Results;
    const get = (variable) => {
      const found = results.find(r => r.Variable === variable && r.Value && r.Value !== 'Not Applicable' && r.Value !== '0' && r.Value !== 'null');
      return found ? found.Value.trim() : null;
    };
    const data = {
      vin,
      year: get('Model Year'),
      make: get('Make'),
      model: get('Model'),
      trim: get('Trim'),
      series: get('Series'),
      bodyClass: get('Body Class'),
      vehicleType: get('Vehicle Type'),
      driveType: get('Drive Type'),
      fuelType: get('Fuel Type - Primary'),
      engineCylinders: get('Engine Number of Cylinders'),
      engineDisplacement: get('Displacement (L)'),
      engineHP: get('Engine Brake (hp) From'),
      transmission: get('Transmission Style'),
      transmissionSpeeds: get('Transmission Speeds'),
      doors: get('Number of Doors'),
      seatRows: get('Number of Seat Rows'),
      plantCountry: get('Plant Country'),
      plantCity: get('Plant City'),
      manufacturer: get('Manufacturer Name'),
      gvwr: get('Gross Vehicle Weight Rating From'),
      airBagFront: get('Air Bag Loc Front'),
      abs: get('Anti-lock Braking System (ABS)'),
      tpms: get('Tire Pressure Monitoring System (TPMS) Type'),
      electronicStability: get('Electronic Stability Control (ESC)')
    };
    _nhtsaCacheSet(cacheKey, data);
    return data;
  } catch (err) {
    console.warn('[VehicleIntel] VIN decode failed:', err.message);
    return null;
  }
}

async function _nhtsaRecalls(make, model, year) {
  const cacheKey = `recalls:${year}:${make}:${model}`;
  const cached = _nhtsaCacheGet(cacheKey);
  if (cached) return cached;

  try {
    const url = `https://api.nhtsa.gov/recalls/recallsByVehicle?make=${encodeURIComponent(make)}&model=${encodeURIComponent(model)}&modelYear=${encodeURIComponent(year)}`;
    const resp = await axios.get(url, { timeout: 10000, headers: { 'User-Agent': 'FlipLane/1.0' } });
    const results = resp.data && resp.data.results ? resp.data.results : [];
    const data = results.map(r => ({
      recallDate: r.RecallDate || null,
      campaign: r.NHTSACampaignNumber || null,
      component: r.Component || null,
      summary: r.Summary || null,
      consequence: r.Conequence || r.Consequence || null,
      remedy: r.Remedy || null,
      notes: r.Notes || null
    }));
    _nhtsaCacheSet(cacheKey, data);
    return data;
  } catch (err) {
    console.warn('[VehicleIntel] Recalls fetch failed:', err.message);
    return [];
  }
}

async function _nhtsaSafetyRatings(make, model, year) {
  const cacheKey = `safety:${year}:${make}:${model}`;
  const cached = _nhtsaCacheGet(cacheKey);
  if (cached) return cached;

  try {
    // First get the list of vehicle variants
    const listUrl = `https://api.nhtsa.gov/SafetyRatings/modelyear/${encodeURIComponent(year)}/make/${encodeURIComponent(make)}/model/${encodeURIComponent(model)}`;
    const listResp = await axios.get(listUrl, { timeout: 10000, headers: { 'User-Agent': 'FlipLane/1.0' } });
    const variants = listResp.data && listResp.data.Results ? listResp.data.Results : [];

    if (!variants.length) {
      const empty = { variants: [], ratings: [] };
      _nhtsaCacheSet(cacheKey, empty);
      return empty;
    }

    // Fetch ratings for first variant (representative)
    const variantId = variants[0].VehicleId;
    const ratingUrl = `https://api.nhtsa.gov/SafetyRatings/VehicleId/${variantId}`;
    const ratingResp = await axios.get(ratingUrl, { timeout: 10000, headers: { 'User-Agent': 'FlipLane/1.0' } });
    const ratingResults = ratingResp.data && ratingResp.data.Results ? ratingResp.data.Results : [];
    const r = ratingResults[0] || {};

    const data = {
      variants: variants.map(v => ({ id: v.VehicleId, description: v.VehicleDescription })),
      overall: r.OverallStarRating || null,
      frontCrash: r.FrontCrashDriversideStar || r.OverallFrontCrashRating || null,
      sideCrash: r.SideCrashDriversideStar || r.OverallSideCrashRating || null,
      rollover: r.RolloverPossibility || null,
      rolloverStars: r.RolloverRating || null,
      vehicleDescription: r.VehicleDescription || variants[0].VehicleDescription || null,
      vehiclePicture: r.VehiclePicture || null
    };
    _nhtsaCacheSet(cacheKey, data);
    return data;
  } catch (err) {
    console.warn('[VehicleIntel] Safety ratings fetch failed:', err.message);
    return { variants: [], overall: null, frontCrash: null, sideCrash: null, rollover: null, rolloverStars: null };
  }
}

async function _nhtsaComplaints(make, model, year) {
  const cacheKey = `complaints:${year}:${make}:${model}`;
  const cached = _nhtsaCacheGet(cacheKey);
  if (cached) return cached;

  try {
    const url = `https://api.nhtsa.gov/complaints/complaintsByVehicle?make=${encodeURIComponent(make)}&model=${encodeURIComponent(model)}&modelYear=${encodeURIComponent(year)}`;
    const resp = await axios.get(url, { timeout: 10000, headers: { 'User-Agent': 'FlipLane/1.0' } });
    const results = resp.data && resp.data.results ? resp.data.results : [];
    const data = results.map(c => ({
      id: c.ODINumber || null,
      date: c.DateOfIncident || null,
      component: c.Component || null,
      summary: c.Summary || null,
      crash: c.Crash || false,
      fire: c.Fire || false,
      injuries: c.NumberOfInjuries || 0,
      deaths: c.NumberOfDeaths || 0,
      mileage: c.VehicleMileage || null
    })).slice(0, 50); // cap at 50 for performance
    _nhtsaCacheSet(cacheKey, data);
    return data;
  } catch (err) {
    console.warn('[VehicleIntel] Complaints fetch failed:', err.message);
    return [];
  }
}

// POST /api/vehicle-intel/lookup
// Body: { vin?, year?, make?, model?, member_email? }
app.post('/api/vehicle-intel/lookup', async (req, res) => {
  try {
    const { vin, year, make, model, member_email } = req.body;

    if (!vin && (!year || !make || !model)) {
      return res.status(400).json({ success: false, message: 'Provide a VIN or Year + Make + Model.' });
    }

    let memberId = null;
    if (member_email) {
      try {
        const mRow = await pool.query(
          "SELECT id FROM members WHERE LOWER(email) = LOWER($1) AND status IN ('active', 'approved')",
          [member_email]
        );
        if (mRow.rows.length > 0) memberId = mRow.rows[0].id;
      } catch (e) { /* non-fatal */ }
    }

    let finalVin = vin ? vin.toUpperCase().trim() : null;
    let finalYear = year ? String(year) : null;
    let finalMake = make ? String(make).trim() : null;
    let finalModel = model ? String(model).trim() : null;

    // Check DB cache (24h)
    let fromCache = false;
    let cacheRow = null;
    try {
      if (finalVin) {
        const cacheRes = await pool.query(
          `SELECT * FROM vehicle_lookups WHERE vin = $1 AND cache_expires_at > NOW() ORDER BY looked_up_at DESC LIMIT 1`,
          [finalVin]
        );
        if (cacheRes.rows.length > 0) cacheRow = cacheRes.rows[0];
      } else if (finalYear && finalMake && finalModel) {
        const cacheRes = await pool.query(
          `SELECT * FROM vehicle_lookups WHERE LOWER(year) = LOWER($1) AND LOWER(make) = LOWER($2) AND LOWER(model) = LOWER($3) AND cache_expires_at > NOW() ORDER BY looked_up_at DESC LIMIT 1`,
          [finalYear, finalMake, finalModel]
        );
        if (cacheRes.rows.length > 0) cacheRow = cacheRes.rows[0];
      }
    } catch (e) { /* non-fatal */ }

    if (cacheRow) {
      fromCache = true;
    } else {
      // Decode VIN if provided
      let decodedData = null;
      if (finalVin && finalVin.length === 17) {
        decodedData = await _nhtsaDecodeVin(finalVin);
        if (decodedData) {
          finalYear = finalYear || decodedData.year;
          finalMake = finalMake || decodedData.make;
          finalModel = finalModel || decodedData.model;
        }
      }

      if (!finalMake || !finalModel || !finalYear) {
        return res.status(400).json({ success: false, message: 'Could not determine Make/Model/Year. Provide them explicitly or use a valid 17-char VIN.' });
      }

      // Fetch all NHTSA data in parallel
      const [recallsData, safetyData, complaintsData] = await Promise.all([
        _nhtsaRecalls(finalMake, finalModel, finalYear),
        _nhtsaSafetyRatings(finalMake, finalModel, finalYear),
        _nhtsaComplaints(finalMake, finalModel, finalYear)
      ]);

      const recallsCount = recallsData.length;
      const safetyRating = safetyData.overall ? String(safetyData.overall) : null;
      const complaintsCount = complaintsData.length;

      // Save to DB
      try {
        const cacheExpires = new Date(Date.now() + 24 * 60 * 60 * 1000);
        const dbRes = await pool.query(
          `INSERT INTO vehicle_lookups
            (member_id, vin, year, make, model, decoded_data, recalls_data, recalls_count, safety_data, safety_rating, complaints_data, complaints_count, cache_expires_at)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
           RETURNING *`,
          [
            memberId,
            finalVin || null,
            finalYear,
            finalMake,
            finalModel,
            decodedData ? JSON.stringify(decodedData) : null,
            JSON.stringify(recallsData),
            recallsCount,
            JSON.stringify(safetyData),
            safetyRating,
            JSON.stringify(complaintsData),
            complaintsCount,
            cacheExpires
          ]
        );
        cacheRow = dbRes.rows[0];
      } catch (dbErr) {
        console.error('[VehicleIntel] DB save error:', dbErr.message);
        // Return data even if DB save fails
        return res.json({
          success: true,
          fromCache: false,
          vehicle: { vin: finalVin, year: finalYear, make: finalMake, model: finalModel, ...decodedData },
          recalls: recallsData,
          recallsCount,
          safety: safetyData,
          safetyRating,
          complaints: complaintsData,
          complaintsCount
        });
      }
    }

    // Parse data from row (cache hit or newly inserted)
    const decodedData = cacheRow.decoded_data || null;
    const recallsData = cacheRow.recalls_data || [];
    const safetyData = cacheRow.safety_data || {};
    const complaintsData = cacheRow.complaints_data || [];

    return res.json({
      success: true,
      fromCache,
      lookupId: cacheRow.id,
      vehicle: {
        vin: cacheRow.vin,
        year: cacheRow.year,
        make: cacheRow.make,
        model: cacheRow.model,
        ...(decodedData || {})
      },
      recalls: recallsData,
      recallsCount: cacheRow.recalls_count,
      safety: safetyData,
      safetyRating: cacheRow.safety_rating,
      complaints: complaintsData,
      complaintsCount: cacheRow.complaints_count
    });
  } catch (err) {
    console.error('[VehicleIntel] Lookup error:', err.message);
    return res.status(500).json({ success: false, message: 'Lookup failed. Please try again.' });
  }
});

// GET /api/vehicle-intel/makes — NHTSA all makes list (for dropdowns)
app.get('/api/vehicle-intel/makes', async (req, res) => {
  const cacheKey = 'makes:all';
  const cached = _nhtsaCacheGet(cacheKey);
  if (cached) return res.json(cached);

  try {
    const url = 'https://vpic.nhtsa.dot.gov/api/vehicles/getallmakes?format=json';
    const resp = await axios.get(url, { timeout: 15000, headers: { 'User-Agent': 'FlipLane/1.0' } });
    const makes = (resp.data && resp.data.Results || []).map(m => m.Make_Name).filter(Boolean).sort();
    _nhtsaCacheSet(cacheKey, { makes });
    return res.json({ makes });
  } catch (err) {
    console.error('[VehicleIntel] Makes fetch failed:', err.message);
    return res.status(502).json({ error: 'Could not fetch makes list.' });
  }
});

// GET /api/vehicle-intel/models?make=Toyota&year=2020 — NHTSA models for make/year
app.get('/api/vehicle-intel/models', async (req, res) => {
  const { make, year } = req.query;
  if (!make) return res.status(400).json({ error: 'make parameter required' });

  const cacheKey = `models:${make}:${year || 'any'}`;
  const cached = _nhtsaCacheGet(cacheKey);
  if (cached) return res.json(cached);

  try {
    let url;
    if (year) {
      url = `https://vpic.nhtsa.dot.gov/api/vehicles/GetModelsForMakeYear/make/${encodeURIComponent(make)}/modelyear/${encodeURIComponent(year)}?format=json`;
    } else {
      url = `https://vpic.nhtsa.dot.gov/api/vehicles/GetModelsForMake/${encodeURIComponent(make)}?format=json`;
    }
    const resp = await axios.get(url, { timeout: 10000, headers: { 'User-Agent': 'FlipLane/1.0' } });
    const models = (resp.data && resp.data.Results || []).map(m => m.Model_Name).filter(Boolean).sort();
    const unique = [...new Set(models)];
    _nhtsaCacheSet(cacheKey, { models: unique });
    return res.json({ models: unique });
  } catch (err) {
    console.error('[VehicleIntel] Models fetch failed:', err.message);
    return res.status(502).json({ error: 'Could not fetch models list.' });
  }
});

// GET /api/vehicle-intel/history?email=... — lookup history for member
app.get('/api/vehicle-intel/history', async (req, res) => {
  const { email } = req.query;
  if (!email) return res.status(400).json({ error: 'email required' });

  try {
    const mRow = await pool.query(
      "SELECT id FROM members WHERE LOWER(email) = LOWER($1) AND status IN ('active', 'approved')",
      [email]
    );
    if (!mRow.rows.length) return res.json({ history: [] });

    const memberId = mRow.rows[0].id;
    const histRes = await pool.query(
      `SELECT id, vin, year, make, model, recalls_count, safety_rating, complaints_count, looked_up_at
       FROM vehicle_lookups WHERE member_id = $1 ORDER BY looked_up_at DESC LIMIT 20`,
      [memberId]
    );
    return res.json({ history: histRes.rows });
  } catch (err) {
    console.error('[VehicleIntel] History fetch error:', err.message);
    return res.status(500).json({ error: 'Could not fetch history.' });
  }
});

// GET /vehicle-intelligence — member Vehicle Intelligence Hub page
app.get('/vehicle-intelligence', (req, res) => {
  const htmlPath = path.join(__dirname, 'public', 'vehicle-intelligence.html');
  if (fs.existsSync(htmlPath)) {
    res.type('html').send(fs.readFileSync(htmlPath, 'utf8'));
  } else {
    res.status(404).send('Page not found');
  }
});

app.listen(port, () => {
  console.log(`FlipLane server running on port ${port}`);

  // Startup: validate email transport (Polsia platform bridge)
  (async () => {
    const polsiaKey = process.env.POLSIA_API_KEY || process.env.POLSIA_API_TOKEN;
    if (polsiaKey) {
      console.log('✅ [STARTUP] Email: Polsia platform bridge configured');
    } else {
      console.error('🚨 [STARTUP] Email: No POLSIA_API_KEY — emails will not send!');
    }
  })();

  // One-time applicant follow-up trigger (task #490977)
  // Set SEND_APPLICANT_FOLLOWUP=true env var to fire on next deploy, then unset.
  if (process.env.SEND_APPLICANT_FOLLOWUP === 'true') {
    console.log('[Startup] SEND_APPLICANT_FOLLOWUP=true — sending co-op applicant follow-up emails...');
    const PARTNER_URL = 'https://fliplane.net/partner';
    const applicants = [
      { id: 1, name: 'Ilyas zouheir', firstName: 'Ilyas', email: 'zouheirilyas@gmail.com', uploadedId: true }
    ];
    (async () => {
      for (const a of applicants) {
        const html = `<!DOCTYPE html><html><head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#f5f5f5;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f5f5;padding:40px 20px;"><tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:8px;overflow:hidden;max-width:600px;width:100%;">
<tr><td style="background:#1a1a2e;padding:32px 40px;text-align:center;">
  <p style="margin:0;font-size:22px;font-weight:700;color:#fff;letter-spacing:1px;">FlipLane</p>
  <p style="margin:6px 0 0;font-size:13px;color:#888cb4;">The AI-Powered Used Car Co-op</p>
</td></tr>
<tr><td style="padding:40px 40px 32px;">
  <p style="margin:0 0 20px;font-size:16px;color:#1a1a2e;">Hey ${a.firstName},</p>
  <p style="margin:0 0 16px;font-size:15px;line-height:1.7;color:#333;">You applied to join FlipLane's Co-op Partner network back on March 7th — and we dropped the ball on following up. That's on us.</p>
  <p style="margin:0 0 16px;font-size:15px;line-height:1.7;color:#333;">${a.uploadedId ? "You've already submitted your ID, which tells us you're serious. Let's get you across the finish line." : "Your application is ready to move forward."}</p>
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f8f9ff;border-radius:6px;margin:24px 0;">
    <tr><td style="padding:24px;">
      <p style="margin:0 0 14px;font-size:13px;font-weight:700;color:#1a1a2e;text-transform:uppercase;letter-spacing:1px;">What You Get as a Co-op Partner</p>
      <p style="margin:6px 0;font-size:14px;color:#333;"><span style="color:#4f6ef7;font-weight:700;">✓</span> Dealer credentials — no $15K+ state license required</p>
      <p style="margin:6px 0;font-size:14px;color:#333;"><span style="color:#4f6ef7;font-weight:700;">✓</span> Full ADESA auction access (50,000+ vehicles weekly)</p>
      <p style="margin:6px 0;font-size:14px;color:#333;"><span style="color:#4f6ef7;font-weight:700;">✓</span> Nationwide transaction processing — we handle the backend</p>
      <p style="margin:6px 0;font-size:14px;color:#333;"><span style="color:#4f6ef7;font-weight:700;">✓</span> Keep 100% profit on your own deals</p>
      <p style="margin:6px 0;font-size:14px;color:#333;"><span style="color:#4f6ef7;font-weight:700;">✓</span> Partner shipping network included</p>
    </td></tr>
  </table>
  <p style="margin:0 0 16px;font-size:15px;line-height:1.7;color:#333;">One-time membership fee is <strong>$250</strong>. No monthly fees, no revenue splits on your deals.</p>
  <p style="margin:0 0 28px;font-size:15px;line-height:1.7;color:#333;">Click below to complete your membership and get activated:</p>
  <table width="100%" cellpadding="0" cellspacing="0"><tr><td align="center">
    <a href="${PARTNER_URL}" style="display:inline-block;background:#4f6ef7;color:#fff;font-size:15px;font-weight:700;padding:14px 36px;border-radius:6px;text-decoration:none;">Complete My Membership →</a>
  </td></tr></table>
  <p style="margin:28px 0 0;font-size:14px;line-height:1.7;color:#666;">Questions? Just reply to this email — it goes straight to the team.</p>
</td></tr>
<tr><td style="padding:24px 40px;border-top:1px solid #eee;text-align:center;">
  <p style="margin:0;font-size:12px;color:#999;">FlipLane · Byrd Dawgs Automotive Group<br>
  <a href="${PARTNER_URL}" style="color:#4f6ef7;text-decoration:none;">fliplane.net/partner</a></p>
</td></tr></table></td></tr></table></body></html>`;

        try {
          const result = await sendEmail({
            to: a.email,
            subject: `${a.firstName}, your FlipLane co-op application — next steps`,
            html,
            tag: 'applicant-followup',
            listUnsubscribe: true
          });
          if (result?.success) {
            console.log(`[Startup] ✅ Follow-up sent to ${a.name} <${a.email}>`);
          } else {
            console.warn(`[Startup] ⚠️ Follow-up failed for ${a.email}: ${result?.error || 'unknown'}`);
          }
        } catch (err) {
          console.error(`[Startup] ❌ Follow-up failed for ${a.email}:`, err.message);
        }
      }
      console.log('[Startup] Applicant follow-up complete.');
    })().catch(err => console.error('[Startup] Follow-up unexpected error:', err.message));
  }

  // ============================================================
  // ONE-TIME: Sync welcome video from Google Drive on startup
  // Set SYNC_GDRIVE_VIDEO=true env var → triggers on next deploy → server downloads & uploads to R2
  // After success, unset the env var to prevent repeated runs.
  // ============================================================
  if (process.env.SYNC_GDRIVE_VIDEO === 'true') {
    console.log('[WelcomeVideo] SYNC_GDRIVE_VIDEO=true — starting Google Drive sync on startup...');
    (async () => {
      try {
        // Check if already set to a non-gdrive URL (R2 URL already present — skip)
        const existing = await pool.query("SELECT value FROM app_settings WHERE key = 'welcome_video_url'");
        const currentUrl = existing.rows.length > 0 ? existing.rows[0].value : null;
        if (currentUrl && !currentUrl.startsWith('gdrive:')) {
          console.log(`[WelcomeVideo] Already set to R2 URL in DB: ${currentUrl}. Skipping sync.`);
          return;
        }

        let videoUrl = null;

        // Priority: SYNC_GDRIVE_VIDEO_FILE_ID env var — download specific file
        const syncFileId = process.env.SYNC_GDRIVE_VIDEO_FILE_ID;
        if (syncFileId) {
          console.log(`[WelcomeVideo] Using SYNC_GDRIVE_VIDEO_FILE_ID: ${syncFileId}`);
          const downloadUrl = `https://drive.google.com/uc?export=download&id=${syncFileId}&confirm=t`;
          const r2UploadUrl = process.env.POLSIA_R2_BASE_URL ? `${process.env.POLSIA_R2_BASE_URL}/upload` : null;

          if (r2UploadUrl) {
            try {
              console.log(`[WelcomeVideo] Downloading from Drive...`);
              const videoResp = await axios.get(downloadUrl, {
                responseType: 'arraybuffer',
                headers: { 'User-Agent': 'Mozilla/5.0' },
                timeout: 180000,
                maxRedirects: 10
              });
              const videoBuffer = Buffer.from(videoResp.data);
              console.log(`[WelcomeVideo] Downloaded ${videoBuffer.length} bytes. Uploading to R2...`);
              const formData = new FormData();
              formData.append('file', videoBuffer, { filename: `welcome_${Date.now()}.mp4`, contentType: 'video/mp4' });
              const uploadResp = await axios.post(r2UploadUrl, formData, {
                headers: { ...formData.getHeaders() },
                timeout: 180000
              });
              videoUrl = uploadResp.data?.url || uploadResp.data?.public_url || null;
              if (videoUrl) {
                console.log(`[WelcomeVideo] ✅ R2 upload success: ${videoUrl}`);
              } else {
                console.warn('[WelcomeVideo] R2 upload response missing URL:', JSON.stringify(uploadResp.data));
              }
            } catch (e) {
              console.warn(`[WelcomeVideo] R2 upload failed: ${e.message}. Using Drive embed fallback.`);
            }
          }
          // Fallback to gdrive embed if R2 failed
          if (!videoUrl) {
            videoUrl = `gdrive:${syncFileId}`;
            console.log(`[WelcomeVideo] Using Google Drive embed fallback: ${videoUrl}`);
          }
        } else {
          // Legacy: folder-based sync
          videoUrl = await syncWelcomeVideoFromDrive('1Q5-BtWpeCGigXWRbygjxfBIUw9ZSmedx');
        }

        if (videoUrl) {
          await pool.query(
            `INSERT INTO app_settings (key, value, updated_at) VALUES ('welcome_video_url', $1, NOW())
             ON CONFLICT (key) DO UPDATE SET value = $1, updated_at = NOW()`,
            [videoUrl]
          );
          process.env.WELCOME_VIDEO_URL = videoUrl;
          console.log(`[WelcomeVideo] ✅ STARTUP SYNC SUCCESS — URL: ${videoUrl}`);
          console.log(`[WelcomeVideo] 🎬 Watch page: ${process.env.APP_URL || 'https://flipl.polsia.app'}/watch/welcome`);
          console.log(`[WelcomeVideo] → Unset SYNC_GDRIVE_VIDEO env var when confirmed.`);
        } else {
          console.warn('[WelcomeVideo] ❌ Startup sync returned no URL. Google Drive folder may require auth or have no videos.');
          console.warn('[WelcomeVideo] → To set manually: POST /api/admin/sync-welcome-video with { videoUrl: "..." } or { fileId: "..." }');
        }
      } catch (e) {
        console.error('[WelcomeVideo] Startup sync error:', e.message);
      }
    })().catch(err => console.error('[WelcomeVideo] Startup sync unexpected error:', err.message));
  }

  // ============================================================
  // SEED TERMS VERSION — create initial Terms version if none exists
  // ============================================================
  (async () => {
    try {
      const existing = await pool.query(
        `SELECT id FROM terms_versions WHERE is_active = TRUE LIMIT 1`
      );
      if (existing.rows.length === 0) {
        // No active Terms version — create one from the default content
        const defaultContent = docuseal.getDefaultTermsContent();
        await docuseal.createTermsVersion(pool, defaultContent, 'system_seed');
        console.log('[DocuSeal] ✅ Initial Terms version 1 created on startup');
      } else {
        console.log('[DocuSeal] Active Terms version already exists');
      }
    } catch (e) {
      console.warn('[DocuSeal] Startup Terms seed skipped (tables may not exist yet):', e.message);
    }
  })();

  // ============================================================
  // INDEXNOW — notify Bing/Yandex of all pages on startup
  // Google deprecated their ping (2023); IndexNow is the modern protocol.
  // Fires once 60s after startup so the server is fully ready.
  // Key file: /public/1c3b3dd0cc218d1d7639f49f9554f3c5.txt
  // ============================================================
  setTimeout(async () => {
    try {
      const INDEXNOW_KEY = '1c3b3dd0cc218d1d7639f49f9554f3c5';
      const INDEXNOW_HOST = 'fliplane.net';

      // Static pages
      const staticUrls = [
        'https://fliplane.net/',
        'https://fliplane.net/buy',
        'https://fliplane.net/earn',
        'https://fliplane.net/partner',
        'https://fliplane.net/flip-to-fortune',
        'https://fliplane.net/pricing',
        'https://fliplane.net/blog',
        'https://fliplane.net/apply',
        'https://fliplane.net/terms'
      ];

      // Fetch published blog post URLs from DB
      let blogPostUrls = [];
      try {
        const result = await pool.query(
          `SELECT slug FROM blog_posts WHERE published = true ORDER BY publish_date DESC`
        );
        blogPostUrls = result.rows.map(p => `https://fliplane.net/blog/${p.slug}`);
      } catch (e) {
        console.warn('[IndexNow] Could not fetch blog posts:', e.message);
      }

      const urlList = [...staticUrls, ...blogPostUrls];
      console.log(`[IndexNow] Submitting ${urlList.length} URLs to api.indexnow.org...`);

      const response = await axios.post('https://api.indexnow.org/indexnow', {
        host: INDEXNOW_HOST,
        key: INDEXNOW_KEY,
        keyLocation: `https://${INDEXNOW_HOST}/${INDEXNOW_KEY}.txt`,
        urlList
      }, {
        headers: { 'Content-Type': 'application/json; charset=utf-8' },
        timeout: 15000
      });

      console.log(`[IndexNow] ✅ Submitted — status: ${response.status}`);
    } catch (err) {
      // Non-critical — don't crash server on ping failure
      const status = err.response?.status;
      const msg = err.response?.data || err.message;
      console.warn(`[IndexNow] ⚠️ Submission failed — ${status || 'network error'}: ${JSON.stringify(msg)}`);
    }
  }, 60000);
});
