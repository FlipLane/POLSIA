#!/usr/bin/env node
// Fix logo references across all HTML files
const fs = require('fs');
const path = require('path');

const dir = path.join(__dirname, '..', 'public');
const files = fs.readdirSync(dir).filter(f => f.endsWith('.html'));

let ogFixed = 0, touchFixed = 0;

for (const file of files) {
  const fp = path.join(dir, file);
  let content = fs.readFileSync(fp, 'utf8');
  const original = content;

  // Fix og:image pointing to .svg → .png
  content = content.replace(
    /(<meta property="og:image" content="https:\/\/fliplane\.net\/)og-image\.svg(")/g,
    '$1og-image.png$2'
  );

  // Fix apple-touch-icon pointing to /favicon.svg → /images/flip-lane-logo.png
  content = content.replace(
    /(<link rel="apple-touch-icon"[^>]*href=")\/favicon\.svg(")/g,
    '$1/images/flip-lane-logo.png$2'
  );

  if (content !== original) {
    fs.writeFileSync(fp, content, 'utf8');
    const changes = [];
    if (content.includes('/og-image.png') && original.includes('/og-image.svg')) {
      changes.push('og:image SVG→PNG');
      ogFixed++;
    }
    if (content.includes('flip-lane-logo.png') && original.includes('/favicon.svg')) {
      changes.push('apple-touch-icon');
      touchFixed++;
    }
    console.log('Updated:', file, '-', changes.join(', '));
  }
}

console.log('\nDone. og:image fixed:', ogFixed, '| apple-touch-icon fixed:', touchFixed);
