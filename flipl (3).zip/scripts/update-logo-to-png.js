const fs = require('fs');
const path = require('path');

const publicDir = 'public';
const htmlFiles = fs.readdirSync(publicDir)
  .filter(f => f.endsWith('.html'))
  .map(f => path.join(publicDir, f));

let totalChanges = 0;

for (const file of htmlFiles) {
  let content = fs.readFileSync(file, 'utf8');
  const before = content;

  // Remove onerror attributes from logo img tags
  // The onerror contains a complex SVG data URI fallback
  // Match: onerror="this.onerror=null;this.src='data:image/svg+xml,...'"
  // The attribute value is delimited by double quotes
  content = content.replace(/ onerror="this\.onerror=null;this\.src=[^"]*"/g, '');

  // Remove orphaned </span> tags after logo img close
  // Pattern: ...height="40"></span></a> or ...height="36"></span></a>
  content = content.replace(/(alt="FlipLane" height="\d+">)<\/span>/g, '$1');

  if (content !== before) {
    totalChanges++;
    fs.writeFileSync(file, content);
    console.log('Fixed:', file);
  }
}

// Verify no orphaned </span> or onerror remain near logo refs
for (const file of htmlFiles) {
  const content = fs.readFileSync(file, 'utf8');
  const lines = content.split('\n');
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].includes('flip-lane-logo.png')) {
      if (lines[i].includes('onerror')) {
        console.log('WARN: onerror still in', file, 'line', i + 1);
      }
      if (lines[i].includes('logo-img-container')) {
        console.log('WARN: container still in', file, 'line', i + 1);
      }
      // Check for orphaned </span> right after img tag
      if (lines[i].match(/flip-lane-logo\.png[^<]*><\/span>/)) {
        console.log('WARN: orphaned </span> in', file, 'line', i + 1);
      }
    }
  }
}

console.log('\nTotal files fixed:', totalChanges);
