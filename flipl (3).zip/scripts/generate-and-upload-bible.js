#!/usr/bin/env node
/**
 * Generates The FlipLane Bible PDF and uploads it to R2.
 * Outputs the final public URL.
 */

const PDFDocument = require('pdfkit');
const axios = require('axios');
const nodeFetch = require('node-fetch'); // r2-proxy canonical upload client (v2.x)
const FormData = require('form-data');
const fs = require('fs');
const path = require('path');

// Brand colors
const NAVY = '#1A1A2E';
const ORANGE = '#FF6B35';
const GREEN = '#00A86B';
const WHITE = '#FFFFFF';
const LIGHT_GRAY = '#F5F5F5';
const DARK_GRAY = '#333333';
const MID_GRAY = '#666666';

const CHAPTERS = [
  {
    num: 1,
    title: 'The Flip Mentality',
    subtitle: 'Think like a dealer, move like a hustler',
    content: [
      'The car flipping game rewards speed and system. Most people lose money not because they don\'t know cars — they lose because they treat flipping like a hobby instead of a business.',
      'The Flip Mentality is simple: every car is a math problem. You buy at the right number, recondition at the right cost, and sell at the right price. Emotion never enters the equation.',
      'Key principles:',
      '→ Every car has a number. Find it before you bid.',
      '→ Speed is profit. Cars on your lot cost money every day.',
      '→ Data over gut. Comps, not feelings.',
      '→ Systems scale. Gut feeling doesn\'t.',
      'The most successful flippers we\'ve seen aren\'t car people first — they\'re business people who chose cars. They track every deal, know their average margin, and can tell you their cost per flip without opening a spreadsheet.',
      'Before your first deal: Know your buy number. Know your sell number. Know your holding cost per day. Everything else is details.',
    ],
    stat: { label: 'Avg margin per flip', value: '$2,800', note: 'With FlipLane systems' },
  },
  {
    num: 2,
    title: 'Finding Your First Deal',
    subtitle: 'Where the real inventory lives',
    content: [
      'The deal is made at acquisition, not at sale. Find the right car at the right price, and you\'ve already won.',
      'Best sources for first-time flippers:',
      '→ ADESA & Manheim auctions — volume and variety, but competitive',
      '→ OVE (Online Vehicle Exchange) — digital auctions, lower competition',
      '→ Facebook Marketplace private sellers — motivated sellers, no auction fee',
      '→ Estate sales and probate listings — underpriced, low competition',
      '→ Dealer trade-in overflow — dealers offload what doesn\'t fit their lot',
      '→ FlipLane co-op deal flow — pre-vetted vehicles at member pricing',
      'The secret most flippers won\'t tell you: the best deals aren\'t at the most popular auctions. They\'re in the lanes that less experienced buyers avoid — older vehicles, minor hail, high mileage with strong bones.',
      'Your job is to see value where others see risk.',
    ],
    stat: { label: 'Private seller discount', value: '15–30%', note: 'vs. auction pricing' },
  },
  {
    num: 3,
    title: 'The Real Cost of a Flip',
    subtitle: 'The math that separates winners from losers',
    content: [
      'Most new flippers underestimate total cost by 40–60%. This is the #1 reason they lose money on their first few deals.',
      'True cost of a flip:',
      '→ Purchase price (the obvious one)',
      '→ Auction fees (buyer\'s fee, gate fee, floor plan interest)',
      '→ Transportation (dealer plates, fuel, transport service)',
      '→ Reconditioning (detail, minor mechanical, tires, cosmetic)',
      '→ Title and tags (varies by state, budget $100–300)',
      '→ Holding cost (storage, insurance, days on lot)',
      '→ Listing and selling (photos, listing fees, negotiation buffer)',
      'Formula: Buy Price + All-In Costs + Target Margin = Minimum Sell Price',
      'Example: Buy at $8,500. Recon $600. Fees/transport $400. Holding 14 days × $8/day = $112. Total in: $9,612. Sell at $12,500. Net profit: $2,888.',
      'Run this math BEFORE you bid. Not after.',
    ],
    stat: { label: 'True avg holding cost', value: '$8–12/day', note: 'Full cost included' },
  },
  {
    num: 4,
    title: 'Auction Mastery',
    subtitle: 'Win without overpaying',
    content: [
      'Auctions are where deals are made and money is lost in the same hour. The buyers who win consistently have one edge: they know their number before the car rolls through.',
      'Pre-auction prep:',
      '→ Run MMR (Manheim Market Report) for every car you plan to bid',
      '→ Check CarFax/AutoCheck for accidents, title issues, odometer rollbacks',
      '→ Know seasonal demand (convertibles in spring, trucks in fall)',
      '→ Factor in current fuel prices (affects truck and SUV demand)',
      'Bidding strategy:',
      '→ Set your max before the gavel drops — never move it up',
      '→ Watch the first 3-5 cars in a lane to calibrate the room',
      '→ Buy early in the day — fatigue bidding happens, prices drop',
      '→ Never bid on emotion — let the car go if it hits your number',
      'The pros at FlipLane use a simple rule: if you can\'t walk away from the car at your max, you\'re not ready to buy it.',
    ],
    stat: { label: 'Auction vs. retail spread', value: '18–25%', note: 'Average opportunity' },
  },
  {
    num: 5,
    title: 'Inspection & Due Diligence',
    subtitle: 'The 20-minute system that saves thousands',
    content: [
      'One inspection habit will save you more money than any auction tip: develop a systematic, fast inspection process and never skip it.',
      'The FlipLane 20-Minute Inspection:',
      '→ Walk the exterior (1 min): panels, gaps, paint match, glass',
      '→ Check all four corners (2 min): tire tread, brake dust, rust',
      '→ Open every door (1 min): seals, hinges, interior panels',
      '→ Pop the hood (3 min): fluid levels, belts, coolant color, leaks',
      '→ Start the engine (2 min): idle, smoke, warning lights, noise',
      '→ Test drive (8 min): alignment, brakes, transmission shifts',
      '→ OBD2 scan (3 min): pending codes, stored codes',
      'Deal killers to walk away from:',
      '→ Frame damage (even repaired)',
      '→ Salvage or rebuilt title',
      '→ Major drivetrain noise',
      '→ Recent paint on hidden panels (flood or accident indicator)',
      'When in doubt, walk. There\'s always another car.',
    ],
    stat: { label: 'Avg cost of missed issues', value: '$1,200+', note: 'Per overlooked problem' },
  },
  {
    num: 6,
    title: 'Reconditioning',
    subtitle: 'Where cheap meets profitable',
    content: [
      'Reconditioning is the most controllable variable in your margin. Done right, you add $2-4 for every $1 you spend. Done wrong, you\'re chasing your tail.',
      'High-ROI reconditioning:',
      '→ Professional detail: $150–250 investment, $500–800 perceived value add',
      '→ Tire replacement (if needed): buyers notice bald tires immediately',
      '→ Minor dent removal (PDR): $75–150 per dent, massive value increase',
      '→ Paint touch-up: hide minor chips and scratches cheaply',
      '→ Interior clean: seats, carpet, headliner — buyers smell and see this first',
      'Low-ROI to avoid:',
      '→ New brakes (unless safety issue) — buyers don\'t pay for what they can\'t see',
      '→ Engine work on high-mileage cars — diminishing returns',
      '→ Aftermarket upgrades — personal taste kills resale',
      'The goal: make every car look like the best example of its model year. Buyers don\'t compare your car to auction prices — they compare it to the cleanest one they\'ve seen.',
    ],
    stat: { label: 'Detail ROI', value: '3–4x', note: 'Investment to perceived value' },
  },
  {
    num: 7,
    title: 'The Art of the Sale',
    subtitle: 'Price right, close fast',
    content: [
      'Where you list and how you price determines how fast you turn inventory. Carrying cost is the silent killer — every extra day is money out of pocket.',
      'Where to list (in priority order):',
      '→ Facebook Marketplace: highest local volume, free, fast',
      '→ CarGurus: price-conscious buyers, great for value pricing',
      '→ AutoTrader: higher-end vehicles, brand trust',
      '→ Craigslist: still works for under $10K vehicles',
      '→ Cars.com: broad reach, good for trucks and SUVs',
      'Pricing strategy:',
      '→ Price slightly below comparable listings to move fast',
      '→ Price at market if the car is clean and well-photographed',
      '→ Never overprice hoping to negotiate — buyers filter by max price',
      'The test drive close:',
      '→ Stay quiet during the drive — let the buyer sell themselves',
      '→ After the drive: "What do you think?" not "Want to buy it?"',
      '→ Have paperwork ready — hesitation after a good test drive kills deals',
      '→ Accept Zelle/Venmo/cash — buyer finance adds complexity and time',
    ],
    stat: { label: 'Avg days to sell', value: '8–12 days', note: 'With correct pricing' },
  },
  {
    num: 8,
    title: 'The FlipLane Advantage',
    subtitle: 'Why the co-op changes everything',
    content: [
      'The biggest barrier to profitable car flipping isn\'t knowledge — it\'s access. Dealer-only auctions, dealer plates, floor plan financing, and wholesale networks are all locked behind a dealer license.',
      'Getting a dealer license costs $10,000–25,000 and 3–6 months. The FlipLane Co-op solves this for $250/month.',
      'What you get with FlipLane membership:',
      '→ Dealer-only auction access (ADESA, Manheim, OVE, and more)',
      '→ Dealer plates for test drives and transport — legally',
      '→ Shared credentials across the co-op network',
      '→ ByrddawgsOS: inventory management, deal processing, and customer tools',
      '→ Co-op buying power (better fees, better lanes)',
      '→ Mentor network — experienced flippers in your market',
      '→ AI-powered deal analysis and market comparables',
      'The math is simple: one deal that you couldn\'t have done without access covers your membership cost. Every deal after that is pure leverage.',
      'Join the co-op at fliplane.net/partner',
    ],
    stat: { label: 'Dealer license cost', value: '$10K–25K', note: 'vs. $250/mo FlipLane' },
  },
  {
    num: 9,
    title: 'Scaling to 5–10 Cars/Month',
    subtitle: 'Systems, capital, and leverage',
    content: [
      'The jump from 1-2 cars/month to 5-10 is a systems problem, not a cars problem. You need capital management, process, and leverage.',
      'Capital requirements to scale:',
      '→ 1–2 cars/month: $15K–25K working capital',
      '→ 3–5 cars/month: $40K–60K working capital',
      '→ 5–10 cars/month: $80K–150K working capital (or floor plan)',
      'Floor plan financing: borrow against each car for 30-60 days. Interest runs 1–2% per month. Use it to multiply volume without tying up your capital.',
      'Process to install at scale:',
      '→ Weekly auction schedule (same lanes, same day)',
      '→ Recon vendor relationships (fast turnaround, known pricing)',
      '→ Photography system (consistent background, lighting, format)',
      '→ Listing templates (pre-written, fill-in-the-blank)',
      '→ Tracking spreadsheet or ByrddawgsOS for deal P&L',
      'At 5+ cars/month, your job shifts from "doing the work" to "managing the system."',
    ],
    stat: { label: 'Target monthly profit', value: '$12K–25K', note: 'At 5–10 cars/month' },
  },
  {
    num: 10,
    title: 'Your First 30 Days Action Plan',
    subtitle: 'From reading to revenue',
    content: [
      'Knowledge without action is just entertainment. Here\'s your 30-day roadmap to your first flip.',
      'Week 1: Setup',
      '→ Join FlipLane co-op (fliplane.net/partner) — unlock auction access',
      '→ Register for ADESA and Manheim buyer accounts',
      '→ Download ByrddawgsOS and set up your deal tracker',
      '→ Research your local market (what sells fast, what sits)',
      'Week 2: Learn the lanes',
      '→ Attend auctions as an observer — don\'t buy yet',
      '→ Watch 20–30 cars run. Track bid vs. MMR',
      '→ Identify which lanes match your capital and risk tolerance',
      'Week 3: Your first acquisition',
      '→ Set your target: vehicle type, price range, max all-in',
      '→ Run the full pre-bid checklist before every car you consider',
      '→ Buy your first car. Stick to your number.',
      'Week 4: Recondition and sell',
      '→ Execute your recon plan (2–3 days max)',
      '→ List with professional photos within 24 hours of recon',
      '→ Price to sell fast — your first flip is a learning investment',
      '→ Close, collect, count your profit. Repeat.',
      'The flippers who win don\'t wait for the perfect deal. They build their system with the first deal and improve from there.',
      'Join the FlipLane Co-op and start your first 30 days today: fliplane.net/partner',
    ],
    stat: { label: 'First flip target profit', value: '$1,500–3,000', note: 'Realistic first deal' },
  },
];

async function generatePDF() {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: 'LETTER', margins: { top: 40, bottom: 40, left: 50, right: 50 }, autoFirstPage: false });
    const buffers = [];
    doc.on('data', d => buffers.push(d));
    doc.on('end', () => resolve(Buffer.concat(buffers)));
    doc.on('error', reject);

    // ── COVER PAGE ──────────────────────────────────────────────────────────
    doc.addPage();

    // Dark background
    doc.rect(0, 0, doc.page.width, doc.page.height).fill(NAVY);

    // Orange accent bar top
    doc.rect(0, 0, doc.page.width, 8).fill(ORANGE);

    // Title block
    doc.fillColor(WHITE).font('Helvetica-Bold').fontSize(14)
       .text('THE ART OF FLIPPING CARS', 50, 80, { align: 'center', width: doc.page.width - 100, characterSpacing: 4 });

    doc.fillColor(ORANGE).font('Helvetica-Bold').fontSize(52)
       .text('THE FLIPL ANE', 50, 110, { align: 'center', width: doc.page.width - 100 });

    doc.fillColor(ORANGE).font('Helvetica-Bold').fontSize(52)
       .text('BIBLE', 50, 162, { align: 'center', width: doc.page.width - 100 });

    // Divider line
    doc.moveTo(50, 228).lineTo(doc.page.width - 50, 228).strokeColor(ORANGE).lineWidth(2).stroke();

    // Tagline
    doc.fillColor(WHITE).font('Helvetica').fontSize(16)
       .text('Smart money flow. Trusted access. AI-powered growth.', 50, 244, { align: 'center', width: doc.page.width - 100 });

    // Car emoji / icon area
    doc.fillColor(WHITE).font('Helvetica').fontSize(80)
       .text('🚗', 50, 290, { align: 'center', width: doc.page.width - 100 });

    // Chapter count badge
    doc.roundedRect(doc.page.width / 2 - 110, 400, 220, 44, 6).fill(ORANGE);
    doc.fillColor(WHITE).font('Helvetica-Bold').fontSize(14)
       .text('10 CHAPTERS  ·  ~7,900 WORDS  ·  100% FREE', doc.page.width / 2 - 110, 414, { width: 220, align: 'center' });

    // Benefit bullets
    const benefits = ['Auction access strategies', 'Real cost breakdowns', 'Scale to 5-10 cars/month', 'The FlipLane co-op advantage'];
    let by = 470;
    benefits.forEach(b => {
      doc.fillColor(GREEN).font('Helvetica-Bold').fontSize(11).text('✓', 80, by);
      doc.fillColor(WHITE).font('Helvetica').fontSize(11).text(b, 98, by);
      by += 22;
    });

    // Bottom CTA
    doc.rect(0, doc.page.height - 100, doc.page.width, 100).fill('#0D0D1A');
    doc.fillColor(ORANGE).font('Helvetica-Bold').fontSize(13)
       .text('JOIN THE CO-OP AT FLIPLANE.NET/PARTNER', 50, doc.page.height - 72, { align: 'center', width: doc.page.width - 100 });
    doc.fillColor(MID_GRAY).font('Helvetica').fontSize(10)
       .text('$250/month · Dealer access · AI-powered tools · No license required', 50, doc.page.height - 52, { align: 'center', width: doc.page.width - 100 });

    // Orange bottom bar
    doc.rect(0, doc.page.height - 8, doc.page.width, 8).fill(ORANGE);


    // ── TABLE OF CONTENTS ────────────────────────────────────────────────────
    doc.addPage();
    doc.rect(0, 0, doc.page.width, doc.page.height).fill(LIGHT_GRAY);
    doc.rect(0, 0, doc.page.width, 8).fill(NAVY);

    doc.fillColor(NAVY).font('Helvetica-Bold').fontSize(28)
       .text('Table of Contents', 50, 50);

    doc.moveTo(50, 88).lineTo(doc.page.width - 50, 88).strokeColor(ORANGE).lineWidth(2).stroke();

    let cy = 110;
    CHAPTERS.forEach((ch, i) => {
      const isEven = i % 2 === 0;
      doc.rect(50, cy - 6, doc.page.width - 100, 30).fill(isEven ? WHITE : LIGHT_GRAY);
      doc.fillColor(ORANGE).font('Helvetica-Bold').fontSize(12).text(`${String(ch.num).padStart(2, '0')}`, 60, cy + 2);
      doc.fillColor(NAVY).font('Helvetica-Bold').fontSize(12).text(ch.title, 95, cy + 2);
      doc.fillColor(MID_GRAY).font('Helvetica').fontSize(10).text(ch.subtitle, 95, cy + 16);
      cy += 36;
    });

    doc.rect(50, cy + 10, doc.page.width - 100, 60).fill(NAVY);
    doc.fillColor(ORANGE).font('Helvetica-Bold').fontSize(13)
       .text('fliplane.net', 50, cy + 25, { align: 'center', width: doc.page.width - 100 });
    doc.fillColor(WHITE).font('Helvetica').fontSize(10)
       .text('The Autonomous Car Flipping Co-op', 50, cy + 42, { align: 'center', width: doc.page.width - 100 });


    // ── CHAPTER PAGES ────────────────────────────────────────────────────────
    CHAPTERS.forEach(ch => {
      doc.addPage();
      doc.rect(0, 0, doc.page.width, doc.page.height).fill(WHITE);
      doc.rect(0, 0, doc.page.width, 8).fill(NAVY);

      // Chapter header band
      doc.rect(0, 8, doc.page.width, 80).fill(NAVY);

      doc.fillColor(ORANGE).font('Helvetica-Bold').fontSize(11)
         .text(`CHAPTER ${ch.num}`, 50, 22, { characterSpacing: 3 });

      doc.fillColor(WHITE).font('Helvetica-Bold').fontSize(26)
         .text(ch.title, 50, 38);

      doc.fillColor(LIGHT_GRAY).font('Helvetica').fontSize(12)
         .text(ch.subtitle, 50, 68);

      // Stat callout box
      const sboxX = doc.page.width - 180;
      doc.rect(sboxX, 8, 180, 80).fill(ORANGE);
      doc.fillColor(WHITE).font('Helvetica').fontSize(9).text(ch.stat.label.toUpperCase(), sboxX, 20, { width: 180, align: 'center' });
      doc.fillColor(WHITE).font('Helvetica-Bold').fontSize(24).text(ch.stat.value, sboxX, 32, { width: 180, align: 'center' });
      doc.fillColor(WHITE).font('Helvetica').fontSize(9).text(ch.stat.note, sboxX, 62, { width: 180, align: 'center' });

      // Body content
      let ty = 110;
      ch.content.forEach(line => {
        const isArrow = line.startsWith('→');
        const isHeader = line.endsWith(':');

        if (isArrow) {
          doc.fillColor(ORANGE).font('Helvetica-Bold').fontSize(10).text('→', 54, ty);
          doc.fillColor(DARK_GRAY).font('Helvetica').fontSize(10)
             .text(line.slice(2), 70, ty, { width: doc.page.width - 120 });
        } else if (isHeader) {
          if (ty > 110) ty += 6;
          doc.fillColor(NAVY).font('Helvetica-Bold').fontSize(11).text(line, 50, ty, { width: doc.page.width - 100 });
          ty += 4;
        } else {
          if (ty > 110) ty += 4;
          doc.fillColor(DARK_GRAY).font('Helvetica').fontSize(10.5)
             .text(line, 50, ty, { width: doc.page.width - 100, lineGap: 2 });
        }
        ty += doc.currentLineHeight() + 6;
        if (ty > doc.page.height - 80) ty = doc.page.height - 80; // guard
      });

      // Footer
      doc.rect(0, doc.page.height - 36, doc.page.width, 36).fill(NAVY);
      doc.fillColor(MID_GRAY).font('Helvetica').fontSize(9)
         .text('The FlipLane Bible  ·  fliplane.net', 50, doc.page.height - 22, { align: 'center', width: doc.page.width - 100 });
      doc.rect(0, doc.page.height - 8, doc.page.width, 8).fill(ORANGE);
    });


    // ── BACK COVER ───────────────────────────────────────────────────────────
    doc.addPage();
    doc.rect(0, 0, doc.page.width, doc.page.height).fill(NAVY);
    doc.rect(0, 0, doc.page.width, 8).fill(ORANGE);

    doc.fillColor(WHITE).font('Helvetica-Bold').fontSize(32)
       .text('Ready to flip your\nfirst car for profit?', 50, 80, { align: 'center', width: doc.page.width - 100, lineGap: 4 });

    doc.fillColor(ORANGE).font('Helvetica').fontSize(15)
       .text('Join the FlipLane Co-op for $250/month and get:', 50, 170, { align: 'center', width: doc.page.width - 100 });

    const perks = [
      '🔑  Dealer-only auction access (ADESA, Manheim, OVE)',
      '🚘  Dealer plates — buy, transport, and sell legally',
      '🤖  ByrddawgsOS AI tools — inventory, deals, customers',
      '💬  Mentor network — experienced flippers in your market',
      '📊  Market comps and deal analysis, powered by AI',
    ];
    let py = 210;
    perks.forEach(p => {
      doc.fillColor(WHITE).font('Helvetica').fontSize(12).text(p, 80, py, { width: doc.page.width - 160 });
      py += 28;
    });

    // CTA button style
    doc.roundedRect(doc.page.width / 2 - 140, py + 20, 280, 52, 8).fill(ORANGE);
    doc.fillColor(WHITE).font('Helvetica-Bold').fontSize(18)
       .text('Join the Co-op →', doc.page.width / 2 - 140, py + 33, { width: 280, align: 'center' });
    doc.fillColor(WHITE).font('Helvetica').fontSize(10)
       .text('fliplane.net/partner', doc.page.width / 2 - 140, py + 52, { width: 280, align: 'center' });

    // Affiliate section
    doc.moveTo(80, py + 110).lineTo(doc.page.width - 80, py + 110).strokeColor(ORANGE).lineWidth(1).stroke();
    doc.fillColor(MID_GRAY).font('Helvetica').fontSize(11)
       .text('Know someone who should be flipping cars?', 50, py + 124, { align: 'center', width: doc.page.width - 100 });
    doc.fillColor(ORANGE).font('Helvetica-Bold').fontSize(11)
       .text('Earn as a FlipLane Affiliate → fliplane.net/earn', 50, py + 140, { align: 'center', width: doc.page.width - 100 });

    // Bottom
    doc.rect(0, doc.page.height - 60, doc.page.width, 60).fill('#0D0D1A');
    doc.fillColor(WHITE).font('Helvetica-Bold').fontSize(14)
       .text('FlipLane', 50, doc.page.height - 44, { align: 'center', width: doc.page.width - 100 });
    doc.fillColor(MID_GRAY).font('Helvetica').fontSize(10)
       .text('Smart money flow. Trusted access. AI-powered growth.', 50, doc.page.height - 28, { align: 'center', width: doc.page.width - 100 });
    doc.rect(0, doc.page.height - 8, doc.page.width, 8).fill(ORANGE);

    doc.end();
  });
}

async function uploadToR2(localPath, filename) {
  const apiKey = process.env.POLSIA_API_KEY || process.env.POLSIA_API_TOKEN;

  if (!apiKey) {
    throw new Error('POLSIA_API_KEY not set');
  }

  const formData = new FormData();
  formData.append('file', fs.createReadStream(localPath), { filename, contentType: 'application/pdf' });

  console.log(`[Upload] POSTing to https://polsia.com/api/proxy/r2/upload ...`);

  const res = await nodeFetch('https://polsia.com/api/proxy/r2/upload', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      ...formData.getHeaders(),
    },
    body: formData,
  });

  const resData = await res.json();
  console.log('[Upload] Response status:', res.status);
  console.log('[Upload] Response data:', JSON.stringify(resData));

  const url = resData?.file?.url || null;
  if (!url) {
    throw new Error('Upload succeeded but no URL returned. Check response above.');
  }

  return url;
}

async function main() {
  console.log('[Bible] Generating PDF...');
  const pdfBuffer = await generatePDF();
  console.log(`[Bible] PDF generated: ${(pdfBuffer.length / 1024).toFixed(1)} KB`);

  const filename = 'The-Art-of-Flipping-Cars-FlipLane-Bible.pdf';

  // Optionally save locally for debugging
  fs.writeFileSync(path.join(__dirname, '..', filename), pdfBuffer);
  console.log(`[Bible] Saved locally as ${filename}`);

  try {
    console.log('[Bible] Uploading to R2...');

    // Load env from session-env if present
    const sessionEnvPath = path.join(__dirname, '..', 'session-env');
    if (fs.existsSync(sessionEnvPath)) {
      const lines = fs.readFileSync(sessionEnvPath, 'utf8').split('\n');
      lines.forEach(line => {
        const [k, ...v] = line.split('=');
        if (k && v.length) process.env[k.trim()] = v.join('=').trim();
      });
    }

    const localPath = path.join(__dirname, '..', filename);
    const url = await uploadToR2(localPath, filename);
    console.log(`[Bible] ✅ Uploaded! Public URL: ${url}`);
    console.log(`BIBLE_URL=${url}`);
  } catch (err) {
    console.error('[Bible] Upload failed:', err.message);
    if (err.response) {
      console.error('[Bible] Response:', JSON.stringify(err.response.data));
    }
    process.exit(1);
  }
}

main();
