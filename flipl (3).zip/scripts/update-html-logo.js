/**
 * update-html-logo.js
 * Updates all HTML pages to:
 * 1. Add proper favicon link tags
 * 2. Update og:image meta tags
 * 3. Replace text-based logo in navbar with image logo
 * 4. Replace footer logo
 * 5. Update dashboard-specific logos
 */

const fs = require('fs');
const path = require('path');

const PUBLIC_DIR = path.join(__dirname, '..', 'public');
const OG_IMAGE_URL = 'https://fliplane.net/og-image.svg';
const LOGO_IMG = '/images/flip-lane-logo.png';

// SVG data URI fallback - use if logo image not yet downloaded
// This creates a placeholder with the FL shield mark
const LOGO_SVG_DATA_URI = `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 60'%3E%3Crect width='200' height='60' fill='%230a0a0a' rx='8'/%3E%3Crect x='4' y='10' width='40' height='40' rx='8' fill='%2300e676'/%3E%3Ctext x='24' y='38' font-family='Georgia,serif' font-weight='700' font-size='22' fill='%230a0a0a' text-anchor='middle'%3EFL%3C/text%3E%3Ctext x='118' y='38' font-family='Arial,sans-serif' font-weight='700' font-size='28' fill='%23ffffff' text-anchor='middle'%3EFlipLane%3C/text%3E%3C/svg%3E`;

// Logo image HTML for navbar
const NAV_LOGO_HTML = `<a href="/" class="logo-img"><img src="${LOGO_IMG}" alt="FlipLane" height="40" onerror="this.onerror=null;this.src='${LOGO_SVG_DATA_URI}'"></a>`;

// Footer logo (slightly smaller)
const FOOTER_LOGO_HTML = `<a href="/" class="logo-img footer-logo-img"><img src="${LOGO_IMG}" alt="FlipLane" height="36" onerror="this.onerror=null;this.src='${LOGO_SVG_DATA_URI}'"></a>`;

// Dashboard login logo image (centered, larger)
const LOGIN_LOGO_HTML = `<a href="/" class="login-logo-img"><img src="${LOGO_IMG}" alt="FlipLane" height="48" onerror="this.onerror=null;this.src='${LOGO_SVG_DATA_URI}'"></a>`;

// Dashboard topbar logo (compact)
const TOPBAR_LOGO_HTML = `<a href="/" class="topbar-logo-img"><img src="${LOGO_IMG}" alt="FlipLane" height="28" onerror="this.onerror=null;this.src='${LOGO_SVG_DATA_URI}'"></a>`;

const HTML_PAGES = [
  'index.html',
  'join.html',
  'buy.html',
  'earn.html',
  'partner.html',
  'pricing.html',
  'terms.html',
  'blog.html',
  'blog-post.html',
  'apply.html',
  'affiliateos.html',
  'dashboard.html',
  'admin.html',
  'admin-login.html',
  'admin-blog.html',
  'byrddawgsos.html',
  'certification.html',
  'welcome.html',
  'vehicle-intelligence.html',
  'unsubscribe.html',
  'tools.html',
  'payment-success.html',
  'game.html',
  'flip-to-fortune.html',
  'flip-to-fortune-read.html',
];

// Favicon tags to add to HTML head
const FAVICON_TAGS = `
    <link rel="icon" type="image/svg+xml" href="/favicon.svg">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon.svg">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon.svg">
    <link rel="apple-touch-icon" href="/favicon.svg">
`;

function updatePageFile(filepath) {
  let content = fs.readFileSync(filepath, 'utf8');
  let modified = false;
  const filename = path.basename(filepath);

  // 1. Add favicon tags (add after charset meta tag if not already present)
  if (!content.includes('href="/favicon.svg"')) {
    content = content.replace(
      /(<meta charset="UTF-8">\s*)/g,
      '$1\n    ' + FAVICON_TAGS.trim() + '\n    '
    );
    modified = true;
  }

  // 2. Update og:image meta tags (only for default /og-image.png URLs)
  if (content.includes('og:image')) {
    // Replace relative /og-image.png with og-image.svg
    content = content.replace(
      /<meta property="og:image" content="https:\/\/fliplane\.net\/og-image\.png">/g,
      `<meta property="og:image" content="${OG_IMAGE_URL}">`
    );
    content = content.replace(
      /<meta name="twitter:image" content="https:\/\/fliplane\.net\/og-image\.png">/g,
      `<meta name="twitter:image" content="${OG_IMAGE_URL}">`
    );
    // Also handle /og-image.png (relative)
    content = content.replace(
      /<meta property="og:image" content="\/og-image\.png">/g,
      `<meta property="og:image" content="${OG_IMAGE_URL}">`
    );
    content = content.replace(
      /<meta name="twitter:image" content="\/og-image\.png">/g,
      `<meta name="twitter:image" content="${OG_IMAGE_URL}">`
    );
    modified = true;
  }

  // 3. Update navbar text logo to image logo (context: inside .nav-inner)
  // Navbar pattern: <div class="nav-inner"> ... <a href="/" class="logo">Flip<span>Lane</span></a>
  if (content.includes('class="nav-inner"') && content.includes('class="logo"') && content.includes('Flip<span>Lane</span>')) {
    content = content.replace(
      /<a href="\/" class="logo">Flip<span>Lane<\/span><\/a>/,
      NAV_LOGO_HTML
    );
    modified = true;
  }

  // 4. Update footer text logo to image logo (context: inside .footer-brand)
  if (content.includes('class="footer-brand"') && content.includes('Flip<span>Lane</span>')) {
    content = content.replace(
      /<a href="\/" class="logo">Flip<span>Lane<\/span><\/a>/,
      FOOTER_LOGO_HTML
    );
    modified = true;
  }

  // 5. Dashboard login logo: <div class="login-logo">FlipLane</div>
  if (content.includes('class="login-logo"') && content.includes('>FlipLane<')) {
    content = content.replace(
      /<div class="login-logo">FlipLane<\/div>/,
      `<div class="login-logo">${LOGIN_LOGO_HTML}</div>`
    );
    modified = true;
  }

  // 6. Dashboard topbar logo: <span class="topbar-logo">Flip<span>Lane</span></span>
  if (content.includes('class="topbar-logo"') && content.includes('Flip<span>Lane</span>')) {
    content = content.replace(
      /<span class="topbar-logo">Flip<span>Lane<\/span><\/span>/,
      TOPBAR_LOGO_HTML
    );
    modified = true;
  }

  // 7. Standalone pages (like join.html) with inline nav logo pattern
  // Pattern: <a href="/" class="logo">Flip<span>Lane</span></a> inside inline nav styles
  if (!content.includes('class="nav-inner"') && content.includes('class="logo"') && content.includes('Flip<span>Lane</span>')) {
    // Check if it's NOT in footer context
    const footerMatch = content.match(/<div class="footer-brand">[\s\S]*?<a href="\/" class="logo">Flip<span>Lane<\/span><\/a>/);
    if (!footerMatch) {
      // Replace the first occurrence (nav logo in inline-styled nav)
      content = content.replace(
        /<a href="\/" class="logo">Flip<span>Lane<\/span><\/a>/,
        NAV_LOGO_HTML
      );
      modified = true;
    }
  }

  if (modified) {
    fs.writeFileSync(filepath, content);
    console.log(`Updated: ${filename}`);
  }
}

console.log('Updating HTML pages with FlipLane logo...\n');

for (const page of HTML_PAGES) {
  const filepath = path.join(PUBLIC_DIR, page);
  if (fs.existsSync(filepath)) {
    updatePageFile(filepath);
  } else {
    console.log(`MISSING: ${page}`);
  }
}

console.log('\nDone!');
console.log('\nNote: If the logo image (public/images/flip-lane-logo.png) is not yet available,');
console.log('SVG data URIs are used as fallback in the onerror attribute.');
console.log('The og:image has been updated to use og-image.svg (proper 1200x630 dimensions).');