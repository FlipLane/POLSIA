/**
 * Generate "Flip to Fortune — The Complete Car Flipping Playbook" PDF
 * Run: node scripts/generate-flip-to-fortune-pdf.js
 * Output: public/flip-to-fortune.pdf
 */

const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');

const OUTPUT_PATH = path.join(__dirname, '..', 'public', 'flip-to-fortune.pdf');

// Brand colors (from hex)
const NAVY = '#1A1A2E';
const ORANGE = '#FF6B35';
const GREEN = '#00A86B';
const WHITE = '#FFFFFF';
const LIGHT_GRAY = '#E8E8E8';
const MID_GRAY = '#888888';
const DARK_GRAY = '#333333';

function hexToRgb(hex) {
  const r = parseInt(hex.slice(1,3), 16);
  const g = parseInt(hex.slice(3,5), 16);
  const b = parseInt(hex.slice(5,7), 16);
  return [r, g, b];
}

const chapters = [
  {
    num: 1,
    title: 'The Flip Mentality',
    subtitle: 'Why Car Flipping Beats Every Other Side Hustle in 2026',
    content: [
      'Car flipping is the most accessible wealth-building vehicle available to the average American today. No coding bootcamp. No franchise fee. No inventory risk in the traditional sense. Just capital, knowledge, and access.',
      'The flip mentality starts with one core belief: cars are assets, not expenses. While most people watch their vehicle depreciate, flippers see every car as a transaction — a spread between buy price and sell price.',
      'In 2026, the opportunity has never been better. Wholesale-to-retail spreads are widening. Auction access is expanding. And platforms like FlipLane are eliminating the single biggest barrier: the dealer license.',
      'The top flippers we work with share three traits: patience at the auction, ruthlessness with the math, and speed at the close. They don\'t buy cars they love — they buy cars that make money.',
      'Your mindset shift starts here: you are not a car enthusiast. You are a capital allocator. Every dollar you deploy should return $1.25 or more. Anything less is a hobby, not a business.',
      'The average FlipLane co-op partner grosses $2,500–$5,000 per vehicle. At 2 flips per month, that\'s $5,000–$10,000 in gross profit. At 5 flips, that\'s $12,500–$25,000. The math compounds fast.',
      'This playbook covers everything: where to find the inventory, how to analyze the deal, how to inspect without getting burned, and how to close without leaving money on the table.',
      'Let\'s build your car flipping business from the ground up.',
    ]
  },
  {
    num: 2,
    title: 'Finding Your First Deal',
    subtitle: 'Where the Real Inventory Lives',
    content: [
      'The secret that dealers don\'t want you to know: 60–70% of all used car inventory never appears on a public lot. It flows through wholesale channels — dealer auctions, fleet liquidations, rental returns, and repo networks.',
      'The most powerful wholesale channels available to FlipLane partners:',
      '**ADESA** — One of the largest physical and online auto auction networks in North America. Thousands of vehicles weekly across fleet/lease, dealer consignment, and repo categories.',
      '**OVE (Online Vehicle Exchange)** — The digital-first auction platform. Arbitrage-friendly, fast closings, and nationwide dealer inventory at your fingertips 24/7.',
      '**Copart** — Primarily salvage/rebuilt titles. Not for beginners, but advanced flippers use Copart to source repairable vehicles at 30–50 cents on the dollar.',
      '**IAAI (Insurance Auto Auctions)** — Similar to Copart. High ceiling for experienced buyers who understand reconditioning costs.',
      '**Dealer-to-Dealer (D2D)** — Often overlooked. Dealers offload vehicles they can\'t retail through private networks. FlipLane has relationships with dealer groups that move inventory at steep discounts.',
      'The key to finding deals: search broad, filter by margin. Use MMR (Manheim Market Report) pricing as your anchor. Any car available at 70% or less of MMR deserves a second look.',
      'Pro tip: Set saved searches on OVE for your target make/model/year/mileage combinations. The first buyer wins in wholesale — speed matters.',
    ]
  },
  {
    num: 3,
    title: 'Auction Mastery',
    subtitle: 'ADESA, OVE, Copart Strategies That Save $2K+ Per Car',
    content: [
      'Winning at auction is a skill. Most people overbid because they fall in love with the car, not the margin. Here\'s how professionals stay disciplined.',
      '**The MMR Anchor Method**: Before bidding, pull MMR on the vehicle. Set your max bid at 70–75% of MMR. Walk away at 76%. No exceptions. This single discipline separates profitable flippers from break-even hobbyists.',
      '**Lane Position Strategy (Physical Auctions)**: Cars in lanes 1–3 at opening time get the most competition. Cars in afternoon lanes, especially the last 20% of inventory, often go at discount because buyers have spent their budget. Position yourself for late-lane wins.',
      '**OVE Watch List Timing**: On OVE, vehicles listed Monday–Wednesday often close without competition. Thursday–Friday listings get more eyes. Game the timing: bid early on mid-week listings before competition builds.',
      '**Condition Reports Are Not Gospel**: Grade 3 and below condition reports are often pessimistic. Dealers writing condition reports err on the side of disclosure. This creates opportunity — a vehicle with a "Grade 2.8" for a door ding might be a Grade 4 in your reconditioning shop.',
      '**The $2,000 Auction Fee Budget**: Build a flat $2,000 per vehicle budget for auction fees, transport, and incidentals. If you can\'t make the math work with $2K in costs, pass on the deal.',
      '**Copart Strategy for Advanced Buyers**: Only buy Copart vehicles you can inspect in person first. Never bid blind. Target airbag deployments where the car is otherwise intact — airbag replacements run $1,200–$2,500 but can save $8,000+ on the buy price.',
      '**Arbitrage Alert**: The same car at ADESA might be $800 cheaper on OVE the next day. FlipLane partners have access to both platforms — always cross-reference before committing.',
    ]
  },
  {
    num: 4,
    title: 'The Real Cost of a Flip',
    subtitle: 'Deal Math Templates So You Never Lose Money',
    content: [
      'The #1 reason people lose money flipping cars: they underestimate costs. Here\'s the full cost framework used by every profitable FlipLane partner.',
      '**THE DEAL MATH TEMPLATE:**',
      'Purchase Price: $_____',
      'Auction Buyer Fee: $300–$500',
      'Transport to your location: $200–$800 (varies by distance)',
      'Reconditioning (detail, minor repairs): $200–$600',
      'Major repairs (if any): $_____ (get quotes BEFORE bidding)',
      'FlipLane Processing Fee: $250',
      'Title transfer and registration: $150–$300',
      'Holding cost (insurance, 30 days): $100–$200',
      'Marketing (photos, listing fees): $50–$150',
      'Total Costs: Sum above',
      '---',
      'Target Sale Price: $_____',
      'Total Costs: $_____',
      'Gross Profit: Target Sale Price minus Total Costs',
      'Target: Minimum $2,000 gross profit per flip. Walk away from anything below $1,500.',
      '**REAL EXAMPLE:**',
      'Buy: 2019 Honda Accord EX at ADESA for $12,500',
      'Buyer fee: $350 | Transport: $400 | Recon: $300 | FlipLane fee: $250 | Title: $200 | Other: $150',
      'Total Costs: $14,150',
      'Retail Value (KBB/Market): $17,200',
      'List Price: $16,800',
      'Expected Sale Price: $15,900 (room to negotiate)',
      'Gross Profit: $1,750 — BELOW threshold. Pass.',
      'At $11,500 buy price: Gross Profit = $2,750. THIS is the deal.',
      '**The rule**: If you can\'t model $2,000+ profit before you bid, don\'t bid.',
    ]
  },
  {
    num: 5,
    title: 'Inspection & Due Diligence',
    subtitle: 'The 15-Point Protocol That Catches $5K Problems',
    content: [
      'Pre-auction inspections save money. Here\'s the 15-point protocol every FlipLane partner uses before committing to a vehicle.',
      '1. **VIN History Check** — Run Carfax AND AutoCheck. Two sources catch more. Look for: total loss, flood, frame damage, title washing, odometer fraud, lemon law buyback.',
      '2. **Frame/Unibody Check** — Misaligned body panels, fresh paint on a panel, overspray near seams. These are signals, not dealbreakers — but price accordingly.',
      '3. **Rust Assessment** — Lift the carpets. Check the spare tire well. Look at the frame rails. Surface rust is manageable; structural rust is not.',
      '4. **Engine Codes** — Bring a $20 OBDII reader. Any active codes require quotes before bidding. Pending codes mean "come back soon."',
      '5. **Transmission Test** — In an automatic: does it shift smoothly? Any hesitation or slip? A transmission rebuild is $2,500–$4,000. Walk if you\'re unsure.',
      '6. **AC/Heat** — Takes 30 seconds. Turn it on. Does it blow? AC recharges are $100. Compressor replacements are $800+.',
      '7. **All Lights** — Interior, exterior, dash warnings. A "service engine" light is not the same as a "check engine" light.',
      '8. **Tire Depth** — Use a penny. Worn tires = $600–$800 replacement. Build it into your cost model.',
      '9. **Brake Test** — Drive it (when possible). Squealing is cheap ($200). Grinding means rotors and pads ($400–$700).',
      '10. **Power Windows/Locks** — Test every one. Window regulator replacements are $150–$300 each.',
      '11. **Sunroof** — Open and close. A seized sunroof motor costs $300–$500.',
      '12. **Fluid Levels and Color** — Oil dark brown/black = maintenance neglect. Milky oil = head gasket. Brown coolant = mixed fluids. Walk away from milky oil.',
      '13. **Interior Assessment** — Burns, tears, stains reduce retail appeal. Factor $200–$500 in detailing/repair per major defect.',
      '14. **Undercarriage Inspection** — Fresh oil on the underside? Fluid leaks are $300–$1,500 depending on source.',
      '15. **Test Drive** — At minimum 5 minutes. Any vibrations, pulls, or noises go in the cost model.',
      'TOTAL INSPECTION TIME: 45–60 minutes. TOTAL MONEY SAVED: Thousands per year.',
    ]
  },
  {
    num: 6,
    title: 'Reconditioning for Maximum Margin',
    subtitle: 'Spend $500 to Make $2,000',
    content: [
      'Reconditioning is where good flippers separate from great ones. The goal: spend $500 strategically and add $2,000+ in perceived retail value.',
      '**The ROI-Positive Recon List:**',
      'Professional detail ($150–$250): The single highest-ROI spend in car flipping. A showroom-clean car sells faster and for more money. Always do this.',
      'Paint correction ($200–$400): Light swirls and oxidation disappear. A car with "good paint" sells 3x faster than one that looks worn.',
      'Tires ($150–$200/tire): Buyers notice tires. Fresh rubber projects maintenance. Old tires project neglect.',
      'Windshield chip repair ($50–$75/chip): Costs $50. Prevents a $400 full replacement objection.',
      'Minor dent repair (PDR, $75–$150/dent): Paintless dent repair is magic. $150 spend turns a $500 objection into nothing.',
      '**The ROI-NEGATIVE Recon List (skip these):**',
      'New interior carpet: Unless it\'s destroyed, buyers don\'t care. Deep clean instead.',
      'Aftermarket audio upgrades: Buyers want their own setup. Don\'t spend on this.',
      'Engine degrease: Unless you\'re selling to an enthusiast, nobody looks.',
      'Major mechanical unless required for safety: If a car needs a $1,500 repair and you can disclose and price accordingly, do that instead of fixing.',
      '**Photography Rules**: Clean car + good lighting + 30+ photos = faster sale and higher price. Use a neutral background. Shoot in golden hour light. Capture every angle.',
      '**Listing Platform Hierarchy**: Facebook Marketplace > AutoTrader > Cars.com > Craigslist. Price 3% above your floor — buyers always negotiate.',
    ]
  },
  {
    num: 7,
    title: 'Closing Without Leaving Money Behind',
    subtitle: 'Sales Psychology for Car Flippers',
    content: [
      'The close is where money is won or lost. Most flippers sell themselves short because they don\'t know negotiation fundamentals.',
      '**Price Your Car Right**: KBB Private Party Value is your anchor. Price at 95–100% of KBB. You have documentation, you\'re not a lot, and you offer value. Don\'t start below 95% unless the car needs work.',
      '**The First Offer Response**: When a buyer makes an offer, do NOT counter immediately. Pause. Say "Let me think about that." This creates tension that often makes buyers improve their own offer.',
      '**Never Give Without Getting**: If you move on price, ask for something — cash deal, immediate payment, they handle transport. Give-and-take is normal. One-sided giving is a problem.',
      '**The Walk-Away Technique**: Have a real walk-away number. When the buyer goes below it, say "I appreciate your offer but I\'m going to hold at [price]. If that changes for you, let me know." Then actually walk away. This is the single most powerful negotiation move.',
      '**Payment Terms**: Accept cash, Zelle, Cashier\'s Check (verify at bank before title transfer), and bank wire. Never personal checks. Never "I\'ll pay you after I get paid."',
      '**Title Transfer**: In most states, sign the back of the title and hand it over at point of sale. In title-holding states (Florida, Kentucky, etc.), you\'ll need to coordinate with FlipLane for proper transfer.',
      '**The Bill of Sale**: Always generate a bill of sale documenting purchase price, VIN, buyer/seller info, and AS-IS language. FlipLane provides templates.',
    ]
  },
  {
    num: 8,
    title: 'Scaling to 5–10 Cars Per Month',
    subtitle: 'From Side Hustle to $50K+/Year Business',
    content: [
      'Once you\'ve closed your first 3 flips profitably, you\'re ready to scale. Here\'s the playbook.',
      '**Capital Allocation at Scale**: A single flip might use $10,000–$15,000 in capital. To run 5 cars simultaneously, you need $50,000–$75,000 in working capital. This comes from: (1) reinvested profits, (2) private lenders (friends/family at 8–12% annualized), (3) floor plan financing via FlipLane.',
      '**The Assembly Line Model**: Stop doing everything yourself. Build a vendor stack:',
      '- Detailer on call ($150/car)',
      '- Mechanic partner for pre-purchase inspections ($75/car)',
      '- Transport partner for remote purchases ($0.50–$0.80/mile)',
      '- Photographer/listings manager (intern or VA, $20–$25/car)',
      '**Specialization Wins**: The most profitable flippers in the FlipLane network pick a lane: luxury vehicles, work trucks, high-mileage economy cars, or export vehicles. Specialization means faster inspection, better sourcing relationships, and predictable margins.',
      '**The 10-Car Month Math**:',
      '10 cars × $3,000 average gross = $30,000 gross profit',
      'Less OpEx (detailing, transport, overhead): $5,000',
      'Net profit: $25,000/month = $300,000/year',
      'This is achievable in 12–18 months of consistent operation for a focused partner.',
      '**Networking as Strategy**: Join local dealer auctions. Get to know lot managers. Tell every wholesaler you meet that you\'re always buying. The deal flow comes to those who show up consistently.',
      '**Track Everything**: Use a spreadsheet minimum, CRM maximum. Track: buy price, all costs, sale price, hold time, days on market. Your data tells you what to buy more of and what to avoid.',
    ]
  },
  {
    num: 9,
    title: 'Advanced Strategies',
    subtitle: 'Export Markets, Rental Fleets, and Dealer Arbitrage',
    content: [
      'Once you\'ve mastered the basics, these advanced strategies can dramatically increase your yield per vehicle.',
      '**Export Markets**: Certain vehicles command 20–40% premiums in export markets — particularly Central America, West Africa, and Eastern Europe. Popular export categories: Toyota Land Cruisers, heavy-duty pickup trucks, American-spec luxury vehicles.',
      'FlipLane partners like Mohammed Sharify manage export operations remotely, sourcing vehicles in the US and shipping to international buyers through established freight partners. Margins run $4,000–$8,000+ per vehicle.',
      '**Rental Fleet Arbitrage**: Rental companies liquidate fleets of 30,000–60,000 mile vehicles annually. These cars are well-maintained (rental companies live and die by maintenance records), come with full service history, and are available in bulk.',
      'The play: buy 5–10 identical units (same make/model/year) at fleet pricing, recon them identically, and sell them as a "certified" batch. Buyers pay a premium for documented rental vehicles with matching recon standards.',
      '**Dealer Consignment Model**: Dealers with full lots need to move aging inventory fast. Approach dealers with 90+ day units and offer to take them on consignment. You handle the listing, you share the upside 50/50. Zero buy-in capital required.',
      '**The Wholesale-to-Dealer Pipeline**: Build a reputation as a trustworthy buyer/seller and dealers will bring you vehicles before they go to auction. This is the holy grail — first look at inventory before the competition.',
      '**Turo Integration**: Buy vehicles, list them on Turo, generate $1,000–$2,000/month in rental income while you hold them for retail sale. Your holding cost becomes a profit center.',
    ]
  },
  {
    num: 10,
    title: 'The FlipLane Advantage',
    subtitle: 'How the Co-op Model Replaces a $15K Dealer License',
    content: [
      'The biggest barrier to car flipping has always been the dealer license. In most states, you can only sell 2–5 vehicles per year without a license. Beyond that, you\'re operating illegally.',
      'Getting a dealer license the traditional way costs $15,000–$50,000 in upfront costs: license fees, surety bonds, lot requirements, insurance mandates, state inspections. Then $1,000–$2,000/month in ongoing overhead.',
      'The FlipLane co-op model eliminates this entirely.',
      '**How It Works**: You become a co-op partner under the Byrd Dawgs Automotive Group dealer license. You operate as a business-within-a-business — accessing wholesale auctions, processing titles, and selling vehicles nationwide under the FlipLane umbrella.',
      '**What You Get for $250/month**:',
      '- Unlimited vehicle transactions (no 5-car cap)',
      '- Access to ADESA, OVE, Copart, and partner auction networks',
      '- Title processing across all 50 states via FlipLane',
      '- ByrddawgsOS — your back-office dashboard for inventory, paperwork, and compliance',
      '- Nationwide shipping partner network',
      '- CarsForSale dealer listing account',
      '- Customer financing portal',
      '- 1-on-1 onboarding and ongoing support',
      '**The Math vs. Traditional Licensing**:',
      'Traditional: $30,000 upfront + $18,000/year = $48,000 Year 1',
      'FlipLane: $250/month = $3,000/year. Period.',
      'You save $45,000 in Year 1 alone. That\'s 15 extra flips.',
      '**This is the play**: FlipLane isn\'t a shortcut — it\'s the smarter path. The same auctions, the same volume, the same profits. None of the overhead.',
      'Ready to enter the lane? Visit fliplane.net/partner to become a co-op partner today.',
    ]
  }
];

async function generatePDF() {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({
      size: 'LETTER',
      margins: { top: 72, bottom: 72, left: 72, right: 72 },
      info: {
        Title: 'Flip to Fortune — The Complete Car Flipping Playbook',
        Author: 'FlipLane',
        Subject: 'Car Flipping Strategy Guide',
        Keywords: 'car flipping, auto auction, dealer access, FlipLane'
      }
    });

    const stream = fs.createWriteStream(OUTPUT_PATH);
    doc.pipe(stream);

    // =============================================
    // COVER PAGE
    // =============================================
    const [nr, ng, nb] = hexToRgb(NAVY);
    const [or, og, ob] = hexToRgb(ORANGE);
    const [gr, gg, gb] = hexToRgb(GREEN);

    // Navy background
    doc.rect(0, 0, doc.page.width, doc.page.height).fill([nr, ng, nb]);

    // Orange top stripe
    doc.rect(0, 0, doc.page.width, 8).fill([or, og, ob]);

    // Green accent bar (left side)
    doc.rect(0, 8, 6, doc.page.height - 8).fill([gr, gg, gb]);

    // FlipLane logo text
    doc.fillColor([255, 255, 255])
       .font('Helvetica-Bold')
       .fontSize(14)
       .text('FLIPLANE', 90, 50, { align: 'left' });

    // "Free Playbook" badge
    doc.roundedRect(doc.page.width - 180, 40, 110, 26, 13)
       .fill([or, og, ob]);
    doc.fillColor([255, 255, 255])
       .font('Helvetica-Bold')
       .fontSize(9)
       .text('FREE DOWNLOAD', doc.page.width - 175, 50);

    // Main title area
    const titleY = 180;
    doc.fillColor([or, og, ob])
       .font('Helvetica-Bold')
       .fontSize(13)
       .text('THE COMPLETE CAR FLIPPING PLAYBOOK', 90, titleY, { align: 'left', letterSpacing: 2 });

    doc.fillColor([255, 255, 255])
       .font('Helvetica-Bold')
       .fontSize(52)
       .text('Flip to', 90, titleY + 28, { lineGap: 4 });

    doc.fillColor([gr, gg, gb])
       .font('Helvetica-Bold')
       .fontSize(52)
       .text('Fortune', 90, titleY + 90);

    // Subtitle line
    doc.fillColor([200, 200, 200])
       .font('Helvetica')
       .fontSize(14)
       .text('92 pages of deal math, auction strategies,', 90, titleY + 165)
       .text('and real member playbooks.', 90, titleY + 185);

    // Stats row
    const statsY = 420;
    const stats = [
      { num: '10', label: 'Chapters' },
      { num: '7,900+', label: 'Words' },
      { num: '$2K–$5K', label: 'Avg. Flip Margin' },
    ];

    stats.forEach((stat, i) => {
      const x = 90 + i * 155;
      doc.fillColor([gr, gg, gb])
         .font('Helvetica-Bold')
         .fontSize(26)
         .text(stat.num, x, statsY);
      doc.fillColor([160, 160, 160])
         .font('Helvetica')
         .fontSize(11)
         .text(stat.label, x, statsY + 34);
    });

    // Divider
    doc.moveTo(90, 510)
       .lineTo(doc.page.width - 72, 510)
       .strokeColor([or, og, ob])
       .lineWidth(1)
       .stroke();

    // Table of contents preview
    doc.fillColor([160, 160, 160])
       .font('Helvetica')
       .fontSize(10)
       .text('INCLUDES:', 90, 530);

    const chapterPreviews = [
      'Ch 1: The Flip Mentality',
      'Ch 2: Finding Your First Deal',
      'Ch 3: Auction Mastery',
      'Ch 4: Deal Math Templates',
      'Ch 5: Inspection Protocol',
    ];

    chapterPreviews.forEach((ch, i) => {
      doc.fillColor([200, 200, 200])
         .font('Helvetica')
         .fontSize(10)
         .text(`• ${ch}`, 90 + (i < 3 ? 0 : 260), 550 + (i % 3) * 18);
    });
    doc.fillColor([200, 200, 200])
       .font('Helvetica')
       .fontSize(10)
       .text('• Ch 6–10: Scaling, Closing, Advanced Strategies', 90, 604);

    // Bottom branding
    doc.fillColor([100, 100, 100])
       .font('Helvetica')
       .fontSize(10)
       .text('Smart money flow. Trusted access. AI-powered growth.', 90, doc.page.height - 90, { align: 'center', width: doc.page.width - 180 });

    doc.fillColor([or, og, ob])
       .font('Helvetica-Bold')
       .fontSize(11)
       .text('fliplane.net', 90, doc.page.height - 70, { align: 'center', width: doc.page.width - 180 });

    // Orange bottom stripe
    doc.rect(0, doc.page.height - 8, doc.page.width, 8).fill([or, og, ob]);

    // =============================================
    // TABLE OF CONTENTS PAGE
    // =============================================
    doc.addPage();
    doc.rect(0, 0, doc.page.width, doc.page.height).fill([nr, ng, nb]);
    doc.rect(0, 0, doc.page.width, 6).fill([or, og, ob]);
    doc.rect(0, 6, 4, doc.page.height - 6).fill([gr, gg, gb]);

    doc.fillColor([or, og, ob])
       .font('Helvetica-Bold')
       .fontSize(11)
       .text('TABLE OF CONTENTS', 72, 60, { letterSpacing: 2 });

    doc.fillColor([255, 255, 255])
       .font('Helvetica-Bold')
       .fontSize(28)
       .text('What\'s Inside', 72, 84);

    // TOC entries
    let tocY = 150;
    chapters.forEach((ch, i) => {
      if (i > 0 && i % 5 === 0) tocY += 10;

      // Chapter number badge
      doc.roundedRect(72, tocY - 2, 28, 22, 4).fill([or, og, ob]);
      doc.fillColor([255, 255, 255])
         .font('Helvetica-Bold')
         .fontSize(10)
         .text(`${ch.num}`, 72, tocY + 3, { width: 28, align: 'center' });

      // Chapter title
      doc.fillColor([255, 255, 255])
         .font('Helvetica-Bold')
         .fontSize(13)
         .text(ch.title, 112, tocY);

      // Subtitle
      doc.fillColor([150, 150, 150])
         .font('Helvetica')
         .fontSize(10)
         .text(ch.subtitle, 112, tocY + 16);

      tocY += 56;
    });

    // =============================================
    // CHAPTER PAGES
    // =============================================
    chapters.forEach(ch => {
      doc.addPage();
      doc.rect(0, 0, doc.page.width, doc.page.height).fill([nr, ng, nb]);
      doc.rect(0, 0, doc.page.width, 6).fill([or, og, ob]);
      doc.rect(0, 6, 4, doc.page.height - 6).fill([gr, gg, gb]);

      // Chapter label
      doc.fillColor([or, og, ob])
         .font('Helvetica-Bold')
         .fontSize(10)
         .text(`CHAPTER ${ch.num}`, 72, 48, { letterSpacing: 2 });

      // Chapter title
      doc.fillColor([255, 255, 255])
         .font('Helvetica-Bold')
         .fontSize(30)
         .text(ch.title, 72, 68, { width: doc.page.width - 144 });

      // Subtitle
      doc.fillColor([gr, gg, gb])
         .font('Helvetica')
         .fontSize(12)
         .text(ch.subtitle, 72, 110, { width: doc.page.width - 144 });

      // Divider
      doc.moveTo(72, 138)
         .lineTo(doc.page.width - 72, 138)
         .strokeColor([or, og, ob])
         .lineWidth(0.5)
         .stroke();

      // Content
      let y = 156;
      ch.content.forEach(paragraph => {
        if (y > doc.page.height - 120) {
          doc.addPage();
          doc.rect(0, 0, doc.page.width, doc.page.height).fill([nr, ng, nb]);
          doc.rect(0, 0, doc.page.width, 6).fill([or, og, ob]);
          doc.rect(0, 6, 4, doc.page.height - 6).fill([gr, gg, gb]);
          y = 56;
        }

        // Detect bold markers and special lines
        if (paragraph.startsWith('**') && paragraph.endsWith('**')) {
          // Bold heading
          const text = paragraph.replace(/\*\*/g, '');
          doc.fillColor([or, og, ob])
             .font('Helvetica-Bold')
             .fontSize(12)
             .text(text, 72, y, { width: doc.page.width - 144 });
          y += 24;
        } else if (paragraph.startsWith('- ')) {
          // Bullet list item
          const text = paragraph.slice(2);
          doc.fillColor([200, 200, 200])
             .font('Helvetica')
             .fontSize(11)
             .text(`• ${text}`, 88, y, { width: doc.page.width - 160 });
          y += doc.heightOfString(`• ${text}`, { width: doc.page.width - 160, fontSize: 11 }) + 6;
        } else if (paragraph.startsWith('---')) {
          // Horizontal rule
          doc.moveTo(72, y + 4)
             .lineTo(doc.page.width - 72, y + 4)
             .strokeColor([60, 60, 80])
             .lineWidth(0.5)
             .stroke();
          y += 16;
        } else {
          // Handle inline bold (**text**)
          const parts = paragraph.split(/(\*\*[^*]+\*\*)/);
          if (parts.length > 1) {
            // Has inline bold - render as plain text (simplified)
            const plainText = paragraph.replace(/\*\*/g, '');
            doc.fillColor([200, 200, 200])
               .font('Helvetica')
               .fontSize(11)
               .text(plainText, 72, y, { width: doc.page.width - 144, lineGap: 4 });
            y += doc.heightOfString(plainText, { width: doc.page.width - 144, fontSize: 11, lineGap: 4 }) + 14;
          } else {
            // Regular paragraph
            doc.fillColor([200, 200, 200])
               .font('Helvetica')
               .fontSize(11)
               .text(paragraph, 72, y, { width: doc.page.width - 144, lineGap: 4 });
            y += doc.heightOfString(paragraph, { width: doc.page.width - 144, fontSize: 11, lineGap: 4 }) + 14;
          }
        }
      });

      // Page footer
      doc.fillColor([80, 80, 80])
         .font('Helvetica')
         .fontSize(9)
         .text(`Flip to Fortune | FlipLane  •  fliplane.net`, 72, doc.page.height - 50, {
           width: doc.page.width - 144,
           align: 'center'
         });
    });

    // =============================================
    // BACK COVER
    // =============================================
    doc.addPage();
    doc.rect(0, 0, doc.page.width, doc.page.height).fill([nr, ng, nb]);
    doc.rect(0, 0, doc.page.width, 6).fill([or, og, ob]);
    doc.rect(0, doc.page.height - 6, doc.page.width, 6).fill([gr, gg, gb]);

    // Tagline
    doc.fillColor([or, og, ob])
       .font('Helvetica-Bold')
       .fontSize(12)
       .text('YOU\'VE READ THE PLAYBOOK.', 72, 100, { align: 'center', width: doc.page.width - 144, letterSpacing: 2 });

    doc.fillColor([255, 255, 255])
       .font('Helvetica-Bold')
       .fontSize(36)
       .text('Now Enter the Lane.', 72, 130, { align: 'center', width: doc.page.width - 144 });

    doc.fillColor([160, 160, 160])
       .font('Helvetica')
       .fontSize(14)
       .text('Three ways to start making money with FlipLane today:', 72, 192, { align: 'center', width: doc.page.width - 144 });

    // CTA Cards
    const ctaCards = [
      { icon: '🚗', title: 'Buyer Lane', desc: 'Find your next car at dealer auction prices.', url: 'fliplane.net/buy', color: [or, og, ob] },
      { icon: '💰', title: 'Affiliate Lane', desc: 'Earn 50% commission. Zero investment.', url: 'fliplane.net/earn', color: [gr, gg, gb] },
      { icon: '🤝', title: 'Co-op Partner', desc: '$250 to start. Keep 100% of your profits.', url: 'fliplane.net/partner', color: [255, 200, 0] },
    ];

    ctaCards.forEach((card, i) => {
      const cardX = 72;
      const cardY = 248 + i * 100;
      const cardW = doc.page.width - 144;
      const cardH = 82;

      doc.roundedRect(cardX, cardY, cardW, cardH, 8).fill([25, 25, 45]);
      doc.roundedRect(cardX, cardY, 6, cardH, 3).fill(card.color);

      doc.fillColor([255, 255, 255])
         .font('Helvetica-Bold')
         .fontSize(16)
         .text(`${card.icon}  ${card.title}`, cardX + 22, cardY + 14);

      doc.fillColor([160, 160, 160])
         .font('Helvetica')
         .fontSize(12)
         .text(card.desc, cardX + 22, cardY + 38);

      doc.fillColor(card.color)
         .font('Helvetica-Bold')
         .fontSize(11)
         .text(card.url, cardX + 22, cardY + 58);
    });

    // Bottom tagline
    doc.fillColor([100, 100, 100])
       .font('Helvetica')
       .fontSize(11)
       .text('Smart money flow. Trusted access. AI-powered growth.', 72, doc.page.height - 80, { align: 'center', width: doc.page.width - 144 });

    doc.fillColor([or, og, ob])
       .font('Helvetica-Bold')
       .fontSize(13)
       .text('fliplane.net', 72, doc.page.height - 55, { align: 'center', width: doc.page.width - 144 });

    doc.end();

    stream.on('finish', () => {
      console.log(`✅ PDF generated: ${OUTPUT_PATH}`);
      const stats = fs.statSync(OUTPUT_PATH);
      console.log(`   Size: ${Math.round(stats.size / 1024)}KB`);
      resolve(OUTPUT_PATH);
    });

    stream.on('error', reject);
  });
}

generatePDF().catch(err => {
  console.error('PDF generation failed:', err);
  process.exit(1);
});
