#!/usr/bin/env node
/**
 * Creates 3 Flip Tips blog posts via the admin API.
 * Run: node scripts/create-blog-posts.js
 */

const https = require('https');
const http = require('http');

const BASE_URL = 'https://flipl.polsia.app';
const ADMIN_EMAIL = 'win@fliplane.net';
const ADMIN_PASSWORD = 'Inchaallah1$';

// ---------------------------------------------------------------------------
// Blog post content
// ---------------------------------------------------------------------------

const POST_1 = {
  title: 'How to Flip Your First Car — Complete Beginner\'s Guide',
  slug: 'how-to-flip-your-first-car-complete-beginners-guide',
  category: 'flip-tips',
  excerpt: 'No dealer license, no experience, no problem. Here\'s exactly how to find, buy, fix, and sell your first flip car for profit — with a real budget breakdown starting at $2K.',
  author: 'FlipLane Team',
  publish_date: '2026-04-15',
  seo_title: 'How to Flip Cars for Beginners — Step-by-Step Guide (2026)',
  seo_description: 'Learn how to flip your first car for profit with this complete beginner guide. Covers finding deals, budgeting $2K-$5K, repairs, and selling fast.',
  featured_image_url: 'https://images.pexels.com/photos/1149137/pexels-photo-1149137.jpeg?auto=compress&cs=tinysrgb&w=1200',
  published: true,
  body: `# How to Flip Your First Car — Complete Beginner's Guide

Most people think flipping cars requires a dealer license, a garage full of tools, or years of mechanic experience. None of that is true. What you actually need is capital, patience, and a process. This guide gives you the process.

---

## What Is Car Flipping?

Car flipping means buying a used vehicle below market value, making it more sellable (cleaning, minor repairs, staging), and reselling it for a profit. You're not building a business from scratch — you're arbitraging information. Most private sellers don't know what their car is worth. You do.

---

## Step 1: Set Your Budget

**Starting capital: $2,000–$5,000**

Here's a realistic breakdown for your first flip:

| Budget Line | Low End | High End |
|-------------|---------|----------|
| Purchase price | $1,200 | $3,500 |
| Basic repairs/detailing | $200 | $600 |
| Listing fees (Marketplace, Craigslist) | $0 | $50 |
| Contingency buffer | $200 | $400 |
| **Total out of pocket** | **$1,600** | **$4,550** |

**Target profit on your first flip: $500–$1,500.** Don't swing for the fences. Get the reps in.

---

## Step 2: Pick the Right Car

Not every car is flippable. Here's what to look for:

**Good flip candidates:**
- Japanese and domestic sedans/SUVs from 2005–2015 (Toyota Camry, Honda Accord, Ford F-150)
- 100K–180K miles (buyers expect it; price reflects it)
- Clean title only — skip salvage/rebuilt titles on your first few flips
- Common paint colors (silver, white, black, gray move fastest)

**Avoid on your first flip:**
- European luxury brands (BMWs, Audis, Mercedes) — repair costs kill margins
- High mileage trucks without documented maintenance
- Anything with a known transmission or engine issue unless you know what you're doing

---

## Step 3: Find the Deal

**Facebook Marketplace** is your best friend. Search within 50 miles for price drops, urgent sales ("moving," "need gone," "must sell"), and cars listed longer than 7 days.

**Other sources:**
- Craigslist (filter by owner, not dealer)
- OfferUp and CarGurus (private listings)
- Estate sales and auctions (see our auction guide for that path)

**The FlipLane co-op** gives members access to wholesale auction platforms like ADESA and Copart — where dealers buy. That's where the real deals are. Without co-op access, you're competing on the same public listings as everyone else.

---

## Step 4: Inspect Before You Buy

**Never buy blind.** Do these before every purchase:

1. **Run a free VIN check** on NMVTIS or a paid CarFax/AutoCheck report ($40 — worth it on a $3K purchase)
2. **Look for frame damage** — run your hand along the door gaps. Uneven gaps mean impact
3. **Check under the hood** — oil cap for milky residue (head gasket), dipstick for burnt smell
4. **Test all electronics** — windows, AC, heat, infotainment, reverse camera
5. **Take it to AutoZone** — free OBD scan. Any codes that light up get Googled before you buy

If you can't inspect it yourself, pay a local mechanic $50–$75 for a pre-purchase inspection. That $75 can save you a $1,200 mistake.

---

## Step 5: Negotiate the Price

Never pay asking price. Private sellers expect negotiation — they've already padded it in.

**The formula:** Research the car on KBB and Facebook Marketplace. Find the 10th percentile of similar listings. That's your target price. Offer 15–20% below asking and explain *why* (repairs needed, mileage, market comps).

Walk away if they won't move. There's always another deal.

---

## Step 6: Make It Sellable

You're not rebuilding the car. You're making it *feel* worth more than you paid:

- **Full detail, inside and out** ($80–$150 at a detail shop, or DIY with a weekend and $40 in products)
- **Fix the obvious stuff** — burned-out bulbs, cracked trim pieces, worn wiper blades ($50–$150 total)
- **Touch up paint chips** — Dupli-Color spray cans are $10 and take 30 minutes
- **New floor mats** if the originals are destroyed ($25 on Amazon)

**Rule:** If a buyer sees it and thinks "that's a lot of work," you lose. Remove all friction from their first impression.

---

## Step 7: Price It Right and List Fast

Price 10–15% above your target sell price. You're leaving room to negotiate. List on:

- Facebook Marketplace (free, massive reach)
- Craigslist (free for private sellers in most markets)
- OfferUp (free, mobile-first buyers)

**Listing checklist:**
- 15+ photos in natural daylight
- Odometer closeup
- Any recent maintenance docs front and center
- Honest description — buyers smell dishonesty; it kills deals

---

## Step 8: Close the Sale

Meet in a public place. Bring the title. Accept cash or Zelle — no personal checks.

If your state requires a bill of sale, download the template from your DMV website. Sign, counter-sign, done.

---

## Your First Flip: Realistic Expectations

Don't expect to retire on one car. Expect to:
- Make $500–$1,500 profit
- Learn what it actually takes
- Build confidence for the next one

Most successful flippers lose a little on their first deal. That's tuition. The pros flip 3–10 cars a month and know which cars move, which repairs pay, and which deals to skip.

---

## Want to Scale Faster?

**FlipLane** is a dealer co-op built for private car flippers who want access to real wholesale inventory — without a $15K dealer license. Members get auction access, mentorship, and a community of active flippers who share deals and strategies.

If you're serious about flipping, the co-op pays for itself on your first auction buy.

[Learn how FlipLane works →](https://fliplane.net)
`
};

const POST_2 = {
  title: 'Car Auction 101 — Buying Smart at ADESA, Copart & IAAI',
  slug: 'car-auction-101-buying-smart-at-adesa-copart-iaai',
  category: 'flip-tips',
  excerpt: 'ADESA, Copart, and IAAI are where dealers get their inventory — and where the real money is made. Here\'s how to register, bid smart, dodge hidden fees, and walk away with a deal.',
  author: 'FlipLane Team',
  publish_date: '2026-04-16',
  seo_title: 'Car Auction Guide: How to Buy at ADESA, Copart & IAAI (2026)',
  seo_description: 'Step-by-step guide to buying cars at ADESA, Copart, and IAAI auctions. Learn to register, bid, inspect, avoid hidden fees, and flip for profit.',
  featured_image_url: 'https://images.pexels.com/photos/3806288/pexels-photo-3806288.jpeg?auto=compress&cs=tinysrgb&w=1200',
  published: true,
  body: `# Car Auction 101 — Buying Smart at ADESA, Copart & IAAI

Public car prices are retail. Auction prices are wholesale. That gap is where car flippers make their money.

The problem? Dealer-only auctions like ADESA, Copart, and IAAI require a dealer license to access — and a dealer license costs $10,000–$20,000 to obtain, plus ongoing fees. That barrier keeps the average flipper buying on Facebook Marketplace like everyone else.

This guide covers how to work with these platforms, what to watch for, and how to get in without the license barrier.

---

## The Big Three: What Makes Each Different

### ADESA
ADESA (now part of OPENLANE) is the largest franchised dealer auction network in North America. They run primarily **run-and-drive vehicles** — cars off lease, off-rental, or dealer trade-ins. Most are in decent condition. Great for flippers who want clean title, driveable inventory.

**Best for:** Lease returns, low-mileage rentals, dealer overstock

### Copart
Copart runs primarily **insurance salvage and total-loss vehicles** — cars after accidents, floods, theft recoveries. Many are repairable. Some aren't. The prices are low; the risk is higher.

**Best for:** Experienced flippers comfortable with repairs, mechanics, parts cars

### IAAI (Insurance Auto Auctions)
IAAI is similar to Copart — insurance salvage, total loss, off-lease end-of-life vehicles. They recently merged with Copart under the same parent company but maintain separate platforms for now.

**Best for:** Same as Copart — salvage, parts, heavy repairers

---

## How to Register (The Honest Truth)

All three require a **dealer license** for buying access. Here's what that actually costs:

| Route | Cost | Time |
|-------|------|------|
| Get your own dealer license | $8,000–$20,000 (bond + lot + fees) | 3–6 months |
| Find a dealer broker | $150–$600/car in fees | Immediate |
| Join a co-op like FlipLane | ~$250/mo membership | Same week |

The co-op model is the smart play for most private flippers. **FlipLane** gives members direct auction access under the co-op's dealer license for a monthly membership — you buy your car, we facilitate the title transfer, done. That $250 compares to a $15,000 license you'd need to get the same access.

---

## Bidding Strategy: Don't Get Caught Up in the Moment

Auction environments are designed to make you spend more. The auctioneer is fast. Other bidders are moving. The energy is real. Here's how to keep your head:

### Pre-Auction Research (Non-Negotiable)

Before you bid on anything:

1. **Pull the VIN** — Run it through NMVTIS or a paid service. Know the title history.
2. **Check comparables** — What's the same car selling for on Facebook Marketplace and KBB in your market?
3. **Set your max bid** — Based on comps minus repair estimate minus your target profit. Write it down.
4. **Stick to it** — Your max bid is your ceiling. Period. If someone bids $100 over, let them have it.

### The All-In Cost Formula

Don't just look at the hammer price. Real cost includes:

| Fee | Typical Range |
|-----|---------------|
| Auction buyer's fee | $200–$800 |
| Transportation/tow | $100–$400 (if not local) |
| Gate/admin fees | $50–$150 |
| Storage (if you don't pick up same day) | $30–$75/day |
| Estimate repairs | Variable |

A $3,000 hammer price can easily become $4,200 landed cost before you touch the car.

---

## Inspection Tips for Auction Cars

**Online-only auctions (Copart, IAAI):** You're bidding on photos and a condition report. The condition reports are graded by staff, not mechanics — take them as a starting point, not gospel.

**What to check in condition reports:**
- Primary/secondary damage codes (look these up — "1/2 front end structural" means frame)
- Odometer status (actual vs. not actual)
- Has it been started? Run? Driven?
- Number of keys listed

**In-person inspection days:** ADESA runs preview days. Copart allows walkthroughs at most locations. **Show up.** Walk the car. Start it. Lift the hood. Check under for frame damage with a flashlight. Bring a mechanic if you can.

**Pro tip:** At Copart/IAAI, bring a Bluetooth OBD-II scanner. Plug it in during inspection. You'll know every stored code before you bid.

---

## Common Rookie Mistakes

**Overbidding on excitement** — You've been watching this clean Accord for two days. The auction starts at $500. You're in it. Stop. Stick to your max.

**Ignoring transportation costs** — "It's only $200 to transport" adds up. Know these costs before bidding.

**Buying a flood car without knowing it** — Flood damage isn't always obvious in condition reports. Look for rust on seat rail bolts, musty smell in photos (sometimes visible water lines on carpet), corrosion under the hood. When in doubt, skip it.

**Not knowing your market** — You need to know what that car sells for *in your city*, not nationally. Facebook Marketplace is your market research tool. Check it before every bid.

---

## How Titles Work at Auction

Clean title cars → standard title transfer. Takes 2–4 weeks typically.

Salvage/rebuilt cars → you get a salvage title. This affects resale value *significantly*. To get a rebuilt title in most states, you'll need a state inspection showing the car is roadworthy. This is a process. Know your state's rules before you bid on salvage.

**Title washing** (registering a salvage car in a state with looser rules to get a clean title) is illegal. Don't do it.

---

## Your First Auction Buy: Play It Safe

For your first auction purchase:
- **Start with ADESA or a franchised dealer auction** — run-and-drive, cleaner inventory, fewer surprises
- **Buy something common** — Camry, Accord, F-150. You know the demand. You know the parts costs.
- **Set your all-in budget before the auction opens.** Emotion kills margins.

---

## FlipLane Co-op: Your Shortcut to Auction Access

FlipLane members get access to wholesale auction platforms under our dealer license — no $15K investment required. Monthly membership, pick your cars, we handle the dealer paperwork.

It's how our members compete with dealers from day one.

[See how co-op membership works →](https://fliplane.net)
`
};

const POST_3 = {
  title: 'The Art of the Lowball — Negotiation Tactics for Car Flippers',
  slug: 'the-art-of-the-lowball-negotiation-tactics-for-car-flippers',
  category: 'flip-tips',
  excerpt: 'A lowball offer isn\'t rude — it\'s a business move. Learn the psychological frameworks, scripts, and walk-away triggers that turn overpriced listings into profitable flips.',
  author: 'FlipLane Team',
  publish_date: '2026-04-17',
  seo_title: 'Car Negotiation Tactics for Flippers — How to Lowball Smart (2026)',
  seo_description: 'Master car flipping negotiation with proven lowball tactics, psychology frameworks, and scripts. Know when to push, when to anchor, and when to walk away.',
  featured_image_url: 'https://images.pexels.com/photos/1170412/pexels-photo-1170412.jpeg?auto=compress&cs=tinysrgb&w=1200',
  published: true,
  body: `# The Art of the Lowball — Negotiation Tactics for Car Flippers

Most people hate negotiating. They feel awkward offering less than asking price. They worry about offending the seller. They accept the first counter or walk away when they shouldn't.

Professional car flippers feel none of that. A lowball offer isn't rude — it's a business move. And done right, it's the single biggest lever on your profit margin.

This guide gives you the framework, the scripts, and the psychology to negotiate like you've done it a hundred times — even if this is your first flip.

---

## The Mindset Shift That Changes Everything

**You are not buying a car. You are making a business investment.**

A $500 drop in purchase price is $500 extra in your pocket at the end. Every dollar you negotiate down is guaranteed profit before you've touched the car.

Sellers don't think this way. They're emotionally attached to their car. They've set an asking price based on feelings, not data. Your job is to provide data — calmly, confidently, without drama.

You're not attacking them. You're solving a problem: they have a car they want to sell; you have cash. The question is just price.

---

## Before You Negotiate: Do Your Research

**Never walk into a negotiation without comps.** Before you contact a seller:

1. **Check Facebook Marketplace** — Search the same car (same year, mileage range, condition) in your market. Screenshot 3–5 listings.
2. **Check KBB Private Party Value** — This is often *above* what cars actually sell for, but it's useful as a reference the seller respects.
3. **Estimate repairs** — If you can see from photos that it needs tires, brakes, paint work — price those out before you offer.
4. **Calculate your max offer** — (Market comp) minus (repair estimate) minus (your target profit). That's your ceiling.

Walk in knowing your number. If the negotiation doesn't get there, you walk.

---

## The Anchor Principle

**Whoever throws out the first number owns the range.**

When a seller asks "what are you willing to pay?" — most buyers either deflect or offer their ceiling. Both are wrong.

**Open below your actual ceiling.** If your max is $4,000, offer $3,200. You've just anchored the negotiation 20% below your real limit. Even if they counter to $3,800, you have room to meet in the middle at $3,500 — which is still below your max.

The anchor works because humans negotiate in percentages from a starting point. A seller seeing $3,200 will think "maybe $3,700?" — not "this offer is disrespectful."

---

## Scripts That Actually Work

### Opening offer (text/phone)
*"Hey, I came out to look at the car — appreciate the time. Based on what I'm seeing and comparable listings in the area, I can do $[X]. Happy to pay cash today if that works for you."*

**Why it works:** You're giving a reason (comps), offering cash (immediate certainty), and not being aggressive. No emotion.

---

### When they say "best I can do is $Y" (above your target)
*"I hear you. I'm not trying to lowball — I pulled three listings this week in our area and [similar car] is moving at $[Z]. I'm already at the top of what makes sense for me. Would $[X+200] make it work?"*

**Why it works:** You've shown your homework. You've moved slightly (they feel progress). You're not anchoring to their number.

---

### The repair anchor move
*"Appreciate you showing me the car. I noticed [issue 1] and [issue 2] — those are probably $400–600 to sort out right. Factoring that in, I can go $[lower offer]. Does that work?"*

**Why it works:** You're not making up problems. You found real ones, you priced them, and you've given the seller a logical reason for your lower number.

---

### When they won't budge at all
*"Understood. I respect that. Here's my number — $[X] — if that works in the next couple days, shoot me a message. If not, no hard feelings."*

**Why it works:** You leave the door open. You show no desperation. Many sellers will follow up 3–5 days later when the car hasn't sold.

---

## When to Walk Away

**The rule:** If you can't hit your target price, walk. Always.

This is harder than it sounds. You've driven to see the car. You've done the research. You've spent an hour on it. Sunk cost is real. The solution is to pre-commit your walk-away point before you go — not in the moment.

**Walk away when:**
- They won't come within 10% of your max bid after two counters
- New damage shows up on inspection that wasn't in photos
- The title has issues you didn't know about
- The seller seems sketchy (trust your gut)
- Your gut says the repair list is longer than you can price

**There is always another car.** The one you're standing in front of is not the last deal on the market.

---

## Psychological Patterns to Recognize

**The fake walk:** Seller says "forget it, I have another buyer coming." Usually not true. If you're at a reasonable price, hold your position. If they're serious, they'll call you.

**The slow yes:** Seller says "I'll think about it" repeatedly. They're interested but need to feel in control of the timeline. Leave your offer on the table clearly and follow up once, 48 hours later.

**The emotional anchor:** "I put $3,000 into this car last year." Not your problem. You're buying the car at today's market value, not reimbursing their maintenance history. Acknowledge it, then redirect to comps.

**Lowball fatigue:** If you're making lots of offers and getting rejected, check your numbers — you might be pricing too aggressively for your market. Adjust comps research.

---

## The Follow-Up Play

Most deals don't close on first contact. The sellers who reject you on Day 1 sometimes become your best deals on Day 7.

**Set a reminder.** After a negotiation that went nowhere, calendar a 5-day follow-up: *"Hey, just checking if that [car] is still available — I'm still interested at $[X] if it works."*

That follow-up text has closed more deals than any in-person negotiation tactic. Sellers get tired of dealing with flakes, low-quality inquiries, and no-shows. A serious cash buyer who follows up professionally stands out.

---

## The Ethics of Lowballing

Lowballing is not deception. You're not lying about problems, hiding your intentions, or manipulating anyone. You're making a below-asking offer backed by market data.

**Don't cross these lines:**
- Don't fabricate repair costs that aren't real
- Don't waste a seller's time if you're not actually buying
- Don't bait-and-switch (agree to a price, then renegotiate at pickup)

Those tactics burn your reputation in local markets — which are smaller than you think.

---

## Put It to Work

Every flip starts with the negotiation. Master this, and every other step in the process gets easier — because your margin is baked in from the start.

Good negotiators don't find better deals. They *make* better deals out of the same listings everyone else is looking at.

---

**FlipLane** trains co-op members in sourcing, negotiation, auction buying, and flipping fundamentals. If you want the community and the tools to flip cars at a professional level, we're here.

[Join the FlipLane co-op →](https://fliplane.net)
`
};

// ---------------------------------------------------------------------------
// HTTP helper
// ---------------------------------------------------------------------------

function request(method, path, data, cookieHeader) {
  return new Promise((resolve, reject) => {
    const url = new URL(BASE_URL + path);
    const isHttps = url.protocol === 'https:';
    const lib = isHttps ? https : http;
    const body = data ? JSON.stringify(data) : null;
    const headers = {
      'Content-Type': 'application/json',
      ...(cookieHeader ? { Cookie: cookieHeader } : {}),
      ...(body ? { 'Content-Length': Buffer.byteLength(body) } : {}),
    };

    const options = {
      hostname: url.hostname,
      port: url.port || (isHttps ? 443 : 80),
      path: url.pathname + url.search,
      method,
      headers,
    };

    const req = lib.request(options, (res) => {
      let raw = '';
      res.on('data', (c) => (raw += c));
      res.on('end', () => {
        const setCookie = res.headers['set-cookie'] || [];
        let json;
        try { json = JSON.parse(raw); } catch { json = { raw }; }
        resolve({ status: res.status || res.statusCode, json, setCookie });
      });
    });

    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

async function run() {
  // 1. Login
  console.log('🔐 Logging in as admin...');
  const loginRes = await request('POST', '/api/admin/login', {
    email: ADMIN_EMAIL,
    password: ADMIN_PASSWORD,
  });
  console.log('   Login status:', loginRes.status);
  if (loginRes.status !== 200 || !loginRes.json.success) {
    throw new Error('Login failed: ' + JSON.stringify(loginRes.json));
  }

  // Extract cookie
  const cookieHeader = loginRes.setCookie.map((c) => c.split(';')[0]).join('; ');
  console.log('   Cookie obtained:', cookieHeader.substring(0, 50) + '...');

  // 2. Create posts
  const posts = [POST_1, POST_2, POST_3];
  for (const post of posts) {
    console.log(`\n📝 Creating: "${post.title}"`);
    const res = await request('POST', '/api/admin/blog/posts', post, cookieHeader);
    if (res.status === 201 && res.json.success) {
      console.log(`   ✅ Created! ID: ${res.json.post.id}, slug: ${res.json.post.slug}`);
    } else if (res.status === 409) {
      console.log(`   ⚠️  Already exists (slug conflict) — skipping`);
    } else {
      console.error(`   ❌ Failed (${res.status}):`, JSON.stringify(res.json));
    }
  }

  console.log('\n✨ Done! Check https://flipl.polsia.app/blog');
}

run().catch((err) => {
  console.error('Fatal error:', err);
  process.exit(1);
});
