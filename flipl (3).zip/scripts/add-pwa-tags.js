/**
 * Add PWA meta tags and service worker registration to all HTML files
 */

const fs = require('fs');
const path = require('path');

const PUBLIC_DIR = path.join(__dirname, '..', 'public');

// PWA tags to inject into <head>
const PWA_HEAD_TAGS = `    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="FlipLane">
    <link rel="manifest" href="/manifest.json">
    <link rel="apple-touch-icon" href="/icons/icon-192x192.png">`;

// Service worker registration script (injected before </body>)
const SW_REGISTRATION = `
    <script>
      if ('serviceWorker' in navigator) {
        window.addEventListener('load', function() {
          navigator.serviceWorker.register('/sw.js').then(function(registration) {
            console.log('FlipLane SW registered:', registration.scope);
          }).catch(function(error) {
            console.log('FlipLane SW registration failed:', error);
          });
        });
      }
    </script>`;

function getHTMLFiles(dir) {
  const results = [];
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      // Skip js/ and data/ directories
      if (entry.name === 'js' || entry.name === 'data' || entry.name === 'icons') continue;
      results.push(...getHTMLFiles(fullPath));
    } else if (entry.isFile() && entry.name.endsWith('.html')) {
      results.push(fullPath);
    }
  }
  return results;
}

function injectHeadTag(content, tag) {
  // Only inject if not already present
  if (content.includes('apple-mobile-web-app-capable')) return content;
  if (content.includes('rel="manifest"') && content.includes('manifest.json')) return content;

  // Find </head> and insert before it
  const headMatch = content.match(/<\/head>/i);
  if (headMatch) {
    const insertPos = headMatch.index;
    return content.slice(0, insertPos) + tag + '\n' + content.slice(insertPos);
  }
  return content;
}

function injectSWRegistration(content, script) {
  // Only inject if not already registered
  if (content.includes('serviceWorker.register')) return content;

  // Find </body> and insert before it
  const bodyMatch = content.match(/<\/body>/i);
  if (bodyMatch) {
    const insertPos = bodyMatch.index;
    return content.slice(0, insertPos) + script + '\n' + content.slice(insertPos);
  }
  return content;
}

function processFile(filePath) {
  let content = fs.readFileSync(filePath, 'utf8');
  let modified = false;

  const originalContent = content;

  content = injectHeadTag(content, PWA_HEAD_TAGS);
  if (content !== originalContent) modified = true;

  const afterHead = content;
  content = injectSWRegistration(content, SW_REGISTRATION);
  if (content !== afterHead) modified = true;

  if (modified) {
    fs.writeFileSync(filePath, content, 'utf8');
    console.log(`Updated: ${path.relative(PUBLIC_DIR, filePath)}`);
  }
}

const htmlFiles = getHTMLFiles(PUBLIC_DIR);
console.log(`Found ${htmlFiles.length} HTML files`);
htmlFiles.forEach(processFile);
console.log('Done!');