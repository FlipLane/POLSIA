#!/usr/bin/env node
/**
 * scripts/send-applicant-followup.js
 *
 * Sends personalized follow-up emails to co-op applicants stuck in 'applied' status.
 * Uses Polsia platform email bridge (same as server.js sendEmail).
 *
 * Applicants sourced from: SELECT * FROM members WHERE status = 'applied'
 * Run date: 2026-03-27
 */

const axios = require('axios');

const FROM = 'FlipLane <flipl@polsia.app>';
const REPLY_TO = 'win@fliplane.net';
const PARTNER_URL = 'https://fliplane.net/partner';

// Real applicants only — test accounts excluded (qa-apply@polsia.app, test-partner@test.com)
const APPLICANTS = [
  {
    id: 1,
    name: 'Ilyas zouheir',
    firstName: 'Ilyas',
    email: 'zouheirilyas@gmail.com',
    experience: 'experienced',
    appliedAt: '2026-03-07',
    uploadedId: true,
  }
];

function buildEmailHtml(applicant) {
  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin:0; padding:0; background:#f5f5f5; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f5f5; padding: 40px 20px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff; border-radius:8px; overflow:hidden; max-width:600px; width:100%;">

          <!-- Header -->
          <tr>
            <td style="background:#1a1a2e; padding: 32px 40px; text-align:center;">
              <p style="margin:0; font-size:22px; font-weight:700; color:#ffffff; letter-spacing:1px;">FlipLane</p>
              <p style="margin:6px 0 0; font-size:13px; color:#888cb4;">The AI-Powered Used Car Co-op</p>
            </td>
          </tr>

          <!-- Body -->
          <tr>
            <td style="padding: 40px 40px 32px;">
              <p style="margin:0 0 20px; font-size:16px; color:#1a1a2e;">Hey ${applicant.firstName},</p>

              <p style="margin:0 0 16px; font-size:15px; line-height:1.7; color:#333333;">
                You applied to join FlipLane's Co-op Partner network back on March 7th — and we dropped the ball on following up. That's on us.
              </p>

              <p style="margin:0 0 16px; font-size:15px; line-height:1.7; color:#333333;">
                ${applicant.uploadedId ? "You've already submitted your ID, which tells us you're serious. Let's get you across the finish line." : "Your application is ready to move forward. Let's get you activated."}
              </p>

              <!-- Benefits -->
              <table width="100%" cellpadding="0" cellspacing="0" style="background:#f8f9ff; border-radius:6px; padding:0; margin: 24px 0;">
                <tr>
                  <td style="padding: 24px;">
                    <p style="margin:0 0 14px; font-size:13px; font-weight:700; color:#1a1a2e; text-transform:uppercase; letter-spacing:1px;">What You Get as a Co-op Partner</p>
                    <table width="100%">
                      <tr>
                        <td style="padding:6px 0; font-size:14px; color:#333333; line-height:1.5;">
                          <span style="color:#4f6ef7; font-weight:700;">✓</span>&nbsp; Dealer credentials — no $15K+ state license required
                        </td>
                      </tr>
                      <tr>
                        <td style="padding:6px 0; font-size:14px; color:#333333; line-height:1.5;">
                          <span style="color:#4f6ef7; font-weight:700;">✓</span>&nbsp; Full ADESA auction access (50,000+ vehicles weekly)
                        </td>
                      </tr>
                      <tr>
                        <td style="padding:6px 0; font-size:14px; color:#333333; line-height:1.5;">
                          <span style="color:#4f6ef7; font-weight:700;">✓</span>&nbsp; Nationwide transaction processing — we handle the backend
                        </td>
                      </tr>
                      <tr>
                        <td style="padding:6px 0; font-size:14px; color:#333333; line-height:1.5;">
                          <span style="color:#4f6ef7; font-weight:700;">✓</span>&nbsp; Keep 100% profit on your own deals
                        </td>
                      </tr>
                      <tr>
                        <td style="padding:6px 0; font-size:14px; color:#333333; line-height:1.5;">
                          <span style="color:#4f6ef7; font-weight:700;">✓</span>&nbsp; Partner shipping network included
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>

              <p style="margin:0 0 16px; font-size:15px; line-height:1.7; color:#333333;">
                One-time membership fee is <strong>$250</strong>. That's it. No monthly fees, no revenue splits on your deals.
              </p>

              <p style="margin:0 0 28px; font-size:15px; line-height:1.7; color:#333333;">
                Click below to complete your membership and get activated:
              </p>

              <!-- CTA -->
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="center">
                    <a href="${PARTNER_URL}"
                       style="display:inline-block; background:#4f6ef7; color:#ffffff; font-size:15px; font-weight:700;
                              padding:14px 36px; border-radius:6px; text-decoration:none; letter-spacing:0.5px;">
                      Complete My Membership →
                    </a>
                  </td>
                </tr>
              </table>

              <p style="margin:28px 0 0; font-size:14px; line-height:1.7; color:#666666;">
                Questions? Just reply to this email — it goes straight to the team.
              </p>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="padding: 24px 40px; border-top: 1px solid #eeeeee; text-align:center;">
              <p style="margin:0; font-size:12px; color:#999999;">
                FlipLane · Byrd Dawgs Automotive Group<br>
                <a href="${PARTNER_URL}" style="color:#4f6ef7; text-decoration:none;">fliplane.net/partner</a>
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>
  `.trim();
}

/**
 * Send email via Polsia platform email bridge (matches server.js sendEmail pattern)
 */
async function sendFollowupEmail(applicant) {
  const subject = `${applicant.firstName}, your FlipLane co-op application — next steps`;
  const html = buildEmailHtml(applicant);

  const apiKey = process.env.POLSIA_API_KEY || process.env.POLSIA_API_TOKEN;
  const companySlug = process.env.POLSIA_ANALYTICS_SLUG || 'flipl';

  if (!apiKey) {
    throw new Error('No POLSIA_API_KEY configured — cannot send emails');
  }

  // Try Polsia bridge endpoints (same pattern as server.js)
  const endpoints = [
    {
      url: 'https://polsia.com/mcp/postmark/send_email',
      headers: { 'Authorization': `Bearer ${apiKey}`, 'Content-Type': 'application/json' }
    },
    {
      url: 'https://polsia.com/mcp/company_email/send_company_email',
      headers: { 'Authorization': `Bearer ${apiKey}`, 'Content-Type': 'application/json' }
    },
    {
      url: 'https://polsia.com/mcp/postmark/send_email',
      headers: { 'X-API-Key': apiKey, 'Content-Type': 'application/json' }
    },
  ];

  const payload = {
    to: applicant.email,
    subject,
    html_body: html,
    from: FROM,
    reply_to: REPLY_TO,
    tag: 'applicant-followup',
    company_slug: companySlug,
    transactional: true,
  };

  let lastError;
  for (const ep of endpoints) {
    try {
      const res = await axios.post(ep.url, payload, { headers: ep.headers, timeout: 15000 });
      if (res.data && (res.data.success || res.data.MessageID || res.status === 200)) {
        return { success: true, data: res.data, endpoint: ep.url };
      }
    } catch (err) {
      lastError = err;
      console.log(`  [Bridge] ${ep.url} failed: ${err.response?.status || err.message}`);
    }
  }

  throw lastError || new Error('All Polsia bridge endpoints failed');
}

async function main() {
  console.log(`[Applicant Followup] Starting — ${APPLICANTS.length} real applicant(s) to contact`);
  console.log(`[Applicant Followup] Skipped test accounts: qa-apply@polsia.app, test-partner@test.com`);
  console.log(`[Applicant Followup] Using Polsia platform email bridge`);
  console.log('');

  const apiKey = process.env.POLSIA_API_KEY || process.env.POLSIA_API_TOKEN;
  if (!apiKey) {
    console.error('[Applicant Followup] FATAL: No POLSIA_API_KEY — cannot send emails');
    process.exit(1);
  }

  const results = [];

  for (const applicant of APPLICANTS) {
    console.log(`[Applicant Followup] Sending to ${applicant.name} <${applicant.email}>...`);
    try {
      const data = await sendFollowupEmail(applicant);
      console.log(`[Applicant Followup] ✅ Sent via ${data.endpoint}`);
      results.push({
        applicant_id: applicant.id,
        name: applicant.name,
        email: applicant.email,
        status: 'sent',
        endpoint: data.endpoint,
      });
    } catch (err) {
      const errMsg = err.response?.data?.Message || err.message;
      console.error(`[Applicant Followup] ❌ Failed for ${applicant.email}: ${errMsg}`);
      results.push({
        applicant_id: applicant.id,
        name: applicant.name,
        email: applicant.email,
        status: 'failed',
        error: errMsg
      });
    }
  }

  console.log('');
  console.log('[Applicant Followup] === SUMMARY ===');
  const sent = results.filter(r => r.status === 'sent').length;
  const failed = results.filter(r => r.status === 'failed').length;
  console.log(`  Sent:   ${sent}`);
  console.log(`  Failed: ${failed}`);
  console.log('');
  console.log(JSON.stringify(results, null, 2));

  return results;
}

main().catch(err => {
  console.error('[Applicant Followup] Unexpected error:', err.message);
  process.exit(1);
});
