#!/usr/bin/env node
// Add FlipLane logo to email templates in server.js
const fs = require('fs');
const path = require('path');

const serverPath = path.join(__dirname, '..', 'server.js');
let content = fs.readFileSync(serverPath, 'utf8');
const original = content;

// Use split/join to replace all occurrences safely (no infinite loop risk)

// Pattern 1: Flip to Fortune email footer (dark #1A1A2E bg, footer row)
// OLD doesn't appear in NEW so safe to use split/join
const FOOT_OLD = 'background:#1A1A2E;padding:20px 40px;text-align:center;"><p style="margin:0 0 4px;color:#ffffff;font-size:13px;font-weight:bold;">FlipLane</p>';
const FOOT_NEW = 'background:#1A1A2E;padding:20px 40px;text-align:center;"><img src="https://fliplane.net/images/flip-lane-logo.png" alt="FlipLane" height="40" style="height:40px;width:auto;display:block;margin:0 auto 10px;"><p style="margin:0 0 4px;color:#ffffff;font-size:13px;font-weight:bold;">FlipLane</p>';
const parts1 = content.split(FOOT_OLD);
const footCount = parts1.length - 1;
content = parts1.join(FOOT_NEW);
console.log('Flip to Fortune footer logo added:', footCount, 'locations');

// Pattern 2: Applicant follow-up email header — use wider context to avoid matching the replacement
// The header row: `<tr><td style="background:#1a1a2e;padding:32px 40px;text-align:center;">\n  <p style=...>FlipLane</p>`
const HEAD_OLD = '<tr><td style="background:#1a1a2e;padding:32px 40px;text-align:center;">\n  <p style="margin:0;font-size:22px;font-weight:700;color:#fff;letter-spacing:1px;">FlipLane</p>';
const HEAD_NEW = '<tr><td style="background:#1a1a2e;padding:32px 40px;text-align:center;">\n  <img src="https://fliplane.net/images/flip-lane-logo.png" alt="FlipLane" height="48" style="height:48px;width:auto;display:block;margin:0 auto 12px;">\n  <p style="margin:0;font-size:22px;font-weight:700;color:#fff;letter-spacing:1px;">FlipLane</p>';
const parts2 = content.split(HEAD_OLD);
const headCount = parts2.length - 1;
content = parts2.join(HEAD_NEW);
console.log('Applicant email header logo added:', headCount, 'locations');

if (content !== original) {
  fs.writeFileSync(serverPath, content, 'utf8');
  console.log('server.js saved with', (footCount + headCount), 'email logo updates');
} else {
  console.log('No changes made — check patterns');
}
