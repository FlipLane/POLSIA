const fs = require('fs');

const files = [
  'public/index.html',
  'public/join.html',
  'public/partner.html',
  'public/earn.html',
  'public/pricing.html',
  'public/flip-to-fortune.html',
  'public/terms.html',
  'public/buy.html',
  'public/blog.html',
  'public/blog-post.html',
  'public/apply.html'
];

let count = 0;
files.forEach(f => {
  if (fs.existsSync(f)) {
    const orig = fs.readFileSync(f, 'utf8');
    const updated = orig.split('og-image.svg').join('og-image.png');
    const changed = updated.length !== orig.length || updated !== orig;
    if (changed) {
      fs.writeFileSync(f, updated);
      console.log('Updated:', f);
      count++;
    } else {
      console.log('No change:', f);
    }
  } else {
    console.log('Not found:', f);
  }
});
console.log('Total updated:', count);
