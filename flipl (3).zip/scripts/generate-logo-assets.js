/**
 * generate-logo-assets.js
 * Downloads the FlipLane logo and generates all required image assets:
 * - favicon.svg (shield mark)
 * - og-image.svg (full OG image)
 * - logo file in public/images/
 */

const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');

const LOGO_URL = 'https://pub-629428d185ca4960a0a73c850d32294b.r2.dev/company_20624/images/03cbe6e7-d1aa-4a26-b722-6158d341e9c5.png';
const PUBLIC_DIR = path.join(__dirname, '..', 'public');
const IMAGES_DIR = path.join(PUBLIC_DIR, 'images');

// Ensure images directory exists
if (!fs.existsSync(IMAGES_DIR)) {
  fs.mkdirSync(IMAGES_DIR, { recursive: true });
}

// Download a file from a URL
function downloadFile(url, destPath) {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(destPath);
    const protocol = url.startsWith('https') ? https : http;

    console.log(`Downloading ${url} -> ${destPath}`);

    protocol.get(url, (response) => {
      if (response.statusCode === 301 || response.statusCode === 302) {
        file.close();
        return downloadFile(response.headers.location, destPath).then(resolve).catch(reject);
      }
      if (response.statusCode !== 200) {
        file.close();
        return reject(new Error(`HTTP ${response.statusCode}`));
      }
      response.pipe(file);
      file.on('finish', () => {
        file.close();
        resolve();
      });
    }).on('error', (err) => {
      fs.unlink(destPath, () => {});
      reject(err);
    });
  });
}

// Create the favicon SVG with the FL shield mark
function createFaviconSvg() {
  const svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" width="32" height="32">
  <defs>
    <linearGradient id="shieldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#00e676;stop-opacity:1" />
      <stop offset="100%" style="stop-color:#00c853;stop-opacity:1" />
    </linearGradient>
  </defs>
  <!-- Dark background -->
  <rect width="32" height="32" rx="6" fill="#0a0a0a"/>
  <!-- Shield shape -->
  <path d="M8 4 L24 4 L24 18 Q24 26 16 29 Q8 26 8 18 Z" fill="#00e676" opacity="0.9"/>
  <!-- FL monogram -->
  <text x="16" y="22" font-family="Georgia, 'Times New Roman', serif" font-weight="700" font-size="13" fill="#0a0a0a" text-anchor="middle">FL</text>
</svg>`;

  const faviconPath = path.join(PUBLIC_DIR, 'favicon.svg');
  fs.writeFileSync(faviconPath, svg);
  console.log('Created favicon.svg');
}

// Create OG image (1200x630) as SVG
function createOgImageSvg() {
  const svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630" viewBox="0 0 1200 630">
  <!-- Dark background -->
  <rect width="1200" height="630" fill="#0a0a0a"/>

  <!-- Subtle grid pattern -->
  <defs>
    <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
      <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#1a1a1a" stroke-width="1"/>
    </pattern>
    <linearGradient id="greenGlow" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#00e676;stop-opacity:0.3" />
      <stop offset="100%" style="stop-color:#00c853;stop-opacity:0.05" />
    </linearGradient>
  </defs>
  <rect width="1200" height="630" fill="url(#grid)"/>

  <!-- Radial glow behind logo -->
  <ellipse cx="600" cy="280" rx="400" ry="200" fill="url(#greenGlow)"/>

  <!-- Shield/logo placeholder - large FL mark -->
  <rect x="500" y="140" width="200" height="220" rx="20" fill="#00e676" opacity="0.95"/>
  <text x="600" y="290" font-family="Georgia, 'Times New Roman', serif" font-weight="700" font-size="120" fill="#0a0a0a" text-anchor="middle">FL</text>

  <!-- Wordmark -->
  <text x="600" y="430" font-family="'Space Grotesk', Arial, sans-serif" font-weight="700" font-size="72" fill="#ffffff" text-anchor="middle">FlipLane</text>

  <!-- Tagline -->
  <text x="600" y="490" font-family="'Space Grotesk', Arial, sans-serif" font-weight="400" font-size="28" fill="#00e676" text-anchor="middle">The $250 Dealership</text>

  <!-- Bottom tagline -->
  <text x="600" y="590" font-family="'Space Grotesk', Arial, sans-serif" font-weight="400" font-size="20" fill="#555555" text-anchor="middle">fliplane.net</text>
</svg>`;

  const ogPath = path.join(PUBLIC_DIR, 'og-image.svg');
  fs.writeFileSync(ogPath, svg);
  console.log('Created og-image.svg (1200x630)');
}

async function main() {
  try {
    // Download the actual logo
    const logoDest = path.join(IMAGES_DIR, 'flip-lane-logo.png');
    await downloadFile(LOGO_URL, logoDest);
    console.log('Downloaded flip-lane-logo.png');

    // Create favicon SVG
    createFaviconSvg();

    // Create OG image SVG (for modern browsers)
    createOgImageSvg();

    console.log('\nAll logo assets generated successfully!');
  } catch (err) {
    console.error('Error generating assets:', err.message);

    // Still create SVGs even if download fails
    createFaviconSvg();
    createOgImageSvg();
    console.log('Created fallback SVG assets (logo download failed)');
  }
}

main();