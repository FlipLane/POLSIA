#!/usr/bin/env node
// One-time script: add second Meta Pixel to all HTML files
const fs = require('fs');
const path = require('path');

const NEW_PIXEL_ID = '1297854672218437';
const EXISTING_PIXEL_ID = '1498257195051913';

const htmlFiles = [
  'public/index.html',
  'public/apply.html',
  'public/buy.html',
  'public/payment-success.html',
  'public/partner.html',
  'public/join.html',
  'public/flip-to-fortune.html',
  'public/earn.html',
  'public/dashboard.html',
  'public/certification.html',
  'public/blog.html',
  'public/blog-post.html',
  'public/terms.html',
  'public/pricing.html',
];

let updated = 0;
let skipped = 0;

for (const file of htmlFiles) {
  if (!fs.existsSync(file)) {
    console.log(`SKIP (not found): ${file}`);
    skipped++;
    continue;
  }

  let content = fs.readFileSync(file, 'utf8');

  if (content.includes(NEW_PIXEL_ID)) {
    console.log(`SKIP (already has new pixel): ${file}`);
    skipped++;
    continue;
  }

  if (!content.includes(`fbq('init', '${EXISTING_PIXEL_ID}')`)) {
    console.log(`SKIP (no existing pixel found): ${file}`);
    skipped++;
    continue;
  }

  // Add second init call right after existing one
  content = content.replace(
    `fbq('init', '${EXISTING_PIXEL_ID}');`,
    `fbq('init', '${EXISTING_PIXEL_ID}');\n    fbq('init', '${NEW_PIXEL_ID}');`
  );

  // Add second noscript pixel — find the noscript with existing pixel ID and append after it
  const noscriptPattern = new RegExp(
    `(<noscript><img[^>]*${EXISTING_PIXEL_ID}[^>]*/></noscript>)`,
    'g'
  );
  if (noscriptPattern.test(content)) {
    content = content.replace(
      new RegExp(`(<noscript><img[^>]*${EXISTING_PIXEL_ID}[^>]*/></noscript>)`, 'g'),
      `$1\n    <noscript><img height="1" width="1" style="display:none"\n    src="https://www.facebook.com/tr?id=${NEW_PIXEL_ID}&ev=PageView&noscript=1"/></noscript>`
    );
  }

  fs.writeFileSync(file, content, 'utf8');
  console.log(`UPDATED: ${file}`);
  updated++;
}

console.log(`\nDone: ${updated} updated, ${skipped} skipped`);
