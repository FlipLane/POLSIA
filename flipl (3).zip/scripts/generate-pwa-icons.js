/**
 * Generate PWA icons using pure Node.js (no external dependencies)
 * Uses built-in zlib for PNG compression
 */

const zlib = require('zlib');
const fs = require('fs');
const path = require('path');

const GREEN = [0x00, 0xe6, 0x76];
const WHITE = [0xff, 0xff, 0xff];
const BLACK = [0x00, 0x00, 0x00];

// 3x5 pixel bitmaps for FL monogram
const F_BITMAP = [
  [1,1,1],
  [1,0,1],
  [1,1,0],
  [1,0,0],
  [1,1,1],
];

const L_BITMAP = [
  [1,0,0],
  [1,0,0],
  [1,0,0],
  [1,0,0],
  [1,1,1],
];

function crc32(buf) {
  let crc = 0xFFFFFFFF;
  const table = [];
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let j = 0; j < 8; j++) {
      c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    }
    table[i] = c >>> 0;
  }
  for (let i = 0; i < buf.length; i++) {
    crc = table[(crc ^ buf[i]) & 0xFF] ^ (crc >>> 8);
  }
  return (crc ^ 0xFFFFFFFF) >>> 0;
}

function makeChunk(type, data) {
  const typeBytes = Buffer.from(type, 'ascii');
  const length = Buffer.alloc(4);
  length.writeUInt32BE(data.length, 0);
  const combined = Buffer.concat([typeBytes, data]);
  const crcVal = crc32(combined);
  const crcBuf = Buffer.alloc(4);
  crcBuf.writeUInt32BE(crcVal, 0);
  return Buffer.concat([length, combined, crcBuf]);
}

function createPNG(width, height, pixelFunc) {
  // PNG signature
  const signature = Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]);

  // IHDR chunk
  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData[8] = 8;  // bit depth
  ihdrData[9] = 2;  // color type (RGB)
  ihdrData[10] = 0; // compression
  ihdrData[11] = 0; // filter
  ihdrData[12] = 0; // interlace
  const ihdr = makeChunk('IHDR', ihdrData);

  // Build raw pixel data (with filter byte per row)
  const rawData = Buffer.alloc((width * 3 + 1) * height);
  for (let y = 0; y < height; y++) {
    const rowOffset = y * (width * 3 + 1);
    rawData[rowOffset] = 0; // filter byte (none)
    for (let x = 0; x < width; x++) {
      const color = pixelFunc(x, y, width, height);
      const pixelOffset = rowOffset + 1 + x * 3;
      rawData[pixelOffset] = color[0];
      rawData[pixelOffset + 1] = color[1];
      rawData[pixelOffset + 2] = color[2];
    }
  }

  // Compress with zlib
  const compressed = zlib.deflateSync(rawData, { level: 9 });
  const idat = makeChunk('IDAT', compressed);

  // IEND chunk
  const iend = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdr, idat, iend]);
}

function createIcon(width, height) {
  const padding = Math.floor(width * 0.1);
  const usable = width - padding * 2;
  const letterWidth = Math.floor(usable * 0.4);
  const letterHeight = Math.floor(height * 0.5);
  const gap = Math.floor(usable * 0.2);
  const startX = padding + Math.floor((usable - letterWidth * 2 - gap) / 2);
  const startY = padding + Math.floor((height - letterHeight) / 2);

  return createPNG(width, height, (x, y, w, h) => {
    // Background: dark with green border
    const borderWidth = Math.max(2, Math.floor(width * 0.06));
    const isInBorder = x < borderWidth || x >= w - borderWidth || y < borderWidth || y >= h - borderWidth;
    const isInBackground = x >= borderWidth && x < w - borderWidth && y >= borderWidth && y < h - borderWidth;

    if (isInBorder) {
      return GREEN; // Brand green border
    }
    if (!isInBackground) {
      return BLACK;
    }

    // Letter "F" position
    const fLeft = startX;
    const fRight = fLeft + letterWidth - 1;
    const fTop = startY;
    const fBottom = startY + letterHeight - 1;
    const flx = x - fLeft;
    const fly = y - fTop;

    if (x >= fLeft && x <= fRight && y >= fTop && y <= fBottom) {
      if (flx < 3 && fly < 5) {
        const pixelVal = F_BITMAP[fly] ? F_BITMAP[fly][flx] : 0;
        if (pixelVal) return WHITE;
      }
      // F bar (horizontal) - row 2 from top
      if (fly >= 2 && fly < 3 && flx >= 0 && flx < 3) {
        const pixelVal = F_BITMAP[2] ? F_BITMAP[2][flx] : 0;
        if (pixelVal) return WHITE;
      }
      // F bar (horizontal) - row 4 from top
      if (fly >= 4 && fly < 5 && flx >= 0 && flx < 3) {
        const pixelVal = F_BITMAP[4] ? F_BITMAP[4][flx] : 0;
        if (pixelVal) return WHITE;
      }
    }

    // Letter "L" position
    const lLeft = startX + letterWidth + gap;
    const lRight = lLeft + letterWidth - 1;
    const lTop = startY;
    const lBottom = startY + letterHeight - 1;
    const llx = x - lLeft;
    const lly = y - lTop;

    if (x >= lLeft && x <= lRight && y >= lTop && y <= lBottom) {
      if (llx < 3 && lly < 5) {
        const pixelVal = L_BITMAP[lly] ? L_BITMAP[lly][llx] : 0;
        if (pixelVal) return WHITE;
      }
    }

    return GREEN; // Green background
  });
}

// Generate icons
const iconsDir = path.join(__dirname, '..', 'public', 'icons');

const icon192 = createIcon(192, 192);
fs.writeFileSync(path.join(iconsDir, 'icon-192x192.png'), icon192);
console.log('Created icon-192x192.png');

const icon512 = createIcon(512, 512);
fs.writeFileSync(path.join(iconsDir, 'icon-512x512.png'), icon512);
console.log('Created icon-512x512.png');

console.log('Done! Icons generated successfully.');