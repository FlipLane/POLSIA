# FlipLane

Dealer group membership platform — buy and sell cars nationwide under a licensed dealership.

## Development

```bash
npm install
npm run migrate
npm run dev
```

## Admin Dashboard

Access the analytics dashboard at:
```
https://flipl.polsia.app/admin?key=<ADMIN_SECRET>
```

**Features:**
- Real-time member metrics (total signups, active, pending, churned)
- Revenue tracking (total revenue, paid members, avg per member)
- Conversion funnel (visits → applications → payments → active members)
- DocuSign agreement status (sent, signed, pending, completion rate)
- Auto-refresh every 30 seconds

**Daily Snapshots:**
```bash
curl -X POST https://flipl.polsia.app/api/admin/snapshot?key=<ADMIN_SECRET>
```

Saves daily metrics to `reports` table for trend analysis.

## Environment Variables

- `DATABASE_URL` — PostgreSQL connection string (required)
- `PORT` — Server port (default: 3000)
- `ADMIN_SECRET` — Secret key for admin endpoints (default: fliplaneadmin2024)

## Endpoints

### Public Pages
- `GET /` - Landing page
- `GET /apply` - Membership application form
- `GET /dashboard` - Member dashboard (redirects to /byrddawgsos)
- `GET /payment-success` - Payment confirmation page
- `GET /byrddawgsos` - ByrddawgsOS dealer dashboard (members only)

### API Endpoints
- `POST /api/signup` - Submit membership application
- `GET /api/member-status` - Check member status by email
- `POST /api/stripe-webhook` - Stripe payment webhook
- `POST /api/generate-login-token` - Generate secure login token
- `POST /api/validate-login-token` - Validate and consume login token
- `POST /api/docusign-webhook` - DocuSign webhook for agreement status
- `GET /api/member/agreement-status` - Check DocuSign agreement status

### Admin Endpoints (require ?key=<ADMIN_SECRET>)
- `GET /admin` - Admin analytics dashboard UI
- `GET /api/admin/metrics` - Fetch all analytics metrics (JSON)
- `POST /api/admin/snapshot` - Save daily metrics snapshot to reports table
- `GET /api/admin/members` - List all members

## Deployment

This app is configured for Render deployment via `render.yaml`.
